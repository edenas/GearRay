#include "hud_weapon.h"
#include "weapon_texture.h"
#include "weapon_shoot_texture.h"
#include "shotgun_held.h"
#include "shotgun_fire.h"
#include "../../game/weapons.h"
#include "../../game/player.h"

#define HUD_WEAPON_SHOOT_FRAME_COUNT 2
/* Touch one additional movement step before the previous contact boundary.
 * Independent of the renderer's world canvas or projected size. */
#define SHOTGUN_PICKUP_TOUCH_EXTENT (128U + 2U * PLAYER_MOVE_SPEED)

static HudWeaponState weapon_state;
static HudWeaponState rendered_weapon_state;
static unsigned char animation_timer;

void game_gear_hud_weapon_initialize(void)
{
    weapon_state = IDLE;
    rendered_weapon_state = IDLE;
    animation_timer = 0;
}

void game_gear_hud_weapon_update(unsigned char shoot_requested)
{
    /* Reuse this existing gameplay dispatch; never collect during pause. */
    if (SHOTGUN_PICKUP_PRESENT
        && (unsigned int)(player_get_position_x()
            - ((unsigned int)shotgun_cell_x << 8)
            + (SHOTGUN_PICKUP_TOUCH_EXTENT - 128U))
            <= 2U * SHOTGUN_PICKUP_TOUCH_EXTENT
        && (unsigned int)(player_get_position_y()
            - ((unsigned int)shotgun_cell_y << 8)
            + (SHOTGUN_PICKUP_TOUCH_EXTENT - 128U))
            <= 2U * SHOTGUN_PICKUP_TOUCH_EXTENT)
    {
        /* First ownership equips the reward; an owned pickup never switches.
         * Drop the old pose, then accept this frame's fresh fire edge below. */
        owned_weapons |= WEAPON_OWNED_SHOTGUN;
        selected_weapon = WEAPON_SHOTGUN;
        weapon_state = IDLE;
        animation_timer = 0;
    }
    if (shoot_requested)
    {
        weapon_state = SHOOT;
        animation_timer = HUD_WEAPON_SHOOT_FRAME_COUNT;
    }
    else if (weapon_state == SHOOT)
    {
        --animation_timer;
        if (animation_timer == 0)
            weapon_state = IDLE;
    }
}

unsigned char game_gear_hud_weapon_changed(void)
{
    return (weapon_state | (selected_weapon << 1)) != rendered_weapon_state;
}

void game_gear_hud_weapon_render_complete(void)
{
    rendered_weapon_state = weapon_state | (selected_weapon << 1);
}

/* Fixed 20x16 source, exact 2x blocks, ten packed bytes per source row.
 * This helper stays in the overlay's Bank 1; the pistol loop is separate. */
static void overlay_shotgun_tile(
    unsigned char *destination,
    unsigned char tile_column,
    unsigned char tile_row)
{
    signed int tile_left = tile_column * 8;
    signed int tile_top = tile_row * 8;
    signed int screen_x;
    signed int screen_y;
    unsigned char texture_x;
    unsigned char texture_y;
    unsigned char row_offset;
    unsigned char pixel_x;
    unsigned char pixel_y;
    unsigned char palette_index;
    unsigned char plane;
    unsigned char mask;
    const unsigned char *weapon_pixels = weapon_state == SHOOT
        ? shotgun_fire_pixels : shotgun_held_pixels;

    for (pixel_y = 0; pixel_y < 8; ++pixel_y)
    {
        screen_y = tile_top + pixel_y;
        if (screen_y < HUD_SHOTGUN_TOP || screen_y >= HUD_WEAPON_BOTTOM)
            continue;
        texture_y = (unsigned char)(screen_y - HUD_SHOTGUN_TOP) >> 1;
        row_offset = (texture_y << 3) + (texture_y << 1);
        for (pixel_x = 0; pixel_x < 8; ++pixel_x)
        {
            screen_x = tile_left + pixel_x;
            if (screen_x < HUD_SHOTGUN_LEFT || screen_x >= HUD_WEAPON_RIGHT)
                continue;
            texture_x = (unsigned char)(screen_x - HUD_SHOTGUN_LEFT) >> 1;
            palette_index = weapon_pixels[row_offset + (texture_x >> 1)];
            if (texture_x & 1)
                palette_index &= 15;
            else
                palette_index >>= 4;
            if (palette_index == shotgun_held_pixels_TRANSPARENT_INDEX)
                continue;
            mask = (unsigned char)(0x80U >> pixel_x);
            if (palette_index & 1U)
                destination[pixel_y * 4 + 0] |= mask;
            else
                destination[pixel_y * 4 + 0] &= (unsigned char)~mask;
            if (palette_index & 2U)
                destination[pixel_y * 4 + 1] |= mask;
            else
                destination[pixel_y * 4 + 1] &= (unsigned char)~mask;
            if (palette_index & 4U)
                destination[pixel_y * 4 + 2] |= mask;
            else
                destination[pixel_y * 4 + 2] &= (unsigned char)~mask;
            if (palette_index & 8U)
                destination[pixel_y * 4 + 3] |= mask;
            else
                destination[pixel_y * 4 + 3] &= (unsigned char)~mask;
        }
    }
}

void game_gear_overlay_hud_weapon_tile(
    unsigned char *destination,
    unsigned char tile_column,
    unsigned char tile_row)
{
    signed int tile_left = tile_column * 8;
    signed int tile_top = tile_row * 8;
    signed int screen_x;
    unsigned char left = HUD_WEAPON_LEFT;
    unsigned char top = HUD_WEAPON_TOP;
    unsigned char size = HUD_WEAPON_WIDTH;
    signed int screen_y;
    unsigned char texture_x;
    unsigned char texture_y;
    unsigned char texture_offset;
    unsigned char pixel_x;
    unsigned char pixel_y;
    unsigned char palette_index;
    unsigned char plane;
    unsigned char mask;
    const unsigned char *weapon_pixels = weapon_state == SHOOT
        ? hud_weapon_shoot_pixels
        : hud_weapon_pixels;
    if (selected_weapon == WEAPON_SHOTGUN)
    {
        overlay_shotgun_tile(destination, tile_column, tile_row);
        return;
    }

    for (pixel_y = 0; pixel_y < 8; ++pixel_y)
    {
        screen_y = tile_top + pixel_y;
        if (screen_y < top || screen_y >= top + size)
            continue;
        texture_y =
            (unsigned char)(screen_y - top) >> 1;

        for (pixel_x = 0; pixel_x < 8; ++pixel_x)
        {
            screen_x = tile_left + pixel_x;
            if (screen_x < left || screen_x >= left + size)
                continue;
            texture_x =
                (unsigned char)(screen_x - left) >> 1;
            texture_offset =
                (texture_y << 3) + (texture_x >> 1);
            palette_index = weapon_pixels[texture_offset];
            if (texture_x & 1)
                palette_index &= 15;
            else
                palette_index >>= 4;
            if (palette_index == hud_weapon_pixels_TRANSPARENT_INDEX)
                continue;

            mask = (unsigned char)(0x80U >> pixel_x);
            if (palette_index & 1U)
                destination[pixel_y * 4 + 0] |= mask;
            else
                destination[pixel_y * 4 + 0] &= (unsigned char)~mask;
            if (palette_index & 2U)
                destination[pixel_y * 4 + 1] |= mask;
            else
                destination[pixel_y * 4 + 1] &= (unsigned char)~mask;
            if (palette_index & 4U)
                destination[pixel_y * 4 + 2] |= mask;
            else
                destination[pixel_y * 4 + 2] &= (unsigned char)~mask;
            if (palette_index & 8U)
                destination[pixel_y * 4 + 3] |= mask;
            else
                destination[pixel_y * 4 + 3] &= (unsigned char)~mask;
        }
    }
}
