;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (MINGW64)
;--------------------------------------------------------
	.module shotgun_fire
	
	.optsdcc -mz80 sdcccall(1)
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _shotgun_fire_pixels
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute ram data
;--------------------------------------------------------
	.area _DABS (ABS)
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
	.area _CODE
	.area _BANK1
	.area _BANK1
_shotgun_fire_pixels:
	.db #0x1e	; 30
	.db #0xee	; 238
	.db #0xe1	; 225
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xe5	; 229
	.db #0x1e	; 30
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0x1c	; 28
	.db #0x01	; 1
	.db #0x5e	; 94
	.db #0x5e	; 94
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0x50	; 80	'P'
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0x10	; 16
	.db #0x66	; 102	'f'
	.db #0xc0	; 192
	.db #0x0f	; 15
	.db #0xfe	; 254
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xe5	; 229
	.db #0x00	; 0
	.db #0x63	; 99	'c'
	.db #0x30	; 48	'0'
	.db #0x0e	; 14
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0x0d	; 13
	.db #0x06	; 6
	.db #0x33	; 51	'3'
	.db #0x30	; 48	'0'
	.db #0x0e	; 14
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xe1	; 225
	.db #0xe0	; 224
	.db #0xd0	; 208
	.db #0x62	; 98	'b'
	.db #0x3c	; 60
	.db #0x30	; 48	'0'
	.db #0x0e	; 14
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xef	; 239
	.db #0x0d	; 13
	.db #0x0d	; 13
	.db #0x23	; 35
	.db #0x3c	; 60
	.db #0xc0	; 192
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xe1	; 225
	.db #0x10	; 16
	.db #0xd0	; 208
	.db #0xd2	; 210
	.db #0x23	; 35
	.db #0x22	; 34
	.db #0x00	; 0
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0x5f	; 95
	.db #0xf1	; 241
	.db #0x0d	; 13
	.db #0x00	; 0
	.db #0x02	; 2
	.db #0x23	; 35
	.db #0x33	; 51	'3'
	.db #0x0e	; 14
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xef	; 239
	.db #0xff	; 255
	.db #0x10	; 16
	.db #0xdd	; 221
	.db #0x00	; 0
	.db #0x03	; 3
	.db #0x03	; 3
	.db #0x0e	; 14
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xff	; 255
	.db #0x1e	; 30
	.db #0xee	; 238
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x02	; 2
	.db #0x02	; 2
	.db #0x0e	; 14
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xff	; 255
	.db #0x1e	; 30
	.db #0xe0	; 224
	.db #0xf0	; 240
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0xee	; 238
	.db #0xef	; 239
	.db #0xf1	; 241
	.db #0x1e	; 30
	.db #0xef	; 239
	.db #0x00	; 0
	.db #0xd0	; 208
	.db #0x0d	; 13
	.db #0xdd	; 221
	.db #0x20	; 32
	.db #0xfe	; 254
	.db #0xff	; 255
	.db #0xf1	; 241
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0x10	; 16
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xdd	; 221
	.db #0xd2	; 210
	.db #0x00	; 0
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
