;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (MINGW64)
;--------------------------------------------------------
	.module hud_weapon
	
	.optsdcc -mz80 sdcccall(1)
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _player_get_position_y
	.globl _player_get_position_x
	.globl _game_gear_hud_weapon_initialize
	.globl _game_gear_hud_weapon_update
	.globl _game_gear_hud_weapon_changed
	.globl _game_gear_hud_weapon_render_complete
	.globl _game_gear_overlay_hud_weapon_tile
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
_weapon_state:
	.ds 1
_rendered_weapon_state:
	.ds 1
_animation_timer:
	.ds 1
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute ram data
;--------------------------------------------------------
	.area _DABS (ABS)
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _BANK1
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:18: void game_gear_hud_weapon_initialize(void)
;	---------------------------------
; Function game_gear_hud_weapon_initialize
; ---------------------------------
_game_gear_hud_weapon_initialize::
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:20: weapon_state = IDLE;
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:21: rendered_weapon_state = IDLE;
	xor	a, a
	ld	(#_weapon_state), a
	ld	(#_rendered_weapon_state), a
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:22: animation_timer = 0;
	xor	a, a
	ld	(#_animation_timer), a
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:23: }
	ret
	.area _BANK1
	.area _BANK1
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:25: void game_gear_hud_weapon_update(unsigned char shoot_requested)
;	---------------------------------
; Function game_gear_hud_weapon_update
; ---------------------------------
_game_gear_hud_weapon_update::
	ld	c, a
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:28: if (SHOTGUN_PICKUP_PRESENT
	ld	a, (_owned_weapons)
	bit	1, a
	jr	nz, 00102$
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:29: && (unsigned int)(player_get_position_x()
	push	bc
	call	_player_get_position_x
	ex	de, hl
	pop	bc
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:30: - ((unsigned int)shotgun_cell_x << 8)
	ld	a, (_shotgun_cell_x+0)
	ld	d, a
	ld	e, #0x00
	cp	a, a
	sbc	hl, de
	ld	de, #0x0094
	add	hl, de
	ld	a, #0x28
	cp	a, l
	ld	a, #0x02
	sbc	a, h
	jr	c, 00102$
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:33: && (unsigned int)(player_get_position_y()
	push	bc
	call	_player_get_position_y
	ex	de, hl
	pop	bc
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:34: - ((unsigned int)shotgun_cell_y << 8)
	ld	a, (_shotgun_cell_y+0)
	ld	d, a
	ld	e, #0x00
	cp	a, a
	sbc	hl, de
	ld	de, #0x0094
	add	hl, de
	ld	a, #0x28
	cp	a, l
	ld	a, #0x02
	sbc	a, h
	jr	c, 00102$
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:40: owned_weapons |= WEAPON_OWNED_SHOTGUN;
	ld	a, (_owned_weapons+0)
	or	a, #0x02
	ld	(_owned_weapons+0), a
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:41: selected_weapon = WEAPON_SHOTGUN;
	ld	hl, #_selected_weapon
	ld	(hl), #0x01
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:42: weapon_state = IDLE;
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:43: animation_timer = 0;
	xor	a, a
	ld	(#_weapon_state), a
	ld	(#_animation_timer), a
00102$:
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:45: if (shoot_requested)
	ld	a, c
	or	a, a
	jr	z, 00110$
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:47: weapon_state = SHOOT;
	ld	hl, #_weapon_state
	ld	(hl), #0x01
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:48: animation_timer = HUD_WEAPON_SHOOT_FRAME_COUNT;
	ld	hl, #_animation_timer
	ld	(hl), #0x02
	ret
00110$:
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:50: else if (weapon_state == SHOOT)
	ld	a, (_weapon_state)
	dec	a
	ret	nz
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:52: --animation_timer;
	ld	hl, #_animation_timer
	dec	(hl)
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:53: if (animation_timer == 0)
	ld	a, (_animation_timer+0)
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:54: weapon_state = IDLE;
	or	a,a
	ret	nz
	ld	(#_weapon_state), a
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:56: }
	ret
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:58: unsigned char game_gear_hud_weapon_changed(void)
;	---------------------------------
; Function game_gear_hud_weapon_changed
; ---------------------------------
_game_gear_hud_weapon_changed::
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:60: return (weapon_state | (selected_weapon << 1)) != rendered_weapon_state;
	ld	a, (_selected_weapon)
	ld	h, #0x00
	ld	l, a
	add	hl, hl
	ld	a, (_weapon_state+0)
	or	a, l
	ld	l, a
	ld	a, (_rendered_weapon_state+0)
	ld	c, a
	xor	a, a
	ld	b, a
	sbc	hl, bc
	ld	a, #0x01
	jr	z, 00104$
	xor	a, a
00104$:
	xor	a, #0x01
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:61: }
	ret
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:63: void game_gear_hud_weapon_render_complete(void)
;	---------------------------------
; Function game_gear_hud_weapon_render_complete
; ---------------------------------
_game_gear_hud_weapon_render_complete::
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:65: rendered_weapon_state = weapon_state | (selected_weapon << 1);
	ld	a, (_selected_weapon+0)
	add	a, a
	ld	c, a
	ld	a, (_weapon_state+0)
	or	a, c
	ld	(#_rendered_weapon_state), a
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:66: }
	ret
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:70: static void overlay_shotgun_tile(
;	---------------------------------
; Function overlay_shotgun_tile
; ---------------------------------
_overlay_shotgun_tile:
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	iy, #-22
	add	iy, sp
	ld	sp, iy
	ld	-5 (ix), l
	ld	-4 (ix), h
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:75: signed int tile_left = tile_column * 8;
	ld	a, 4 (ix)
	ld	-2 (ix), a
	ld	-1 (ix), #0x00
	ld	a, -2 (ix)
	ld	-22 (ix), a
	ld	-21 (ix), #0x00
	ld	b, #0x03
00219$:
	sla	-22 (ix)
	rl	-21 (ix)
	djnz	00219$
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:76: signed int tile_top = tile_row * 8;
	ld	a, 5 (ix)
	ld	-2 (ix), a
	ld	-1 (ix), #0x00
	ld	a, -2 (ix)
	ld	-20 (ix), a
	ld	-19 (ix), #0x00
	ld	b, #0x03
00220$:
	sla	-20 (ix)
	rl	-19 (ix)
	djnz	00220$
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:87: const unsigned char *weapon_pixels = weapon_state == SHOOT
	ld	a, (_weapon_state)
	dec	a
	jr	nz, 00126$
	ld	bc, #_shotgun_fire_pixels+0
	jr	00127$
00126$:
	ld	bc, #_shotgun_held_pixels+0
00127$:
	ld	-18 (ix), c
	ld	-17 (ix), b
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:90: for (pixel_y = 0; pixel_y < 8; ++pixel_y)
	ld	-3 (ix), #0x00
00123$:
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:92: screen_y = tile_top + pixel_y;
	ld	a, -3 (ix)
	ld	-16 (ix), a
	ld	-15 (ix), #0x00
	pop	hl
	pop	de
	push	de
	push	hl
	ld	l, -16 (ix)
	ld	h, #0x00
	add	hl, de
	ld	-2 (ix), l
	ld	-1 (ix), h
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:93: if (screen_y < HUD_SHOTGUN_TOP || screen_y >= HUD_WEAPON_BOTTOM)
	ld	a, -2 (ix)
	sub	a, #0x20
	ld	a, -1 (ix)
	sbc	a, #0x00
	jp	c, 00118$
	ld	a, -2 (ix)
	sub	a, #0x40
	ld	a, -1 (ix)
	sbc	a, #0x00
	jp	nc, 00118$
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:95: texture_y = (unsigned char)(screen_y - HUD_SHOTGUN_TOP) >> 1;
	ld	a, -2 (ix)
	ld	-1 (ix), a
	add	a, #0xe0
	ld	-1 (ix), a
	srl	-1 (ix)
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:96: row_offset = (texture_y << 3) + (texture_y << 1);
	ld	a, -1 (ix)
	add	a, a
	add	a, a
	add	a, a
	ld	-2 (ix), a
	sla	-1 (ix)
	ld	a, -1 (ix)
	add	a, -2 (ix)
	ld	-14 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:97: for (pixel_x = 0; pixel_x < 8; ++pixel_x)
	ld	-2 (ix), #0x00
00122$:
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:99: screen_x = tile_left + pixel_x;
	ld	a, -2 (ix)
	ld	-9 (ix), a
	ld	-8 (ix), #0x00
	pop	de
	push	de
	ld	l, -9 (ix)
	ld	h, #0x00
	add	hl, de
	ld	-7 (ix), l
	ld	-6 (ix), h
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:100: if (screen_x < HUD_SHOTGUN_LEFT || screen_x >= HUD_WEAPON_RIGHT)
	ld	a, -7 (ix)
	sub	a, #0x40
	ld	a, -6 (ix)
	sbc	a, #0x00
	jp	c, 00116$
	ld	a, -7 (ix)
	sub	a, #0x68
	ld	a, -6 (ix)
	sbc	a, #0x00
	jp	nc, 00116$
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:102: texture_x = (unsigned char)(screen_x - HUD_SHOTGUN_LEFT) >> 1;
	ld	a, -7 (ix)
	add	a, #0xc0
	ld	c, a
	srl	c
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:103: palette_index = weapon_pixels[row_offset + (texture_x >> 1)];
	ld	a, -14 (ix)
	ld	e, c
	srl	e
	add	a, e
	add	a, -18 (ix)
	ld	e, a
	ld	a, #0x00
	adc	a, -17 (ix)
	ld	d, a
	ld	a, (de)
	ld	-1 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:104: if (texture_x & 1)
	bit	0, c
	jr	z, 00108$
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:105: palette_index &= 15;
	ld	a, -1 (ix)
	and	a, #0x0f
	ld	-13 (ix), a
	jr	00109$
00108$:
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:107: palette_index >>= 4;
	ld	a, -1 (ix)
	rlca
	rlca
	rlca
	rlca
	and	a, #0x0f
	ld	-13 (ix), a
00109$:
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:108: if (palette_index == shotgun_held_pixels_TRANSPARENT_INDEX)
	ld	a, -13 (ix)
	sub	a, #0x0e
	jp	z, 00116$
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:110: mask = (unsigned char)(0x80U >> pixel_x);
	ld	b, -2 (ix)
	ld	de, #0x0080
	inc	b
	jr	00226$
00225$:
	srl	d
	rr	e
00226$:
	djnz	00225$
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:111: for (plane = 0; plane < 4; ++plane)
	ld	-12 (ix), e
	ld	a, e
	cpl
	ld	-11 (ix), a
	ld	-1 (ix), #0x00
00120$:
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:113: if (palette_index & (1U << plane))
	ld	b, -1 (ix)
	ld	iy, #0x0001
	inc	b
	jr	00228$
00227$:
	add	iy, iy
00228$:
	djnz	00227$
	ld	c, -13 (ix)
	ld	b, #0x00
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:114: destination[pixel_y * 4 + plane] |= mask;
	ld	e, -1 (ix)
	ld	d, #0x00
	ld	l, -16 (ix)
	ld	h, #0x00
	add	hl, hl
	add	hl, hl
	add	hl, de
	ld	a, l
	add	a, -5 (ix)
	ld	-10 (ix), a
	ld	a, h
	adc	a, -4 (ix)
	ld	-9 (ix), a
	ld	l, -10 (ix)
	ld	h, -9 (ix)
	ld	a, (hl)
	ld	-8 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:113: if (palette_index & (1U << plane))
	push	iy
	ld	a, -24 (ix)
	pop	iy
	and	a, c
	ld	-7 (ix), a
	xor	a, a
	ld	-6 (ix), a
	or	a, -7 (ix)
	jr	z, 00113$
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:114: destination[pixel_y * 4 + plane] |= mask;
	ld	a, -8 (ix)
	or	a, -12 (ix)
	ld	l, -10 (ix)
	ld	h, -9 (ix)
	ld	(hl), a
	jr	00121$
00113$:
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:116: destination[pixel_y * 4 + plane] &= (unsigned char)~mask;
	ld	a, -8 (ix)
	and	a, -11 (ix)
	ld	l, -10 (ix)
	ld	h, -9 (ix)
	ld	(hl), a
00121$:
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:111: for (plane = 0; plane < 4; ++plane)
	inc	-1 (ix)
	ld	a, -1 (ix)
	sub	a, #0x04
	jr	c, 00120$
00116$:
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:97: for (pixel_x = 0; pixel_x < 8; ++pixel_x)
	inc	-2 (ix)
	ld	a, -2 (ix)
	sub	a, #0x08
	jp	c, 00122$
00118$:
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:90: for (pixel_y = 0; pixel_y < 8; ++pixel_y)
	inc	-3 (ix)
	ld	a, -3 (ix)
	sub	a, #0x08
	jp	c, 00123$
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:120: }
	ld	sp, ix
	pop	ix
	pop	hl
	pop	af
	jp	(hl)
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:122: void game_gear_overlay_hud_weapon_tile(
;	---------------------------------
; Function game_gear_overlay_hud_weapon_tile
; ---------------------------------
_game_gear_overlay_hud_weapon_tile::
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	iy, #-22
	add	iy, sp
	ld	sp, iy
	ld	-5 (ix), l
	ld	-4 (ix), h
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:127: signed int tile_left = tile_column * 8;
	ld	a, 4 (ix)
	ld	-2 (ix), a
	ld	-1 (ix), #0x00
	ld	a, -2 (ix)
	ld	-22 (ix), a
	ld	-21 (ix), #0x00
	ld	b, #0x03
00229$:
	sla	-22 (ix)
	rl	-21 (ix)
	djnz	00229$
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:128: signed int tile_top = tile_row * 8;
	ld	a, 5 (ix)
	ld	-2 (ix), a
	ld	-1 (ix), #0x00
	ld	a, -2 (ix)
	ld	-20 (ix), a
	ld	-19 (ix), #0x00
	ld	b, #0x03
00230$:
	sla	-20 (ix)
	rl	-19 (ix)
	djnz	00230$
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:142: const unsigned char *weapon_pixels = weapon_state == SHOOT
	ld	a, (_weapon_state)
	dec	a
	jr	nz, 00128$
	ld	bc, #_hud_weapon_shoot_pixels+0
	jr	00129$
00128$:
	ld	bc, #_hud_weapon_pixels+0
00129$:
	ld	-18 (ix), c
	ld	-17 (ix), b
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:145: if (selected_weapon == WEAPON_SHOTGUN)
	ld	a, (_selected_weapon)
	dec	a
	jr	nz, 00153$
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:147: overlay_shotgun_tile(destination, tile_column, tile_row);
	ld	h, 5 (ix)
	ld	l, 4 (ix)
	push	hl
	ld	l, -5 (ix)
	ld	h, -4 (ix)
	call	_overlay_shotgun_tile
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:148: return;
	jp	00126$
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:151: for (pixel_y = 0; pixel_y < 8; ++pixel_y)
00153$:
	ld	-3 (ix), #0x00
00125$:
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:153: screen_y = tile_top + pixel_y;
	ld	a, -3 (ix)
	ld	-16 (ix), a
	ld	-15 (ix), #0x00
	pop	hl
	pop	de
	push	de
	push	hl
	ld	l, -16 (ix)
	ld	h, #0x00
	add	hl, de
	ld	-2 (ix), l
	ld	-1 (ix), h
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:154: if (screen_y < top || screen_y >= top + size)
	ld	a, -2 (ix)
	sub	a, #0x28
	ld	a, -1 (ix)
	sbc	a, #0x00
	jp	c, 00120$
	ld	a, -2 (ix)
	sub	a, #0x40
	ld	a, -1 (ix)
	sbc	a, #0x00
	jp	nc, 00120$
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:157: (unsigned char)(screen_y - top) >> 1;
	ld	a, -2 (ix)
	ld	-1 (ix), a
	add	a, #0xd8
	ld	-1 (ix), a
	srl	a
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:159: for (pixel_x = 0; pixel_x < 8; ++pixel_x)
	add	a, a
	add	a, a
	add	a, a
	ld	-14 (ix), a
	ld	-2 (ix), #0x00
00124$:
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:161: screen_x = tile_left + pixel_x;
	ld	a, -2 (ix)
	ld	-9 (ix), a
	ld	-8 (ix), #0x00
	pop	de
	push	de
	ld	l, -9 (ix)
	ld	h, #0x00
	add	hl, de
	ld	-7 (ix), l
	ld	-6 (ix), h
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:162: if (screen_x < left || screen_x >= left + size)
	ld	a, -7 (ix)
	sub	a, #0x50
	ld	a, -6 (ix)
	sbc	a, #0x00
	jp	c, 00118$
	ld	a, -7 (ix)
	sub	a, #0x68
	ld	a, -6 (ix)
	sbc	a, #0x00
	jp	nc, 00118$
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:165: (unsigned char)(screen_x - left) >> 1;
	ld	a, -7 (ix)
	add	a, #0xb0
	ld	c, a
	srl	c
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:167: (texture_y << 3) + (texture_x >> 1);
	ld	a, c
	srl	a
	add	a, -14 (ix)
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:168: palette_index = weapon_pixels[texture_offset];
	add	a, -18 (ix)
	ld	e, a
	ld	a, #0x00
	adc	a, -17 (ix)
	ld	d, a
	ld	a, (de)
	ld	-1 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:169: if (texture_x & 1)
	bit	0, c
	jr	z, 00110$
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:170: palette_index &= 15;
	ld	a, -1 (ix)
	and	a, #0x0f
	ld	-13 (ix), a
	jr	00111$
00110$:
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:172: palette_index >>= 4;
	ld	a, -1 (ix)
	rlca
	rlca
	rlca
	rlca
	and	a, #0x0f
	ld	-13 (ix), a
00111$:
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:173: if (palette_index == hud_weapon_pixels_TRANSPARENT_INDEX)
	ld	a, -13 (ix)
	sub	a, #0x0e
	jp	z, 00118$
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:176: mask = (unsigned char)(0x80U >> pixel_x);
	ld	b, -2 (ix)
	ld	de, #0x0080
	inc	b
	jr	00238$
00237$:
	srl	d
	rr	e
00238$:
	djnz	00237$
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:177: for (plane = 0; plane < 4; ++plane)
	ld	-12 (ix), e
	ld	a, e
	cpl
	ld	-11 (ix), a
	ld	-1 (ix), #0x00
00122$:
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:179: if (palette_index & (1U << plane))
	ld	b, -1 (ix)
	ld	iy, #0x0001
	inc	b
	jr	00240$
00239$:
	add	iy, iy
00240$:
	djnz	00239$
	ld	c, -13 (ix)
	ld	b, #0x00
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:180: destination[pixel_y * 4 + plane] |= mask;
	ld	e, -1 (ix)
	ld	d, #0x00
	ld	l, -16 (ix)
	ld	h, #0x00
	add	hl, hl
	add	hl, hl
	add	hl, de
	ld	a, l
	add	a, -5 (ix)
	ld	-10 (ix), a
	ld	a, h
	adc	a, -4 (ix)
	ld	-9 (ix), a
	ld	l, -10 (ix)
	ld	h, -9 (ix)
	ld	a, (hl)
	ld	-8 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:179: if (palette_index & (1U << plane))
	push	iy
	ld	a, -24 (ix)
	pop	iy
	and	a, c
	ld	-7 (ix), a
	xor	a, a
	ld	-6 (ix), a
	or	a, -7 (ix)
	jr	z, 00115$
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:180: destination[pixel_y * 4 + plane] |= mask;
	ld	a, -8 (ix)
	or	a, -12 (ix)
	ld	l, -10 (ix)
	ld	h, -9 (ix)
	ld	(hl), a
	jr	00123$
00115$:
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:183: (unsigned char)~mask;
	ld	a, -8 (ix)
	and	a, -11 (ix)
	ld	l, -10 (ix)
	ld	h, -9 (ix)
	ld	(hl), a
00123$:
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:177: for (plane = 0; plane < 4; ++plane)
	inc	-1 (ix)
	ld	a, -1 (ix)
	sub	a, #0x04
	jr	c, 00122$
00118$:
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:159: for (pixel_x = 0; pixel_x < 8; ++pixel_x)
	inc	-2 (ix)
	ld	a, -2 (ix)
	sub	a, #0x08
	jp	c, 00124$
00120$:
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:151: for (pixel_y = 0; pixel_y < 8; ++pixel_y)
	inc	-3 (ix)
	ld	a, -3 (ix)
	sub	a, #0x08
	jp	c, 00125$
00126$:
;D:/mano_projektai/GearRay/platform/game_gear/hud_weapon.c:187: }
	ld	sp, ix
	pop	ix
	pop	hl
	pop	af
	jp	(hl)
	.area _BANK1
	.area _BANK1
	.area _INITIALIZER
	.area _CABS (ABS)
