;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (MINGW64)
;--------------------------------------------------------
	.module weapon_texture
	
	.optsdcc -mz80 sdcccall(1)
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _hud_weapon_pixels
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute ram data
;--------------------------------------------------------
	.area _DABS (ABS)
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
	.area _CODE
	.area _BANK1
	.area _BANK1
_hud_weapon_pixels:
	.db #0xe0	; 224
	.db #0x0e	; 14
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0x02	; 2
	.db #0x30	; 48	'0'
	.db #0x0e	; 14
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0x00	; 0
	.db #0x22	; 34
	.db #0x30	; 48	'0'
	.db #0x0e	; 14
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0x0d	; 13
	.db #0x02	; 2
	.db #0x22	; 34
	.db #0xc0	; 192
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xe0	; 224
	.db #0xd0	; 208
	.db #0x23	; 35
	.db #0x23	; 35
	.db #0x0e	; 14
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0x0d	; 13
	.db #0x03	; 3
	.db #0x23	; 35
	.db #0x01	; 1
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xe0	; 224
	.db #0xd0	; 208
	.db #0x00	; 0
	.db #0x0c	; 12
	.db #0x1e	; 30
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xe1	; 225
	.db #0x0d	; 13
	.db #0x23	; 35
	.db #0x0b	; 11
	.db #0xc1	; 193
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0x1b	; 27
	.db #0xb0	; 176
	.db #0x00	; 0
	.db #0xbb	; 187
	.db #0xf1	; 241
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xe1	; 225
	.db #0x1f	; 31
	.db #0xbb	; 187
	.db #0xbb	; 187
	.db #0xbb	; 187
	.db #0xf1	; 241
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xe1	; 225
	.db #0x11	; 17
	.db #0xff	; 255
	.db #0xfb	; 251
	.db #0xbb	; 187
	.db #0xc1	; 193
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0xee	; 238
	.db #0x1f	; 31
	.db #0x11	; 17
	.db #0xff	; 255
	.db #0xbb	; 187
	.db #0xc1	; 193
	.db #0xee	; 238
	.db #0xee	; 238
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
