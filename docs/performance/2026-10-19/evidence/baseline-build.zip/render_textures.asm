;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (MINGW64)
;--------------------------------------------------------
	.module render_textures
	
	.optsdcc -mz80 sdcccall(1)
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _game_gear_wall_texture_sampler_initialize
	.globl _game_gear_wall_texture_palette_sample_next
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute ram data
;--------------------------------------------------------
	.area _DABS (ABS)
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:11: void game_gear_wall_texture_sampler_initialize(
;	---------------------------------
; Function game_gear_wall_texture_sampler_initialize
; ---------------------------------
_game_gear_wall_texture_sampler_initialize::
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	iy, #-10
	add	iy, sp
	ld	sp, iy
	ld	-2 (ix), l
	ld	-1 (ix), h
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:20: unsigned int first_wall_pixel = 0;
	ld	bc, #0x0000
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:21: unsigned char sampler_height_index = projected_wall_height
	ld	a, 7 (ix)
	add	a, #0xef
	ld	e, a
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:24: sampler->texture_id = texture_id - 1;
	ld	a, -2 (ix)
	add	a, #0x0d
	ld	l, a
	ld	a, -1 (ix)
	adc	a, #0x00
	ld	h, a
	ld	d, 4 (ix)
	dec	d
	ld	(hl), d
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:26: if (first_screen_y > wall_top)
	ld	l, 10 (ix)
	ld	d, #0x00
	ld	a, 8 (ix)
	sub	a, l
	ld	a, 9 (ix)
	sbc	a, d
	jp	po, 00162$
	xor	a, #0x80
00162$:
	jp	p, 00102$
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:27: first_wall_pixel = first_screen_y - wall_top;
	ld	a, l
	sub	a, 8 (ix)
	ld	c, a
	sbc	a, a
	sub	a, 9 (ix)
	ld	b, a
00102$:
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:36: sampler->texture_step = wall_texture_steps[sampler_height_index];
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	inc	hl
	inc	hl
	ex	(sp), hl
	ld	l, e
	ld	h, #0x00
	add	hl, hl
	ld	iy, #_wall_texture_steps
	push	bc
	ld	c, l
	ld	b, h
	add	iy, bc
	pop	bc
	ld	a, 0 (iy)
	ld	-4 (ix), a
	ld	a, 1 (iy)
	ld	-3 (ix), a
	pop	hl
	push	hl
	ld	a, -4 (ix)
	ld	(hl), a
	inc	hl
	ld	a, -3 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:37: sampler->step_remainder =
	ld	a, -2 (ix)
	add	a, #0x04
	ld	-8 (ix), a
	ld	a, -1 (ix)
	adc	a, #0x00
	ld	-7 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:38: wall_texture_step_remainders[sampler_height_index];
	ld	hl, #_wall_texture_step_remainders+0
	ld	d, #0x00
	add	hl, de
	ld	e, (hl)
	ld	d, #0x00
	ld	l, -8 (ix)
	ld	h, -7 (ix)
	ld	(hl), e
	inc	hl
	ld	(hl), d
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:39: sampler->texture_position = 0;
	ld	a, -2 (ix)
	ld	-6 (ix), a
	ld	a, -1 (ix)
	ld	-5 (ix), a
	ld	l, -6 (ix)
	ld	h, -5 (ix)
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:40: sampler->remainder_position = 0;
	ld	de, #0x0006
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	add	hl, de
	ld	-4 (ix), l
	ld	-3 (ix), h
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:42: if (first_wall_pixel != 0)
	ld	a, b
	or	a, c
	jr	z, 00107$
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:44: sampler->texture_position = first_wall_pixel * sampler->texture_step;
	pop	hl
	push	hl
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	push	bc
	ld	l, c
	ld	h, b
	call	__mulint
	pop	bc
	ld	l, -6 (ix)
	ld	h, -5 (ix)
	ld	(hl), e
	inc	hl
	ld	(hl), d
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:46: first_wall_pixel * sampler->step_remainder;
	ld	l, -8 (ix)
	ld	h, -7 (ix)
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	ld	l, c
	ld	h, b
	call	__mulint
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	ld	(hl), e
	inc	hl
	ld	(hl), d
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:48: while (sampler->remainder_position >= projected_wall_height)
00103$:
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	ld	e, 7 (ix)
	ld	d, #0x00
	ld	a, c
	sub	a, e
	ld	a, b
	sbc	a, d
	jr	c, 00107$
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:50: ++sampler->texture_position;
	ld	l, -6 (ix)
	ld	h, -5 (ix)
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	inc	bc
	ld	l, -6 (ix)
	ld	h, -5 (ix)
	ld	(hl), c
	inc	hl
	ld	(hl), b
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:51: sampler->remainder_position -= projected_wall_height;
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	ld	a, (hl)
	inc	hl
	ld	h, (hl)
	ld	l, a
	ld	c, 7 (ix)
	ld	b, #0x00
	cp	a, a
	sbc	hl, bc
	ex	de, hl
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	ld	(hl), e
	inc	hl
	ld	(hl), d
	jr	00103$
00107$:
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:54: sampler->wall_top = wall_top;
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	ld	de, #0x0008
	add	hl, de
	ld	a, 8 (ix)
	ld	(hl), a
	inc	hl
	ld	a, 9 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:55: sampler->wall_bottom = wall_top + projected_wall_height;
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	ld	de, #0x000a
	add	hl, de
	ld	a, 7 (ix)
	ld	b, #0x00
	add	a, 8 (ix)
	ld	c, a
	ld	a, b
	adc	a, 9 (ix)
	ld	(hl), c
	inc	hl
	ld	(hl), a
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:56: sampler->projected_wall_height = projected_wall_height;
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	ld	de, #0x000c
	add	hl, de
	ld	a, 7 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:58: sampler->texture_byte_x_and_nibble = oriented_hit_offset >> 6;
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	ld	de, #0x000e
	add	hl, de
	ld	a, 6 (ix)
	rlca
	rlca
	and	a, #0x03
	ld	(hl), a
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:59: if ((oriented_hit_offset & TEXTURE_X_PARITY_HIT_MASK) == 0)
	bit	5, 6 (ix)
	jr	nz, 00109$
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:60: sampler->texture_byte_x_and_nibble |= TEXTURE_HIGH_NIBBLE_FLAG;
	set	7, (hl)
00109$:
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:62: sampler->palette_indices = wall_side == WALL_SIDE_X
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	ld	de, #0x000f
	add	hl, de
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:63: ? wall_palette_x_indices
	ld	a, 5 (ix)
	or	a, a
	jr	nz, 00112$
	ld	bc, #_wall_palette_x_indices+0
	jr	00113$
00112$:
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:64: : wall_palette_y_indices;
	ld	bc, #_wall_palette_y_indices+0
00113$:
	ld	(hl), c
	inc	hl
	ld	(hl), b
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:65: }
	ld	sp, ix
	pop	ix
	pop	hl
	pop	af
	pop	af
	pop	af
	inc	sp
	jp	(hl)
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:67: unsigned char game_gear_wall_texture_palette_sample_next(
;	---------------------------------
; Function game_gear_wall_texture_palette_sample_next
; ---------------------------------
_game_gear_wall_texture_palette_sample_next::
	push	ix
	ld	ix,	#0
	add	ix, sp
	push	af
	push	af
	push	af
	ld	c, l
	ld	b, h
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:76: if (screen_y < sampler->wall_top ||
	ld	e, c
	ld	d, b
	ld	hl, #8
	add	hl, de
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	ld	a, 4 (ix)
	ld	-2 (ix), a
	ld	-1 (ix), #0x00
	ld	a, -2 (ix)
	sub	a, e
	ld	a, #0x00
	sbc	a, d
	jp	po, 00144$
	xor	a, #0x80
00144$:
	jp	m, 00101$
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:77: screen_y >= sampler->wall_bottom)
	ld	e, c
	ld	d, b
	ld	hl, #10
	add	hl, de
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	ld	a, -2 (ix)
	sub	a, e
	ld	a, #0x00
	sbc	a, d
	jp	po, 00145$
	xor	a, #0x80
00145$:
	jp	m, 00102$
00101$:
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:78: return GAME_GEAR_WALL_TEXTURE_OUTSIDE;
	ld	a, #0xff
	jp	00110$
00102$:
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:80: texture_y = (unsigned char)(sampler->texture_position
	pop	de
	push	bc
	pop	hl
	push	hl
	ld	a, (hl)
	inc	hl
	ld	d, (hl)
	ld	e, d
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:82: sampler->texture_position += sampler->texture_step;
	ld	l, c
	ld	h, b
	inc	hl
	inc	hl
	push	af
	ld	a, (hl)
	inc	hl
	ld	h, (hl)
	ld	l, a
	pop	af
	add	a, l
	ld	-2 (ix), a
	ld	a, d
	adc	a, h
	ld	-1 (ix), a
	pop	hl
	push	hl
	ld	a, -2 (ix)
	ld	(hl), a
	inc	hl
	ld	a, -1 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:83: sampler->remainder_position += sampler->step_remainder;
	ld	hl, #0x0006
	add	hl, bc
	ld	-4 (ix), l
	ld	-3 (ix), h
	ld	a, (hl)
	inc	hl
	ld	d, (hl)
	push	bc
	pop	iy
	push	af
	ld	l, 4 (iy)
	ld	h, 5 (iy)
	pop	af
	add	a, l
	ld	-2 (ix), a
	ld	a, d
	adc	a, h
	ld	-1 (ix), a
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	ld	a, -2 (ix)
	ld	(hl), a
	inc	hl
	ld	a, -1 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:85: if (sampler->remainder_position >= sampler->projected_wall_height)
	ld	iy, #0x000c
	add	iy, bc
	ld	d, (iy)
	ld	l, #0x00
	ld	a, -2 (ix)
	sub	a, d
	ld	a, -1 (ix)
	sbc	a, l
	jr	c, 00105$
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:87: ++sampler->texture_position;
	pop	hl
	push	hl
	ld	a, (hl)
	inc	hl
	ld	h, (hl)
	ld	l, a
	inc	hl
	ld	-2 (ix), l
	ld	-1 (ix), h
	pop	hl
	push	hl
	ld	a, -2 (ix)
	ld	(hl), a
	inc	hl
	ld	a, -1 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:88: sampler->remainder_position -= sampler->projected_wall_height;
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	ld	a, (hl)
	inc	hl
	ld	d, (hl)
	ld	l, (iy)
	ld	h, #0x00
	sub	a, l
	ld	-2 (ix), a
	ld	a, d
	sbc	a, h
	ld	-1 (ix), a
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	ld	a, -2 (ix)
	ld	(hl), a
	inc	hl
	ld	a, -1 (ix)
	ld	(hl), a
00105$:
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:92: ((unsigned int)texture_y << GAME_GEAR_WALL_TEXTURE_PACKED_ROW_SHIFT)
	ld	d, #0x00
	ex	de, hl
	add	hl, hl
	add	hl, hl
	ex	de, hl
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:93: + (sampler->texture_byte_x_and_nibble & TEXTURE_BYTE_X_MASK);
	ld	l, c
	ld	h, b
	push	bc
	ld	bc, #0x000e
	add	hl, bc
	pop	bc
	ld	a, (hl)
	ld	-1 (ix), a
	and	a, #0x03
	ld	l, a
	ld	h, #0x00
	add	hl, de
	ex	de, hl
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:94: indexed_color = wall_textures[sampler->texture_id][byte_offset];
	ld	l, c
	ld	h, b
	push	bc
	ld	bc, #0x000d
	add	hl, bc
	pop	bc
	ld	l, (hl)
	ld	h, #0x00
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	ld	a, #<(_wall_textures)
	add	a, l
	ld	l, a
	ld	a, #>(_wall_textures)
	adc	a, h
	ld	h, a
	add	hl, de
	ld	a, (hl)
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:95: if (sampler->texture_byte_x_and_nibble & TEXTURE_HIGH_NIBBLE_FLAG)
	bit	7, -1 (ix)
	jr	z, 00107$
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:96: indexed_color >>= 4;
	rlca
	rlca
	rlca
	rlca
	and	a, #0x0f
00107$:
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:99: indexed_color &= 15;
	and	a, #0x0f
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:100: if (indexed_color >= WALL_TEXTURE_COLOR_COUNT)
	ld	e, a
	sub	a, #0x0a
	jr	c, 00109$
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:101: indexed_color = 0;
	ld	e, #0x00
00109$:
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:102: return sampler->palette_indices[indexed_color];
	ld	hl, #15
	add	hl, bc
	ld	a, (hl)
	inc	hl
	ld	h, (hl)
	ld	l, a
	ld	d, #0x00
	add	hl, de
	ld	a, (hl)
00110$:
;D:/mano_projektai/GearRay/platform/game_gear/render_textures.c:103: }
	ld	sp, ix
	pop	ix
	pop	hl
	inc	sp
	jp	(hl)
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
