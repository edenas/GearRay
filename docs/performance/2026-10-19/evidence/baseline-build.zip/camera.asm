;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (MINGW64)
;--------------------------------------------------------
	.module camera
	
	.optsdcc -mz80 sdcccall(1)
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _camera_initialize
	.globl _camera_set_fixed_position
	.globl _camera_rotate_left
	.globl _camera_rotate_right
	.globl _camera_get_position_x
	.globl _camera_get_position_y
	.globl _camera_get_direction_x
	.globl _camera_get_direction_y
	.globl _camera_get_plane_x
	.globl _camera_get_plane_y
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
_position_x:
	.ds 2
_position_y:
	.ds 2
_direction_x:
	.ds 2
_direction_y:
	.ds 2
_plane_x:
	.ds 2
_plane_y:
	.ds 2
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute ram data
;--------------------------------------------------------
	.area _DABS (ABS)
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;D:/mano_projektai/GearRay/game/camera.c:16: static signed int camera_round_rotation(signed long value)
;	---------------------------------
; Function camera_round_rotation
; ---------------------------------
_camera_round_rotation:
	push	ix
	ld	ix,	#0
	add	ix, sp
	push	af
	push	af
	ld	c, l
	ld	b, h
;D:/mano_projektai/GearRay/game/camera.c:18: if (value < 0)
	bit	7, b
	jr	z, 00102$
;D:/mano_projektai/GearRay/game/camera.c:19: value -= ROTATION_SCALE / 2;
	ld	a, d
	add	a, #0xf8
	ld	d, a
	ld	a, c
	adc	a, #0xff
	ld	c, a
	ld	a, b
	adc	a, #0xff
	ld	b, a
	jr	00103$
00102$:
;D:/mano_projektai/GearRay/game/camera.c:21: value += ROTATION_SCALE / 2;
	ld	a, d
	add	a, #0x08
	ld	d, a
	jr	nc, 00123$
	inc	bc
00123$:
00103$:
;D:/mano_projektai/GearRay/game/camera.c:23: return (signed int)(value / ROTATION_SCALE);
	pop	hl
	push	de
	ld	-2 (ix), c
	ld	-1 (ix), b
	bit	7, b
	jr	z, 00106$
	ld	a, e
	add	a, #0xff
	ld	-4 (ix), a
	ld	a, d
	adc	a, #0x0f
	ld	-3 (ix), a
	ld	a, c
	adc	a, #0x00
	ld	-2 (ix), a
	ld	a, b
	adc	a, #0x00
	ld	-1 (ix), a
00106$:
	pop	de
	pop	hl
	push	hl
	push	de
	ld	b, #0x0c
00124$:
	sra	h
	rr	l
	rr	d
	rr	e
	djnz	00124$
;D:/mano_projektai/GearRay/game/camera.c:24: }
	ld	sp, ix
	pop	ix
	ret
;D:/mano_projektai/GearRay/game/camera.c:26: static signed int camera_round_scaled(signed long value,
;	---------------------------------
; Function camera_round_scaled
; ---------------------------------
_camera_round_scaled:
	push	ix
	ld	ix,	#0
	add	ix, sp
	push	af
	push	af
	ld	c, l
	ld	b, h
;D:/mano_projektai/GearRay/game/camera.c:30: value -= scale / 2;
	ld	l, 4 (ix)
	ld	h, 5 (ix)
	srl	h
	rr	l
	ex	(sp), hl
	xor	a, a
	ld	-2 (ix), a
	ld	-1 (ix), a
;D:/mano_projektai/GearRay/game/camera.c:29: if (value < 0)
	bit	7, b
	jr	z, 00102$
;D:/mano_projektai/GearRay/game/camera.c:30: value -= scale / 2;
	ld	a, e
	sub	a, -4 (ix)
	ld	e, a
	ld	a, d
	sbc	a, -3 (ix)
	ld	d, a
	ld	a, c
	sbc	a, -2 (ix)
	ld	c, a
	ld	a, b
	sbc	a, -1 (ix)
	ld	b, a
	jr	00103$
00102$:
;D:/mano_projektai/GearRay/game/camera.c:32: value += scale / 2;
	ld	a, e
	add	a, -4 (ix)
	ld	e, a
	ld	a, d
	adc	a, -3 (ix)
	ld	d, a
	jr	nc, 00114$
	inc	bc
00114$:
00103$:
;D:/mano_projektai/GearRay/game/camera.c:34: return (signed int)(value / scale);
	ld	l, 4 (ix)
	ld	h, 5 (ix)
	ld	iy, #0x0000
	push	iy
	push	hl
	ld	l, c
	ld	h, b
	call	__divslong
;D:/mano_projektai/GearRay/game/camera.c:35: }
	ld	sp,ix
	pop	ix
	pop	hl
	pop	af
	jp	(hl)
;D:/mano_projektai/GearRay/game/camera.c:37: static unsigned int camera_integer_square_root(unsigned long value)
;	---------------------------------
; Function camera_integer_square_root
; ---------------------------------
_camera_integer_square_root:
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	iy, #-20
	add	iy, sp
	ld	sp, iy
	ld	-8 (ix), e
	ld	-7 (ix), d
	ld	-6 (ix), l
	ld	-5 (ix), h
;D:/mano_projektai/GearRay/game/camera.c:39: unsigned long result = 0;
	xor	a, a
	ld	-20 (ix), a
	ld	-19 (ix), a
	ld	-18 (ix), a
	ld	-17 (ix), a
;D:/mano_projektai/GearRay/game/camera.c:40: unsigned long bit = 1UL << 30;
	xor	a, a
	ld	-4 (ix), a
	ld	-3 (ix), a
	ld	-2 (ix), a
	ld	-1 (ix), #0x40
;D:/mano_projektai/GearRay/game/camera.c:42: while (bit > value)
00101$:
	ld	a, -8 (ix)
	sub	a, -4 (ix)
	ld	a, -7 (ix)
	sbc	a, -3 (ix)
	ld	a, -6 (ix)
	sbc	a, -2 (ix)
	ld	a, -5 (ix)
	sbc	a, -1 (ix)
	jr	nc, 00107$
;D:/mano_projektai/GearRay/game/camera.c:43: bit >>= 2;
	ld	b, #0x02
00152$:
	srl	-1 (ix)
	rr	-2 (ix)
	rr	-3 (ix)
	rr	-4 (ix)
	djnz	00152$
	jr	00101$
;D:/mano_projektai/GearRay/game/camera.c:45: while (bit != 0)
00107$:
	ld	a, -1 (ix)
	or	a, -2 (ix)
	or	a, -3 (ix)
	or	a, -4 (ix)
	jp	z, 00109$
;D:/mano_projektai/GearRay/game/camera.c:47: if (value >= result + bit)
	ld	e, -4 (ix)
	ld	d, -3 (ix)
	pop	hl
	push	hl
	add	hl, de
	ld	-16 (ix), l
	ld	-15 (ix), h
	ld	a, -18 (ix)
	adc	a, -2 (ix)
	ld	-14 (ix), a
	ld	a, -17 (ix)
	adc	a, -1 (ix)
	ld	-13 (ix), a
;D:/mano_projektai/GearRay/game/camera.c:50: result = (result >> 1) + bit;
	ld	a, -20 (ix)
	ld	-12 (ix), a
	ld	a, -19 (ix)
	ld	-11 (ix), a
	ld	a, -18 (ix)
	ld	-10 (ix), a
	ld	a, -17 (ix)
	ld	-9 (ix), a
	srl	-9 (ix)
	rr	-10 (ix)
	rr	-11 (ix)
	rr	-12 (ix)
;D:/mano_projektai/GearRay/game/camera.c:47: if (value >= result + bit)
	ld	a, -8 (ix)
	sub	a, -16 (ix)
	ld	a, -7 (ix)
	sbc	a, -15 (ix)
	ld	a, -6 (ix)
	sbc	a, -14 (ix)
	ld	a, -5 (ix)
	sbc	a, -13 (ix)
	jr	c, 00105$
;D:/mano_projektai/GearRay/game/camera.c:49: value -= result + bit;
	ld	a, -8 (ix)
	sub	a, -16 (ix)
	ld	-8 (ix), a
	ld	a, -7 (ix)
	sbc	a, -15 (ix)
	ld	-7 (ix), a
	ld	a, -6 (ix)
	sbc	a, -14 (ix)
	ld	-6 (ix), a
	ld	a, -5 (ix)
	sbc	a, -13 (ix)
	ld	-5 (ix), a
;D:/mano_projektai/GearRay/game/camera.c:50: result = (result >> 1) + bit;
	ld	e, -4 (ix)
	ld	d, -3 (ix)
	ld	l, -12 (ix)
	ld	h, -11 (ix)
	add	hl, de
	ex	(sp), hl
	ld	a, -10 (ix)
	adc	a, -2 (ix)
	ld	-18 (ix), a
	ld	a, -9 (ix)
	adc	a, -1 (ix)
	ld	-17 (ix), a
	jr	00106$
00105$:
;D:/mano_projektai/GearRay/game/camera.c:53: result >>= 1;
	ld	hl, #0
	add	hl, sp
	ex	de, hl
	ld	hl, #8
	add	hl, sp
	ld	bc, #4
	ldir
00106$:
;D:/mano_projektai/GearRay/game/camera.c:55: bit >>= 2;
	ld	b, #0x02
00156$:
	srl	-1 (ix)
	rr	-2 (ix)
	rr	-3 (ix)
	rr	-4 (ix)
	djnz	00156$
	jp	00107$
00109$:
;D:/mano_projektai/GearRay/game/camera.c:58: return (unsigned int)result;
	pop	de
	push	de
;D:/mano_projektai/GearRay/game/camera.c:59: }
	ld	sp, ix
	pop	ix
	ret
;D:/mano_projektai/GearRay/game/camera.c:61: static void camera_stabilize_vectors(void)
;	---------------------------------
; Function camera_stabilize_vectors
; ---------------------------------
_camera_stabilize_vectors:
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	hl, #-8
	add	hl, sp
	ld	sp, hl
;D:/mano_projektai/GearRay/game/camera.c:63: unsigned int direction_length = camera_integer_square_root(
	ld	a, (_direction_x+0)
	ld	-8 (ix), a
	ld	a, (_direction_x + 1)
	ld	-7 (ix), a
	rlca
	sbc	a, a
	ld	-6 (ix), a
	ld	-5 (ix), a
	pop	de
	push	de
	ld	l, e
	ld	h, d
	call	___mulsint2slong
	ld	c, e
	ld	b, d
	ld	a, (_direction_y+0)
	ld	-4 (ix), a
	ld	a, (_direction_y + 1)
	ld	-3 (ix), a
	rlca
	sbc	a, a
	ld	-2 (ix), a
	ld	-1 (ix), a
	ld	e, -4 (ix)
	ld	d, -3 (ix)
	push	hl
	push	bc
	ld	l, e
	ld	h, d
	call	___mulsint2slong
	push	de
	pop	iy
	ex	de, hl
	pop	bc
	pop	hl
	add	iy, bc
	ld	a, e
	adc	a, l
	ld	l, a
	ld	a, d
	adc	a, h
	push	iy
	pop	de
	ld	h, a
	call	_camera_integer_square_root
;D:/mano_projektai/GearRay/game/camera.c:67: if (direction_length == 0)
	ld	a, d
	or	a, e
;D:/mano_projektai/GearRay/game/camera.c:68: return;
	jr	z, 00103$
;D:/mano_projektai/GearRay/game/camera.c:71: (signed long)direction_x * DIRECTION_LENGTH,
	ld	c, -8 (ix)
	ld	l, -7 (ix)
	ld	h, -6 (ix)
	xor	a, a
	push	de
	push	de
	ld	e, a
	ld	d, c
	call	_camera_round_scaled
	ex	de, hl
	pop	de
	ld	(_direction_x), hl
;D:/mano_projektai/GearRay/game/camera.c:74: (signed long)direction_y * DIRECTION_LENGTH,
	ld	b, -4 (ix)
	ld	l, -3 (ix)
	ld	h, -2 (ix)
	ld	c, #0x00
	push	de
	ld	e, c
	ld	d, b
	call	_camera_round_scaled
	ld	(_direction_y), de
;D:/mano_projektai/GearRay/game/camera.c:78: -(signed long)direction_y * CAMERA_PLANE_LENGTH,
	ld	hl, (_direction_y)
	ld	a, (_direction_y + 1)
	ld	h, a
	rlca
	sbc	a, a
	ld	c, a
	ld	b, a
	xor	a, a
	sub	a, l
	ld	e, a
	ld	a, #0x00
	sbc	a, h
	ld	d, a
	ld	hl, #0x0000
	sbc	hl, bc
	push	hl
	push	de
	ld	de, #0x00a9
	ld	hl, #0x0000
	call	__mullong
	pop	af
	pop	af
	ld	bc, #0x0100
	push	bc
	call	_camera_round_scaled
	ld	(_plane_x), de
;D:/mano_projektai/GearRay/game/camera.c:81: (signed long)direction_x * CAMERA_PLANE_LENGTH,
	ld	de, (_direction_x)
	ld	hl, #0x00a9
	call	___mulsint2slong
	ld	bc, #0x0100
	push	bc
	call	_camera_round_scaled
	ld	(_plane_y), de
00103$:
;D:/mano_projektai/GearRay/game/camera.c:83: }
	ld	sp, ix
	pop	ix
	ret
;D:/mano_projektai/GearRay/game/camera.c:85: static void camera_rotate(signed int rotation_sine)
;	---------------------------------
; Function camera_rotate
; ---------------------------------
_camera_rotate:
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	iy, #-14
	add	iy, sp
	ld	sp, iy
	ex	de, hl
;D:/mano_projektai/GearRay/game/camera.c:87: signed int old_direction_x = direction_x;
	ld	hl, (_direction_x)
;D:/mano_projektai/GearRay/game/camera.c:88: signed int old_direction_y = direction_y;
	ld	bc, (_direction_y)
;D:/mano_projektai/GearRay/game/camera.c:91: (signed long)old_direction_x * ROTATION_COSINE
	ld	-14 (ix), l
	ld	a, h
	ld	-13 (ix), a
	rlca
	sbc	a, a
	ld	-12 (ix), a
	pop	hl
	push	hl
	push	bc
	ex	de, hl
	push	hl
	ld	hl, #0x0fda
;D:/mano_projektai/GearRay/game/camera.c:92: - (signed long)old_direction_y * rotation_sine);
	call	___mulsint2slong
	ld	-11 (ix), e
	ld	-10 (ix), d
	ld	-9 (ix), l
	ld	-8 (ix), h
	pop	de
	pop	bc
	ld	a, b
	rlca
	sbc	a, a
	ld	l, a
	ld	-7 (ix), e
	ld	a, d
	ld	-6 (ix), a
	rlca
	sbc	a, a
	ld	-5 (ix), a
	push	bc
	pop	iy
	ld	e, -7 (ix)
	ld	d, -6 (ix)
	push	hl
	push	bc
	push	iy
	pop	hl
	call	___mulsint2slong
	ld	-4 (ix), e
	ld	-3 (ix), d
	ld	-2 (ix), l
	ld	-1 (ix), h
	pop	bc
	pop	hl
	ld	a, -11 (ix)
	sub	a, -4 (ix)
	ld	e, a
	ld	a, -10 (ix)
	sbc	a, -3 (ix)
	ld	d, a
	ld	a, -9 (ix)
	sbc	a, -2 (ix)
	ld	h, a
	ld	a, -8 (ix)
	sbc	a, -1 (ix)
	push	hl
	push	bc
	ld	l, h
	ld	h, a
	call	_camera_round_rotation
	pop	bc
	pop	hl
	ld	(_direction_x), de
;D:/mano_projektai/GearRay/game/camera.c:94: (signed long)old_direction_y * ROTATION_COSINE
	ld	e, c
	ld	d, b
	ld	hl, #0x0fda
;D:/mano_projektai/GearRay/game/camera.c:95: + (signed long)old_direction_x * rotation_sine);
	call	___mulsint2slong
	push	de
	pop	iy
	ld	c, l
	ld	b, h
	pop	hl
	push	hl
	ld	e, -7 (ix)
	ld	d, -6 (ix)
	push	bc
	push	iy
	call	___mulsint2slong
	pop	iy
	pop	bc
	add	iy, de
	ld	a, l
	adc	a, c
	ld	l, a
	ld	a, h
	adc	a, b
	push	iy
	pop	de
	ld	h, a
	call	_camera_round_rotation
	ld	(_direction_y), de
;D:/mano_projektai/GearRay/game/camera.c:97: camera_stabilize_vectors();
	call	_camera_stabilize_vectors
;D:/mano_projektai/GearRay/game/camera.c:98: }
	ld	sp, ix
	pop	ix
	ret
;D:/mano_projektai/GearRay/game/camera.c:100: void camera_initialize(void)
;	---------------------------------
; Function camera_initialize
; ---------------------------------
_camera_initialize::
;D:/mano_projektai/GearRay/game/camera.c:102: position_x = 1280;
	ld	hl, #0x0500
	ld	(_position_x), hl
;D:/mano_projektai/GearRay/game/camera.c:103: position_y = 1024;
	ld	h, #0x04
	ld	(_position_y), hl
;D:/mano_projektai/GearRay/game/camera.c:104: direction_x = 0;
	ld	h, l
	ld	(_direction_x), hl
;D:/mano_projektai/GearRay/game/camera.c:105: direction_y = -DIRECTION_LENGTH;
	ld	h, #0xff
	ld	(_direction_y), hl
;D:/mano_projektai/GearRay/game/camera.c:106: plane_x = CAMERA_PLANE_LENGTH;
	ld	hl, #0x00a9
	ld	(_plane_x), hl
;D:/mano_projektai/GearRay/game/camera.c:107: plane_y = 0;
	ld	l, h
	ld	(_plane_y), hl
;D:/mano_projektai/GearRay/game/camera.c:108: }
	ret
;D:/mano_projektai/GearRay/game/camera.c:110: void camera_set_fixed_position(signed int fixed_position_x,
;	---------------------------------
; Function camera_set_fixed_position
; ---------------------------------
_camera_set_fixed_position::
	ld	(_position_x), hl
	ld	(_position_y), de
;D:/mano_projektai/GearRay/game/camera.c:114: position_y = fixed_position_y;
;D:/mano_projektai/GearRay/game/camera.c:115: }
	ret
;D:/mano_projektai/GearRay/game/camera.c:117: void camera_rotate_left(void)
;	---------------------------------
; Function camera_rotate_left
; ---------------------------------
_camera_rotate_left::
;D:/mano_projektai/GearRay/game/camera.c:119: camera_rotate(-ROTATION_SINE);
	ld	hl, #0xfdd4
;D:/mano_projektai/GearRay/game/camera.c:120: }
	jp	_camera_rotate
;D:/mano_projektai/GearRay/game/camera.c:122: void camera_rotate_right(void)
;	---------------------------------
; Function camera_rotate_right
; ---------------------------------
_camera_rotate_right::
;D:/mano_projektai/GearRay/game/camera.c:124: camera_rotate(ROTATION_SINE);
	ld	hl, #0x022c
;D:/mano_projektai/GearRay/game/camera.c:125: }
	jp	_camera_rotate
;D:/mano_projektai/GearRay/game/camera.c:127: signed int camera_get_position_x(void)
;	---------------------------------
; Function camera_get_position_x
; ---------------------------------
_camera_get_position_x::
;D:/mano_projektai/GearRay/game/camera.c:129: return position_x;
	ld	de, (_position_x)
;D:/mano_projektai/GearRay/game/camera.c:130: }
	ret
;D:/mano_projektai/GearRay/game/camera.c:132: signed int camera_get_position_y(void)
;	---------------------------------
; Function camera_get_position_y
; ---------------------------------
_camera_get_position_y::
;D:/mano_projektai/GearRay/game/camera.c:134: return position_y;
	ld	de, (_position_y)
;D:/mano_projektai/GearRay/game/camera.c:135: }
	ret
;D:/mano_projektai/GearRay/game/camera.c:137: signed int camera_get_direction_x(void)
;	---------------------------------
; Function camera_get_direction_x
; ---------------------------------
_camera_get_direction_x::
;D:/mano_projektai/GearRay/game/camera.c:139: return direction_x;
	ld	de, (_direction_x)
;D:/mano_projektai/GearRay/game/camera.c:140: }
	ret
;D:/mano_projektai/GearRay/game/camera.c:142: signed int camera_get_direction_y(void)
;	---------------------------------
; Function camera_get_direction_y
; ---------------------------------
_camera_get_direction_y::
;D:/mano_projektai/GearRay/game/camera.c:144: return direction_y;
	ld	de, (_direction_y)
;D:/mano_projektai/GearRay/game/camera.c:145: }
	ret
;D:/mano_projektai/GearRay/game/camera.c:147: signed int camera_get_plane_x(void)
;	---------------------------------
; Function camera_get_plane_x
; ---------------------------------
_camera_get_plane_x::
;D:/mano_projektai/GearRay/game/camera.c:149: return plane_x;
	ld	de, (_plane_x)
;D:/mano_projektai/GearRay/game/camera.c:150: }
	ret
;D:/mano_projektai/GearRay/game/camera.c:152: signed int camera_get_plane_y(void)
;	---------------------------------
; Function camera_get_plane_y
; ---------------------------------
_camera_get_plane_y::
;D:/mano_projektai/GearRay/game/camera.c:154: return plane_y;
	ld	de, (_plane_y)
;D:/mano_projektai/GearRay/game/camera.c:155: }
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
