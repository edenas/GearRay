;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (MINGW64)
;--------------------------------------------------------
	.module video
	
	.optsdcc -mz80 sdcccall(1)
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _game_gear_prepare_world_sprites
	.globl _game_gear_wall_texture_palette_sample_next
	.globl _game_gear_wall_texture_sampler_initialize
	.globl _game_gear_overlay_hud_weapon_tile
	.globl _game_gear_hud_weapon_render_complete
	.globl _game_gear_hud_weapon_changed
	.globl _world_sprite_get_count
	.globl _raycaster_get_rendered_rays
	.globl _SMS_VRAMmemcpy
	.globl _SMS_load1bppTiles
	.globl _SMS_crt0_RST18
	.globl _SMS_crt0_RST08
	.globl _SMS_setBGScrollX
	.globl _game_gear_damage_shake_phase
	.globl _previous_projected_sprite_count
	.globl _previous_wall_columns
	.globl _viewport_tile_states
	.globl _SMS_SRAM
	.globl _SRAM_bank_to_be_mapped_on_slot2
	.globl _ROM_bank_to_be_mapped_on_slot0
	.globl _ROM_bank_to_be_mapped_on_slot1
	.globl _ROM_bank_to_be_mapped_on_slot2
	.globl _game_gear_damage_shake_update
	.globl _game_gear_video_draw_wall_columns
	.globl _game_gear_video_draw_viewport_border
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
_SMS_VDPControlPort	=	0x00bf
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
_ROM_bank_to_be_mapped_on_slot2	=	0xffff
_ROM_bank_to_be_mapped_on_slot1	=	0xfffe
_ROM_bank_to_be_mapped_on_slot0	=	0xfffd
_SRAM_bank_to_be_mapped_on_slot2	=	0xfffc
_SMS_SRAM	=	0x8000
_projected_wall_column:
	.ds 256
_viewport_tile_states::
	.ds 112
_previous_wall_columns::
	.ds 98
_previous_projected_sprites:
	.ds 153
_previous_projected_sprite_count::
	.ds 1
_game_gear_damage_shake_phase::
	.ds 1
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute ram data
;--------------------------------------------------------
	.area _DABS (ABS)
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;D:/mano_projektai/GearRay/platform/game_gear/video.c:108: void game_gear_damage_shake_update(void)
;	---------------------------------
; Function game_gear_damage_shake_update
; ---------------------------------
_game_gear_damage_shake_update::
;D:/mano_projektai/GearRay/platform/game_gear/video.c:110: if (game_gear_damage_shake_phase == 0)
	ld	a, (_game_gear_damage_shake_phase+0)
	or	a, a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:111: return;
	ret	z
;D:/mano_projektai/GearRay/platform/game_gear/video.c:113: --game_gear_damage_shake_phase;
	ld	hl, #_game_gear_damage_shake_phase
	dec	(hl)
;D:/mano_projektai/GearRay/platform/game_gear/video.c:115: game_gear_damage_shake_offsets[game_gear_damage_shake_phase]);
	ld	hl, #_game_gear_damage_shake_offsets
	ld	a, (_game_gear_damage_shake_phase)
	ld	e, a
	ld	d, #0x00
	add	hl, de
	ld	l, (hl)
;D:/mano_projektai/GearRay/platform/game_gear/video.c:116: }
	jp	_SMS_setBGScrollX
	.area _BANK1
	.area _BANK1
_left_lod1_x_rows:
	.db #0xa0	; 160
	.db #0x50	; 80	'P'
	.db #0x00	; 0
	.db #0xa0	; 160
	.db #0x50	; 80	'P'
	.db #0xa0	; 160
	.db #0x00	; 0
	.db #0x50	; 80	'P'
	.db #0xa0	; 160
	.db #0x50	; 80	'P'
	.db #0x00	; 0
	.db #0xa0	; 160
	.db #0x50	; 80	'P'
	.db #0xa0	; 160
	.db #0x00	; 0
	.db #0x50	; 80	'P'
	.db #0xa0	; 160
	.db #0x50	; 80	'P'
	.db #0x00	; 0
	.db #0xa0	; 160
	.db #0x50	; 80	'P'
	.db #0xa0	; 160
	.db #0x00	; 0
	.db #0x50	; 80	'P'
	.db #0xa0	; 160
	.db #0x50	; 80	'P'
	.db #0x00	; 0
	.db #0xa0	; 160
	.db #0x50	; 80	'P'
	.db #0xa0	; 160
	.db #0x00	; 0
	.db #0x50	; 80	'P'
	.area _CODE
	.area _BANK1
_right_lod1_x_rows:
	.db #0x0a	; 10
	.db #0x05	; 5
	.db #0x00	; 0
	.db #0x0a	; 10
	.db #0x05	; 5
	.db #0x0a	; 10
	.db #0x00	; 0
	.db #0x05	; 5
	.db #0x0a	; 10
	.db #0x05	; 5
	.db #0x00	; 0
	.db #0x0a	; 10
	.db #0x05	; 5
	.db #0x0a	; 10
	.db #0x00	; 0
	.db #0x05	; 5
	.db #0x0a	; 10
	.db #0x05	; 5
	.db #0x00	; 0
	.db #0x0a	; 10
	.db #0x05	; 5
	.db #0x0a	; 10
	.db #0x00	; 0
	.db #0x05	; 5
	.db #0x0a	; 10
	.db #0x05	; 5
	.db #0x00	; 0
	.db #0x0a	; 10
	.db #0x05	; 5
	.db #0x0a	; 10
	.db #0x00	; 0
	.db #0x05	; 5
	.area _CODE
	.area _BANK1
_left_lod1_y_rows:
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0x00	; 0
	.db #0xa0	; 160
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0x00	; 0
	.db #0x50	; 80	'P'
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0x00	; 0
	.db #0xa0	; 160
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0x00	; 0
	.db #0x50	; 80	'P'
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0x00	; 0
	.db #0xa0	; 160
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0x00	; 0
	.db #0x50	; 80	'P'
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0x00	; 0
	.db #0xa0	; 160
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0x00	; 0
	.db #0x50	; 80	'P'
	.area _CODE
	.area _BANK1
_right_lod1_y_rows:
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0x0a	; 10
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0x05	; 5
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0x0a	; 10
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0x05	; 5
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0x0a	; 10
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0x05	; 5
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0x0a	; 10
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0x05	; 5
	.area _CODE
	.area _BANK1
_left_lod2_rows:
	.db #0x00	; 0
	.db #0xb0	; 176
	.db #0x00	; 0
	.db #0xa0	; 160
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0x00	; 0
	.db #0x70	; 112	'p'
	.db #0x00	; 0
	.db #0x70	; 112	'p'
	.db #0x00	; 0
	.db #0x50	; 80	'P'
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0x00	; 0
	.db #0xb0	; 176
	.db #0x00	; 0
	.db #0x70	; 112	'p'
	.db #0x00	; 0
	.db #0x60	; 96
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0x00	; 0
	.db #0x70	; 112	'p'
	.db #0x00	; 0
	.db #0xb0	; 176
	.db #0x00	; 0
	.db #0x90	; 144
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0x00	; 0
	.db #0xb0	; 176
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0x00	; 0
	.db #0xb0	; 176
	.db #0x00	; 0
	.db #0x70	; 112	'p'
	.db #0x00	; 0
	.db #0x50	; 80	'P'
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0x00	; 0
	.db #0x70	; 112	'p'
	.db #0x00	; 0
	.db #0xb0	; 176
	.db #0x00	; 0
	.db #0xa0	; 160
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0x00	; 0
	.db #0xb0	; 176
	.db #0x00	; 0
	.db #0xb0	; 176
	.db #0x00	; 0
	.db #0x90	; 144
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0x00	; 0
	.db #0x70	; 112	'p'
	.db #0x00	; 0
	.db #0x70	; 112	'p'
	.db #0x00	; 0
	.db #0x60	; 96
	.area _CODE
	.area _BANK1
_right_lod2_rows:
	.db #0x00	; 0
	.db #0x0b	; 11
	.db #0x00	; 0
	.db #0x0a	; 10
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0x07	; 7
	.db #0x00	; 0
	.db #0x07	; 7
	.db #0x00	; 0
	.db #0x05	; 5
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0x0b	; 11
	.db #0x00	; 0
	.db #0x07	; 7
	.db #0x00	; 0
	.db #0x06	; 6
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0x07	; 7
	.db #0x00	; 0
	.db #0x0b	; 11
	.db #0x00	; 0
	.db #0x09	; 9
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0x0b	; 11
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0x0b	; 11
	.db #0x00	; 0
	.db #0x07	; 7
	.db #0x00	; 0
	.db #0x05	; 5
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0x07	; 7
	.db #0x00	; 0
	.db #0x0b	; 11
	.db #0x00	; 0
	.db #0x0a	; 10
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0x0b	; 11
	.db #0x00	; 0
	.db #0x0b	; 11
	.db #0x00	; 0
	.db #0x09	; 9
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0x07	; 7
	.db #0x00	; 0
	.db #0x07	; 7
	.db #0x00	; 0
	.db #0x06	; 6
	.area _CODE
	.area _BANK1
_debug_border_tiles:
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x01	; 1
	.area _CODE
	.area _CODE
;D:/mano_projektai/GearRay/platform/game_gear/video.c:140: static unsigned char game_gear_get_background_palette_index(
;	---------------------------------
; Function game_gear_get_background_palette_index
; ---------------------------------
_game_gear_get_background_palette_index:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:144: ? CEILING_PALETTE_INDEX
	sub	a, #0x20
	jr	nc, 00103$
	ld	a, #0x03
	ret
00103$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:145: : FLOOR_PALETTE_INDEX;
	ld	a, #0x0a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:146: }
	ret
	.area _BANK1
	.area _BANK1
_left_palette_bitplanes:
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0xf0	; 240
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0xf0	; 240
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0xf0	; 240
	.db #0xf0	; 240
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0xf0	; 240
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0xf0	; 240
	.db #0xf0	; 240
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0xf0	; 240
	.db #0xf0	; 240
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0xf0	; 240
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0xf0	; 240
	.db #0xf0	; 240
	.db #0xf0	; 240
	.db #0xf0	; 240
	.db #0xf0	; 240
	.db #0xf0	; 240
	.area _CODE
	.area _BANK1
_right_palette_bitplanes:
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x0f	; 15
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x0f	; 15
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x0f	; 15
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x0f	; 15
	.db #0x0f	; 15
	.db #0x0f	; 15
	.db #0x0f	; 15
	.db #0x0f	; 15
	.db #0x0f	; 15
	.area _CODE
	.area _CODE
;D:/mano_projektai/GearRay/platform/game_gear/video.c:148: static unsigned char game_gear_sprite_covers_tile_column(
;	---------------------------------
; Function game_gear_sprite_covers_tile_column
; ---------------------------------
_game_gear_sprite_covers_tile_column:
	push	ix
	ld	ix,	#0
	add	ix, sp
	push	af
	ex	de, hl
;D:/mano_projektai/GearRay/platform/game_gear/video.c:152: signed int tile_left = tile_column * 8;
	ld	l, 4 (ix)
	ld	h, #0x00
	add	hl, hl
	add	hl, hl
	add	hl, hl
	ld	c, l
	ld	b, h
;D:/mano_projektai/GearRay/platform/game_gear/video.c:153: signed int tile_right = tile_left + 8;
	ld	hl, #0x0008
	add	hl, bc
	ex	(sp), hl
;D:/mano_projektai/GearRay/platform/game_gear/video.c:155: return sprite->visible
	ld	a, (de)
	or	a, a
	jr	z, 00103$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:156: && sprite->right > tile_left
	ld	l, e
	ld	h, d
	inc	hl
	inc	hl
	inc	hl
	ld	a, (hl)
	inc	hl
	ld	h, (hl)
	ld	l, a
	ld	a, c
	sub	a, l
	ld	a, b
	sbc	a, h
	jp	po, 00124$
	xor	a, #0x80
00124$:
	jp	p, 00103$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:157: && sprite->left < tile_right;
	ex	de, hl
	inc	hl
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	ld	a, c
	sub	a, -2 (ix)
	ld	a, b
	sbc	a, -1 (ix)
	jp	po, 00125$
	xor	a, #0x80
00125$:
	jp	m, 00104$
00103$:
	xor	a, a
	jr	00105$
00104$:
	ld	a, #0x01
00105$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:158: }
	ld	sp, ix
	pop	ix
	pop	hl
	inc	sp
	jp	(hl)
;D:/mano_projektai/GearRay/platform/game_gear/video.c:160: static unsigned char game_gear_sprite_covers_tile(
;	---------------------------------
; Function game_gear_sprite_covers_tile
; ---------------------------------
_game_gear_sprite_covers_tile:
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	c, l
	ld	b, h
;D:/mano_projektai/GearRay/platform/game_gear/video.c:165: signed int tile_top = tile_row * 8;
	ld	e, 5 (ix)
	ld	d, #0x00
	ex	de, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
;D:/mano_projektai/GearRay/platform/game_gear/video.c:167: return game_gear_sprite_covers_tile_column(sprite, tile_column)
	push	bc
	push	hl
	ld	a, 4 (ix)
	push	af
	inc	sp
	ld	l, c
	ld	h, b
	call	_game_gear_sprite_covers_tile_column
	pop	de
	pop	bc
	or	a, a
	jr	z, 00103$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:168: && sprite->bottom > tile_top
	ld	l, c
	ld	h, b
	push	bc
	ld	bc, #0x0007
	add	hl, bc
	pop	bc
	ld	a, (hl)
	inc	hl
	ld	h, (hl)
	ld	l, a
	ld	a, e
	sub	a, l
	ld	a, d
	sbc	a, h
	jp	po, 00124$
	xor	a, #0x80
00124$:
	jp	p, 00103$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:169: && sprite->top < tile_top + 8;
	ld	hl, #5
	add	hl, bc
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	ld	hl, #0x0008
	add	hl, de
	ld	a, c
	sub	a, l
	ld	a, b
	sbc	a, h
	jp	po, 00125$
	xor	a, #0x80
00125$:
	jp	m, 00104$
00103$:
	xor	a, a
	jr	00105$
00104$:
	ld	a, #0x01
00105$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:170: }
	pop	ix
	pop	hl
	pop	bc
	jp	(hl)
;D:/mano_projektai/GearRay/platform/game_gear/video.c:172: static void game_gear_overlay_sprite_tile(
;	---------------------------------
; Function game_gear_overlay_sprite_tile
; ---------------------------------
_game_gear_overlay_sprite_tile:
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	iy, #-44
	add	iy, sp
	ld	sp, iy
	ld	-5 (ix), l
	ld	-4 (ix), h
;D:/mano_projektai/GearRay/platform/game_gear/video.c:179: const unsigned char *pixels =
	ld	c, 6 (ix)
	ld	b, 7 (ix)
	push	bc
	pop	iy
	ld	e, 15 (iy)
	ld	a, e
	inc	a
	ld	a, #0x01
	jr	z, 00260$
	xor	a, a
00260$:
	ld	-1 (ix), a
	or	a, a
	jr	z, 00132$
	ld	e, c
	ld	d, b
	ld	hl, #13
	add	hl, de
	ld	e, (hl)
	inc	hl
	ld	a, (hl)
	jr	00133$
00132$:
	ld	d, #0x00
	ex	de, hl
	add	hl, hl
	ld	de, #_near_zombie_texture_pixels
	add	hl, de
	ld	e, (hl)
	inc	hl
	ld	a, (hl)
00133$:
	ld	-42 (ix), e
	ld	-41 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:183: unsigned int source_size = projected->near_texture_id
	ld	a, -1 (ix)
	or	a, a
	jr	z, 00134$
	ld	e, c
	ld	d, b
	ld	hl, #16
	add	hl, de
	ld	e, (hl)
	xor	a, a
	jr	00135$
00134$:
	ld	e, #0x20
	xor	a, a
00135$:
	ld	-40 (ix), e
	ld	-39 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:185: unsigned char packed_row_stride = (unsigned char)source_size >> 1;
	ld	a, -40 (ix)
	srl	a
	ld	-38 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:186: signed int tile_left = tile_column * 8;
	ld	l, 4 (ix)
	ld	h, #0x00
	add	hl, hl
	add	hl, hl
	add	hl, hl
	ld	-37 (ix), l
	ld	-36 (ix), h
;D:/mano_projektai/GearRay/platform/game_gear/video.c:187: signed int tile_top = tile_row * 8;
	ld	l, 5 (ix)
	ld	h, #0x00
	add	hl, hl
	add	hl, hl
	add	hl, hl
	ld	-35 (ix), l
	ld	-34 (ix), h
;D:/mano_projektai/GearRay/platform/game_gear/video.c:199: for (pixel_y = 0; pixel_y < 8; ++pixel_y)
	ld	e, -40 (ix)
	ld	d, #0x00
	dec	de
	ld	-33 (ix), e
	ld	-32 (ix), d
	ld	hl, #0x000b
	add	hl, bc
	ld	-31 (ix), l
	ld	-30 (ix), h
	ld	a, -33 (ix)
	ld	-29 (ix), a
	ld	a, -32 (ix)
	ld	-28 (ix), a
	ld	-27 (ix), c
	ld	-26 (ix), b
	ld	-25 (ix), c
	ld	-24 (ix), b
	ld	-23 (ix), c
	ld	-22 (ix), b
	ld	-21 (ix), c
	ld	-20 (ix), b
	ld	-19 (ix), c
	ld	-18 (ix), b
	ld	-3 (ix), #0x00
00129$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:201: screen_y = tile_top + pixel_y;
	ld	a, -3 (ix)
	ld	-17 (ix), a
	ld	-16 (ix), #0x00
	ld	e, -35 (ix)
	ld	d, -34 (ix)
	ld	l, -17 (ix)
	ld	h, #0x00
	add	hl, de
	ld	-7 (ix), l
	ld	-6 (ix), h
;D:/mano_projektai/GearRay/platform/game_gear/video.c:202: if (screen_y < projected->top || screen_y >= projected->bottom)
	ld	l, -19 (ix)
	ld	h, -18 (ix)
	ld	de, #0x0005
	add	hl, de
	ld	a, (hl)
	ld	-2 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-1 (ix), a
	ld	a, -7 (ix)
	sub	a, -2 (ix)
	ld	a, -6 (ix)
	sbc	a, -1 (ix)
	jp	po, 00261$
	xor	a, #0x80
00261$:
	jp	m, 00124$
	ld	l, -21 (ix)
	ld	h, -20 (ix)
	ld	de, #0x0007
	add	hl, de
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	ld	a, -7 (ix)
	sub	a, c
	ld	a, -6 (ix)
	sbc	a, b
	jp	po, 00262$
	xor	a, #0x80
00262$:
	jp	p, 00124$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:205: ((unsigned int)(screen_y - projected->top)
	ld	a, -7 (ix)
	sub	a, -2 (ix)
	ld	c, a
	ld	a, -6 (ix)
	sbc	a, -1 (ix)
	ld	b, a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:206: * projected->texture_step) >> 8;
	ld	l, -31 (ix)
	ld	h, -30 (ix)
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	ld	l, c
	ld	h, b
	call	__mulint
	ld	l, d
	ld	h, #0x00
;D:/mano_projektai/GearRay/platform/game_gear/video.c:207: if (texture_y >= source_size)
	ld	a, l
	sub	a, -40 (ix)
	jr	c, 00105$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:208: texture_y = source_size - 1;
	ld	l, -33 (ix)
	ld	h, -32 (ix)
00105$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:209: source_row = pixels + texture_y * packed_row_stride;
	ld	e, -38 (ix)
	ld	d, #0x00
	call	__mulint
	ld	l, -42 (ix)
	ld	h, -41 (ix)
	add	hl, de
	ld	-15 (ix), l
	ld	-14 (ix), h
;D:/mano_projektai/GearRay/platform/game_gear/video.c:211: for (pixel_x = 0; pixel_x < 8; ++pixel_x)
	ld	-2 (ix), #0x00
00128$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:213: screen_x = tile_left + pixel_x;
	ld	a, -2 (ix)
	ld	-7 (ix), a
	ld	-6 (ix), #0x00
	ld	e, -37 (ix)
	ld	d, -36 (ix)
	ld	l, -7 (ix)
	ld	h, #0x00
	add	hl, de
	ld	-13 (ix), l
	ld	-12 (ix), h
;D:/mano_projektai/GearRay/platform/game_gear/video.c:214: if (screen_x < projected->left || screen_x >= projected->right)
	ld	l, -23 (ix)
	ld	h, -22 (ix)
	inc	hl
	ld	a, (hl)
	ld	-11 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-10 (ix), a
	ld	a, -13 (ix)
	sub	a, -11 (ix)
	ld	a, -12 (ix)
	sbc	a, -10 (ix)
	jp	po, 00263$
	xor	a, #0x80
00263$:
	jp	m, 00122$
	ld	l, -25 (ix)
	ld	h, -24 (ix)
	inc	hl
	inc	hl
	inc	hl
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	ld	a, -13 (ix)
	sub	a, c
	ld	a, -12 (ix)
	sbc	a, b
	jp	po, 00264$
	xor	a, #0x80
00264$:
	jp	p, 00122$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:216: if (projected->depth
	ld	l, -27 (ix)
	ld	h, -26 (ix)
	ld	de, #0x0009
	add	hl, de
	ld	a, (hl)
	ld	-9 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-8 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:217: >= rays[(unsigned char)screen_x >> 2].wall_distance)
	ld	a, -13 (ix)
	ld	-1 (ix), a
	rrca
	rrca
	and	a, #0x3f
	ld	-1 (ix), a
	ld	c, a
	ld	b, #0x00
	ld	l, c
	ld	h, b
	add	hl, hl
	add	hl, bc
	add	hl, hl
	ex	(sp), hl
	pop	de
	push	de
	ld	l, 8 (ix)
	ld	h, 9 (ix)
	add	hl, de
	ld	-7 (ix), l
	ld	-6 (ix), h
	ld	de, #0x0004
	add	hl, de
	ld	a, (hl)
	ld	-7 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-6 (ix), a
	ld	a, -9 (ix)
	sub	a, -7 (ix)
	ld	a, -8 (ix)
	sbc	a, -6 (ix)
	jp	nc, 00122$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:223: ((unsigned int)(screen_x - projected->left)
	ld	a, -13 (ix)
	sub	a, -11 (ix)
	ld	-7 (ix), a
	ld	a, -12 (ix)
	sbc	a, -10 (ix)
	ld	-6 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:224: * projected->texture_step) >> 8;
	ld	l, -31 (ix)
	ld	h, -30 (ix)
	ld	a, (hl)
	ld	-9 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-8 (ix), a
	ld	e, -9 (ix)
	ld	d, -8 (ix)
	ld	l, -7 (ix)
	ld	h, -6 (ix)
	call	__mulint
	ld	e, #0x00
;D:/mano_projektai/GearRay/platform/game_gear/video.c:225: if (texture_x >= source_size)
	ld	a, d
	sub	a, -40 (ix)
	jr	c, 00112$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:226: texture_x = source_size - 1;
	ld	d, -29 (ix)
	ld	e, -28 (ix)
00112$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:227: palette_index = source_row[texture_x >> 1];
	ld	c, d
	ld	b, e
	srl	b
	rr	c
	ld	l, -15 (ix)
	ld	h, -14 (ix)
	add	hl, bc
	ld	a, (hl)
	ld	-1 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:228: if (texture_x & 1)
	bit	0, d
	jr	z, 00114$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:229: palette_index &= 15;
	ld	a, -1 (ix)
	and	a, #0x0f
	ld	-13 (ix), a
	jr	00115$
00114$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:231: palette_index >>= 4;
	ld	a, -1 (ix)
	rlca
	rlca
	rlca
	rlca
	and	a, #0x0f
	ld	-13 (ix), a
00115$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:232: if (palette_index == SPRITE_TRANSPARENT_INDEX)
	ld	a, -13 (ix)
	sub	a, #0x0f
	jp	z, 00122$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:235: mask = (unsigned char)(0x80U >> pixel_x);
	ld	b, -2 (ix)
	ld	de, #0x0080
	inc	b
	jr	00268$
00267$:
	srl	d
	rr	e
00268$:
	djnz	00267$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:236: for (plane = 0; plane < 4; ++plane)
	ld	-12 (ix), e
	ld	a, e
	cpl
	ld	-11 (ix), a
	ld	-1 (ix), #0x00
00126$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:238: if (palette_index & (1U << plane))
	ld	b, -1 (ix)
	ld	iy, #0x0001
	inc	b
	jr	00270$
00269$:
	add	iy, iy
00270$:
	djnz	00269$
	ld	c, -13 (ix)
	ld	b, #0x00
;D:/mano_projektai/GearRay/platform/game_gear/video.c:239: destination[pixel_y * 4 + plane] |= mask;
	ld	e, -1 (ix)
	ld	d, #0x00
	ld	l, -17 (ix)
	ld	h, #0x00
	add	hl, hl
	add	hl, hl
	add	hl, de
	ld	a, l
	add	a, -5 (ix)
	ld	-10 (ix), a
	ld	a, h
	adc	a, -4 (ix)
	ld	-9 (ix), a
	ld	l, -10 (ix)
	ld	h, -9 (ix)
	ld	a, (hl)
	ld	-8 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:238: if (palette_index & (1U << plane))
	push	iy
	ld	a, -46 (ix)
	pop	iy
	and	a, c
	ld	-7 (ix), a
	xor	a, a
	ld	-6 (ix), a
	or	a, -7 (ix)
	jr	z, 00119$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:239: destination[pixel_y * 4 + plane] |= mask;
	ld	a, -8 (ix)
	or	a, -12 (ix)
	ld	l, -10 (ix)
	ld	h, -9 (ix)
	ld	(hl), a
	jr	00127$
00119$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:242: (unsigned char)~mask;
	ld	a, -8 (ix)
	and	a, -11 (ix)
	ld	l, -10 (ix)
	ld	h, -9 (ix)
	ld	(hl), a
00127$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:236: for (plane = 0; plane < 4; ++plane)
	inc	-1 (ix)
	ld	a, -1 (ix)
	sub	a, #0x04
	jr	c, 00126$
00122$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:211: for (pixel_x = 0; pixel_x < 8; ++pixel_x)
	inc	-2 (ix)
	ld	a, -2 (ix)
	sub	a, #0x08
	jp	c, 00128$
00124$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:199: for (pixel_y = 0; pixel_y < 8; ++pixel_y)
	inc	-3 (ix)
	ld	a, -3 (ix)
	sub	a, #0x08
	jp	c, 00129$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:246: }
	ld	sp, ix
	pop	ix
	pop	hl
	pop	af
	pop	af
	pop	af
	jp	(hl)
;D:/mano_projektai/GearRay/platform/game_gear/video.c:248: static unsigned char game_gear_wall_column_is_unchanged(
;	---------------------------------
; Function game_gear_wall_column_is_unchanged
; ---------------------------------
_game_gear_wall_column_is_unchanged:
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	c, l
	ld	b, h
;D:/mano_projektai/GearRay/platform/game_gear/video.c:259: unsigned char side_flags = 0;
	ld	e, #0x00
;D:/mano_projektai/GearRay/platform/game_gear/video.c:261: if ((previous->side_and_valid_flags & WALL_COLUMN_VALID_FLAG) == 0)
	push	bc
	pop	iy
	ld	d, 6 (iy)
	bit	7, d
	jr	nz, 00102$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:262: return 0;
	xor	a, a
	jr	00107$
00102$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:264: if (left_wall_side == WALL_SIDE_Y)
	ld	a, 10 (ix)
	dec	a
	jr	nz, 00104$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:265: side_flags |= WALL_COLUMN_LEFT_SIDE_Y_FLAG;
	ld	e, #0x01
00104$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:267: if (right_wall_side == WALL_SIDE_Y)
	ld	a, 11 (ix)
	dec	a
	jr	nz, 00106$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:268: side_flags |= WALL_COLUMN_RIGHT_SIDE_Y_FLAG;
	set	1, e
00106$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:270: return previous->left_wall_height == left_wall_height
	ld	a, (bc)
	sub	a, 4 (ix)
	jr	nz, 00109$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:271: && previous->right_wall_height == right_wall_height
	ld	l, c
	ld	h, b
	inc	hl
	ld	a, (hl)
	sub	a, 5 (ix)
	jr	nz, 00109$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:272: && previous->left_hit_offset == left_hit_offset
	ld	l, c
	ld	h, b
	inc	hl
	inc	hl
	ld	a, (hl)
	sub	a, 6 (ix)
	jr	nz, 00109$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:273: && previous->right_hit_offset == right_hit_offset
	ld	l, c
	ld	h, b
	inc	hl
	inc	hl
	inc	hl
	ld	a, (hl)
	sub	a, 7 (ix)
	jr	nz, 00109$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:274: && previous->left_texture_id == left_texture_id
	ld	l, c
	ld	h, b
	inc	hl
	inc	hl
	inc	hl
	inc	hl
	ld	a, (hl)
	sub	a, 8 (ix)
	jr	nz, 00109$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:275: && previous->right_texture_id == right_texture_id
	ld	hl, #5
	add	hl, bc
	ld	a, (hl)
	sub	a, 9 (ix)
	jr	nz, 00109$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:276: && (previous->side_and_valid_flags
	ld	a, d
	and	a, #0x03
	sub	a, e
	jr	z, 00110$
00109$:
	xor	a, a
	jr	00111$
00110$:
	ld	a, #0x01
00111$:
00107$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:279: }
	pop	ix
	pop	hl
	pop	bc
	pop	bc
	pop	bc
	pop	bc
	jp	(hl)
;D:/mano_projektai/GearRay/platform/game_gear/video.c:281: static void game_gear_store_wall_column_signature(
;	---------------------------------
; Function game_gear_store_wall_column_signature
; ---------------------------------
_game_gear_store_wall_column_signature:
	push	ix
	ld	ix,	#0
	add	ix, sp
	ex	de, hl
;D:/mano_projektai/GearRay/platform/game_gear/video.c:292: unsigned char side_and_valid_flags = WALL_COLUMN_VALID_FLAG;
	ld	c, #0x80
;D:/mano_projektai/GearRay/platform/game_gear/video.c:294: previous->left_wall_height = left_wall_height;
	ld	a, 4 (ix)
	ld	(de), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:295: previous->right_wall_height = right_wall_height;
	ld	l, e
	ld	h, d
	inc	hl
	ld	a, 5 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:296: previous->left_hit_offset = left_hit_offset;
	ld	l, e
	ld	h, d
	inc	hl
	inc	hl
	ld	a, 6 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:297: previous->right_hit_offset = right_hit_offset;
	ld	l, e
	ld	h, d
	inc	hl
	inc	hl
	inc	hl
	ld	a, 7 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:298: previous->left_texture_id = left_texture_id;
	ld	hl, #0x0004
	add	hl, de
	ld	a, 8 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:299: previous->right_texture_id = right_texture_id;
	ld	hl, #0x0005
	add	hl, de
	ld	a, 9 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:300: if (left_wall_side == WALL_SIDE_Y)
	ld	a, 10 (ix)
	dec	a
	jr	nz, 00102$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:301: side_and_valid_flags |= WALL_COLUMN_LEFT_SIDE_Y_FLAG;
	ld	c, #0x81
00102$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:303: if (right_wall_side == WALL_SIDE_Y)
	ld	a, 11 (ix)
	dec	a
	jr	nz, 00104$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:304: side_and_valid_flags |= WALL_COLUMN_RIGHT_SIDE_Y_FLAG;
	set	1, c
00104$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:306: previous->side_and_valid_flags = side_and_valid_flags;
	ld	hl, #0x0006
	add	hl, de
	ld	(hl), c
;D:/mano_projektai/GearRay/platform/game_gear/video.c:307: }
	pop	ix
	pop	hl
	pop	af
	pop	af
	pop	af
	pop	af
	jp	(hl)
;D:/mano_projektai/GearRay/platform/game_gear/video.c:309: static void game_gear_build_native_wall_tile(
;	---------------------------------
; Function game_gear_build_native_wall_tile
; ---------------------------------
_game_gear_build_native_wall_tile:
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	iy, #-13
	add	iy, sp
	ld	sp, iy
	ld	c, l
	ld	b, h
	ld	-9 (ix), e
	ld	-8 (ix), d
;D:/mano_projektai/GearRay/platform/game_gear/video.c:331: left_wall_height += left_wall_top;
	ld	a, 8 (ix)
	add	a, 7 (ix)
	ld	8 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:332: right_wall_height += right_wall_top;
	ld	a, 15 (ix)
	add	a, 14 (ix)
	ld	15 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:334: if (!left_wall_is_far && !right_wall_is_far)
	ld	a, 4 (ix)
	or	a, a
	jp	nz, 00163$
	ld	a, 11 (ix)
	or	a, a
	jp	nz, 00163$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:336: for (tile_row = 0; tile_row < 8; ++tile_row)
	ld	-3 (ix), c
	ld	-2 (ix), b
	ld	-1 (ix), #0x00
00128$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:338: screen_y = tile_pixel_y + tile_row;
	ld	a, -1 (ix)
	add	a, 16 (ix)
	ld	b, a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:340: game_gear_get_background_palette_index(screen_y);
	push	bc
	ld	a, b
	call	_game_gear_get_background_palette_index
	ld	-5 (ix), a
	pop	bc
;D:/mano_projektai/GearRay/platform/game_gear/video.c:342: left_sampler, screen_y);
	push	bc
	push	bc
	inc	sp
	ld	l, -9 (ix)
	ld	h, -8 (ix)
	call	_game_gear_wall_texture_palette_sample_next
	ld	-4 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:344: right_sampler, screen_y);
	inc	sp
	ld	l, 9 (ix)
	ld	h, 10 (ix)
	call	_game_gear_wall_texture_palette_sample_next
	ld	c, a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:346: if (left_palette_index == GAME_GEAR_WALL_TEXTURE_OUTSIDE)
	ld	a, -4 (ix)
	inc	a
	jr	nz, 00102$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:347: left_palette_index = background_palette_index;
	ld	a, -5 (ix)
	ld	-4 (ix), a
00102$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:348: if (right_palette_index == GAME_GEAR_WALL_TEXTURE_OUTSIDE)
	ld	a, c
	inc	a
	jr	nz, 00104$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:349: right_palette_index = background_palette_index;
	ld	c, -5 (ix)
00104$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:351: left_bitplanes = left_palette_bitplanes[left_palette_index];
	ld	l, -4 (ix)
	ld	h, #0x00
	add	hl, hl
	add	hl, hl
	ld	iy, #_left_palette_bitplanes
	ex	de, hl
	add	iy, de
;D:/mano_projektai/GearRay/platform/game_gear/video.c:352: right_bitplanes = right_palette_bitplanes[right_palette_index];
	ld	l, c
	ld	h, #0x00
	add	hl, hl
	add	hl, hl
	ld	de, #_right_palette_bitplanes
	add	hl, de
	ex	de, hl
;D:/mano_projektai/GearRay/platform/game_gear/video.c:353: destination[0] = left_bitplanes[0] | right_bitplanes[0];
	ld	c, (iy)
	ld	a, (de)
	or	a, c
	ld	l, -3 (ix)
	ld	h, -2 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:354: destination[1] = left_bitplanes[1] | right_bitplanes[1];
	ld	c, -3 (ix)
	ld	b, -2 (ix)
	inc	bc
	push	iy
	pop	hl
	inc	hl
	ld	a, (hl)
	ld	l, e
	ld	h, d
	inc	hl
	or	a, (hl)
	ld	(bc), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:355: destination[2] = left_bitplanes[2] | right_bitplanes[2];
	ld	c, -3 (ix)
	ld	b, -2 (ix)
	inc	bc
	inc	bc
	push	iy
	pop	hl
	inc	hl
	inc	hl
	ld	a, (hl)
	ld	l, e
	ld	h, d
	inc	hl
	inc	hl
	or	a, (hl)
	ld	(bc), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:356: destination[3] = left_bitplanes[3] | right_bitplanes[3];
	ld	c, -3 (ix)
	ld	b, -2 (ix)
	inc	bc
	inc	bc
	inc	bc
	ld	a, 3 (iy)
	ld	hl, #3
	add	hl, de
	or	a, (hl)
	ld	(bc), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:357: destination += NATIVE_TILE_ROW_BYTES;
	ld	de, #0x0004
	ld	l, -3 (ix)
	ld	h, -2 (ix)
	add	hl, de
	ld	-3 (ix), l
	ld	-2 (ix), h
;D:/mano_projektai/GearRay/platform/game_gear/video.c:336: for (tile_row = 0; tile_row < 8; ++tile_row)
	inc	-1 (ix)
	ld	a, -1 (ix)
	sub	a, #0x08
	jp	c, 00128$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:359: return;
	jp	00132$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:362: for (tile_row = 0; tile_row < 8; ++tile_row)
00163$:
	ld	a, 5 (ix)
	ld	-7 (ix), a
	ld	a, 6 (ix)
	ld	-6 (ix), a
	ld	a, 12 (ix)
	ld	-5 (ix), a
	ld	a, 13 (ix)
	ld	-4 (ix), a
	ld	-3 (ix), c
	ld	-2 (ix), b
	ld	-1 (ix), #0x00
00130$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:364: screen_y = tile_pixel_y + tile_row;
	ld	a, -1 (ix)
	add	a, 16 (ix)
;D:/mano_projektai/GearRay/platform/game_gear/video.c:366: game_gear_get_background_palette_index(screen_y);
	ld	-13 (ix), a
	call	_game_gear_get_background_palette_index
;D:/mano_projektai/GearRay/platform/game_gear/video.c:379: left_palette_bitplanes[background_palette_index];
	ld	-12 (ix), a
	ld	l, a
	ld	h, #0x00
	add	hl, hl
	add	hl, hl
	ld	-11 (ix), l
	ld	-10 (ix), h
;D:/mano_projektai/GearRay/platform/game_gear/video.c:370: if (left_wall_is_far)
	ld	a, 4 (ix)
	or	a, a
	jr	z, 00116$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:373: && screen_y < left_wall_height)
	ld	a, -13 (ix)
	sub	a, 7 (ix)
	jr	c, 00110$
	ld	a, -13 (ix)
	sub	a, 8 (ix)
	jr	nc, 00110$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:375: left_bitplanes = left_flat_rows;
	ld	e, -7 (ix)
	ld	d, -6 (ix)
	jr	00111$
00110$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:379: left_palette_bitplanes[background_palette_index];
	ld	a, #<(_left_palette_bitplanes)
	add	a, -11 (ix)
	ld	e, a
	ld	a, #>(_left_palette_bitplanes)
	adc	a, -10 (ix)
	ld	d, a
00111$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:380: left_flat_rows += NATIVE_TILE_ROW_BYTES;
	ld	bc, #0x0004
	ld	l, -7 (ix)
	ld	h, -6 (ix)
	add	hl, bc
	ld	-7 (ix), l
	ld	-6 (ix), h
	jr	00117$
00116$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:385: left_sampler, screen_y);
	ld	a, -13 (ix)
	push	af
	inc	sp
	ld	l, -9 (ix)
	ld	h, -8 (ix)
	call	_game_gear_wall_texture_palette_sample_next
;D:/mano_projektai/GearRay/platform/game_gear/video.c:386: if (left_palette_index == GAME_GEAR_WALL_TEXTURE_OUTSIDE)
	cp	a, #0xff
	jr	nz, 00114$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:387: left_palette_index = background_palette_index;
	ld	a, -12 (ix)
00114$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:388: left_bitplanes = left_palette_bitplanes[left_palette_index];
	ld	h, #0x00
	ld	l, a
	add	hl, hl
	add	hl, hl
	ld	de, #_left_palette_bitplanes
	add	hl, de
	ex	de, hl
00117$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:391: if (right_wall_is_far)
	ld	a, 11 (ix)
	or	a, a
	jr	z, 00125$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:394: && screen_y < right_wall_height)
	ld	a, -13 (ix)
	sub	a, 14 (ix)
	jr	c, 00119$
	ld	a, -13 (ix)
	sub	a, 15 (ix)
	jr	nc, 00119$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:396: right_bitplanes = right_flat_rows;
	ld	a, -5 (ix)
	ld	-11 (ix), a
	ld	a, -4 (ix)
	ld	-10 (ix), a
	jr	00120$
00119$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:400: right_palette_bitplanes[background_palette_index];
	ld	a, #<(_right_palette_bitplanes)
	add	a, -11 (ix)
	ld	c, a
	ld	a, #>(_right_palette_bitplanes)
	adc	a, -10 (ix)
	ld	-11 (ix), c
	ld	-10 (ix), a
00120$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:401: right_flat_rows += NATIVE_TILE_ROW_BYTES;
	ld	bc, #0x0004
	ld	l, -5 (ix)
	ld	h, -4 (ix)
	add	hl, bc
	ld	-5 (ix), l
	ld	-4 (ix), h
	jr	00126$
00125$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:406: right_sampler, screen_y);
	push	de
	ld	a, -13 (ix)
	push	af
	inc	sp
	ld	l, 9 (ix)
	ld	h, 10 (ix)
	call	_game_gear_wall_texture_palette_sample_next
	pop	de
;D:/mano_projektai/GearRay/platform/game_gear/video.c:407: if (right_palette_index == GAME_GEAR_WALL_TEXTURE_OUTSIDE)
	cp	a, #0xff
	jr	nz, 00123$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:408: right_palette_index = background_palette_index;
	ld	a, -12 (ix)
00123$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:409: right_bitplanes = right_palette_bitplanes[right_palette_index];
	ld	h, #0x00
	ld	l, a
	add	hl, hl
	add	hl, hl
	ld	bc, #_right_palette_bitplanes
	add	hl, bc
	ld	-11 (ix), l
	ld	-10 (ix), h
00126$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:412: destination[0] = left_bitplanes[0] | right_bitplanes[0];
	ld	a, (de)
	ld	l, -11 (ix)
	ld	h, -10 (ix)
	or	a, (hl)
	ld	l, -3 (ix)
	ld	h, -2 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:413: destination[1] = left_bitplanes[1] | right_bitplanes[1];
	ld	c, -3 (ix)
	ld	b, -2 (ix)
	inc	bc
	ld	l, e
	ld	h, d
	inc	hl
	ld	a, (hl)
	ld	l, -11 (ix)
	ld	h, -10 (ix)
	inc	hl
	or	a, (hl)
	ld	(bc), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:414: destination[2] = left_bitplanes[2] | right_bitplanes[2];
	ld	c, -3 (ix)
	ld	b, -2 (ix)
	inc	bc
	inc	bc
	ld	l, e
	ld	h, d
	inc	hl
	inc	hl
	ld	a, (hl)
	ld	l, -11 (ix)
	ld	h, -10 (ix)
	inc	hl
	inc	hl
	or	a, (hl)
	ld	(bc), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:415: destination[3] = left_bitplanes[3] | right_bitplanes[3];
	ld	c, -3 (ix)
	ld	b, -2 (ix)
	inc	bc
	inc	bc
	inc	bc
	ld	hl, #3
	add	hl, de
	ld	a, (hl)
	pop	de
	pop	hl
	push	hl
	inc	hl
	inc	hl
	inc	hl
	push	de
	or	a, (hl)
	ld	(bc), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:416: destination += NATIVE_TILE_ROW_BYTES;
	ld	de, #0x0004
	ld	l, -3 (ix)
	ld	h, -2 (ix)
	add	hl, de
	ld	-3 (ix), l
	ld	-2 (ix), h
;D:/mano_projektai/GearRay/platform/game_gear/video.c:362: for (tile_row = 0; tile_row < 8; ++tile_row)
	inc	-1 (ix)
	ld	a, -1 (ix)
	sub	a, #0x08
	jp	c, 00130$
00132$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:418: }
	ld	sp, ix
	pop	ix
	pop	hl
	pop	af
	pop	af
	pop	af
	pop	af
	pop	af
	pop	af
	inc	sp
	jp	(hl)
;D:/mano_projektai/GearRay/platform/game_gear/video.c:420: static unsigned char game_gear_get_visible_wall_pixels(
;	---------------------------------
; Function game_gear_get_visible_wall_pixels
; ---------------------------------
_game_gear_get_visible_wall_pixels:
	push	ix
	ld	ix,	#0
	add	ix, sp
	push	af
	push	af
	ld	-2 (ix), l
	ld	-1 (ix), h
;D:/mano_projektai/GearRay/platform/game_gear/video.c:426: signed int wall_bottom = wall_top + wall_height;
	ld	a, 4 (ix)
	ld	c, #0x00
	add	a, -2 (ix)
	ld	-4 (ix), a
	ld	a, c
	adc	a, -1 (ix)
	ld	-3 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:428: if (wall_bottom <= 0 || wall_top >= GAME_GEAR_VIEWPORT_PIXEL_HEIGHT)
	xor	a, a
	cp	a, -4 (ix)
	sbc	a, -3 (ix)
	jp	po, 00134$
	xor	a, #0x80
00134$:
	jp	p, 00101$
	ld	a, -2 (ix)
	sub	a, #0x40
	ld	a, -1 (ix)
	rla
	ccf
	rra
	sbc	a, #0x80
	jr	c, 00102$
00101$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:429: return 0;
	xor	a, a
	jr	00108$
00102$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:431: *visible_top = wall_top;
	ld	c, 5 (ix)
	ld	b, 6 (ix)
	ld	l, c
	ld	h, b
	ld	a, -2 (ix)
	ld	(hl), a
	inc	hl
	ld	a, -1 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:432: *visible_bottom = wall_bottom;
	ld	e, 7 (ix)
	ld	d, 8 (ix)
	ld	l, e
	ld	h, d
	ld	a, -4 (ix)
	ld	(hl), a
	inc	hl
	ld	a, -3 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:434: if (*visible_top < 0)
	ld	l, c
	ld	h, b
	inc	hl
	bit	7, (hl)
	jr	z, 00105$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:435: *visible_top = 0;
	xor	a, a
	ld	(bc), a
	inc	bc
	ld	(bc), a
00105$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:437: if (*visible_bottom > GAME_GEAR_VIEWPORT_PIXEL_HEIGHT)
	ld	l, e
	ld	h, d
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	ld	a, #0x40
	cp	a, c
	ld	a, #0x00
	sbc	a, b
	jp	po, 00135$
	xor	a, #0x80
00135$:
	jp	p, 00107$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:438: *visible_bottom = GAME_GEAR_VIEWPORT_PIXEL_HEIGHT;
	ld	a, #0x40
	ld	(de), a
	inc	de
	xor	a, a
	ld	(de), a
00107$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:440: return 1;
	ld	a, #0x01
00108$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:441: }
	ld	sp, ix
	pop	ix
	pop	hl
	pop	bc
	pop	bc
	inc	sp
	jp	(hl)
;D:/mano_projektai/GearRay/platform/game_gear/video.c:443: static unsigned char game_gear_get_active_wall_rows(
;	---------------------------------
; Function game_gear_get_active_wall_rows
; ---------------------------------
_game_gear_get_active_wall_rows:
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	iy, #-10
	add	iy, sp
	ld	sp, iy
;D:/mano_projektai/GearRay/platform/game_gear/video.c:455: signed int combined_top = GAME_GEAR_VIEWPORT_PIXEL_HEIGHT;
	ld	bc, #0x0040
;D:/mano_projektai/GearRay/platform/game_gear/video.c:456: signed int combined_bottom = 0;
	xor	a, a
	ld	-2 (ix), a
	ld	-1 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:461: left_wall_top, left_wall_height, &left_top, &left_bottom);
	ex	de, hl
	ld	hl, #0
	add	hl, sp
	push	bc
	ex	de, hl
	push	hl
	ld	hl, #6
	add	hl, sp
	ex	(sp), hl
	push	de
	ld	a, 4 (ix)
	push	af
	inc	sp
	call	_game_gear_get_visible_wall_pixels
	ld	e, a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:463: right_wall_top, right_wall_height, &right_top, &right_bottom);
	push	de
	ld	hl, #10
	add	hl, sp
	push	hl
	dec	hl
	dec	hl
	push	hl
	ld	a, 7 (ix)
	push	af
	inc	sp
	ld	l, 5 (ix)
	ld	h, 6 (ix)
	call	_game_gear_get_visible_wall_pixels
	ld	l, a
	pop	de
	pop	bc
;D:/mano_projektai/GearRay/platform/game_gear/video.c:465: if (has_left_wall)
	ld	a, e
	or	a, a
	jr	z, 00102$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:467: combined_top = left_top;
	pop	bc
	push	bc
;D:/mano_projektai/GearRay/platform/game_gear/video.c:468: combined_bottom = left_bottom;
	ld	a, -8 (ix)
	ld	-2 (ix), a
	ld	a, -7 (ix)
	ld	-1 (ix), a
00102$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:471: if (has_right_wall)
	ld	a, l
	or	a, a
	jr	z, 00108$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:473: if (right_top < combined_top)
	ld	a, -6 (ix)
	sub	a, c
	ld	a, -5 (ix)
	sbc	a, b
	jp	po, 00180$
	xor	a, #0x80
00180$:
	jp	p, 00104$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:474: combined_top = right_top;
	ld	c, -6 (ix)
	ld	b, -5 (ix)
00104$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:476: if (right_bottom > combined_bottom)
	ld	a, -2 (ix)
	sub	a, -4 (ix)
	ld	a, -1 (ix)
	sbc	a, -3 (ix)
	jp	po, 00181$
	xor	a, #0x80
00181$:
	jp	p, 00108$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:477: combined_bottom = right_bottom;
	ld	a, -4 (ix)
	ld	-2 (ix), a
	ld	a, -3 (ix)
	ld	-1 (ix), a
00108$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:480: if (!has_left_wall && !has_right_wall)
	ld	a, e
	or	a, a
	jr	nz, 00110$
	or	a, l
	jr	nz, 00110$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:481: return 0;
	xor	a, a
	jr	00112$
00110$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:483: *first_row = (unsigned char)(combined_top / 8);
	ld	e, 8 (ix)
	ld	d, 9 (ix)
	ld	l, c
	ld	h, b
	bit	7, b
	jr	z, 00114$
	ld	hl, #0x0007
	add	hl, bc
00114$:
	ld	a, l
	sra	h
	rr	a
	sra	h
	rr	a
	sra	h
	rr	a
	ld	(de), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:484: *last_row = (unsigned char)((combined_bottom - 1) / 8);
	ld	c, 10 (ix)
	ld	b, 11 (ix)
	ld	e, -2 (ix)
	ld	d, -1 (ix)
	dec	de
	ld	l, e
	ld	h, d
	bit	7, d
	jr	z, 00115$
	ld	hl, #0x0007
	add	hl, de
00115$:
	ld	a, l
	sra	h
	rr	a
	sra	h
	rr	a
	sra	h
	rr	a
	ld	(bc), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:485: return 1;
	ld	a, #0x01
00112$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:486: }
	ld	sp, ix
	pop	ix
	pop	hl
	pop	bc
	pop	bc
	pop	bc
	pop	bc
	jp	(hl)
;D:/mano_projektai/GearRay/platform/game_gear/video.c:488: void game_gear_video_draw_wall_columns(void)
;	---------------------------------
; Function game_gear_video_draw_wall_columns
; ---------------------------------
_game_gear_video_draw_wall_columns::
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	hl, #-247
	add	hl, sp
	ld	sp, hl
;D:/mano_projektai/GearRay/platform/game_gear/video.c:506: const unsigned char *left_flat_rows = 0;
	xor	a, a
	ld	-46 (ix), a
	ld	-45 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:507: const unsigned char *right_flat_rows = 0;
	xor	a, a
	ld	-44 (ix), a
	ld	-43 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:510: unsigned char *tile_states = viewport_tile_states;
;D:/mano_projektai/GearRay/platform/game_gear/video.c:511: GameGearWallColumnSignature *previous_wall_column = previous_wall_columns;
;D:/mano_projektai/GearRay/platform/game_gear/video.c:523: unsigned char near_bank_mapped = 0;
	ld	-42 (ix), #0x00
;D:/mano_projektai/GearRay/platform/game_gear/video.c:524: unsigned char previous_slot2_page = 0;
	ld	-41 (ix), #0x00
;D:/mano_projektai/GearRay/platform/game_gear/video.c:525: unsigned char ordered_sprite_count = 0;
	ld	iy, #4
	add	iy, sp
	ld	0 (iy), #0x00
;D:/mano_projektai/GearRay/platform/game_gear/video.c:529: const RaycasterRay *rendered_rays = raycaster_get_rendered_rays();
	call	_raycaster_get_rendered_rays
	ld	-40 (ix), e
	ld	-39 (ix), d
;D:/mano_projektai/GearRay/platform/game_gear/video.c:530: const RaycasterRay *left_ray = rendered_rays;
	ld	a, -40 (ix)
	ld	-2 (ix), a
	ld	a, -39 (ix)
	ld	-1 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:534: projected_sprite_count = world_sprite_get_count();
	call	_world_sprite_get_count
	ld	-9 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:535: if (SHOTGUN_PICKUP_PRESENT) ++projected_sprite_count;
	ld	a, (_owned_weapons)
	bit	1, a
	jr	nz, 00102$
	inc	-9 (ix)
00102$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:542: &ordered_sprite_count);
;D:/mano_projektai/GearRay/platform/game_gear/video.c:541: ordered_sprite_indices,
;D:/mano_projektai/GearRay/platform/game_gear/video.c:539: previous_projected_sprites,
;D:/mano_projektai/GearRay/platform/game_gear/video.c:537: projected_sprites,
	ld	hl, #4
	add	hl, sp
	push	hl
	inc	hl
	push	hl
	ld	a, (_previous_projected_sprite_count)
	push	af
	inc	sp
	ld	hl, #_previous_projected_sprites
	push	hl
	ld	a, -9 (ix)
	push	af
	inc	sp
	ld	hl, #56
	add	hl, sp
	call	_game_gear_prepare_world_sprites
	ld	-38 (ix), e
	ld	-37 (ix), d
;D:/mano_projektai/GearRay/platform/game_gear/video.c:543: hud_weapon_changed = game_gear_hud_weapon_changed();
	call	_game_gear_hud_weapon_changed
	ld	-36 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:546: for (sprite_index = 0;
	ld	-3 (ix), #0x00
00195$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:547: sprite_index < projected_sprite_count;
	ld	a, -3 (ix)
	sub	a, -9 (ix)
	jr	nc, 00352$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:550: if (projected_sprites[sprite_index].visible
	ld	c, -3 (ix)
	ld	b, #0x00
	ld	l, c
	ld	h, b
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, bc
	ld	-7 (ix), l
	ld	-6 (ix), h
	ex	de, hl
	ld	hl, #48
	add	hl, sp
	add	hl, de
	ld	-5 (ix), l
	ld	-4 (ix), h
	ld	a, (hl)
	or	a, a
	jr	z, 00196$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:551: && projected_sprites[sprite_index].near_texture_id
	ld	c, -5 (ix)
	ld	b, -4 (ix)
	ld	hl, #15
	add	hl, bc
	ld	c, (hl)
	inc	c
	jr	z, 00196$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:554: previous_slot2_page = SMS_MAPPER_SLOT2_REGISTER;
	ld	a, (#0xffff)
	ld	-41 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:555: SMS_MAPPER_SLOT2_REGISTER = NEAR_ZOMBIE_ROM_PAGE;
	ld	hl, #0xffff
	ld	(hl), #0x02
;D:/mano_projektai/GearRay/platform/game_gear/video.c:556: near_bank_mapped = 1;
	ld	-42 (ix), #0x01
;D:/mano_projektai/GearRay/platform/game_gear/video.c:557: break;
	jr	00352$
00196$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:548: ++sprite_index)
	inc	-3 (ix)
	jr	00195$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:561: for (tile_column = 0;
00352$:
	ld	-8 (ix), #0x00
	ld	a, -2 (ix)
	ld	-7 (ix), a
	ld	a, -1 (ix)
	ld	-6 (ix), a
	ld	-5 (ix), #<(_previous_wall_columns)
	ld	-4 (ix), #>(_previous_wall_columns)
	ld	-3 (ix), #<(_viewport_tile_states)
	ld	-2 (ix), #>(_viewport_tile_states)
00211$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:568: right_ray = left_ray + 1;
	ld	de, #0x0006
	ld	l, -7 (ix)
	ld	h, -6 (ix)
	add	hl, de
	ld	-12 (ix), l
	ld	-11 (ix), h
;D:/mano_projektai/GearRay/platform/game_gear/video.c:570: left_wall_height = left_ray->wall_height;
	ld	l, -7 (ix)
	ld	h, -6 (ix)
	ld	a, (hl)
	ld	-35 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:571: right_wall_height = right_ray->wall_height;
	ld	l, -12 (ix)
	ld	h, -11 (ix)
	ld	a, (hl)
	ld	-34 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:572: left_hit_offset = left_ray->hit_offset;
	ld	c, -7 (ix)
	ld	b, -6 (ix)
	inc	bc
	inc	bc
	ld	a, (bc)
	ld	-33 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:573: right_hit_offset = right_ray->hit_offset;
	ld	c, -12 (ix)
	ld	b, -11 (ix)
	inc	bc
	inc	bc
	ld	a, (bc)
	ld	-32 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:574: left_wall_side = left_ray->hit_side;
	ld	c, -7 (ix)
	ld	b, -6 (ix)
	inc	bc
	ld	a, (bc)
	ld	-31 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:575: right_wall_side = right_ray->hit_side;
	ld	c, -12 (ix)
	ld	b, -11 (ix)
	inc	bc
	ld	a, (bc)
	ld	-30 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:576: current_sprite_column = 0;
	ld	-1 (ix), #0x00
;D:/mano_projektai/GearRay/platform/game_gear/video.c:577: sprite_dirty_column = 0;
	ld	-13 (ix), #0x00
;D:/mano_projektai/GearRay/platform/game_gear/video.c:578: for (sprite_index = 0;
	ld	-10 (ix), #0x00
00198$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:579: sprite_index < projected_sprite_count;
	ld	a, -10 (ix)
	sub	a, -9 (ix)
	jr	nc, 00111$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:583: &projected_sprites[sprite_index], tile_column))
	ld	c, -10 (ix)
	ld	b, #0x00
	ld	l, c
	ld	h, b
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, bc
	ld	-17 (ix), l
	ld	-16 (ix), h
	ex	de, hl
	ld	hl, #48
	add	hl, sp
	add	hl, de
	ld	-15 (ix), l
	ld	-14 (ix), h
	ld	a, -8 (ix)
	push	af
	inc	sp
	ld	l, -15 (ix)
	ld	h, -14 (ix)
	call	_game_gear_sprite_covers_tile_column
	or	a, a
	jr	z, 00199$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:585: current_sprite_column = 1;
	ld	-1 (ix), #0x01
;D:/mano_projektai/GearRay/platform/game_gear/video.c:586: if (sprite_changed_mask & (1U << sprite_index))
	ld	b, -10 (ix)
	ld	hl, #0x0001
	inc	b
	jr	00748$
00747$:
	add	hl, hl
00748$:
	djnz	00747$
	ld	a, l
	and	a, -38 (ix)
	ld	c, a
	ld	a, h
	and	a, -37 (ix)
	or	a, c
	jr	z, 00199$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:587: sprite_dirty_column = 1;
	ld	-13 (ix), #0x01
00199$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:580: ++sprite_index)
	inc	-10 (ix)
	jr	00198$
00111$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:590: for (sprite_index = 0;
	ld	c, #0x00
00201$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:591: sprite_index < previous_projected_sprite_count;
	ld	a, c
	ld	hl, #_previous_projected_sprite_count
	sub	a, (hl)
	jr	nc, 00118$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:595: &previous_projected_sprites[sprite_index], tile_column))
	ld	b, #0x00
	ld	l, c
	ld	h, b
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, bc
	ld	de, #_previous_projected_sprites
	add	hl, de
	push	bc
	ld	a, -8 (ix)
	push	af
	inc	sp
	call	_game_gear_sprite_covers_tile_column
	pop	bc
	or	a, a
	jr	z, 00202$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:597: if (sprite_changed_mask & (1U << sprite_index))
	ld	b, c
	ld	hl, #0x0001
	inc	b
	jr	00750$
00749$:
	add	hl, hl
00750$:
	djnz	00749$
	ld	a, l
	and	a, -38 (ix)
	ld	b, a
	ld	a, h
	and	a, -37 (ix)
	or	a, b
	jr	z, 00202$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:598: sprite_dirty_column = 1;
	ld	-13 (ix), #0x01
00202$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:592: ++sprite_index)
	inc	c
	jr	00201$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:603: GEAR_RAY_PROFILE_INCREMENT(sprite_driven_dirty_columns);
00118$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:611: right_ray->texture_id,
	ld	de, #0x0003
	ld	l, -12 (ix)
	ld	h, -11 (ix)
	add	hl, de
	ld	-29 (ix), l
	ld	-28 (ix), h
	ld	b, (hl)
;D:/mano_projektai/GearRay/platform/game_gear/video.c:610: left_ray->texture_id,
	ld	de, #0x0003
	ld	l, -7 (ix)
	ld	h, -6 (ix)
	add	hl, de
	ld	-27 (ix), l
	ld	-26 (ix), h
	ld	a, (hl)
;D:/mano_projektai/GearRay/platform/game_gear/video.c:605: if (game_gear_wall_column_is_unchanged(previous_wall_column,
	ld	h, -30 (ix)
	push	hl
	inc	sp
	ld	h, -31 (ix)
	ld	l, b
	push	hl
	push	af
	inc	sp
	ld	h, -32 (ix)
	ld	l, -33 (ix)
	push	hl
	ld	h, -34 (ix)
	ld	l, -35 (ix)
	push	hl
	ld	l, -5 (ix)
	ld	h, -4 (ix)
	call	_game_gear_wall_column_is_unchanged
	ld	-12 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:617: && tile_column <= HUD_WEAPON_LAST_TILE_COLUMN))
	ld	a, -8 (ix)
	sub	a, #0x08
	ld	a, #0x00
	rla
	ld	-11 (ix), a
	ld	a, #0x0c
	sub	a, -8 (ix)
	ld	a, #0x00
	rla
	ld	-10 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:605: if (game_gear_wall_column_is_unchanged(previous_wall_column,
	ld	a, -12 (ix)
	or	a, a
	jr	z, 00120$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:614: && !sprite_dirty_column
	ld	a, -13 (ix)
	or	a, a
	jr	nz, 00120$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:615: && !(hud_weapon_changed
	ld	a, -36 (ix)
	or	a, a
	jp	z, 00189$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:617: && tile_column <= HUD_WEAPON_LAST_TILE_COLUMN))
	bit	0, -11 (ix)
	jp	nz, 00189$
	bit	0, -10 (ix)
	jp	nz, 00189$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:619: continue;
00120$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:625: - left_wall_height) / 2;
	ld	a, -35 (ix)
	ld	-13 (ix), a
	ld	-12 (ix), #0x00
	ld	a, #0x40
	sub	a, -13 (ix)
	ld	-15 (ix), a
	sbc	a, a
	ld	-14 (ix), a
	ld	a, -15 (ix)
	ld	-13 (ix), a
	ld	a, -14 (ix)
	ld	-12 (ix), a
	bit	7, -14 (ix)
	jr	z, 00217$
	ld	l, -15 (ix)
	ld	h, -14 (ix)
	inc	hl
	ld	-13 (ix), l
	ld	-12 (ix), h
00217$:
	ld	a, -13 (ix)
	ld	-25 (ix), a
	ld	a, -12 (ix)
	ld	-24 (ix), a
	sra	-24 (ix)
	rr	-25 (ix)
;D:/mano_projektai/GearRay/platform/game_gear/video.c:627: - right_wall_height) / 2;
	ld	a, -34 (ix)
	ld	-13 (ix), a
	ld	-12 (ix), #0x00
	ld	a, #0x40
	sub	a, -13 (ix)
	ld	-15 (ix), a
	sbc	a, a
	ld	-14 (ix), a
	ld	a, -15 (ix)
	ld	-13 (ix), a
	ld	a, -14 (ix)
	ld	-12 (ix), a
	bit	7, -14 (ix)
	jr	z, 00218$
	ld	l, -15 (ix)
	ld	h, -14 (ix)
	inc	hl
	ld	-13 (ix), l
	ld	-12 (ix), h
00218$:
	ld	a, -13 (ix)
	ld	-23 (ix), a
	ld	a, -12 (ix)
	ld	-22 (ix), a
	sra	-22 (ix)
	rr	-23 (ix)
;D:/mano_projektai/GearRay/platform/game_gear/video.c:634: &last_active_row);
;D:/mano_projektai/GearRay/platform/game_gear/video.c:633: &first_active_row,
;D:/mano_projektai/GearRay/platform/game_gear/video.c:629: left_wall_top,
	ld	hl, #3
	add	hl, sp
	push	hl
	dec	hl
	push	hl
	ld	a, -34 (ix)
	push	af
	inc	sp
	ld	l, -23 (ix)
	ld	h, -22 (ix)
	push	hl
	ld	a, -35 (ix)
	push	af
	inc	sp
	ld	l, -25 (ix)
	ld	h, -24 (ix)
	call	_game_gear_get_active_wall_rows
	ld	-21 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:636: if (current_sprite_column)
	ld	a, -1 (ix)
	or	a, a
	jp	z, 00143$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:638: for (sprite_index = 0;
	ld	-1 (ix), #0x00
00204$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:639: sprite_index < projected_sprite_count;
	ld	a, -1 (ix)
	sub	a, -9 (ix)
	jp	nc, 00143$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:643: &projected_sprites[sprite_index], tile_column))
	ld	c, -1 (ix)
	ld	b, #0x00
	ld	l, c
	ld	h, b
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, bc
	ld	-15 (ix), l
	ld	-14 (ix), h
	ex	de, hl
	ld	hl, #48
	add	hl, sp
	add	hl, de
	ld	-13 (ix), l
	ld	-12 (ix), h
	ld	a, -13 (ix)
	ld	-15 (ix), a
	ld	a, -12 (ix)
	ld	-14 (ix), a
	ld	a, -8 (ix)
	push	af
	inc	sp
	ld	l, -15 (ix)
	ld	h, -14 (ix)
	call	_game_gear_sprite_covers_tile_column
	ld	-14 (ix), a
	or	a, a
	jp	z, 00140$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:647: sprite_visible_top = projected_sprites[sprite_index].top;
	ld	a, -13 (ix)
	ld	-15 (ix), a
	ld	a, -12 (ix)
	ld	-14 (ix), a
	ld	l, -15 (ix)
	ld	h, -14 (ix)
	ld	de, #0x0005
	add	hl, de
	ld	a, (hl)
	ld	-15 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-14 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:648: sprite_visible_bottom = projected_sprites[sprite_index].bottom;
	ld	l, -13 (ix)
	ld	h, -12 (ix)
	ld	de, #0x0007
	add	hl, de
	ld	a, (hl)
	ld	-13 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-12 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:649: if (sprite_visible_top < 0)
	bit	7, -14 (ix)
	jr	z, 00128$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:650: sprite_visible_top = 0;
	xor	a, a
	ld	-15 (ix), a
	ld	-14 (ix), a
00128$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:651: if (sprite_visible_bottom > GAME_GEAR_VIEWPORT_PIXEL_HEIGHT)
	ld	a, #0x40
	cp	a, -13 (ix)
	ld	a, #0x00
	sbc	a, -12 (ix)
	jp	po, 00751$
	xor	a, #0x80
00751$:
	jp	p, 00130$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:652: sprite_visible_bottom = GAME_GEAR_VIEWPORT_PIXEL_HEIGHT;
	ld	-13 (ix), #0x40
	ld	-12 (ix), #0
00130$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:653: if (sprite_visible_bottom > sprite_visible_top)
	ld	a, -15 (ix)
	sub	a, -13 (ix)
	ld	a, -14 (ix)
	sbc	a, -12 (ix)
	jp	po, 00752$
	xor	a, #0x80
00752$:
	jp	p, 00140$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:656: (unsigned char)(sprite_visible_top / 8);
	sra	-14 (ix)
	rr	-15 (ix)
	sra	-14 (ix)
	rr	-15 (ix)
	sra	-14 (ix)
	rr	-15 (ix)
	ld	a, -15 (ix)
	ld	-16 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:658: (unsigned char)((sprite_visible_bottom - 1) / 8);
	ld	c, -13 (ix)
	ld	b, -12 (ix)
	dec	bc
	ld	-15 (ix), c
	ld	-14 (ix), b
	ld	a, -15 (ix)
	ld	-13 (ix), a
	ld	a, -14 (ix)
	ld	-12 (ix), a
	bit	7, -14 (ix)
	jr	z, 00220$
	ld	de, #0x0007
	ld	l, -15 (ix)
	ld	h, -14 (ix)
	add	hl, de
	ld	-13 (ix), l
	ld	-12 (ix), h
00220$:
	ld	e, -13 (ix)
	ld	a, -12 (ix)
	sra	a
	rr	e
	sra	a
	rr	e
	sra	a
	rr	e
;D:/mano_projektai/GearRay/platform/game_gear/video.c:659: if (!has_active_wall)
	ld	a, -21 (ix)
	or	a, a
	jr	nz, 00136$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:661: first_active_row = sprite_first_row;
	ld	a, -16 (ix)
	ld	iy, #2
	add	iy, sp
	ld	0 (iy), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:662: last_active_row = sprite_last_row;
	ld	1 (iy), e
;D:/mano_projektai/GearRay/platform/game_gear/video.c:663: has_active_wall = 1;
	ld	-21 (ix), #0x01
	jr	00140$
00136$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:667: if (sprite_first_row < first_active_row)
	ld	a, -16 (ix)
	ld	iy, #2
	add	iy, sp
	sub	a, 0 (iy)
	jr	nc, 00132$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:668: first_active_row = sprite_first_row;
	ld	a, -16 (ix)
	ld	0 (iy), a
00132$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:669: if (sprite_last_row > last_active_row)
	ld	iy, #3
	add	iy, sp
	ld	a, 0 (iy)
	sub	a, e
	jr	nc, 00140$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:670: last_active_row = sprite_last_row;
	ld	0 (iy), e
00140$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:640: ++sprite_index)
	inc	-1 (ix)
	jp	00204$
00143$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:677: && tile_column <= HUD_WEAPON_LAST_TILE_COLUMN)
	ld	a, -11 (ix)
	ld	-20 (ix), a
	bit	0, -11 (ix)
	jr	nz, 00150$
	bit	0, -10 (ix)
	jr	nz, 00150$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:679: if (!has_active_wall)
	ld	a, -21 (ix)
	or	a, a
	jr	nz, 00147$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:680: first_active_row = HUD_WEAPON_FIRST_TILE_ROW;
	ld	iy, #2
	add	iy, sp
	ld	0 (iy), #0x04
	jr	00148$
00147$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:681: else if (first_active_row > HUD_WEAPON_FIRST_TILE_ROW)
	ld	a, #0x04
	ld	iy, #2
	add	iy, sp
	sub	a, 0 (iy)
	jr	nc, 00148$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:682: first_active_row = HUD_WEAPON_FIRST_TILE_ROW;
	ld	0 (iy), #0x04
00148$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:683: last_active_row = HUD_WEAPON_LAST_TILE_ROW;
	ld	iy, #3
	add	iy, sp
	ld	0 (iy), #0x07
;D:/mano_projektai/GearRay/platform/game_gear/video.c:684: has_active_wall = 1;
	ld	-21 (ix), #0x01
00150$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:701: left_flat_rows = &left_lod2_rows[tile_column & 1][0][0];
	ld	a, -8 (ix)
	ld	-12 (ix), a
	ld	-11 (ix), #0x00
;D:/mano_projektai/GearRay/platform/game_gear/video.c:819: SMS_loadTiles(
	ld	l, -12 (ix)
	ld	h, #0x00
	add	hl, hl
	add	hl, hl
	add	hl, hl
	ld	a, l
	add	a, #0x66
	ld	-19 (ix), a
	ld	a, h
	adc	a, #0x00
	ld	-18 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:687: if (has_active_wall)
	ld	a, -21 (ix)
	or	a, a
	jp	z, 00350$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:689: first_screen_y = first_active_row * 8;
	ld	hl, #2
	add	hl, sp
	ld	a, (hl)
	add	a, a
	add	a, a
	add	a, a
	ld	-1 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:691: left_wall_height <= DISTANT_WALL_MAX_PROJECTED_HEIGHT;
	ld	a, #0x10
	sub	a, -35 (ix)
	ld	a, #0x00
	rla
	xor	a, #0x01
	ld	-17 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:693: right_wall_height <= DISTANT_WALL_MAX_PROJECTED_HEIGHT;
	ld	a, #0x10
	sub	a, -34 (ix)
	ld	a, #0x00
	rla
	xor	a, #0x01
	ld	-16 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:701: left_flat_rows = &left_lod2_rows[tile_column & 1][0][0];
	ld	a, -12 (ix)
	and	a, #0x01
	ld	l, a
	ld	h, #0x00
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	ld	-12 (ix), l
	ld	-11 (ix), h
;D:/mano_projektai/GearRay/platform/game_gear/video.c:697: if (left_wall_is_far)
	ld	a, -17 (ix)
	or	a, a
	jr	z, 00156$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:699: if (left_wall_height <= VERY_DISTANT_WALL_MAX_PROJECTED_HEIGHT)
	ld	a, #0x08
	sub	a, -35 (ix)
	jr	c, 00153$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:701: left_flat_rows = &left_lod2_rows[tile_column & 1][0][0];
	ld	a, #<(_left_lod2_rows)
	add	a, -12 (ix)
	ld	c, a
	ld	a, #>(_left_lod2_rows)
	adc	a, -11 (ix)
	ld	-46 (ix), c
	ld	-45 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:702: GEAR_RAY_PROFILE_INCREMENT(lod2_wall_halves_rendered);
	jr	00157$
00153$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:707: ? &left_lod1_x_rows[0][0]
	ld	a, -31 (ix)
	or	a, a
	jr	nz, 00221$
	ld	bc, #_left_lod1_x_rows
	jr	00222$
00221$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:708: : &left_lod1_y_rows[0][0];
	ld	bc, #_left_lod1_y_rows
00222$:
	ld	-46 (ix), c
	ld	-45 (ix), b
;D:/mano_projektai/GearRay/platform/game_gear/video.c:709: GEAR_RAY_PROFILE_INCREMENT(lod1_wall_halves_rendered);
	jr	00157$
00156$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:716: left_ray->texture_id,
	ld	l, -27 (ix)
	ld	h, -26 (ix)
	ld	a, (hl)
;D:/mano_projektai/GearRay/platform/game_gear/video.c:715: &left_sampler,
	ld	h, -1 (ix)
	push	hl
	inc	sp
	ld	l, -25 (ix)
	ld	h, -24 (ix)
	push	hl
	ld	h, -35 (ix)
	push	hl
	inc	sp
	ld	h, -33 (ix)
	push	hl
	inc	sp
	ld	h, -31 (ix)
	push	hl
	inc	sp
	push	af
	inc	sp
	ld	hl, #21
	add	hl, sp
	call	_game_gear_wall_texture_sampler_initialize
00157$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:724: if (right_wall_is_far)
	ld	a, -16 (ix)
	or	a, a
	jr	z, 00162$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:726: if (right_wall_height <= VERY_DISTANT_WALL_MAX_PROJECTED_HEIGHT)
	ld	a, #0x08
	sub	a, -34 (ix)
	jr	c, 00159$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:728: right_flat_rows = &right_lod2_rows[tile_column & 1][0][0];
	ld	a, #<(_right_lod2_rows)
	add	a, -12 (ix)
	ld	c, a
	ld	a, #>(_right_lod2_rows)
	adc	a, -11 (ix)
	ld	-44 (ix), c
	ld	-43 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:729: GEAR_RAY_PROFILE_INCREMENT(lod2_wall_halves_rendered);
	jr	00163$
00159$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:734: ? &right_lod1_x_rows[0][0]
	ld	a, -30 (ix)
	or	a, a
	jr	nz, 00223$
	ld	bc, #_right_lod1_x_rows
	jr	00224$
00223$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:735: : &right_lod1_y_rows[0][0];
	ld	bc, #_right_lod1_y_rows
00224$:
	ld	-44 (ix), c
	ld	-43 (ix), b
;D:/mano_projektai/GearRay/platform/game_gear/video.c:736: GEAR_RAY_PROFILE_INCREMENT(lod1_wall_halves_rendered);
	jr	00163$
00162$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:743: right_ray->texture_id,
	ld	l, -29 (ix)
	ld	h, -28 (ix)
	ld	a, (hl)
;D:/mano_projektai/GearRay/platform/game_gear/video.c:742: &right_sampler,
	ld	h, -1 (ix)
	push	hl
	inc	sp
	ld	l, -23 (ix)
	ld	h, -22 (ix)
	push	hl
	ld	h, -34 (ix)
	push	hl
	inc	sp
	ld	h, -32 (ix)
	push	hl
	inc	sp
	ld	h, -30 (ix)
	push	hl
	inc	sp
	push	af
	inc	sp
	ld	hl, #38
	add	hl, sp
	call	_game_gear_wall_texture_sampler_initialize
00163$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:751: for (row = first_active_row;
	ld	hl, #2
	add	hl, sp
	ld	a, (hl)
	ld	-1 (ix), a
	ld	a, -10 (ix)
	ld	-15 (ix), a
00208$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:755: unsigned char *native_tile =
	ld	iy, #2
	add	iy, sp
	ld	a, 0 (iy)
	dec	iy
	dec	iy
	ld	0 (iy), a
	ld	1 (iy), #0x00
;D:/mano_projektai/GearRay/platform/game_gear/video.c:752: row <= last_active_row;
	ld	hl, #3
	add	hl, sp
	ld	a, (hl)
	sub	a, -1 (ix)
	jp	c, 00172$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:755: unsigned char *native_tile =
	ld	a, -1 (ix)
	ld	-13 (ix), a
	ld	-12 (ix), #0x00
	ld	hl, #0
	add	hl, sp
	ld	a, -13 (ix)
	sub	a, (hl)
	ld	-11 (ix), a
	sbc	a, a
	ld	-10 (ix), a
	ld	a, -11 (ix)
	ld	-13 (ix), a
	ld	a, -10 (ix)
	ld	-12 (ix), a
	ld	b, #0x05
00753$:
	sla	-13 (ix)
	rl	-12 (ix)
	djnz	00753$
	ld	de, #_projected_wall_column
	ld	l, -13 (ix)
	ld	h, -12 (ix)
	add	hl, de
	ld	-11 (ix), l
	ld	-10 (ix), h
	ld	a, -11 (ix)
	ld	-14 (ix), a
	ld	a, -10 (ix)
	ld	-13 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:770: row * 8);
	ld	a, -1 (ix)
	add	a, a
	add	a, a
	add	a, a
	ld	-12 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:768: right_wall_top,
	ld	a, -23 (ix)
	ld	-11 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:765: &right_sampler,
;D:/mano_projektai/GearRay/platform/game_gear/video.c:763: left_wall_top,
	ld	a, -25 (ix)
	ld	-10 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:760: &left_sampler,
;D:/mano_projektai/GearRay/platform/game_gear/video.c:759: native_tile,
	ld	h, -12 (ix)
	ld	l, -34 (ix)
	push	hl
	ld	a, -11 (ix)
	push	af
	inc	sp
	ld	l, -44 (ix)
	ld	h, -43 (ix)
	push	hl
	ld	a, -16 (ix)
	push	af
	inc	sp
	ld	hl, #37
	add	hl, sp
	push	hl
	ld	h, -35 (ix)
	ld	l, -10 (ix)
	push	hl
	ld	l, -46 (ix)
	ld	h, -45 (ix)
	push	hl
	ld	a, -17 (ix)
	push	af
	inc	sp
	ld	hl, #27
	add	hl, sp
	ex	de, hl
	ld	l, -14 (ix)
	ld	h, -13 (ix)
	call	_game_gear_build_native_wall_tile
;D:/mano_projektai/GearRay/platform/game_gear/video.c:778: for (ordered_sprite_index = 0;
	ld	c, #0x00
00206$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:779: ordered_sprite_index < ordered_sprite_count;
	ld	a, c
	ld	hl, #4
	add	hl, sp
	sub	a, (hl)
	jr	nc, 00167$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:782: unsigned char selected =
	ld	e, c
	ld	d, #0x00
	ld	hl, #5
	add	hl, sp
	add	hl, de
	ld	e, (hl)
;D:/mano_projektai/GearRay/platform/game_gear/video.c:787: &projected_sprites[selected],
	ld	d, #0x00
	ld	l, e
	ld	h, d
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, de
	ex	de, hl
	ld	hl, #48
	add	hl, sp
	add	hl, de
	push	hl
	push	bc
	ld	d, -1 (ix)
	ld	e, -8 (ix)
	push	de
	call	_game_gear_sprite_covers_tile
	pop	bc
	pop	hl
	or	a, a
	jr	z, 00166$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:794: native_tile,
	push	bc
	ld	e, -40 (ix)
	ld	d, -39 (ix)
	push	de
	push	hl
	ld	h, -1 (ix)
	ld	l, -8 (ix)
	push	hl
	ld	l, -14 (ix)
	ld	h, -13 (ix)
	call	_game_gear_overlay_sprite_tile
	pop	bc
00166$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:780: ++ordered_sprite_index)
	inc	c
	jr	00206$
00167$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:802: && tile_column <= HUD_WEAPON_LAST_TILE_COLUMN
	bit	0, -20 (ix)
	jr	nz, 00209$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:803: && row >= HUD_WEAPON_FIRST_TILE_ROW)
	bit	0, -15 (ix)
	jr	nz, 00209$
	ld	a, -1 (ix)
	sub	a, #0x04
	jr	c, 00209$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:805: game_gear_overlay_hud_weapon_tile(native_tile,
	ld	h, -1 (ix)
	ld	l, -8 (ix)
	push	hl
	ld	l, -14 (ix)
	ld	h, -13 (ix)
	call	_game_gear_overlay_hud_weapon_tile
00209$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:753: ++row)
	inc	-1 (ix)
	jp	00208$
00172$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:811: active_tile_count = last_active_row - first_active_row + 1;
	ld	hl, #2
	add	hl, sp
	ld	iy, #3
	add	iy, sp
	ld	a, 0 (iy)
	sub	a, (hl)
	inc	a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:819: SMS_loadTiles(
	ld	h, #0x00
	ld	l, a
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	ex	de, hl
	ld	hl, #0
	add	hl, sp
	ld	a, (hl)
	add	a, -19 (ix)
	ld	c, a
	ld	a, #0x00
	adc	a, -18 (ix)
	ld	l, c
	ld	h, a
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	push	de
	ld	de, #_projected_wall_column
	call	_SMS_VRAMmemcpy
;D:/mano_projektai/GearRay/platform/game_gear/video.c:827: for (row = 0; row < GAME_GEAR_VIEWPORT_TILE_ROWS; ++row)
00350$:
	ld	-1 (ix), #0x00
00210$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:830: ? VIEWPORT_TILE_STATE_CEILING
	ld	a, -1 (ix)
	sub	a, #0x04
	ld	a, #0x00
	rla
	ld	c, a
	or	a, a
	jr	z, 00225$
	xor	a, a
	jr	00226$
00225$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:831: : VIEWPORT_TILE_STATE_FLOOR;
	ld	a, #0x01
00226$:
	ld	-14 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:833: if (has_active_wall &&
	ld	a, -21 (ix)
	or	a, a
	jr	z, 00176$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:834: row >= first_active_row &&
	ld	a, -1 (ix)
	ld	iy, #2
	add	iy, sp
	sub	a, 0 (iy)
	jr	c, 00176$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:835: row <= last_active_row)
	ld	a, 1 (iy)
	sub	a, -1 (ix)
	jr	c, 00176$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:837: desired_state = VIEWPORT_TILE_STATE_WALL;
	ld	-14 (ix), #0x02
00176$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:840: if (tile_states[row] == desired_state)
	ld	e, -1 (ix)
	ld	d, #0x00
	ld	l, -3 (ix)
	ld	h, -2 (ix)
	add	hl, de
	ld	-13 (ix), l
	ld	-12 (ix), h
	ld	a, (hl)
	sub	a, -14 (ix)
	jr	z, 00187$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:843: if (desired_state == VIEWPORT_TILE_STATE_WALL)
	ld	a, -14 (ix)
	sub	a, #0x02
	jr	nz, 00182$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:847: + row;
	ld	a, -1 (ix)
	ld	c, #0x00
	add	a, -19 (ix)
	ld	e, a
	ld	a, c
	adc	a, -18 (ix)
	ld	d, a
	jr	00184$
00182$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:851: ? CEILING_TILE_INDEX
	ld	a, c
	or	a, a
	jr	z, 00227$
	ld	-11 (ix), #0x64
	ld	-10 (ix), #0
	jr	00228$
00227$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:852: : FLOOR_TILE_INDEX;
	ld	-11 (ix), #0x65
	ld	-10 (ix), #0
00228$:
	ld	e, -11 (ix)
	ld	d, #0x00
;D:/mano_projektai/GearRay/platform/game_gear/video.c:854: SMS_setTileatXY(
00184$:
	ld	a, -1 (ix)
	add	a, #0x08
	ld	l, a
	ld	h, #0x00
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	ld	a, -8 (ix)
	add	a, #0x09
	ld	b, #0x00
	ld	c, a
	add	hl, bc
	add	hl, hl
	ld	a, h
	or	a, #0x78
	ld	h, a
	rst	#0x08
	ex	de, hl
	rst	#0x18
;D:/mano_projektai/GearRay/platform/game_gear/video.c:861: tile_states[row] = desired_state;
	ld	l, -13 (ix)
	ld	h, -12 (ix)
	ld	a, -14 (ix)
	ld	(hl), a
00187$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:827: for (row = 0; row < GAME_GEAR_VIEWPORT_TILE_ROWS; ++row)
	inc	-1 (ix)
	ld	a, -1 (ix)
	sub	a, #0x08
	jp	c, 00210$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:870: right_ray->texture_id,
	ld	l, -29 (ix)
	ld	h, -28 (ix)
	ld	a, (hl)
;D:/mano_projektai/GearRay/platform/game_gear/video.c:869: left_ray->texture_id,
	ld	l, -27 (ix)
	ld	h, -26 (ix)
	ld	b, (hl)
;D:/mano_projektai/GearRay/platform/game_gear/video.c:864: game_gear_store_wall_column_signature(previous_wall_column,
	ld	h, -30 (ix)
	push	hl
	inc	sp
	ld	h, -31 (ix)
	push	hl
	inc	sp
	push	af
	inc	sp
	push	bc
	inc	sp
	ld	h, -32 (ix)
	ld	l, -33 (ix)
	push	hl
	ld	h, -34 (ix)
	ld	l, -35 (ix)
	push	hl
	ld	l, -5 (ix)
	ld	h, -4 (ix)
	call	_game_gear_store_wall_column_signature
00189$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:563: ++tile_column,
	inc	-8 (ix)
;D:/mano_projektai/GearRay/platform/game_gear/video.c:564: left_ray += 2,
	ld	de, #0x000c
	ld	l, -7 (ix)
	ld	h, -6 (ix)
	add	hl, de
	ld	-7 (ix), l
	ld	-6 (ix), h
;D:/mano_projektai/GearRay/platform/game_gear/video.c:565: ++previous_wall_column,
	ld	de, #0x0007
	ld	l, -5 (ix)
	ld	h, -4 (ix)
	add	hl, de
	ld	-5 (ix), l
	ld	-4 (ix), h
;D:/mano_projektai/GearRay/platform/game_gear/video.c:566: tile_states += GAME_GEAR_VIEWPORT_TILE_ROWS)
	ld	de, #0x0008
	ld	l, -3 (ix)
	ld	h, -2 (ix)
	add	hl, de
	ld	-3 (ix), l
	ld	-2 (ix), h
;D:/mano_projektai/GearRay/platform/game_gear/video.c:562: tile_column < GAME_GEAR_VIEWPORT_TILE_COLUMNS;
	ld	a, -8 (ix)
	sub	a, #0x0e
	jp	c, 00211$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:875: previous_projected_sprite_count = projected_sprite_count;
	ld	a, -9 (ix)
	ld	(#_previous_projected_sprite_count), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:876: for (sprite_index = 0;
	ld	b, #0x00
00213$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:877: sprite_index < projected_sprite_count;
	ld	a, b
	sub	a, -9 (ix)
	jr	nc, 00191$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:881: projected_sprites[sprite_index];
	ld	e, b
	ld	d, #0x00
	ld	l, e
	ld	h, d
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, de
	ex	de, hl
	ld	hl, #48
	add	hl, sp
	add	hl, de
;D:/mano_projektai/GearRay/platform/game_gear/video.c:880: previous_projected_sprites[sprite_index] =
	ld	a, #<(_previous_projected_sprites)
	add	a, e
	ld	c, a
	ld	a, #>(_previous_projected_sprites)
	adc	a, d
	push	bc
	ld	de, #0x0011
	ex	de, hl
	push	hl
	ld	l, c
	ld	h, a
	call	___memcpy
	pop	bc
;D:/mano_projektai/GearRay/platform/game_gear/video.c:878: ++sprite_index)
	inc	b
	jr	00213$
00191$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:883: game_gear_hud_weapon_render_complete();
	call	_game_gear_hud_weapon_render_complete
;D:/mano_projektai/GearRay/platform/game_gear/video.c:885: if (near_bank_mapped)
	ld	a, -42 (ix)
	or	a, a
	jr	z, 00215$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:886: SMS_MAPPER_SLOT2_REGISTER = previous_slot2_page;
	ld	hl, #0xffff
	ld	a, -41 (ix)
	ld	(hl), a
00215$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:888: }
	ld	sp, ix
	pop	ix
	ret
;D:/mano_projektai/GearRay/platform/game_gear/video.c:891: void game_gear_video_draw_viewport_border(void)
;	---------------------------------
; Function game_gear_video_draw_viewport_border
; ---------------------------------
_game_gear_video_draw_viewport_border::
;D:/mano_projektai/GearRay/platform/game_gear/video.c:895: SMS_load1bppTiles(debug_border_tiles,
	ld	hl, #0xc00
	push	hl
	ld	hl, #0x0018
	push	hl
	ld	de, #0x0061
	ld	hl, #_debug_border_tiles
	call	_SMS_load1bppTiles
;D:/mano_projektai/GearRay/platform/game_gear/video.c:901: SMS_setTileatXY(GAME_GEAR_VIEWPORT_BORDER_TILE_LEFT,
	ld	hl, #0x79d0
	rst	#0x08
	ld	hl, #0x0063
	rst	#0x18
;D:/mano_projektai/GearRay/platform/game_gear/video.c:904: SMS_setTileatXY(GAME_GEAR_VIEWPORT_BORDER_TILE_RIGHT,
	ld	hl, #0x79ee
	rst	#0x08
	ld	hl, #0x0263
	rst	#0x18
;D:/mano_projektai/GearRay/platform/game_gear/video.c:907: SMS_setTileatXY(GAME_GEAR_VIEWPORT_BORDER_TILE_LEFT,
	ld	hl, #0x7c10
	rst	#0x08
	ld	hl, #0x0463
	rst	#0x18
;D:/mano_projektai/GearRay/platform/game_gear/video.c:910: SMS_setTileatXY(GAME_GEAR_VIEWPORT_BORDER_TILE_RIGHT,
	ld	hl, #0x7c2e
	rst	#0x08
	ld	hl, #0x0663
	rst	#0x18
;D:/mano_projektai/GearRay/platform/game_gear/video.c:919: SMS_setTileatXY(GAME_GEAR_VIEWPORT_TILE_ORIGIN_X + tile_offset,
	ld	b, #0x00
00113$:
	ld	a, b
	add	a, #0x09
	ld	e, a
	ld	d, #0x00
	ld	hl, #0x00e0
	add	hl, de
	add	hl, hl
	ld	a, h
	or	a, #0x78
	ld	h, a
	rst	#0x08
	ld	hl, #0x0061
	rst	#0x18
;D:/mano_projektai/GearRay/platform/game_gear/video.c:922: SMS_setTileatXY(GAME_GEAR_VIEWPORT_TILE_ORIGIN_X + tile_offset,
	ld	hl, #0x0200
	add	hl, de
	add	hl, hl
	ld	a, h
	or	a, #0x78
	ld	h, a
	rst	#0x08
	ld	hl, #0x0461
	rst	#0x18
;D:/mano_projektai/GearRay/platform/game_gear/video.c:917: ++tile_offset)
	inc	b
;D:/mano_projektai/GearRay/platform/game_gear/video.c:916: tile_offset < GAME_GEAR_VIEWPORT_TILE_COLUMNS;
	ld	a, b
	sub	a, #0x0e
	jr	c, 00113$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:931: SMS_setTileatXY(GAME_GEAR_VIEWPORT_BORDER_TILE_LEFT,
	ld	b, #0x00
00120$:
	ld	a, b
	add	a, #0x08
	ld	h, #0x00
	ld	l, a
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	ex	de, hl
	ld	hl, #0x0008
	add	hl, de
	add	hl, hl
	ld	a, h
	or	a, #0x78
	ld	h, a
	rst	#0x08
	ld	hl, #0x0062
	rst	#0x18
;D:/mano_projektai/GearRay/platform/game_gear/video.c:934: SMS_setTileatXY(GAME_GEAR_VIEWPORT_BORDER_TILE_RIGHT,
	ld	hl, #0x0017
	add	hl, de
	add	hl, hl
	ld	a, h
	or	a, #0x78
	ld	h, a
	rst	#0x08
	ld	hl, #0x0262
	rst	#0x18
;D:/mano_projektai/GearRay/platform/game_gear/video.c:929: ++tile_offset)
	inc	b
;D:/mano_projektai/GearRay/platform/game_gear/video.c:928: tile_offset < GAME_GEAR_VIEWPORT_TILE_ROWS;
	ld	a, b
	sub	a, #0x08
	jr	c, 00120$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:939: }
	ret
	.area _CODE
	.area _BANK1
	.area _INITIALIZER
	.area _CABS (ABS)
