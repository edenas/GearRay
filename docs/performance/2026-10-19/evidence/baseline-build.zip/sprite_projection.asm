;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (MINGW64)
;--------------------------------------------------------
	.module sprite_projection
	
	.optsdcc -mz80 sdcccall(1)
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _raycaster_get_rendered_rays
	.globl _world_sprite_get
	.globl _camera_get_plane_y
	.globl _camera_get_plane_x
	.globl _camera_get_direction_y
	.globl _camera_get_direction_x
	.globl _camera_get_position_y
	.globl _camera_get_position_x
	.globl _game_gear_prepare_world_sprites
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute ram data
;--------------------------------------------------------
	.area _DABS (ABS)
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _BANK1
;D:/mano_projektai/GearRay/game/world_sprite.h:25: static unsigned int zombie_distance_metric(signed int delta_x,
;	---------------------------------
; Function zombie_distance_metric
; ---------------------------------
_zombie_distance_metric:
	ld	c, l
	ld	b, h
;D:/mano_projektai/GearRay/game/world_sprite.h:28: unsigned int distance_x = delta_x < 0
	bit	7, b
	jr	z, 00103$
	xor	a, a
	sub	a, c
	ld	c, a
	sbc	a, a
	sub	a, b
	ld	b, a
00103$:
;D:/mano_projektai/GearRay/game/world_sprite.h:30: unsigned int distance_y = delta_y < 0
	bit	7, d
	jr	z, 00105$
	xor	a, a
	sub	a, e
	ld	l, a
	sbc	a, a
	sub	a, d
	ld	h, a
	jr	00106$
00105$:
	ex	de, hl
00106$:
;D:/mano_projektai/GearRay/game/world_sprite.h:34: ? distance_x + (distance_y >> 1)
	ld	a, l
	sub	a, c
	ld	a, h
	sbc	a, b
	jr	nc, 00107$
	srl	h
	rr	l
	add	hl, bc
	ex	de, hl
	ret
00107$:
;D:/mano_projektai/GearRay/game/world_sprite.h:35: : distance_y + (distance_x >> 1);
	srl	b
	rr	c
	add	hl, bc
	ex	de, hl
;D:/mano_projektai/GearRay/game/world_sprite.h:36: }
	ret
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:115: static const unsigned char *game_gear_get_zombie_lod_pixels(
;	---------------------------------
; Function game_gear_get_zombie_lod_pixels
; ---------------------------------
_game_gear_get_zombie_lod_pixels:
	push	ix
	ld	ix,	#0
	add	ix, sp
	push	af
	push	af
	ld	-2 (ix), l
	ld	-1 (ix), h
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:134: unsigned char pose = WORLD_SPRITE_LIFE_STATE(sprite)
	pop	hl
	pop	bc
	push	bc
	push	hl
	ld	hl, #6
	add	hl, bc
	ld	a, (hl)
	and	a, #0x03
	cp	a, #0x01
	jr	nz, 00103$
	ld	l, #0x03
	jr	00104$
00103$:
	pop	hl
	pop	bc
	push	bc
	push	hl
	ld	hl, #8
	add	hl, bc
	ld	a, (hl)
	or	a, a
	jr	z, 00105$
	pop	hl
	pop	bc
	push	bc
	push	hl
	ld	hl, #7
	add	hl, bc
	ld	a, (hl)
	rrca
	rrca
	rrca
	rrca
	and	a, #0x01
	jr	z, 00107$
	ld	l, #0x01
	jr	00106$
00107$:
	ld	l, #0x02
	jr	00106$
00105$:
	pop	hl
	pop	bc
	push	bc
	push	hl
	ld	hl, #4
	add	hl, bc
	ld	a, (hl)
	ld	-4 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-3 (ix), a
	ld	bc, #_zombie_01_walking_01_pixels+0
	pop	hl
	push	hl
	xor	a, a
	sbc	hl, bc
	jr	nz, 00109$
	ld	l, #0x04
	jr	00110$
00109$:
	ld	bc, #_zombie_01_walking_02_pixels+0
	pop	hl
	push	hl
	xor	a, a
	sbc	hl, bc
	ld	l, #0x05
	jr	z, 00112$
	ld	l, #0x00
00112$:
00110$:
00106$:
00104$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:144: return medium ? medium_pixels[pose] : simple_pixels[pose];
	ld	h, #0x00
	add	hl, hl
	ld	c, l
	ld	b, h
	ld	a, 4 (ix)
	or	a, a
	jr	z, 00113$
	ld	hl, #_game_gear_get_zombie_lod_pixels_medium_pixels_10000_47+0
	add	hl, bc
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	jr	00114$
00113$:
	ld	hl, #_game_gear_get_zombie_lod_pixels_simple_pixels_10000_47
	add	hl, bc
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
00114$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:145: }
	ld	sp, ix
	pop	ix
	pop	hl
	inc	sp
	jp	(hl)
	.area _BANK1
	.area _BANK1
_shotgun_far_pixels:
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xdd	; 221
	.db #0xdd	; 221
	.db #0xdd	; 221
	.db #0xff	; 255
	.db #0xfd	; 253
	.db #0xdd	; 221
	.db #0xdd	; 221
	.db #0xdd	; 221
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xfd	; 253
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.area _BANK1
	.area _BANK1
_zombie_standing_medium_lod_pixels:
	.db #0xff	; 255
	.db #0xfd	; 253
	.db #0xdf	; 223
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xfd	; 253
	.db #0xdf	; 223
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xdd	; 221
	.db #0xdd	; 221
	.db #0xff	; 255
	.db #0xfd	; 253
	.db #0xdd	; 221
	.db #0xda	; 218
	.db #0xdf	; 223
	.db #0xdf	; 223
	.db #0xdd	; 221
	.db #0xdd	; 221
	.db #0xfd	; 253
	.db #0xdf	; 223
	.db #0xda	; 218
	.db #0xdd	; 221
	.db #0xfd	; 253
	.db #0xff	; 255
	.db #0xdf	; 223
	.db #0xfd	; 253
	.db #0xff	; 255
	.db #0xfd	; 253
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xdf	; 223
	.area _BANK1
	.area _BANK1
_zombie_standing_simple_lod_pixels:
	.db #0xff	; 255
	.db #0xfd	; 253
	.db #0xdf	; 223
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xfd	; 253
	.db #0xdf	; 223
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xfd	; 253
	.db #0xdf	; 223
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xdd	; 221
	.db #0xdd	; 221
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xfd	; 253
	.db #0xdf	; 223
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xfd	; 253
	.db #0xdf	; 223
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xdf	; 223
	.db #0xfd	; 253
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xdf	; 223
	.db #0xfd	; 253
	.db #0xff	; 255
	.area _BANK1
	.area _BANK1
_zombie_shot_01_medium_lod_pixels:
	.db #0xfa	; 250
	.db #0xfd	; 253
	.db #0xdf	; 223
	.db #0xff	; 255
	.db #0xfd	; 253
	.db #0xfd	; 253
	.db #0xdf	; 223
	.db #0xdf	; 223
	.db #0xfd	; 253
	.db #0xdd	; 221
	.db #0xdd	; 221
	.db #0xdf	; 223
	.db #0xff	; 255
	.db #0xdd	; 221
	.db #0xdd	; 221
	.db #0xdf	; 223
	.db #0xff	; 255
	.db #0xdd	; 221
	.db #0xdd	; 221
	.db #0xfd	; 253
	.db #0xdf	; 223
	.db #0xdd	; 221
	.db #0xdd	; 221
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xdf	; 223
	.db #0xdf	; 223
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xfd	; 253
	.db #0xfd	; 253
	.db #0xff	; 255
	.area _BANK1
	.area _BANK1
_zombie_shot_01_simple_lod_pixels:
	.db #0xff	; 255
	.db #0xfd	; 253
	.db #0xdf	; 223
	.db #0xff	; 255
	.db #0xfd	; 253
	.db #0xfd	; 253
	.db #0xdf	; 223
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xdd	; 221
	.db #0xdd	; 221
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xdd	; 221
	.db #0xdd	; 221
	.db #0xdf	; 223
	.db #0xff	; 255
	.db #0xfd	; 253
	.db #0xdd	; 221
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xfd	; 253
	.db #0xdf	; 223
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xfd	; 253
	.db #0xfd	; 253
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xfd	; 253
	.db #0xfd	; 253
	.db #0xff	; 255
	.area _BANK1
	.area _BANK1
_zombie_shot_02_medium_lod_pixels:
	.db #0xff	; 255
	.db #0xfd	; 253
	.db #0xdf	; 223
	.db #0xda	; 218
	.db #0xdf	; 223
	.db #0xfd	; 253
	.db #0xdf	; 223
	.db #0xdf	; 223
	.db #0xfd	; 253
	.db #0xdd	; 221
	.db #0xdd	; 221
	.db #0xdf	; 223
	.db #0xfd	; 253
	.db #0xdd	; 221
	.db #0xdf	; 223
	.db #0xff	; 255
	.db #0xdf	; 223
	.db #0xdd	; 221
	.db #0xdd	; 221
	.db #0xff	; 255
	.db #0xdf	; 223
	.db #0xdd	; 221
	.db #0xdd	; 221
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xdf	; 223
	.db #0xdf	; 223
	.db #0xdf	; 223
	.db #0xff	; 255
	.db #0xdf	; 223
	.db #0xdf	; 223
	.db #0xff	; 255
	.area _BANK1
	.area _BANK1
_zombie_shot_02_simple_lod_pixels:
	.db #0xff	; 255
	.db #0xfd	; 253
	.db #0xdf	; 223
	.db #0xdf	; 223
	.db #0xff	; 255
	.db #0xfd	; 253
	.db #0xdf	; 223
	.db #0xdf	; 223
	.db #0xff	; 255
	.db #0xdd	; 221
	.db #0xdd	; 221
	.db #0xdf	; 223
	.db #0xfd	; 253
	.db #0xdd	; 221
	.db #0xdf	; 223
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xfd	; 253
	.db #0xdd	; 221
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xfd	; 253
	.db #0xdd	; 221
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xdf	; 223
	.db #0xdf	; 223
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xdf	; 223
	.db #0xdf	; 223
	.db #0xff	; 255
	.area _BANK1
	.area _BANK1
_zombie_shot_dead_medium_lod_pixels:
	.db #0xff	; 255
	.db #0xfd	; 253
	.db #0xdf	; 223
	.db #0xdf	; 223
	.db #0xfd	; 253
	.db #0xfd	; 253
	.db #0xdf	; 223
	.db #0xfd	; 253
	.db #0xdf	; 223
	.db #0xdd	; 221
	.db #0xdd	; 221
	.db #0xff	; 255
	.db #0xad	; 173
	.db #0xdd	; 221
	.db #0xdd	; 221
	.db #0xdd	; 221
	.db #0xff	; 255
	.db #0xdd	; 221
	.db #0xdd	; 221
	.db #0xfd	; 253
	.db #0xdf	; 223
	.db #0xdd	; 221
	.db #0xdd	; 221
	.db #0xdf	; 223
	.db #0xff	; 255
	.db #0xdf	; 223
	.db #0xdd	; 221
	.db #0xfd	; 253
	.db #0xfd	; 253
	.db #0xfd	; 253
	.db #0xff	; 255
	.db #0xdf	; 223
	.area _BANK1
	.area _BANK1
_zombie_shot_dead_simple_lod_pixels:
	.db #0xff	; 255
	.db #0xfd	; 253
	.db #0xdf	; 223
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xfd	; 253
	.db #0xdf	; 223
	.db #0xdf	; 223
	.db #0xfd	; 253
	.db #0xfd	; 253
	.db #0xdd	; 221
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xdd	; 221
	.db #0xdd	; 221
	.db #0xdd	; 221
	.db #0xff	; 255
	.db #0xdd	; 221
	.db #0xdd	; 221
	.db #0xdf	; 223
	.db #0xff	; 255
	.db #0xfd	; 253
	.db #0xdd	; 221
	.db #0xdf	; 223
	.db #0xff	; 255
	.db #0xdf	; 223
	.db #0xdd	; 221
	.db #0xff	; 255
	.db #0xfd	; 253
	.db #0xfd	; 253
	.db #0xff	; 255
	.db #0xdf	; 223
	.area _BANK1
	.area _BANK1
_zombie_corpse_lod_pixels:
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xdd	; 221
	.db #0xdd	; 221
	.db #0xff	; 255
	.db #0xfd	; 253
	.db #0xdd	; 221
	.db #0xdd	; 221
	.db #0xdf	; 223
	.db #0xdd	; 221
	.db #0xdd	; 221
	.db #0xdd	; 221
	.db #0xdd	; 221
	.area _BANK1
	.area _BANK1
_game_gear_get_zombie_lod_pixels_medium_pixels_10000_47:
	.dw _zombie_standing_medium_lod_pixels
	.dw _zombie_shot_01_medium_lod_pixels
	.dw _zombie_shot_02_medium_lod_pixels
	.dw _zombie_shot_dead_medium_lod_pixels
	.dw _zombie_01_walking_01_pixels_medium_lod
	.dw _zombie_01_walking_02_pixels_medium_lod
	.area _BANK1
	.area _BANK1
_game_gear_get_zombie_lod_pixels_simple_pixels_10000_47:
	.dw _zombie_standing_simple_lod_pixels
	.dw _zombie_shot_01_simple_lod_pixels
	.dw _zombie_shot_02_simple_lod_pixels
	.dw _zombie_shot_dead_simple_lod_pixels
	.dw _zombie_01_walking_01_pixels_simple_lod
	.dw _zombie_01_walking_02_pixels_simple_lod
	.area _BANK1
	.area _BANK1
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:147: static unsigned char game_gear_get_sprite_render_cost(
;	---------------------------------
; Function game_gear_get_sprite_render_cost
; ---------------------------------
_game_gear_get_sprite_render_cost:
	push	ix
	ld	ix,	#0
	add	ix, sp
	push	af
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:150: unsigned int projected_height =
	ld	e, l
	ld	d, h
	inc	hl
	inc	hl
	inc	hl
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	ld	l, e
	ld	h, d
	inc	hl
	ld	a, (hl)
	inc	hl
	ld	h, (hl)
	ld	l, a
	ld	a, c
	sub	a, l
	ld	c, a
	ld	a, b
	sbc	a, h
	ld	b, a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:153: if (projected->near_texture_id != NEAR_ZOMBIE_TEXTURE_NONE)
	push	de
	pop	iy
	ld	l, 15 (iy)
	inc	l
	jr	z, 00102$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:154: return 8;
	ld	a, #0x08
	jr	00113$
00102$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:155: if (projected->pixels == shotgun_far_pixels) return 1;
	ld	hl, #13
	add	hl, de
	ld	a, (hl)
	ld	-2 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-1 (ix), a
	ld	de, #_shotgun_far_pixels
	pop	hl
	push	hl
	xor	a, a
	sbc	hl, de
	jr	nz, 00104$
	ld	a, #0x01
	jr	00113$
00104$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:156: if (projected->pixels == shotgun_world_pixels) return 2;
	ld	de, #_shotgun_world_pixels
	pop	hl
	push	hl
	xor	a, a
	sbc	hl, de
	jr	nz, 00106$
	ld	a, #0x02
	jr	00113$
00106$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:157: if (projected->pixels == zombie_corpse_lod_pixels)
	ld	de, #_zombie_corpse_lod_pixels
	pop	hl
	push	hl
	xor	a, a
	sbc	hl, de
	jr	nz, 00108$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:158: return 1;
	ld	a, #0x01
	jr	00113$
00108$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:159: if (projected_height >= SPRITE_FULL_DETAIL_MIN_HEIGHT)
	ld	a, c
	sub	a, #0x11
	ld	a, b
	sbc	a, #0x00
	jr	c, 00110$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:160: return 5;
	ld	a, #0x05
	jr	00113$
00110$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:161: if (projected_height >= SPRITE_MEDIUM_LOD_MIN_HEIGHT)
	ld	a, c
	sub	a, #0x0f
	jr	c, 00112$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:162: return 2;
	ld	a, #0x02
	jr	00113$
00112$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:163: return 1;
	ld	a, #0x01
00113$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:164: }
	ld	sp, ix
	pop	ix
	ret
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:166: static unsigned char game_gear_projected_sprite_changed(
;	---------------------------------
; Function game_gear_projected_sprite_changed
; ---------------------------------
_game_gear_projected_sprite_changed:
	push	ix
	ld	ix,	#0
	add	ix, sp
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:170: if (current->visible != previous->visible)
	push	hl
	ld	c, (hl)
	ld	a, (de)
	sub	a, c
	jr	z, 00102$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:171: return 1;
	ld	a, #0x01
	jp	00105$
00102$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:172: if (!current->visible)
	ld	a, c
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:173: return 0;
	or	a,a
	jp	z, 00105$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:175: return current->left != previous->left
	pop	hl
	push	hl
	inc	hl
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	ld	l, e
	ld	h, d
	inc	hl
	ld	a, (hl)
	inc	hl
	ld	h, (hl)
	ld	l, a
	xor	a, a
	sbc	hl, bc
	jp	nz, 00108$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:176: || current->right != previous->right
	pop	hl
	push	hl
	inc	hl
	inc	hl
	inc	hl
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	ld	l, e
	ld	h, d
	inc	hl
	inc	hl
	inc	hl
	ld	a, (hl)
	inc	hl
	ld	h, (hl)
	ld	l, a
	xor	a, a
	sbc	hl, bc
	jp	nz, 00108$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:177: || current->top != previous->top
	pop	bc
	push	bc
	ld	hl, #5
	add	hl, bc
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	ld	l, e
	ld	h, d
	inc	hl
	inc	hl
	inc	hl
	inc	hl
	inc	hl
	ld	a, (hl)
	inc	hl
	ld	h, (hl)
	ld	l, a
	xor	a, a
	sbc	hl, bc
	jr	nz, 00108$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:178: || current->bottom != previous->bottom
	pop	bc
	push	bc
	ld	hl, #7
	add	hl, bc
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	ld	l, e
	ld	h, d
	push	bc
	ld	bc, #0x0007
	add	hl, bc
	pop	bc
	ld	a, (hl)
	inc	hl
	ld	h, (hl)
	ld	l, a
	xor	a, a
	sbc	hl, bc
	jr	nz, 00108$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:179: || current->depth != previous->depth
	pop	bc
	push	bc
	ld	hl, #9
	add	hl, bc
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	ld	l, e
	ld	h, d
	push	bc
	ld	bc, #0x0009
	add	hl, bc
	pop	bc
	ld	a, (hl)
	inc	hl
	ld	h, (hl)
	ld	l, a
	xor	a, a
	sbc	hl, bc
	jr	nz, 00108$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:180: || current->pixels != previous->pixels
	pop	bc
	push	bc
	ld	hl, #13
	add	hl, bc
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	ld	l, e
	ld	h, d
	push	bc
	ld	bc, #0x000d
	add	hl, bc
	pop	bc
	ld	a, (hl)
	inc	hl
	ld	h, (hl)
	ld	l, a
	xor	a, a
	sbc	hl, bc
	jr	nz, 00108$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:181: || current->near_texture_id != previous->near_texture_id
	pop	bc
	push	bc
	ld	hl, #15
	add	hl, bc
	ld	a, (hl)
	ld	c, e
	ld	b, d
	ld	hl, #15
	add	hl, bc
	sub	a, (hl)
	jr	nz, 00108$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:182: || current->source_size != previous->source_size;
	pop	bc
	push	bc
	ld	hl, #16
	add	hl, bc
	ld	a, (hl)
	ld	hl, #16
	add	hl, de
	sub	a, (hl)
	jr	z, 00109$
00108$:
	ld	a, #0x01
00109$:
00105$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:183: }
	ld	sp, ix
	pop	ix
	ret
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:185: static unsigned char game_gear_get_zombie_presentation_pose(
;	---------------------------------
; Function game_gear_get_zombie_presentation_pose
; ---------------------------------
_game_gear_get_zombie_presentation_pose:
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	iy, #-9
	add	iy, sp
	ld	sp, iy
	ld	-2 (ix), l
	ld	-1 (ix), h
	ld	-4 (ix), e
	ld	-3 (ix), d
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:188: if (WORLD_SPRITE_LIFE_STATE(sprite) == ZOMBIE_STATE_CORPSE)
	ld	a, -2 (ix)
	ld	-9 (ix), a
	ld	a, -1 (ix)
	ld	-8 (ix), a
	pop	hl
	push	hl
	ld	de, #0x0006
	add	hl, de
	ld	a, (hl)
	ld	-6 (ix), a
	and	a, #0x03
	ld	-5 (ix), a
	sub	a, #0x02
	jr	nz, 00102$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:189: return ZOMBIE_PRESENTATION_CORPSE;
	ld	a, #0x05
	jp	00115$
00102$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:190: if (WORLD_SPRITE_LIFE_STATE(sprite) == ZOMBIE_STATE_SHOT_DEAD)
	ld	a, -5 (ix)
	dec	a
	jr	nz, 00104$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:191: return ZOMBIE_PRESENTATION_DEAD;
	ld	a, #0x04
	jr	00115$
00104$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:192: if (sprite->state_timer != 0
	ld	c, -2 (ix)
	ld	b, -1 (ix)
	ld	hl, #8
	add	hl, bc
	ld	c, (hl)
	ld	a, c
	or	a, a
	jr	z, 00106$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:193: && (sprite->pixels == zombie_01_shot_01_pixels
	ld	e, -2 (ix)
	ld	d, -1 (ix)
	ld	hl, #4
	add	hl, de
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	ld	hl, #_zombie_01_shot_01_pixels+0
	xor	a, a
	sbc	hl, de
	jr	z, 00105$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:194: || sprite->pixels == zombie_01_shot_02_pixels))
	ld	hl, #_zombie_01_shot_02_pixels+0
	xor	a, a
	sbc	hl, de
	jr	nz, 00106$
00105$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:196: return ZOMBIE_PRESENTATION_SHOT;
	ld	a, #0x03
	jr	00115$
00106$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:198: if (distance <= ZOMBIE_ATTACK_DISTANCE)
	ld	a, #0x18
	cp	a, -4 (ix)
	ld	a, #0x01
	sbc	a, -3 (ix)
	jr	c, 00112$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:200: if (sprite->state_timer
	ld	a, c
	sub	a, #0x03
	jr	nz, 00110$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:203: return sprite->state & ZOMBIE_ATTACK_PHASE_MASK
	bit	6, -6 (ix)
	jr	z, 00117$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:204: ? ZOMBIE_PRESENTATION_ATTACK_01
	ld	-5 (ix), #0x07
	jr	00118$
00117$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:205: : ZOMBIE_PRESENTATION_ATTACK_02;
	ld	-5 (ix), #0x08
00118$:
	ld	a, -5 (ix)
	jr	00115$
00110$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:207: return ZOMBIE_PRESENTATION_STANDING_ATTACK;
	ld	a, #0x06
	jr	00115$
00112$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:209: if (sprite->health_and_hit_count & ZOMBIE_AI_CHASING_MASK)
	ld	c, -2 (ix)
	ld	b, -1 (ix)
	ld	hl, #7
	add	hl, bc
	ld	a, (hl)
	rlca
	jr	nc, 00114$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:211: return sprite->state & ZOMBIE_WALKING_PHASE_MASK
	bit	7, -6 (ix)
	jr	z, 00119$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:212: ? ZOMBIE_PRESENTATION_WALKING_02
	ld	a, #0x02
	jr	00115$
00119$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:213: : ZOMBIE_PRESENTATION_WALKING_01;
	ld	a, #0x01
	jr	00115$
00114$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:215: return ZOMBIE_PRESENTATION_STANDING;
	xor	a, a
00115$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:216: }
	ld	sp, ix
	pop	ix
	ret
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:218: static const unsigned char *game_gear_get_middle_zombie_pixels(
;	---------------------------------
; Function game_gear_get_middle_zombie_pixels
; ---------------------------------
_game_gear_get_middle_zombie_pixels:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:221: switch (pose)
	or	a, a
	jr	z, 00101$
	cp	a, #0x02
	jr	z, 00102$
	cp	a, #0x03
	jr	z, 00103$
	cp	a, #0x04
	jr	z, 00104$
	cp	a, #0x05
	jr	z, 00105$
	jr	00106$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:223: case ZOMBIE_PRESENTATION_STANDING:
00101$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:224: return zombie_middle_standing_pixels;
	ld	de, #_zombie_middle_standing_pixels
	ret
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:225: case ZOMBIE_PRESENTATION_WALKING_02:
00102$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:226: return zombie_middle_walking_02_pixels;
	ld	de, #_zombie_middle_walking_02_pixels
	ret
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:227: case ZOMBIE_PRESENTATION_SHOT:
00103$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:228: return zombie_middle_shot_01_pixels;
	ld	de, #_zombie_middle_shot_01_pixels
	ret
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:229: case ZOMBIE_PRESENTATION_DEAD:
00104$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:230: return zombie_middle_shot_dead_pixels;
	ld	de, #_zombie_middle_shot_dead_pixels
	ret
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:231: case ZOMBIE_PRESENTATION_CORPSE:
00105$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:232: return zombie_middle_corps_pixels;
	ld	de, #_zombie_middle_corps_pixels
	ret
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:233: default:
00106$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:234: return zombie_middle_walking_01_pixels;
	ld	de, #_zombie_middle_walking_01_pixels
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:235: }
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:236: }
	ret
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:238: static unsigned char game_gear_get_near_zombie_texture_id(
;	---------------------------------
; Function game_gear_get_near_zombie_texture_id
; ---------------------------------
_game_gear_get_near_zombie_texture_id:
	ld	c, a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:241: switch (pose)
	ld	a, #0x08
	sub	a, c
	jr	c, 00108$
	ld	b, #0x00
	ld	hl, #00120$
	add	hl, bc
	add	hl, bc
	ld	c, (hl)
	inc	hl
	ld	h, (hl)
	ld	l, c
	jp	(hl)
00120$:
	.dw	00108$
	.dw	00108$
	.dw	00101$
	.dw	00103$
	.dw	00103$
	.dw	00104$
	.dw	00105$
	.dw	00106$
	.dw	00107$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:243: case ZOMBIE_PRESENTATION_WALKING_02:
00101$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:244: return NEAR_ZOMBIE_TEXTURE_WALKING_02;
	ld	a, #0x01
	ret
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:246: case ZOMBIE_PRESENTATION_DEAD:
00103$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:247: return NEAR_ZOMBIE_TEXTURE_SHOT_01;
	ld	a, #0x05
	ret
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:248: case ZOMBIE_PRESENTATION_CORPSE:
00104$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:249: return NEAR_ZOMBIE_TEXTURE_CORPSE;
	ld	a, #0x06
	ret
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:250: case ZOMBIE_PRESENTATION_STANDING_ATTACK:
00105$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:251: return NEAR_ZOMBIE_TEXTURE_STANDING_ATTACK;
	ld	a, #0x02
	ret
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:252: case ZOMBIE_PRESENTATION_ATTACK_01:
00106$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:253: return NEAR_ZOMBIE_TEXTURE_ATTACK_01;
	ld	a, #0x03
	ret
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:254: case ZOMBIE_PRESENTATION_ATTACK_02:
00107$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:255: return NEAR_ZOMBIE_TEXTURE_ATTACK_02;
	ld	a, #0x04
	ret
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:256: default:
00108$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:257: return NEAR_ZOMBIE_TEXTURE_WALKING_01;
	xor	a, a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:258: }
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:259: }
	ret
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:272: static void game_gear_project_world_sprite(
;	---------------------------------
; Function game_gear_project_world_sprite
; ---------------------------------
_game_gear_project_world_sprite:
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	iy, #-44
	add	iy, sp
	ld	sp, iy
	ld	-7 (ix), l
	ld	-6 (ix), h
	ld	-9 (ix), e
	ld	-8 (ix), d
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:283: signed int relative_x =
	ld	a, -6 (ix)
	or	a, -7 (ix)
	jr	z, 00161$
	ld	l, -7 (ix)
	ld	h, -6 (ix)
	ld	c, (hl)
	inc	hl
	ld	h, (hl)
	jr	00162$
00161$:
	ld	a, (_shotgun_cell_x)
	ld	h, a
	ld	c, #0x80
00162$:
	ld	e, 4 (ix)
	ld	d, 5 (ix)
	ld	a, c
	sub	a, e
	ld	-23 (ix), a
	ld	a, h
	sbc	a, d
	ld	-22 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:286: signed int relative_y =
	ld	a, -6 (ix)
	or	a, -7 (ix)
	jr	z, 00163$
	ld	l, -7 (ix)
	ld	h, -6 (ix)
	inc	hl
	inc	hl
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	jr	00164$
00163$:
	ld	a, (_shotgun_cell_y)
	ld	b, a
	ld	c, #0x80
00164$:
	ld	e, 6 (ix)
	ld	d, 7 (ix)
	ld	a, c
	sub	a, e
	ld	-3 (ix), a
	ld	a, b
	sbc	a, d
	ld	-2 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:292: unsigned int distance = 0;
	xor	a, a
	ld	-18 (ix), a
	ld	-17 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:297: signed int bottom = 0;
	xor	a, a
	ld	-5 (ix), a
	ld	-4 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:303: unsigned char presentation_pose = 0;
	ld	-16 (ix), #0x00
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:306: projected->visible = 0;
	ld	a, -9 (ix)
	ld	-41 (ix), a
	ld	a, -8 (ix)
	ld	-40 (ix), a
	ld	l, -41 (ix)
	ld	h, -40 (ix)
	ld	(hl), #0x00
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:307: projected->left = 0;
	ld	l, -9 (ix)
	ld	h, -8 (ix)
	inc	hl
	ld	-39 (ix), l
	ld	-38 (ix), h
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:308: projected->right = 0;
	ld	de, #0x0003
	ld	l, -9 (ix)
	ld	h, -8 (ix)
	add	hl, de
	ld	-37 (ix), l
	ld	-36 (ix), h
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:309: projected->top = 0;
	ld	de, #0x0005
	ld	l, -9 (ix)
	ld	h, -8 (ix)
	add	hl, de
	ld	-35 (ix), l
	ld	-34 (ix), h
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:310: projected->bottom = 0;
	ld	de, #0x0007
	ld	l, -9 (ix)
	ld	h, -8 (ix)
	add	hl, de
	ld	-33 (ix), l
	ld	-32 (ix), h
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:311: projected->texture_step = 0;
	ld	de, #0x000b
	ld	l, -9 (ix)
	ld	h, -8 (ix)
	add	hl, de
	ld	-31 (ix), l
	ld	-30 (ix), h
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:312: projected->pixels = shotgun_far_pixels;
	ld	de, #0x000d
	ld	l, -9 (ix)
	ld	h, -8 (ix)
	add	hl, de
	ld	-15 (ix), l
	ld	-14 (ix), h
	ld	(hl), #<(_shotgun_far_pixels)
	inc	hl
	ld	(hl), #>(_shotgun_far_pixels)
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:313: if (sprite) projected->pixels = sprite->pixels;
	ld	a, -6 (ix)
	or	a, -7 (ix)
	jr	z, 00102$
	ld	c, -7 (ix)
	ld	b, -6 (ix)
	ld	hl, #4
	add	hl, bc
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	ld	l, -15 (ix)
	ld	h, -14 (ix)
	ld	(hl), c
	inc	hl
	ld	(hl), b
00102$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:314: projected->near_texture_id = NEAR_ZOMBIE_TEXTURE_NONE;
	ld	de, #0x000f
	ld	l, -9 (ix)
	ld	h, -8 (ix)
	add	hl, de
	ld	-29 (ix), l
	ld	-28 (ix), h
	ld	(hl), #0xff
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:315: projected->source_size = 8;
	ld	de, #0x0010
	ld	l, -9 (ix)
	ld	h, -8 (ix)
	add	hl, de
	ld	-27 (ix), l
	ld	-26 (ix), h
	ld	(hl), #0x08
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:316: if (determinant == 0)
	ld	a, 19 (ix)
	or	a, 18 (ix)
	or	a, 17 (ix)
	or	a, 16 (ix)
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:317: return;
	jp	z, 00159$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:319: depth = ((signed long)plane_x * relative_y
	ld	l, 12 (ix)
	ld	h, 13 (ix)
	ld	a, -3 (ix)
	ld	-44 (ix), a
	ld	a, -2 (ix)
	ld	-43 (ix), a
	rlca
	sbc	a, a
	ld	-42 (ix), a
	pop	de
	push	de
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:320: - (signed long)relative_x * plane_y) * 256L
	call	___mulsint2slong
	ld	-13 (ix), e
	ld	-12 (ix), d
	ld	-11 (ix), l
	ld	-10 (ix), h
	ld	a, -23 (ix)
	ld	-21 (ix), a
	ld	a, -22 (ix)
	ld	-20 (ix), a
	rlca
	sbc	a, a
	ld	-19 (ix), a
	ld	e, 14 (ix)
	ld	d, 15 (ix)
	ld	l, -21 (ix)
	ld	h, -20 (ix)
	call	___mulsint2slong
	ex	de, hl
	ld	a, -13 (ix)
	sub	a, l
	ld	c, a
	ld	a, -12 (ix)
	sbc	a, h
	ld	b, a
	ld	l, -11 (ix)
	ld	h, -10 (ix)
	sbc	hl, de
	ld	d, c
	ld	h, l
	ld	l, b
	ld	e, #0x00
	ld	c, 18 (ix)
	ld	b, 19 (ix)
	push	bc
	ld	c, 16 (ix)
	ld	b, 17 (ix)
	push	bc
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:322: if (depth <= SPRITE_NEAR_PLANE_DEPTH || depth > 65535L)
	call	__divslong
	pop	af
	pop	af
	ld	-13 (ix), e
	ld	-12 (ix), d
	ld	-11 (ix), l
	ld	-10 (ix), h
	ld	a, #0x20
	cp	a, -13 (ix)
	ld	a, #0x00
	sbc	a, -12 (ix)
	ld	a, #0x00
	sbc	a, -11 (ix)
	ld	a, #0x00
	sbc	a, -10 (ix)
	jp	po, 00494$
	xor	a, #0x80
00494$:
	jp	p, 00159$
	ld	a, #0xff
	cp	a, -13 (ix)
	sbc	a, -12 (ix)
	ld	a, #0x00
	sbc	a, -11 (ix)
	ld	a, #0x00
	sbc	a, -10 (ix)
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:323: return;
	jp	c, 00159$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:325: projected->depth = (unsigned int)depth;
	ld	de, #0x0009
	ld	l, -9 (ix)
	ld	h, -8 (ix)
	add	hl, de
	ld	-25 (ix), l
	ld	-24 (ix), h
	ld	c, -13 (ix)
	ld	b, -12 (ix)
	ld	l, -25 (ix)
	ld	h, -24 (ix)
	ld	(hl), c
	inc	hl
	ld	(hl), b
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:326: life_state = ZOMBIE_STATE_ALIVE;
	ld	-1 (ix), #0x00
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:327: if (sprite)
	ld	a, -6 (ix)
	or	a, -7 (ix)
	jp	z, 00116$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:329: life_state = WORLD_SPRITE_LIFE_STATE(sprite);
	ld	c, -7 (ix)
	ld	b, -6 (ix)
	ld	hl, #6
	add	hl, bc
	ld	a, (hl)
	and	a, #0x03
	ld	-1 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:331: (unsigned long)((signed long)relative_x * relative_x)
	ld	e, -21 (ix)
	ld	d, -20 (ix)
	ld	l, e
	ld	h, d
	call	___mulsint2slong
	ld	c, e
	ld	b, d
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:332: + (unsigned long)((signed long)relative_y * relative_y);
	pop	de
	push	de
	push	hl
	push	bc
	ld	l, e
	ld	h, d
	call	___mulsint2slong
	push	hl
	pop	iy
	pop	bc
	pop	hl
	ld	a, c
	add	a, e
	ld	c, a
	ld	a, b
	adc	a, d
	ld	b, a
	push	iy
	ld	a, -46 (ix)
	pop	iy
	adc	a, l
	ld	e, a
	push	iy
	ld	a, -45 (ix)
	pop	iy
	adc	a, h
	ld	d, a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:333: if (distance_squared > SPRITE_VISIBLE_MAX_DISTANCE_SQUARED)
	ld	a, #0x90
	cp	a, c
	ld	a, #0x39
	sbc	a, b
	ld	hl, #0x0018
	sbc	hl, de
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:334: return;
	jp	c, 00159$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:336: && projected->depth <= SPRITE_CORPSE_CLOSE_HIDDEN_MAX_DEPTH)
	ld	a, -1 (ix)
	sub	a, #0x02
	jr	nz, 00111$
	ld	l, -25 (ix)
	ld	h, -24 (ix)
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	ld	a, #0x9f
	cp	a, c
	ld	a, #0x00
	sbc	a, b
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:338: return;
	jp	nc, 00159$
00111$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:340: distance = zombie_distance_metric(relative_x, relative_y);
	ld	e, -3 (ix)
	ld	d, -2 (ix)
	ld	l, -23 (ix)
	ld	h, -22 (ix)
	call	_zombie_distance_metric
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:342: sprite, distance);
	ld	-18 (ix), e
	ld	-17 (ix), d
	ld	l, -7 (ix)
	ld	h, -6 (ix)
	call	_game_gear_get_zombie_presentation_pose
	ld	-16 (ix), a
	jr	00117$
00116$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:344: else if (depth > SPRITE_VISIBLE_MAX_DISTANCE)
	ld	c, -13 (ix)
	ld	b, -12 (ix)
	ld	e, -11 (ix)
	ld	d, -10 (ix)
	ld	a, #0xec
	cp	a, c
	ld	a, #0x04
	sbc	a, b
	ld	hl, #0x0000
	sbc	hl, de
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:345: return;
	jp	c, 00159$
00117$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:346: horizontal = ((signed long)direction_y * relative_x
	ld	l, 10 (ix)
	ld	h, 11 (ix)
	ld	e, -21 (ix)
	ld	d, -20 (ix)
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:347: - (signed long)direction_x * relative_y) * 256L
	call	___mulsint2slong
	ld	-22 (ix), e
	ld	-21 (ix), d
	ld	-20 (ix), l
	ld	-19 (ix), h
	ld	l, 8 (ix)
	ld	h, 9 (ix)
	pop	de
	push	de
	call	___mulsint2slong
	ex	de, hl
	ld	a, -22 (ix)
	sub	a, l
	ld	c, a
	ld	a, -21 (ix)
	sbc	a, h
	ld	b, a
	ld	l, -20 (ix)
	ld	h, -19 (ix)
	sbc	hl, de
	ld	h, l
	ld	l, b
	ld	b, c
	ld	-22 (ix), #0x00
	ld	-21 (ix), b
	ld	-20 (ix), l
	ld	-19 (ix), h
	ld	l, 18 (ix)
	ld	h, 19 (ix)
	push	hl
	ld	l, 16 (ix)
	ld	h, 17 (ix)
	push	hl
	ld	e, -22 (ix)
	ld	d, -21 (ix)
	ld	l, -20 (ix)
	ld	h, -19 (ix)
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:350: projected_height = 16384U / projected->depth;
	call	__divslong
	pop	af
	pop	af
	ld	-23 (ix), e
	ld	-22 (ix), d
	ld	-21 (ix), l
	ld	-20 (ix), h
	ld	l, -25 (ix)
	ld	h, -24 (ix)
	ld	a, (hl)
	ld	-3 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-2 (ix), a
	ld	e, -3 (ix)
	ld	d, -2 (ix)
	ld	hl, #0x4000
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:351: if (projected_height == 0)
	call	__divuint
	ld	-3 (ix), e
	ld	-2 (ix), d
	ld	a, d
	or	a, -3 (ix)
	jr	nz, 00119$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:352: projected_height = 1;
	ld	-3 (ix), #0x01
	ld	-2 (ix), #0
00119$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:353: if (projected_height > 144)
	ld	a, #0x90
	cp	a, -3 (ix)
	ld	a, #0x00
	sbc	a, -2 (ix)
	jr	nc, 00121$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:354: projected_height = 144;
	ld	-3 (ix), #0x90
	ld	-2 (ix), #0
00121$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:336: && projected->depth <= SPRITE_CORPSE_CLOSE_HIDDEN_MAX_DEPTH)
	ld	a, -1 (ix)
	sub	a, #0x02
	ld	a, #0x01
	jr	z, 00500$
	xor	a, a
00500$:
	ld	-19 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:358: if (!sprite)
	ld	a, -6 (ix)
	or	a, -7 (ix)
	jr	nz, 00141$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:363: if ((unsigned char)projected_height > 64)
	ld	a, -3 (ix)
	cp	a, #0x41
	jr	c, 00123$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:364: projected_height = 64;
	ld	-3 (ix), #0x40
	ld	-2 (ix), #0
00123$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:366: + ((unsigned char)projected_height >> 1)
	ld	c, -3 (ix)
	ld	e, c
	srl	e
	ld	d, #0x00
	ld	hl, #0x0020
	add	hl, de
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:367: + ((unsigned char)projected_height >> 2);
	srl	c
	srl	c
	ld	b, #0x00
	add	hl, bc
	ld	-5 (ix), l
	ld	-4 (ix), h
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:369: projected->source_size = projected_height > 16 ? 16 : 8;
	ld	c, -27 (ix)
	ld	b, -26 (ix)
	ld	a, #0x10
	cp	a, -3 (ix)
	jr	nc, 00165$
	ld	a, #0x10
	jr	00166$
00165$:
	ld	a, #0x08
00166$:
	ld	(bc), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:370: projected->pixels = projected->source_size == 16
	ld	c, -15 (ix)
	ld	b, -14 (ix)
	ld	l, -27 (ix)
	ld	h, -26 (ix)
	ld	a, (hl)
	cp	a, #0x10
	jr	nz, 00167$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:371: ? shotgun_world_pixels : shotgun_far_pixels;
	ld	de, #_shotgun_world_pixels+0
	jr	00168$
00167$:
	ld	de, #_shotgun_far_pixels
00168$:
	ld	a, e
	ld	(bc), a
	inc	bc
	ld	a, d
	ld	(bc), a
	jp	00142$
00141$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:375: if (projected_height < SPRITE_MEDIUM_LOD_MIN_HEIGHT)
	ld	a, -3 (ix)
	sub	a, #0x0f
	jr	nc, 00133$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:377: projected_height = SPRITE_SIMPLE_LOD_MIN_HEIGHT;
	ld	-3 (ix), #0x0d
	ld	-2 (ix), #0
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:378: projected->pixels = life_state == ZOMBIE_STATE_CORPSE
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:379: ? zombie_corpse_lod_pixels
	ld	a, -19 (ix)
	or	a, a
	jr	z, 00169$
	ld	de, #_zombie_corpse_lod_pixels+0
	jr	00170$
00169$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:380: : game_gear_get_zombie_lod_pixels(sprite, 0);
	xor	a, a
	push	af
	inc	sp
	ld	l, -7 (ix)
	ld	h, -6 (ix)
	call	_game_gear_get_zombie_lod_pixels
00170$:
	ld	l, -15 (ix)
	ld	h, -14 (ix)
	ld	(hl), e
	inc	hl
	ld	(hl), d
	jr	00134$
00133$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:382: else if (projected_height < SPRITE_FULL_DETAIL_MIN_HEIGHT)
	ld	a, -3 (ix)
	sub	a, #0x11
	jr	nc, 00130$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:385: (projected_height - SPRITE_MEDIUM_LOD_MIN_HEIGHT) & 1U;
	ld	a, -3 (ix)
	add	a, #0xf1
	and	a, #0x01
	ld	c, a
	ld	a, -3 (ix)
	sub	a, c
	ld	-3 (ix), a
	sbc	a, a
	ld	-2 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:386: projected->pixels = life_state == ZOMBIE_STATE_CORPSE
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:387: ? zombie_corpse_lod_pixels
	ld	a, -19 (ix)
	or	a, a
	jr	z, 00171$
	ld	de, #_zombie_corpse_lod_pixels+0
	jr	00172$
00171$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:388: : game_gear_get_zombie_lod_pixels(sprite, 1);
	ld	a, #0x01
	push	af
	inc	sp
	ld	l, -7 (ix)
	ld	h, -6 (ix)
	call	_game_gear_get_zombie_lod_pixels
00172$:
	ld	l, -15 (ix)
	ld	h, -14 (ix)
	ld	(hl), e
	inc	hl
	ld	(hl), d
	jr	00134$
00130$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:390: else if (distance <= SPRITE_NEAR_DETAIL_MAX_DISTANCE)
	ld	a, #0x88
	cp	a, -18 (ix)
	ld	a, #0x01
	sbc	a, -17 (ix)
	jr	c, 00127$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:393: game_gear_get_near_zombie_texture_id(presentation_pose);
	ld	a, -16 (ix)
	call	_game_gear_get_near_zombie_texture_id
	ld	l, -29 (ix)
	ld	h, -28 (ix)
	ld	(hl), a
	jr	00134$
00127$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:395: else if (distance <= SPRITE_MIDDLE_DETAIL_MAX_DISTANCE)
	ld	a, #0x68
	cp	a, -18 (ix)
	ld	a, #0x02
	sbc	a, -17 (ix)
	jr	c, 00134$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:398: game_gear_get_middle_zombie_pixels(presentation_pose);
	ld	a, -16 (ix)
	call	_game_gear_get_middle_zombie_pixels
	ld	l, -15 (ix)
	ld	h, -14 (ix)
	ld	(hl), e
	inc	hl
	ld	(hl), d
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:399: projected->source_size = 16;
	ld	l, -27 (ix)
	ld	h, -26 (ix)
	ld	(hl), #0x10
00134$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:401: if (life_state == ZOMBIE_STATE_ALIVE
	ld	a, -1 (ix)
	or	a, a
	jr	nz, 00142$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:402: && projected->source_size == 8
	ld	l, -27 (ix)
	ld	h, -26 (ix)
	ld	a, (hl)
	cp	a, #0x08
	jr	nz, 00142$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:403: && projected->near_texture_id == NEAR_ZOMBIE_TEXTURE_NONE
	ld	l, -29 (ix)
	ld	h, -28 (ix)
	ld	c, (hl)
	inc	c
	jr	nz, 00142$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:404: && projected_height > ZOMBIE_8X8_MAX_PROJECTED_HEIGHT)
	ld	a, #0x20
	cp	a, -3 (ix)
	jr	nc, 00142$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:406: projected_height = ZOMBIE_8X8_MAX_PROJECTED_HEIGHT;
	ld	-3 (ix), #0x20
	ld	-2 (ix), #0
00142$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:412: / depth;
	ld	l, -21 (ix)
	ld	h, -20 (ix)
	push	hl
	ld	l, -23 (ix)
	ld	h, -22 (ix)
	push	hl
	ld	de, #0x0050
	ld	hl, #0x0000
	call	__mullong
	pop	af
	pop	af
	ld	c, -11 (ix)
	ld	b, -10 (ix)
	push	bc
	ld	c, -13 (ix)
	ld	b, -12 (ix)
	push	bc
	call	__divslong
	pop	af
	pop	af
	push	bc
	ex	de, hl
	ld	bc, #0x0038
	add	hl, bc
	pop	bc
	jr	nc, 00507$
	inc	de
00507$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:413: left = center_x - (signed int)projected_height / 2;
	ld	a, -3 (ix)
	ld	-15 (ix), a
	ld	-14 (ix), #0x00
	ld	c, -15 (ix)
	ld	b, #0x00
	sra	b
	rr	c
	ld	-13 (ix), c
	xor	a, a
	ld	-12 (ix), a
	rlca
	sbc	a, a
	ld	-11 (ix), a
	ld	-10 (ix), a
	ld	a, l
	sub	a, -13 (ix)
	ld	c, a
	ld	a, h
	sbc	a, -12 (ix)
	ld	b, a
	ld	a, e
	sbc	a, -11 (ix)
	ld	e, a
	ld	a, d
	sbc	a, -10 (ix)
	ld	d, a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:414: right = left + projected_height;
	ld	a, -3 (ix)
	push	iy
	ex	(sp), hl
	ld	h, #0x00
	ex	(sp), hl
	pop	iy
	ld	hl, #0x0000
	add	a, c
	ld	-13 (ix), a
	push	iy
	ld	a, -45 (ix)
	pop	iy
	adc	a, b
	ld	-12 (ix), a
	ld	a, l
	adc	a, e
	ld	-11 (ix), a
	ld	a, h
	adc	a, d
	ld	-10 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:415: if (sprite)
	ld	a, -6 (ix)
	or	a, -7 (ix)
	jr	z, 00146$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:418: + (signed int)projected_height / 2;
	ld	a, -15 (ix)
	ld	l, #0x00
	sra	l
	rr	a
	add	a, #0x20
	ld	-5 (ix), a
	ld	a, l
	adc	a, #0x00
	ld	-4 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:419: if (life_state == ZOMBIE_STATE_CORPSE)
	ld	a, -19 (ix)
	or	a, a
	jr	z, 00146$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:420: bottom += (signed int)projected_height / 3;
	ld	a, -15 (ix)
	push	bc
	push	de
	ld	l, #0x03
	call	__divuchar
	ld	a, e
	pop	de
	pop	bc
	ld	l, #0x00
	add	a, -5 (ix)
	ld	-5 (ix), a
	ld	a, l
	adc	a, -4 (ix)
	ld	-4 (ix), a
00146$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:424: || left >= GAME_GEAR_VIEWPORT_PIXEL_WIDTH
	xor	a, a
	cp	a, -13 (ix)
	sbc	a, -12 (ix)
	ld	a, #0x00
	sbc	a, -11 (ix)
	ld	a, #0x00
	sbc	a, -10 (ix)
	jp	po, 00508$
	xor	a, #0x80
00508$:
	jp	p, 00159$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:425: || bottom <= 0
	ld	a, c
	sub	a, #0x70
	ld	a, b
	sbc	a, #0x00
	ld	a, e
	sbc	a, #0x00
	ld	a, d
	rla
	ccf
	rra
	sbc	a, #0x80
	jp	nc, 00159$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:426: || bottom - (signed int)projected_height
	xor	a, a
	cp	a, -5 (ix)
	sbc	a, -4 (ix)
	jp	nc, 00159$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:427: >= GAME_GEAR_VIEWPORT_PIXEL_HEIGHT)
	ld	a, -5 (ix)
	sub	a, -15 (ix)
	ld	-23 (ix), a
	ld	a, -4 (ix)
	sbc	a, -14 (ix)
	ld	-22 (ix), a
	ld	a, -23 (ix)
	sub	a, #0x40
	ld	a, -22 (ix)
	rla
	ccf
	rra
	sbc	a, #0x80
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:429: return;
	jp	nc, 00159$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:432: visible_left = left < 0 ? 0 : (signed int)left;
	ld	-21 (ix), c
	ld	-20 (ix), b
	bit	7, d
	jr	z, 00175$
	xor	a, a
	ld	-15 (ix), a
	ld	-14 (ix), a
	jr	00176$
00175$:
	ld	a, -21 (ix)
	ld	-15 (ix), a
	ld	a, -20 (ix)
	ld	-14 (ix), a
00176$:
	ld	a, -15 (ix)
	ld	-1 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:435: : (signed int)right;
	ld	a, -13 (ix)
	ld	-19 (ix), a
	ld	a, -12 (ix)
	ld	-18 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:434: ? GAME_GEAR_VIEWPORT_PIXEL_WIDTH
	ld	a, #0x70
	cp	a, -13 (ix)
	ld	a, #0x00
	sbc	a, -12 (ix)
	ld	a, #0x00
	sbc	a, -11 (ix)
	ld	a, #0x00
	sbc	a, -10 (ix)
	jr	nc, 00177$
	ld	-11 (ix), #0x70
	ld	-10 (ix), #0
	jr	00178$
00177$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:435: : (signed int)right;
	ld	a, -19 (ix)
	ld	-11 (ix), a
	ld	a, -18 (ix)
	ld	-10 (ix), a
00178$:
	ld	a, -11 (ix)
	ld	-10 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:436: first_ray = (unsigned char)visible_left >> 2;
	ld	c, -1 (ix)
	srl	c
	srl	c
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:437: last_ray = (unsigned char)(visible_right - 1) >> 2;
	ld	a, -10 (ix)
	dec	a
	rrca
	rrca
	and	a, #0x3f
	ld	-17 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:438: rays = raycaster_get_rendered_rays();
	push	bc
	call	_raycaster_get_rendered_rays
	ld	-16 (ix), e
	ld	-15 (ix), d
	pop	bc
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:439: while (first_ray <= last_ray)
	ld	-1 (ix), c
00154$:
	ld	a, -17 (ix)
	sub	a, -1 (ix)
	ld	a, #0x00
	rla
	ld	-14 (ix), a
	bit	0, -14 (ix)
	jr	nz, 00156$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:441: if (projected->depth < rays[first_ray].wall_distance)
	ld	l, -25 (ix)
	ld	h, -24 (ix)
	ld	a, (hl)
	ld	-13 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-12 (ix), a
	ld	c, -1 (ix)
	ld	b, #0x00
	ld	l, c
	ld	h, b
	add	hl, hl
	add	hl, bc
	add	hl, hl
	ld	-11 (ix), l
	ld	-10 (ix), h
	ld	a, -11 (ix)
	add	a, -16 (ix)
	ld	c, a
	ld	a, -10 (ix)
	adc	a, -15 (ix)
	ld	b, a
	ld	hl, #4
	add	hl, bc
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	ld	a, -13 (ix)
	sub	a, c
	ld	a, -12 (ix)
	sbc	a, b
	jr	c, 00156$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:443: ++first_ray;
	inc	-1 (ix)
	jr	00154$
00156$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:445: if (first_ray > last_ray)
	ld	a, -14 (ix)
	or	a, a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:446: return;
	jr	nz, 00159$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:448: projected->left = (signed int)left;
	ld	l, -39 (ix)
	ld	h, -38 (ix)
	ld	a, -21 (ix)
	ld	(hl), a
	inc	hl
	ld	a, -20 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:449: projected->right = (signed int)right;
	ld	l, -37 (ix)
	ld	h, -36 (ix)
	ld	a, -19 (ix)
	ld	(hl), a
	inc	hl
	ld	a, -18 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:450: projected->bottom = bottom;
	ld	l, -33 (ix)
	ld	h, -32 (ix)
	ld	a, -5 (ix)
	ld	(hl), a
	inc	hl
	ld	a, -4 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:451: projected->top = bottom - (signed int)projected_height;
	ld	l, -35 (ix)
	ld	h, -34 (ix)
	ld	a, -23 (ix)
	ld	(hl), a
	inc	hl
	ld	a, -22 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:452: projected->texture_step =
	ld	a, -31 (ix)
	ld	-5 (ix), a
	ld	a, -30 (ix)
	ld	-4 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:453: (projected->near_texture_id != NEAR_ZOMBIE_TEXTURE_NONE
	ld	l, -29 (ix)
	ld	h, -28 (ix)
	ld	c, (hl)
	inc	c
	jr	z, 00179$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:454: ? 8192U : (unsigned int)projected->source_size << 8)
	ld	bc, #0x2000
	jr	00180$
00179$:
	ld	l, -27 (ix)
	ld	h, -26 (ix)
	ld	b, (hl)
	ld	c, #0x00
00180$:
	ld	e, -3 (ix)
	ld	d, #0x00
	ld	l, c
	ld	h, b
	call	__divuint
	ld	l, -5 (ix)
	ld	h, -4 (ix)
	ld	(hl), e
	inc	hl
	ld	(hl), d
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:456: projected->visible = 1;
	ld	l, -41 (ix)
	ld	h, -40 (ix)
	ld	(hl), #0x01
00159$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:457: }
	ld	sp, ix
	pop	ix
	pop	hl
	ld	iy, #16
	add	iy, sp
	ld	sp, iy
	jp	(hl)
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:459: unsigned int game_gear_prepare_world_sprites(
;	---------------------------------
; Function game_gear_prepare_world_sprites
; ---------------------------------
_game_gear_prepare_world_sprites::
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	iy, #-48
	add	iy, sp
	ld	sp, iy
	ld	-10 (ix), l
	ld	-9 (ix), h
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:468: unsigned int accepted_mask = 0;
	xor	a, a
	ld	-8 (ix), a
	ld	-7 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:469: unsigned int changed_mask = 0;
	xor	a, a
	ld	-6 (ix), a
	ld	-5 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:470: unsigned int ordered_mask = 0;
	xor	a, a
	ld	-4 (ix), a
	ld	-3 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:471: unsigned char remaining_budget = SPRITE_RENDER_BUDGET;
	ld	-2 (ix), #0x0c
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:474: unsigned char zombie_count = projected_sprite_count;
	ld	a, 4 (ix)
	ld	-26 (ix), a
	ld	-25 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:476: context.position_x = camera_get_position_x();
	call	_camera_get_position_x
	ld	-42 (ix), e
	ld	-41 (ix), d
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:477: context.position_y = camera_get_position_y();
	call	_camera_get_position_y
	ld	-40 (ix), e
	ld	-39 (ix), d
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:478: context.direction_x = camera_get_direction_x();
	call	_camera_get_direction_x
	ld	-38 (ix), e
	ld	-37 (ix), d
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:479: context.direction_y = camera_get_direction_y();
	call	_camera_get_direction_y
	ld	-36 (ix), e
	ld	-35 (ix), d
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:480: context.plane_x = camera_get_plane_x();
	call	_camera_get_plane_x
	ld	-34 (ix), e
	ld	-33 (ix), d
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:481: context.plane_y = camera_get_plane_y();
	call	_camera_get_plane_y
	ld	c, e
	ld	b, d
	ld	-32 (ix), c
	ld	-31 (ix), b
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:482: context.determinant =
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:483: (signed long)context.plane_x * context.direction_y
	ld	a, -34 (ix)
	ld	-12 (ix), a
	ld	a, -33 (ix)
	ld	-11 (ix), a
	ld	e, -36 (ix)
	ld	d, -35 (ix)
	push	bc
	ld	l, -12 (ix)
	ld	h, -11 (ix)
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:484: - (signed long)context.direction_x * context.plane_y;
	call	___mulsint2slong
	ld	-14 (ix), e
	ld	-13 (ix), d
	ld	-12 (ix), l
	ld	-11 (ix), h
	pop	bc
	ld	l, -38 (ix)
	ld	h, -37 (ix)
	ld	e, c
	ld	d, b
	call	___mulsint2slong
	ex	de, hl
	ld	a, -14 (ix)
	sub	a, l
	ld	c, a
	ld	a, -13 (ix)
	sbc	a, h
	ld	b, a
	ld	l, -12 (ix)
	ld	h, -11 (ix)
	sbc	hl, de
	ld	-30 (ix), c
	ld	-29 (ix), b
	ld	-28 (ix), l
	ld	-27 (ix), h
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:486: if (SHOTGUN_PICKUP_PRESENT) --zombie_count;
	ld	a, (_owned_weapons)
	bit	1, a
	jr	nz, 00213$
	ld	a, -26 (ix)
	dec	a
	ld	-25 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:488: for (sprite_index = 0;
00213$:
	ld	-1 (ix), #0x00
00147$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:489: sprite_index < projected_sprite_count;
	ld	a, -1 (ix)
	sub	a, 4 (ix)
	jp	nc, 00121$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:502: context.determinant);
	ld	a, -30 (ix)
	ld	-48 (ix), a
	ld	a, -29 (ix)
	ld	-47 (ix), a
	ld	a, -28 (ix)
	ld	-46 (ix), a
	ld	a, -27 (ix)
	ld	-45 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:501: context.plane_y,
	ld	a, -32 (ix)
	ld	-44 (ix), a
	ld	a, -31 (ix)
	ld	-43 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:500: context.plane_x,
	ld	a, -34 (ix)
	ld	-24 (ix), a
	ld	a, -33 (ix)
	ld	-23 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:499: context.direction_y,
	ld	a, -36 (ix)
	ld	-22 (ix), a
	ld	a, -35 (ix)
	ld	-21 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:498: context.direction_x,
	ld	a, -38 (ix)
	ld	-20 (ix), a
	ld	a, -37 (ix)
	ld	-19 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:497: context.position_y,
	ld	a, -40 (ix)
	ld	-18 (ix), a
	ld	a, -39 (ix)
	ld	-17 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:496: context.position_x,
	ld	a, -42 (ix)
	ld	-16 (ix), a
	ld	a, -41 (ix)
	ld	-15 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:495: &projected_sprites[sprite_index],
	ld	c, -1 (ix)
	ld	b, #0x00
	ld	l, c
	ld	h, b
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, bc
	ld	a, -10 (ix)
	add	a, l
	ld	-14 (ix), a
	ld	a, -9 (ix)
	adc	a, h
	ld	-13 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:494: ? world_sprite_get(sprite_index) : 0,
	ld	a, -1 (ix)
	sub	a, -25 (ix)
	jr	nc, 00161$
	ld	a, -1 (ix)
	call	_world_sprite_get
	ld	-12 (ix), e
	ld	-11 (ix), d
	jr	00162$
00161$:
	xor	a, a
	ld	-12 (ix), a
	ld	-11 (ix), a
00162$:
	pop	de
	pop	hl
	ex	de, hl
	push	de
	push	hl
	push	de
	push	hl
	ld	l, -44 (ix)
	ld	h, -43 (ix)
	push	hl
	ld	l, -24 (ix)
	ld	h, -23 (ix)
	push	hl
	ld	l, -22 (ix)
	ld	h, -21 (ix)
	push	hl
	ld	l, -20 (ix)
	ld	h, -19 (ix)
	push	hl
	ld	l, -18 (ix)
	ld	h, -17 (ix)
	push	hl
	ld	l, -16 (ix)
	ld	h, -15 (ix)
	push	hl
	ld	e, -14 (ix)
	ld	d, -13 (ix)
	ld	l, -12 (ix)
	ld	h, -11 (ix)
	call	_game_gear_project_world_sprite
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:490: ++sprite_index)
	inc	-1 (ix)
	jp	00147$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:505: while (remaining_budget != 0)
00121$:
	ld	a, -2 (ix)
	or	a, a
	jp	z, 00234$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:507: unsigned char selected = PROJECTED_SPRITE_MAX_COUNT;
	ld	-25 (ix), #0x09
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:508: unsigned char selected_center_distance = 255;
	ld	-24 (ix), #0xff
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:509: unsigned char selected_visible_width = 0;
	ld	-23 (ix), #0x00
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:510: unsigned char selected_render_cost = 0;
	ld	-22 (ix), #0x00
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:511: unsigned int selected_depth = 65535U;
	ld	-21 (ix), #0xff
	ld	-20 (ix), #0xff
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:513: for (sprite_index = 0;
	ld	-1 (ix), #0x00
00150$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:549: || projected->depth < selected_depth
	ld	a, -25 (ix)
	sub	a, #0x09
	ld	a, #0x01
	jr	z, 00484$
	xor	a, a
00484$:
	ld	-19 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:514: sprite_index < projected_sprite_count;
	ld	a, -1 (ix)
	sub	a, 4 (ix)
	jp	nc, 00118$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:517: GameGearProjectedSprite *projected =
	ld	c, -1 (ix)
	ld	b, #0x00
	ld	l, c
	ld	h, b
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, bc
	ld	a, l
	add	a, -10 (ix)
	ld	-18 (ix), a
	ld	a, h
	adc	a, -9 (ix)
	ld	-17 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:526: if (!projected->visible
	ld	l, -18 (ix)
	ld	h, -17 (ix)
	ld	a, (hl)
	or	a, a
	jp	z, 00117$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:527: || (accepted_mask & (1U << sprite_index)))
	ld	b, -1 (ix)
	ld	hl, #0x0001
	inc	b
	jr	00486$
00485$:
	add	hl, hl
00486$:
	djnz	00485$
	ld	a, l
	and	a, -8 (ix)
	ld	c, a
	ld	a, h
	and	a, -7 (ix)
	or	a, c
	jp	nz, 00117$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:532: render_cost = game_gear_get_sprite_render_cost(projected);
	ld	l, -18 (ix)
	ld	h, -17 (ix)
	call	_game_gear_get_sprite_render_cost
	ld	-16 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:533: if (render_cost > remaining_budget)
	ld	a, -2 (ix)
	sub	a, -16 (ix)
	jp	c, 00117$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:536: center = (projected->left + projected->right) / 2;
	ld	l, -18 (ix)
	ld	h, -17 (ix)
	inc	hl
	ld	a, (hl)
	ld	-12 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-11 (ix), a
	ld	l, -18 (ix)
	ld	h, -17 (ix)
	inc	hl
	inc	hl
	inc	hl
	ld	a, (hl)
	ld	-15 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-14 (ix), a
	ld	a, -12 (ix)
	add	a, -15 (ix)
	ld	l, a
	ld	a, -11 (ix)
	adc	a, -14 (ix)
	ld	h, a
	ld	e, l
	ld	d, h
	bit	7, h
	jr	z, 00163$
	ex	de, hl
	inc	de
00163$:
	sra	d
	rr	e
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:538: ? GAME_GEAR_VIEWPORT_PIXEL_WIDTH / 2 - center
	ld	-13 (ix), e
	ld	a, e
	sub	a, #0x38
	ld	a, d
	rla
	ccf
	rra
	sbc	a, #0x80
	jr	nc, 00164$
	ld	a, #0x38
	sub	a, -13 (ix)
	jr	00165$
00164$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:539: : center - GAME_GEAR_VIEWPORT_PIXEL_WIDTH / 2;
	ld	a, -13 (ix)
	add	a, #0xc8
00165$:
	ld	-13 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:540: visible_left = projected->left < 0 ? 0 : projected->left;
	bit	7, -11 (ix)
	jr	z, 00166$
	xor	a, a
	ld	-12 (ix), a
	ld	-11 (ix), a
00166$:
	ld	e, -12 (ix)
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:542: projected->right > GAME_GEAR_VIEWPORT_PIXEL_WIDTH
	ld	a, #0x70
	cp	a, -15 (ix)
	ld	a, #0x00
	sbc	a, -14 (ix)
	jp	po, 00487$
	xor	a, #0x80
00487$:
	jp	p, 00168$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:543: ? GAME_GEAR_VIEWPORT_PIXEL_WIDTH
	ld	a, #0x70
	ld	b, #0x00
	jr	00169$
00168$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:544: : projected->right;
	ld	a, -15 (ix)
	ld	b, -14 (ix)
00169$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:546: (unsigned char)(visible_right - visible_left);
	sub	a, e
	ld	c, a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:549: || projected->depth < selected_depth
	ld	e, -18 (ix)
	ld	d, -17 (ix)
	ld	hl, #9
	add	hl, de
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	ld	a, -19 (ix)
	or	a, a
	jr	nz, 00109$
	ld	a, e
	sub	a, -21 (ix)
	ld	a, d
	sbc	a, -20 (ix)
	jr	c, 00109$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:550: || (projected->depth == selected_depth
	ld	l, -21 (ix)
	ld	h, -20 (ix)
	xor	a, a
	sbc	hl, de
	jr	nz, 00489$
	inc	a
00489$:
	ld	b, a
	or	a, a
	jr	z, 00116$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:551: && center_distance < selected_center_distance)
	ld	a, -13 (ix)
	sub	a, -24 (ix)
	jr	c, 00109$
00116$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:552: || (projected->depth == selected_depth
	ld	a, b
	or	a, a
	jr	z, 00117$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:554: && visible_width > selected_visible_width))
	ld	a, -13 (ix)
	sub	a, -24 (ix)
	jr	nz, 00117$
	ld	a, -23 (ix)
	sub	a, c
	jr	nc, 00117$
00109$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:556: selected = sprite_index;
	ld	a, -1 (ix)
	ld	-25 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:557: selected_depth = projected->depth;
	ld	-21 (ix), e
	ld	-20 (ix), d
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:558: selected_center_distance = center_distance;
	ld	a, -13 (ix)
	ld	-24 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:559: selected_visible_width = visible_width;
	ld	-23 (ix), c
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:560: selected_render_cost = render_cost;
	ld	a, -16 (ix)
	ld	-22 (ix), a
00117$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:515: ++sprite_index)
	inc	-1 (ix)
	jp	00150$
00118$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:564: if (selected == PROJECTED_SPRITE_MAX_COUNT)
	ld	a, -19 (ix)
	or	a, a
	jr	nz, 00234$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:567: accepted_mask |= 1U << selected;
	ld	b, -25 (ix)
	ld	hl, #0x0001
	inc	b
	jr	00493$
00492$:
	add	hl, hl
00493$:
	djnz	00492$
	ld	a, -8 (ix)
	or	a, l
	ld	-8 (ix), a
	ld	a, -7 (ix)
	or	a, h
	ld	-7 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:568: remaining_budget -= selected_render_cost;
	ld	a, -2 (ix)
	sub	a, -22 (ix)
	ld	-2 (ix), a
	jp	00121$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:571: for (sprite_index = 0;
00234$:
	ld	-1 (ix), #0x00
00152$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:572: sprite_index < projected_sprite_count;
	ld	a, -1 (ix)
	sub	a, 4 (ix)
	jr	nc, 00127$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:575: if (projected_sprites[sprite_index].visible
	ld	c, -1 (ix)
	ld	b, #0x00
	ld	l, c
	ld	h, b
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, bc
	ld	e, -10 (ix)
	ld	d, -9 (ix)
	add	hl, de
	ld	a, (hl)
	or	a, a
	jr	z, 00153$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:576: && !(accepted_mask & (1U << sprite_index)))
	ld	b, -1 (ix)
	ld	de, #0x0001
	inc	b
	jr	00495$
00494$:
	sla	e
	rl	d
00495$:
	djnz	00494$
	ld	a, -8 (ix)
	and	a, e
	ld	c, a
	ld	a, -7 (ix)
	and	a, d
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:578: projected_sprites[sprite_index].visible = 0;
	or	a, c
	jr	nz, 00153$
	ld	(hl), a
00153$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:573: ++sprite_index)
	inc	-1 (ix)
	jr	00152$
00127$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:582: *ordered_sprite_count = 0;
	ld	a, 10 (ix)
	ld	-19 (ix), a
	ld	a, 11 (ix)
	ld	-18 (ix), a
	ld	l, -19 (ix)
	ld	h, -18 (ix)
	ld	(hl), #0x00
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:583: while (*ordered_sprite_count < projected_sprite_count)
00138$:
	ld	l, -19 (ix)
	ld	h, -18 (ix)
	ld	a, (hl)
	sub	a, 4 (ix)
	jp	nc, 00140$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:585: unsigned char selected = PROJECTED_SPRITE_MAX_COUNT;
	ld	-17 (ix), #0x09
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:586: unsigned int selected_depth = 0;
	xor	a, a
	ld	-16 (ix), a
	ld	-15 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:588: for (sprite_index = 0;
	ld	-1 (ix), #0x00
00155$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:600: && depth <= selected_depth)
	ld	a, -17 (ix)
	sub	a, #0x09
	ld	a, #0x01
	jr	z, 00497$
	xor	a, a
00497$:
	ld	-2 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:589: sprite_index < projected_sprite_count;
	ld	a, -1 (ix)
	sub	a, 4 (ix)
	jp	nc, 00135$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:594: if (!projected_sprites[sprite_index].visible
	ld	c, -1 (ix)
	ld	b, #0x00
	ld	l, c
	ld	h, b
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, bc
	ld	-8 (ix), l
	ld	-7 (ix), h
	ld	e, -10 (ix)
	ld	d, -9 (ix)
	ld	l, -8 (ix)
	ld	h, -7 (ix)
	add	hl, de
	ld	-14 (ix), l
	ld	-13 (ix), h
	ld	a, (hl)
	ld	-7 (ix), a
	or	a, a
	jr	z, 00134$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:595: || (ordered_mask & (1U << sprite_index)))
	ld	b, -1 (ix)
	ld	-12 (ix), #0x01
	ld	-11 (ix), #0
	inc	b
	jr	00499$
00498$:
	sla	-12 (ix)
	rl	-11 (ix)
00499$:
	djnz	00498$
	ld	a, -4 (ix)
	and	a, -12 (ix)
	ld	-8 (ix), a
	ld	a, -3 (ix)
	and	a, -11 (ix)
	ld	-7 (ix), a
	or	a, -8 (ix)
	jr	nz, 00134$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:598: depth = projected_sprites[sprite_index].depth;
	ld	a, -14 (ix)
	ld	-8 (ix), a
	ld	a, -13 (ix)
	ld	-7 (ix), a
	ld	l, -8 (ix)
	ld	h, -7 (ix)
	ld	de, #0x0009
	add	hl, de
	ld	a, (hl)
	ld	-8 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-7 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:600: && depth <= selected_depth)
	bit	0, -2 (ix)
	jr	nz, 00132$
	ld	a, -16 (ix)
	sub	a, -8 (ix)
	ld	a, -15 (ix)
	sbc	a, -7 (ix)
	jr	nc, 00134$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:601: continue;
00132$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:603: selected = sprite_index;
	ld	a, -1 (ix)
	ld	-17 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:604: selected_depth = depth;
	ld	a, -8 (ix)
	ld	-16 (ix), a
	ld	a, -7 (ix)
	ld	-15 (ix), a
00134$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:590: ++sprite_index)
	inc	-1 (ix)
	jp	00155$
00135$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:606: if (selected == PROJECTED_SPRITE_MAX_COUNT)
	ld	a, -2 (ix)
	or	a, a
	jr	nz, 00140$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:608: ordered_sprite_indices[(*ordered_sprite_count)++] = selected;
	ld	l, -19 (ix)
	ld	h, -18 (ix)
	ld	e, (hl)
	ld	a, e
	inc	a
	ld	l, -19 (ix)
	ld	h, -18 (ix)
	ld	(hl), a
	ld	l, 8 (ix)
	ld	h, 9 (ix)
	ld	d, #0x00
	add	hl, de
	ld	a, -17 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:609: ordered_mask |= 1U << selected;
	ld	b, -17 (ix)
	ld	hl, #0x0001
	inc	b
	jr	00501$
00500$:
	add	hl, hl
00501$:
	djnz	00500$
	ld	a, -4 (ix)
	or	a, l
	ld	-4 (ix), a
	ld	a, -3 (ix)
	or	a, h
	ld	-3 (ix), a
	jp	00138$
00140$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:613: ? projected_sprite_count : previous_sprite_count;
	ld	a, 7 (ix)
	sub	a, 4 (ix)
	jr	nc, 00170$
	ld	a, -26 (ix)
	jr	00171$
00170$:
	ld	a, 7 (ix)
00171$:
	ld	-1 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:614: for (sprite_index = 0;
	ld	c, #0x00
00157$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:615: sprite_index < compared_sprite_count;
	ld	a, c
	sub	a, -1 (ix)
	jr	nc, 00145$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:619: || sprite_index >= previous_sprite_count
	ld	a, c
	sub	a, 4 (ix)
	jr	nc, 00141$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:620: || game_gear_projected_sprite_changed(
	ld	a, c
	sub	a, 7 (ix)
	jr	nc, 00141$
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:622: &previous_sprites[sprite_index]))
	ld	b, #0x00
	ld	l, c
	ld	h, b
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, bc
	ex	de, hl
	ld	l, 5 (ix)
	ld	h, 6 (ix)
	add	hl, de
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:621: &projected_sprites[sprite_index],
	ld	a, -10 (ix)
	add	a, e
	ld	b, a
	ld	a, -9 (ix)
	adc	a, d
	push	bc
	ex	de, hl
	ld	l, b
	ld	h, a
	call	_game_gear_projected_sprite_changed
	pop	bc
	or	a, a
	jr	z, 00158$
00141$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:624: changed_mask |= 1U << sprite_index;
	ld	b, c
	ld	hl, #0x0001
	inc	b
	jr	00503$
00502$:
	add	hl, hl
00503$:
	djnz	00502$
	ld	a, -6 (ix)
	or	a, l
	ld	-6 (ix), a
	ld	a, -5 (ix)
	or	a, h
	ld	-5 (ix), a
00158$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:616: ++sprite_index)
	inc	c
	jr	00157$
00145$:
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:627: return changed_mask;
	ld	e, -6 (ix)
	ld	d, -5 (ix)
;D:/mano_projektai/GearRay/platform/game_gear/sprite_projection.c:628: }
	ld	sp, ix
	pop	ix
	pop	hl
	pop	af
	pop	af
	pop	af
	pop	af
	jp	(hl)
	.area _BANK1
	.area _BANK1
	.area _INITIALIZER
	.area _CABS (ABS)
