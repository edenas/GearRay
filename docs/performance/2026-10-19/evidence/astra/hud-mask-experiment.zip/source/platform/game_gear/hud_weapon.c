#include "hud_weapon.h"
#include "weapon_texture.h"
#include "weapon_shoot_texture.h"
#include "shotgun_held.h"
#include "shotgun_fire.h"
#include "../../game/weapons.h"
#include "../../game/player.h"

#define HUD_WEAPON_SHOOT_FRAME_COUNT 2
/* Touch one additional movement step before the previous contact boundary.
 * Independent of the renderer's world canvas or projected size. */
#define SHOTGUN_PICKUP_TOUCH_EXTENT (128U + 2U * PLAYER_MOVE_SPEED)

static HudWeaponState weapon_state;
static HudWeaponState rendered_weapon_state;
static unsigned char animation_timer;

void game_gear_hud_weapon_initialize(void)
{
    weapon_state = IDLE;
    rendered_weapon_state = IDLE;
    animation_timer = 0;
}

void game_gear_hud_weapon_update(unsigned char shoot_requested)
{
    /* Reuse this existing gameplay dispatch; never collect during pause. */
    if (SHOTGUN_PICKUP_PRESENT
        && (unsigned int)(player_get_position_x()
            - ((unsigned int)shotgun_cell_x << 8)
            + (SHOTGUN_PICKUP_TOUCH_EXTENT - 128U))
            <= 2U * SHOTGUN_PICKUP_TOUCH_EXTENT
        && (unsigned int)(player_get_position_y()
            - ((unsigned int)shotgun_cell_y << 8)
            + (SHOTGUN_PICKUP_TOUCH_EXTENT - 128U))
            <= 2U * SHOTGUN_PICKUP_TOUCH_EXTENT)
    {
        /* First ownership equips the reward; an owned pickup never switches.
         * Drop the old pose, then accept this frame's fresh fire edge below. */
        owned_weapons |= WEAPON_OWNED_SHOTGUN;
        selected_weapon = WEAPON_SHOTGUN;
        weapon_state = IDLE;
        animation_timer = 0;
    }
    if (shoot_requested)
    {
        weapon_state = SHOOT;
        animation_timer = HUD_WEAPON_SHOOT_FRAME_COUNT;
    }
    else if (weapon_state == SHOOT)
    {
        --animation_timer;
        if (animation_timer == 0)
            weapon_state = IDLE;
    }
}

unsigned char game_gear_hud_weapon_changed(void)
{
    return (weapon_state | (selected_weapon << 1)) != rendered_weapon_state;
}

void game_gear_hud_weapon_render_complete(void)
{
    rendered_weapon_state = weapon_state | (selected_weapon << 1);
}

static const unsigned char mask_weapon_texture[] = {195,0,0,0,0,0,12,60,0,0,0,0,15,0,0,0,48,3,48,48,255,0,0,0,0,63,0,0,0,0,3,192,192,0,0,0,0,240,12,12,255,0,0,0,0,255,0,0,0,0,255,0,0,0,0,255,0,0,0,0,192,12,0,12,12,240,3,0,3,3,252,0,0,0,0,252,3,0,0,0,0,51,255,0,0,0,51,63,0,0,0,192,0,192,192,0,51,15,48,48,63,0,0,0,0,15,48,0,0,0,3,12,0,48,48,0,51,48,12,60,240,15,3,0,3,192,63,3,3,3,192,63,0,0,0,240,15,3,3,3,0,192,192,0,192,0,255,255,0,255,0,255,255,252,255,0,255,15,15,15,0,255,252,12,252,0,255,252,12,252,0,243,240,12,252,0,243,240,12,252};

static const unsigned char mask_weapon_shoot_texture[] = {3,252,0,60,48,0,192,0,240,240,0,192,15,204,0,192,0,3,3,0,255,0,0,0,0,63,0,0,0,0,15,0,0,192,192,3,0,192,48,48,255,0,0,0,0,255,0,0,0,0,255,0,0,0,0,255,0,0,0,0,192,0,3,3,0,240,0,0,0,0,240,3,0,3,3,252,0,0,0,0,0,12,252,0,0,0,0,255,192,0,0,0,60,3,3,0,204,15,192,192,255,0,0,0,0,63,0,0,0,0,15,0,192,0,0,3,204,192,0,0,252,0,0,0,0,252,0,0,0,0,252,3,0,0,0,240,15,0,0,0,0,3,3,0,0,0,252,240,0,240,0,255,255,195,255,0,255,63,48,63,0,3,192,12,12,0,63,12,12,12,0,243,48,60,60,0,243,240,12,252};

static const unsigned char mask_shotgun_held[] = {255,0,0,0,0,255,0,0,0,0,255,0,0,0,0,207,0,0,0,0,255,0,0,0,0,255,0,0,0,0,255,0,0,0,0,255,0,0,0,0,255,0,0,0,0,255,0,0,0,0,255,0,0,0,0,255,0,0,0,0,255,0,0,0,0,255,0,0,0,0,255,0,0,0,0,255,0,0,0,0,255,0,0,0,0,255,0,0,0,0,255,0,0,0,0,255,0,0,0,0,0,0,0,0,0,0,12,60,3,3,192,0,3,0,0,192,12,0,12,12,255,0,0,0,0,0,15,15,15,15,0,240,240,0,0,0,15,63,0,0,255,0,0,0,0,255,0,0,0,0,63,0,0,0,0,0,0,0,192,192,255,0,0,0,0,255,0,0,0,0,255,0,0,0,0,255,0,0,0,0,255,0,0,0,0,255,0,0,0,0,255,0,0,0,0,255,0,0,0,0,240,15,12,15,15,240,12,0,0,0,252,3,3,3,3,240,15,15,15,15,0,192,3,192,192,0,60,0,60,60,0,207,0,15,15,0,240,192,192,192,0,240,240,15,15,0,15,63,0,0,0,192,3,192,192,0,252,0,252,252,3,0,0,0,0,0,60,252,0,0,0,51,243,0,0,0,51,51,0,0,255,0,0,0,0,255,0,0,0,0,63,0,0,0,0,63,0,0,0,0,240,15,15,15,15,192,63,63,63,63,0,255,252,252,252,0,255,252,252,252,60,192,0,0,0,60,192,0,0,0,255,0,0,0,0,255,0,0,0,0,0,48,0,48,48,0,192,192,192,192,0,3,0,3,3,0,240,192,192,192,0,0,0,0,0,0,204,0,204,204,0,63,0,63,63,0,63,0,63,63,63,0,0,0,0,15,48,48,48,48,3,0,192,0,0,0,240,12,240,240};

static const unsigned char mask_shotgun_fire[] = {63,192,0,0,0,195,60,0,48,0,0,195,0,48,48,0,192,0,192,0,207,48,0,0,0,255,0,0,0,0,51,204,0,204,0,15,48,0,0,0,255,0,0,0,0,255,0,0,0,0,255,0,0,0,0,255,0,0,0,0,255,0,0,0,0,255,0,0,0,0,255,0,0,0,0,255,0,0,0,0,255,0,0,0,0,255,0,0,0,0,255,0,0,0,0,255,0,0,0,0,0,192,15,15,0,192,48,0,48,0,240,3,0,3,3,204,48,0,0,0,0,3,3,195,195,0,60,252,192,0,0,15,63,48,0,0,192,15,204,192,63,192,192,192,192,63,0,0,0,0,3,192,192,0,0,0,204,204,48,48,255,0,0,0,0,255,0,0,0,0,255,0,0,0,0,63,0,0,0,0,255,0,0,0,0,255,0,0,0,0,255,0,0,0,0,255,0,0,0,0,252,3,3,3,3,252,3,0,0,0,240,15,3,15,3,252,3,3,3,3,0,51,0,51,51,0,204,0,12,12,0,243,192,195,195,0,252,240,240,240,0,60,252,3,3,0,195,63,192,192,0,0,3,0,0,0,240,0,240,240,15,0,0,192,192,0,0,240,0,0,0,63,255,0,0,0,51,51,0,0,255,0,0,0,0,255,0,0,0,0,63,0,0,0,0,63,0,0,0,0,240,15,15,15,15,240,15,15,15,15,192,63,60,60,60,0,255,252,252,252,63,192,0,0,0,60,192,0,0,0,60,195,3,3,3,255,0,0,0,0,0,0,0,0,0,0,192,192,192,192,0,12,0,12,12,0,192,0,0,0,0,0,51,0,0,0,0,0,0,0,0,63,0,63,63,0,15,0,15,15,63,0,0,0,0,15,48,48,48,48,3,12,204,12,12,0,192,48,192,192};

void game_gear_overlay_hud_weapon_tile(unsigned char *destination,
    unsigned char tile_column, unsigned char tile_row)
{
    const unsigned char *m;
    unsigned char index, row, repeat, keep;
    if (selected_weapon == WEAPON_SHOTGUN) {
        if (tile_column < 8 || tile_column > 12 || tile_row < 4 || tile_row > 7) return;
        index = (tile_row - 4) * 5 + tile_column - 8;
        m = weapon_state == SHOOT ? mask_shotgun_fire : mask_shotgun_held;
    } else {
        if (tile_column < 10 || tile_column > 12 || tile_row < 5 || tile_row > 7) return;
        index = (tile_row - 5) * 3 + tile_column - 10;
        m = weapon_state == SHOOT ? mask_weapon_shoot_texture : mask_weapon_texture;
    }
    m += (unsigned int)index * 20;
    for (row = 0; row < 4; ++row) {
        keep = m[0];
        for (repeat = 0; repeat < 2; ++repeat) {
            destination[0] = (destination[0] & keep) | m[1];
            destination[1] = (destination[1] & keep) | m[2];
            destination[2] = (destination[2] & keep) | m[3];
            destination[3] = (destination[3] & keep) | m[4];
            destination += 4;
        }
        m += 5;
    }
}
