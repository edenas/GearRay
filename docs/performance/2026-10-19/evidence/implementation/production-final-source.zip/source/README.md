# GearRay

GearRay is an open-source, fixed-point raycasting engine built for the Sega
Game Gear. It is written in C for SDCC and uses devkitSMS/SMSlib for hardware
access, ROM startup, and packaging.

The project favors readable code, deterministic behaviour, simple module
boundaries, and measured improvements that are validated on the target
hardware.

## Screenshot

_A current Engine Foundation screenshot will be added for the first public
release._

Historical renderer captures are available in [`artifacts/`](artifacts/).

## Measured performance implementation

The [2026-10-19 implementation report](docs/performance/2026-10-19/IMPLEMENTATION_REPORT.md) records exact renderer/camera/cache improvements, 2,880 matching replay records, and cooperative scheduling/presentation experiments. Production retains its per-completed-loop timing; display refresh is not gameplay FPS. Physical hardware validation of these changes remains pending.

## Current Status

The hardware-tested **Engine Foundation v1.0.0** now includes the accepted
multi-zombie combat, authored multi-resolution presentation, melee attack,
player-health, HUD, and Game Over milestones. It preserves the established
renderer, movement, interaction, and ROM-banking contracts.

GearRay is an engine foundation and workshop ROM, not yet a complete game.

## Features

- An isolated SEGA startup presentation on black using its own palette and a
  180-frame hold before gameplay initialization begins.
- Centred 112×64 first-person viewport with 28 rays.
- Deterministic fixed-point movement, rotation, collision, and raycasting.
- Native Game Gear tile rendering with indexed-colour wall textures.
- Directional wall shading, distance-based wall detail, and uniform light-gray
  ceiling/dark-gray floor backgrounds.
- Up to eight floor-anchored zombies with shared walking phase across 8x8,
  authored 16x16, and authored 32x32 presentation, exact wall-depth occlusion,
  deterministic render budgeting, temporary hit reactions, lethal
  presentation, and stateless distance-derived corpses.
- One authored 12×12 first-person HUD weapon, drawn as the final screen-space
  compositor at exactly 24×24 with shift-based 2× nearest-neighbor scaling and
  transparent pixels, with idle and firing frames.
- Press-edge pistol shooting with renderer-aligned target depth, cumulative
  12-point packed zombie health, projected-footprint aiming, and cumulative
  one- through four-shot damage across the exact 36/28/17/13 height bands.
- Deterministic zombie awareness and pursuit: clear-LOS activation within 963
  world units, loss beyond 1260 or behind blocking geometry, and integer-only
  dominant-axis movement of56 Q8.8 units per AI pass, once per four gameplay updates; wall-clock speed varies with workload.
- Door-aware enemy collision with player and living-zombie separation; hit
  reactions pause pursuit, while death and corpses remain stationary.
- Inclusive 280-unit melee attacks with alternating authored attack poses,
  independent per-zombie cooldowns, 20-point strikes, a 100-point player
  health model, minimal health HUD, damage shake, and a three-second Game Over
  presentation before the shared restart path.
- One shared 16-entry BG master palette for the complete software-composited
  scene; the hardware-sprite palette remains unused.
- Complete first-frame preparation before the direct-to-game display becomes
  visible.
- Two toggleable yellow doors, a switch-activated red door, interaction
  targeting, and a permanent 13×13 workshop map.
- Banked 64 KiB packaged ROM with hot Bank 0 code, Bank 1 gameplay and
  presentation code/data, and explicitly mapped Bank 2 near-zombie textures.
- Compile-time renderer profiling with no release-build counter overhead.
- Host-side workshop-map, exhaustive control, ray-direction, renderer,
  multi-sprite, combat, complete-palette, weapon-decoding, and startup-order
  validators.

## Controls

| Input | Action |
| --- | --- |
| D-pad Up / Down | Move forward / backward |
| D-pad Left / Right | Turn left / right |
| Tap Button 1 | Fire pistol; holding does not autofire |
| Hold Button 2 + Left / Right | Strafe left / right; rotation is suppressed |
| Release Button 2 without strafing during that hold | Interact once |
| Start | Reserved for menu |

The pistol has no ammo, automatic fire, recoil, switching, or additional
weapon system. Start remains reserved.

## Supported Toolchain

The current Windows build uses:

- CMake 3.20 or newer;
- Ninja;
- SDCC 4.6.0 (tested);
- devkitSMS and SMSlib;
- Windows PowerShell 5.1;
- `makesms` from devkitSMS.

The exact setup and currently unpinned dependencies are documented in
[`docs/BUILDING.md`](docs/BUILDING.md).

## Quick Build

From a Windows Command Prompt or PowerShell session:

```bat
build.bat
```

This generates the release ROM at `rom\GearRay.gg`. To build the isolated
renderer-profiling ROM:

```bat
build-profile.bat
```

The default devkitSMS location is `D:\Tools\devkitSMS`; it can be overridden
when configuring CMake. See the full [build guide](docs/BUILDING.md).

## Documentation

- [Current behavior and architecture](docs/CURRENT_BEHAVIOR.md)
- [Building GearRay](docs/BUILDING.md)
- [Engine architecture](docs/ENGINE_ARCHITECTURE.md)
- [Engine Foundation v1.0.0](docs/ENGINE_FOUNDATION_V1.0.0.md)
- [ROM banking architecture](docs/ROM_BANKING.md)
- [Zombie system architecture and melee-spacing audit](docs/ZOMBIE_SYSTEM_ARCHITECTURE_AUDIT.md)
- [Zombie presentation and renderer audit](docs/ZOMBIE_PRESENTATION_PIPELINE.md)
- [Asset provenance](docs/ASSET_PROVENANCE.md)
- [Contributing](CONTRIBUTING.md)
- [Changelog](CHANGELOG.md)

The sprint documents under [`docs/`](docs/) are historical engineering records.
They preserve measurements, experiments, rejected alternatives, and validation
evidence; they are not all descriptions of the current implementation.

## Roadmap

Near-term work focuses on public-release documentation, provenance, and
reproducible builds. The maintained current reference is
[Current behavior and architecture](docs/CURRENT_BEHAVIOR.md). The broader
[GearRay Developer Bible](GearRay_Developer_Bible.md) includes historical background. Later work may add
gameplay systems, content, audio, and user-interface features while preserving
the Engine Foundation contracts.

## Known Limitations

- The supported build workflow is currently Windows-only.
- SDCC and devkitSMS must be installed separately.
- The devkitSMS revision is not yet pinned.
- The ROM is a technical workshop rather than a finished game.
- Audio, save data, menu gameplay, and complete progression are not yet
  implemented.
- Some asset ownership and release status still requires confirmation; see the
  [asset provenance record](docs/ASSET_PROVENANCE.md).

## Acknowledgements

GearRay was created by Edenas Pocius through a collaborative Vibe Coding
workflow using OpenAI ChatGPT as an AI-assisted development tool. Project
authorship, decisions, integration, and release responsibility remain with the
human maintainer and contributors. See [ACKNOWLEDGEMENTS.md](ACKNOWLEDGEMENTS.md).

## License

GearRay is released under the [MIT License](LICENSE).

## Third-Party Software

GearRay builds with SDCC and devkitSMS components that retain their own
licensing terms. See [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md).
