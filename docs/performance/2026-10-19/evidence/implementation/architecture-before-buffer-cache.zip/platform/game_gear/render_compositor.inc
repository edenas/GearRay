extern unsigned char wall_schedule_palette(const RaycasterRay *ray,unsigned char y);
/* Full rebuild, no physical-buffer cache assumptions. Every cursor belongs
 * to this active frozen job. Each call returns with an empty VDP stream. */
GameGearProjectedSprite render_projected[PROJECTED_SPRITE_MAX_COUNT];
static unsigned char ordered[PROJECTED_SPRITE_MAX_COUNT],ordered_count;
static unsigned char span_x[PROJECTED_SPRITE_MAX_COUNT][8];
static unsigned char column,tile_y,pixel_y,entity,span_pixel,compose_phase;
static unsigned char left_far,right_far;
static signed int left_top,right_top;
static GameGearWallTextureSampler render_left_sampler,render_right_sampler;
static const RaycasterRay *render_left_ray,*render_right_ray;
static const unsigned char *render_left_flat,*render_right_flat;

void render_video_begin(void)
{
    unsigned char count=render_snapshot.actor_count+render_snapshot.pickup;
    game_gear_prepare_world_sprites(render_projected,count,
        previous_projected_sprites,0,ordered,&ordered_count);
    column=tile_y=pixel_y=entity=span_pixel=compose_phase=0;
}
static void render_wall_row(void)
{
    unsigned char y=tile_y*8+pixel_y;
    unsigned char background=game_gear_get_background_palette_index(y);
    unsigned char color;
    const unsigned char *l,*r;
    unsigned char *dst=projected_wall_column+pixel_y*4;
    if(left_far) l=(y>=left_top && y<left_top+render_left_ray->wall_height)
        ?render_left_flat+(y&7)*4:left_palette_bitplanes[background];
    else {
        SMS_mapROMBank(4); color=wall_schedule_palette(render_left_ray,y); SMS_mapROMBank(2);
        l=left_palette_bitplanes[color==255?background:color];
    }
    if(right_far) r=(y>=right_top && y<right_top+render_right_ray->wall_height)
        ?render_right_flat+(y&7)*4:right_palette_bitplanes[background];
    else {
        SMS_mapROMBank(4); color=wall_schedule_palette(render_right_ray,y); SMS_mapROMBank(2);
        r=right_palette_bitplanes[color==255?background:color];
    }
    dst[0]=l[0]|r[0]; dst[1]=l[1]|r[1]; dst[2]=l[2]|r[2]; dst[3]=l[3]|r[3];
}
static void render_sprite_row(unsigned char selected)
{
    const GameGearProjectedSprite *p=&render_projected[selected];
    const unsigned char *source;
    unsigned char size=p->near_texture_id==255?p->source_size:32;
    signed int y=tile_y*8+pixel_y;
    unsigned int ty;
    unsigned char x,sx,color,bit,keep=255,b0=0,b1=0,b2=0,b3=0;
    unsigned char *dst=projected_wall_column+pixel_y*4;
    if(y<p->top || y>=p->bottom) return;
    ty=((unsigned int)(y-p->top)*p->texture_step)>>8;
    if(ty>=size) ty=size-1;
    source=(p->near_texture_id==255?p->pixels:near_zombie_texture_pixels[p->near_texture_id])
        +ty*(size>>1);
    for(x=0;x<8;++x) {
        sx=span_x[selected][x]; if(sx==255) continue;
        color=source[sx>>1]; if(sx&1) color&=15; else color>>=4;
        if(color==15) continue;
        bit=128U>>x; keep&=~bit;
        if(color&1) b0|=bit; if(color&2) b1|=bit;
        if(color&4) b2|=bit; if(color&8) b3|=bit;
    }
    dst[0]=(dst[0]&keep)|b0; dst[1]=(dst[1]&keep)|b1;
    dst[2]=(dst[2]&keep)|b2; dst[3]=(dst[3]&keep)|b3;
}
unsigned char render_video_step(void)
{
    unsigned char count=render_snapshot.actor_count+render_snapshot.pickup;
    unsigned char selected,size;
    signed int x;
    unsigned int sx;
    GameGearProjectedSprite *p;
    switch(compose_phase) {
    case 0:
        if(column==14) return 1;
        render_left_ray=&render_snapshot.rays[column*2]; render_right_ray=render_left_ray+1;
        left_top=(64-(signed int)render_left_ray->wall_height)/2;
        right_top=(64-(signed int)render_right_ray->wall_height)/2;
        left_far=render_left_ray->wall_height<=16; right_far=render_right_ray->wall_height<=16;
        render_left_flat=render_left_ray->wall_height<=8?&left_lod2_rows[column&1][0][0]:
            render_left_ray->hit_side==WALL_SIDE_X?&left_lod1_x_rows[0][0]:&left_lod1_y_rows[0][0];
        render_right_flat=render_right_ray->wall_height<=8?&right_lod2_rows[column&1][0][0]:
            render_right_ray->hit_side==WALL_SIDE_X?&right_lod1_x_rows[0][0]:&right_lod1_y_rows[0][0];
        compose_phase=1; return 0;
    case 1:
        compose_phase=2; return 0;
    case 2:
        entity=span_pixel=0; compose_phase=3; return 0;
    case 3:
        if(entity==count) { tile_y=pixel_y=0; compose_phase=4; return 0; }
        p=&render_projected[entity]; x=column*8+span_pixel; span_x[entity][span_pixel]=255;
        if(p->visible && x>=p->left && x<p->right
            && p->depth<render_snapshot.rays[(unsigned char)x>>2].wall_distance) {
            size=p->near_texture_id==255?p->source_size:32;
            sx=((unsigned int)(x-p->left)*p->texture_step)>>8;
            if(sx>=size) sx=size-1;
            span_x[entity][span_pixel]=(unsigned char)sx;
        }
        if(++span_pixel==8) { span_pixel=0; ++entity; }
        return 0;
    case 4:
        render_wall_row();
        if(++pixel_y==8) { pixel_y=entity=0; compose_phase=5; }
        return 0;
    case 5:
        if(entity==ordered_count) { compose_phase=6; return 0; }
        selected=ordered[entity];
        if(game_gear_sprite_covers_tile(&render_projected[selected],column,tile_y))
            render_sprite_row(selected);
        if(++pixel_y==8) { pixel_y=0; ++entity; }
        return 0;
    case 6:
        render_hud_tile(projected_wall_column,column,tile_y);
        compose_phase=7; return 0;
    case 7:
        SMS_loadTiles(projected_wall_column,render_target_patterns+column*8+tile_y,32);
        compose_phase=8; return 0;
    default:
        render_write_name(GAME_GEAR_VIEWPORT_TILE_ORIGIN_X+column,
            GAME_GEAR_VIEWPORT_TILE_ORIGIN_Y+tile_y,render_target_patterns+column*8+tile_y);
        pixel_y=0;
        if(++tile_y==8) { ++column; compose_phase=0; } else compose_phase=4;
        return 0;
    }
}
void game_gear_video_draw_wall_columns(void)
{
    render_capture();
    while(render_active) render_step();
    render_ready=0;
    displayed_generation=render_snapshot.generation;
}
