param([Parameter(Mandatory=$true)][string]$OutputHeader)
$ErrorActionPreference='Stop'
$lines=[Collections.Generic.List[string]]::new()
$lines.Add('/* Exact clipped source rows, heights 17..144, 64 screen rows. */')
$lines.Add('static const unsigned char wall_source_rows[128][32] = {')
for($height=17;$height -le 144;++$height) {
    $top=[int][Math]::Truncate((64-$height)/2.0)
    $row=@()
    for($y=0;$y -lt 64;$y+=2) {
        $values=@()
        foreach($screen in @($y,($y+1))) {
            $value=if($screen -lt $top -or $screen -ge $top+$height){15}else{[int][Math]::Floor(($screen-$top)*8.0/$height)}
            # Independent exact Q8.8 step/remainder form used by the old sampler.
            if($value -ne 15) {
                $pixel=$screen-$top;$step=[int][Math]::Floor(2048.0/$height);$remainder=2048%$height
                $position=$pixel*$step+[int][Math]::Floor(($pixel*$remainder)/[double]$height)
                if(($position -shr 8) -ne $value) {throw 'Wall schedule proof failure'}
            }
            $values+=$value
        }
        $row+=($values[0] -shl 4) -bor $values[1]
    }
    $lines.Add('    {'+(($row|ForEach-Object{'0x{0:X2}' -f $_}) -join ',')+'},')
}
$lines.Add('};')
[IO.File]::WriteAllLines($OutputHeader,$lines,[Text.Encoding]::ASCII)
Write-Output 'Generated 4096 schedule bytes; 8192 clipped screen-row cases match old exact sampler arithmetic.'
