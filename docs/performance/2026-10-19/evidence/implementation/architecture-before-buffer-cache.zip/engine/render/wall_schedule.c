#include "scene_geometry.h"
#include "wall_textures.h"
#include "wall_texture.h"
#include "wall_schedules.h"
/* Physical page 4 is owned only during this leaf. Texture bytes and palettes
 * remain in page 1; the row schedule pointer never escapes to a caller. */
unsigned char wall_schedule_palette(const RaycasterRay *ray,unsigned char y)
{
    unsigned char row=wall_source_rows[ray->wall_height-17][y>>1];
    unsigned char column=ray->hit_offset>>5,color;
    if(y&1) row&=15;else row>>=4;
    if(row==15) return 255;
    color=wall_textures[ray->texture_id-1][row*4+(column>>1)];
    if(!(column&1)) color>>=4;
    color&=15;
    if(color>=WALL_TEXTURE_COLOR_COUNT) color=0;
    return ray->hit_side==WALL_SIDE_X?wall_palette_x_indices[color]:wall_palette_y_indices[color];
}
