#include "renderer_profile.h"
/* Coarse exact kernel experiment. One ray is the measured blocking unit;
 * input still captures in IRQs, and its maximum belongs to deadline admission. */
static unsigned char kernel_is_wall(const RayScene *scene,unsigned char x,unsigned char y)
{
    unsigned char tile=world_get_tile(x,y),door;
    if(tile==WORLD_TILE_EMPTY) return 0;
    if(tile!=WORLD_TILE_DOOR && tile!=WORLD_TILE_RED_DOOR) return 1;
    door=door_instance_find_at(x,y);
    return door>=3 || !scene->doors[door];
}
static unsigned char ray_kernel_cast(signed int direction_x,
                              signed int direction_y,
                              WallSide *result_side,
                              unsigned char *result_offset,
                              unsigned char *result_texture_id,
                              unsigned int *result_distance,
                              const RayScene *scene)
{
#ifdef GEARRAY_PROFILE_RENDERER
    unsigned char ray_dda_iterations = 0;
#endif
    unsigned int projected_height;
    unsigned int projection_distance;
    unsigned char world_tile_id;
    signed int position_x = scene->x;
    signed int position_y = scene->y;
    signed int map_x = position_x / FIXED_POINT_SCALE;
    signed int map_y = position_y / FIXED_POINT_SCALE;
    signed int step_x;
    signed int step_y;
    unsigned int direction_magnitude_x;
    unsigned int direction_magnitude_y;
    unsigned long delta_distance_x;
    unsigned long delta_distance_y;
    unsigned long side_distance_x;
    unsigned long side_distance_y;
    unsigned long ray_distance;

    GEAR_RAY_PROFILE_INCREMENT(rays_cast);

    if (direction_x == 0)
    {
        step_x = 1;
        delta_distance_x = DDA_INFINITY;
        side_distance_x = DDA_INFINITY;
    }
    else if (direction_x < 0)
    {
        step_x = -1;
        direction_magnitude_x = (unsigned int)(-(signed long)direction_x);
        delta_distance_x = dda_get_reciprocal(direction_magnitude_x);
        side_distance_x = dda_get_side_distance(
            (unsigned int)(position_x - map_x * FIXED_POINT_SCALE),
            delta_distance_x);
    }
    else
    {
        step_x = 1;
        direction_magnitude_x = (unsigned int)direction_x;
        delta_distance_x = dda_get_reciprocal(direction_magnitude_x);
        side_distance_x = dda_get_side_distance(
            (unsigned int)((map_x + 1) * FIXED_POINT_SCALE - position_x),
            delta_distance_x);
    }

    if (direction_y == 0)
    {
        step_y = 1;
        delta_distance_y = DDA_INFINITY;
        side_distance_y = DDA_INFINITY;
    }
    else if (direction_y < 0)
    {
        step_y = -1;
        direction_magnitude_y = (unsigned int)(-(signed long)direction_y);
        delta_distance_y = dda_get_reciprocal(direction_magnitude_y);
        side_distance_y = dda_get_side_distance(
            (unsigned int)(position_y - map_y * FIXED_POINT_SCALE),
            delta_distance_y);
    }
    else
    {
        step_y = 1;
        direction_magnitude_y = (unsigned int)direction_y;
        delta_distance_y = dda_get_reciprocal(direction_magnitude_y);
        side_distance_y = dda_get_side_distance(
            (unsigned int)((map_y + 1) * FIXED_POINT_SCALE - position_y),
            delta_distance_y);
    }

    do
    {
        GEAR_RAY_PROFILE_INCREMENT(dda_iterations);
#ifdef GEARRAY_PROFILE_RENDERER
        ++ray_dda_iterations;
#endif
        if (side_distance_x < side_distance_y)
        {
            ray_distance = side_distance_x;
            side_distance_x += delta_distance_x;
            map_x += step_x;
            *result_side = WALL_SIDE_X;
        }
        else
        {
            ray_distance = side_distance_y;
            side_distance_y += delta_distance_y;
            map_y += step_y;
            *result_side = WALL_SIDE_Y;
        }
    }
    while (!kernel_is_wall(scene,(unsigned char)map_x,(unsigned char)map_y));

#ifdef GEARRAY_PROFILE_RENDERER
    if (game_gear_renderer_profile.minimum_dda_iterations == 0
        || ray_dda_iterations
           < game_gear_renderer_profile.minimum_dda_iterations)
    {
        game_gear_renderer_profile.minimum_dda_iterations =
            ray_dda_iterations;
    }
    if (ray_dda_iterations
        > game_gear_renderer_profile.maximum_dda_iterations)
    {
        game_gear_renderer_profile.maximum_dda_iterations =
            ray_dda_iterations;
    }
#endif

    world_tile_id = world_get_tile((unsigned char)map_x,
                                   (unsigned char)map_y);
    *result_texture_id = world_tile_id==WORLD_TILE_RED_DOOR_SWITCH?scene->material:
        world_tile_id>WORLD_TILE_RED_DOOR_SWITCH?WORLD_TILE_STONE:world_tile_id;
    if (*result_side == WALL_SIDE_X)
    {
        *result_offset = raycaster_calculate_hit_offset(position_y,
                                                        direction_y,
                                                        ray_distance);
    }
    else
    {
        *result_offset = raycaster_calculate_hit_offset(position_x,
                                                        direction_x,
                                                        ray_distance);
    }

    /*
     * PNG texture X increases from authored left to right. For X-side hits,
     * increasing world Y runs left-to-right on the west face and
     * right-to-left on the east face. For Y-side hits, increasing world X
     * runs left-to-right on the south face and right-to-left on the north
     * face. Orient the coordinate from the physical face entered by the ray.
     */
    if (*result_side == WALL_SIDE_X)
    {
        /* A negative-X ray enters the cell's east face. */
        if (direction_x < 0)
            *result_offset = 255 - *result_offset;
    }
    /* A positive-Y ray enters the cell's north face. */
    else if (direction_y > 0)
        *result_offset = 255 - *result_offset;

    if (ray_distance == 0)
        projection_distance = 1;
    else
        projection_distance = (unsigned int)ray_distance;
    *result_distance = projection_distance;

    projected_height = WALL_HEIGHT_SCALE / projection_distance;

    if (projected_height > GAME_GEAR_SCREEN_HEIGHT)
        projected_height = GAME_GEAR_SCREEN_HEIGHT;
    else if (projected_height == 0)
        projected_height = 1;

    return (unsigned char)projected_height;
}

unsigned char ray_kernel_step(RayWork *w)
{
    const RayScene *s=w->scene;
    RaycasterRay *r=w->out;
    signed int camera_x=camera_x_by_ray[w->index];
    signed int dx=s->dx+(signed int)((s->px*camera_x)/256);
    signed int dy=s->dy+(signed int)((s->py*camera_x)/256);
    r->wall_height=ray_kernel_cast(dx,dy,&r->hit_side,&r->hit_offset,&r->texture_id,&r->wall_distance,s);
    return 1;
}
