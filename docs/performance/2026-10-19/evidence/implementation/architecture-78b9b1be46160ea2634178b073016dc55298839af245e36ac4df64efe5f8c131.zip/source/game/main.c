#include "SMSlib.h"
#include "frame_clock.h"
#include "scheduled_input.h"
#include "render_job.h"
#include "camera.h"
#include "input.h"
#include "hud_weapon.h"
#include "player.h"
#include "pause_map.h"
#include "red_door_switch.h"
#include "raycaster.h"
#include "renderer_profile.h"
#include "startup_logo.h"
#include "video.h"
#include "world.h"
#define GEAR_RAY_WORLD_SPRITE_NO_DISTANCE_METRIC
#include "world_sprite.h"
#include "zombie_shooting.h"
#include "zombie_ai.h"

/* SMSlib defaults this header nibble to 32 KB; this build is 64 KB. */
#undef SMS_EMBED_SEGA_ROM_HEADER_REGION_CODE
#define SMS_EMBED_SEGA_ROM_HEADER_REGION_CODE 0x7E
SMS_EMBED_SEGA_ROM_HEADER(0, 0);

static unsigned char pending_shot;
static unsigned char zombie_ai_frame_counter;


#ifndef GEARRAY_SIM_DIVISOR
#define GEARRAY_SIM_DIVISOR 12
#endif
unsigned int simulation_tick_id,simulation_misses,scheduler_max_debt;
unsigned char scheduler_overload;
static unsigned int next_tick;
void gameplay_tick(void)
{
    signed char forward_direction;
    signed char strafe_direction;
    signed char rotation_direction;
    unsigned char shoot_requested;
            world_sprites_update();
            shoot_requested = input_shoot_requested();
            rotation_direction = input_get_rotation_intent();

            if (rotation_direction < 0)
                camera_rotate_left();
            else if (rotation_direction > 0)
                camera_rotate_right();
#ifdef GEARRAY_PROFILE_RENDERER
            if (rotation_direction != 0)
                GEAR_RAY_PROFILE_INCREMENT(rotation_steps);
#endif

            forward_direction = input_get_forward_intent();
            strafe_direction = input_get_strafe_intent();

            if (forward_direction != 0 || strafe_direction != 0)
            {
                player_move_combined(forward_direction, strafe_direction);
                camera_set_fixed_position(player_get_position_x(),
                                          player_get_position_y());
            }

            game_gear_hud_weapon_update(shoot_requested);
            if (++zombie_ai_frame_counter >= ZOMBIE_AI_UPDATE_INTERVAL)
            {
                zombie_ai_frame_counter = 0;
                zombie_ai_update_all();
            }

            if (player_is_dead())
                return;

            player_process_interaction();
            red_door_switch_update();

            if (pending_shot)
                zombie_shooting_process();
            pending_shot = shoot_requested;
    game_gear_damage_shake_update();
}
/* Inclusive scheduling service: queued input, ordered actions and full tick. */
void gameplay_service(unsigned int cutoff)
{
    scheduled_input_drain(cutoff);
    if(scheduled_pause || frame_overflow || action_overflow) return;
    scheduled_input_tick();
    gameplay_tick();
    ++simulation_tick_id;
}
void main(void)
{
    unsigned int now;
    unsigned char burst;
    frame_clock_initialize();

    while (1)
    {
        game_gear_startup_logo_show();
        game_gear_video_initialize();
        game_gear_input_initialize();
        game_gear_hud_weapon_initialize();
        pending_shot = 0;
        zombie_ai_frame_counter = 0;
        simulation_tick_id=simulation_misses=scheduler_max_debt=0;
        scheduler_overload=frame_overflow=action_overflow=0;
        world_initialize();
        player_initialize();
        camera_initialize();
        camera_set_fixed_position(player_get_position_x(),
                                  player_get_position_y());
        raycaster_initialize();
        raycaster_update();
        /*
         * TODO: This build boots directly into gameplay, so pre-render the
         * first complete frame while display output is disabled to avoid
         * progressive wall loading. When startup becomes logo -> main menu
         * -> intro -> gameplay, review this sequence and prepare the complete
         * gameplay frame during that transition. Do not remove display
         * blanking unless the first gameplay frame is complete before it
         * becomes visible.
         */
        game_gear_video_draw_wall_columns();
#if GEARRAY_DEBUG_VIEWPORT_BORDER
        game_gear_video_draw_viewport_border();
#endif
        render_clone_names();
        SMS_displayOff();
        SMS_waitForVBlank();
        SMS_displayOn();
        scheduled_input_epoch();
        next_tick=frame_clock_now()+GEARRAY_SIM_DIVISOR;

        while (!player_is_dead())
        {
            /* Admission failure is sticky: preserve authoritative state and
             * stop both simulation and rendering until restart/debug reset. */
            if(frame_overflow || action_overflow) { scheduler_overload=1; continue; }
            now=frame_clock_now(); burst=0;
            while((signed int)(now-next_tick)>=0 && burst<2)
            {
                gameplay_service(next_tick);
                if(scheduled_pause || frame_overflow || action_overflow) break;
                ++burst;
                if(player_is_dead()) break;
                now=frame_clock_now();
                if((signed int)(now-next_tick)>=GEARRAY_SIM_DIVISOR) ++simulation_misses;
                next_tick+=GEARRAY_SIM_DIVISOR;
            }
            if(player_is_dead()) break;
            if((signed int)(now-next_tick)<0) scheduled_input_drain(now);
            if(scheduled_pause)
            {
                frame_clock_epoch(0); render_active=render_ready=0;
                game_gear_pause_map_show(); game_gear_video_restore_gameplay();
                scheduled_input_epoch(); next_tick=frame_clock_now()+GEARRAY_SIM_DIVISOR;
                continue;
            }
            if(frame_overflow || action_overflow) { scheduler_overload=1; continue; }
            if((signed int)(now-next_tick)>=0)
            {
                if((unsigned int)(now-next_tick)>scheduler_max_debt) scheduler_max_debt=now-next_tick;
                continue;
            }
            if(render_ready) render_publish();
            if(!render_active && !render_ready && displayed_generation!=simulation_tick_id) { render_capture(); continue; }
            if(render_active) {
                extern unsigned int render_hold_until;
                if((signed int)(now-render_hold_until)>=0) render_step();
            }
        }
        frame_clock_epoch(0);render_active=render_ready=0;

        pending_shot = 0;
        game_gear_video_present_player_death();
    }
}
