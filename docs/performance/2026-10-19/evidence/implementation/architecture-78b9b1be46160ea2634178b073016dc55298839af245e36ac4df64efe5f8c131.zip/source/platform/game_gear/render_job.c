#include "SMSlib.h"
#include "render_job.h"
#include "frame_clock.h"
#include "video.h"
#include "video_internal.h"
#include "../../game/camera.h"
#include "../../game/weapons.h"
#include "../../game/player.h"
#include <string.h>
#ifndef GEARRAY_COHERENT
#define GEARRAY_COHERENT 1
#endif
/* Installed SMSlib shadows only R0/R1, and hardcodes its name writers to
 * 0x3800. Own R2 explicitly; all incremental names use render_write_name.
 * Cold screens reset R2 while blanked before using library name writers. */
unsigned char render_vdp_reg2;
extern void game_gear_health_hud_names(unsigned char health);
RenderSnapshot render_snapshot;
unsigned int render_generation,displayed_generation;
unsigned int render_hold_until;
unsigned char render_active,render_ready,render_front;
unsigned int render_target_names,render_target_patterns;
static RayWork render_ray_work;
static unsigned char render_phase,ray_index,ray_started,initialized;
static void table_select(unsigned char back)
{
    unsigned char irq=frame_irq_save();
    render_vdp_reg2=back?0x0c:0x0e;
    SMS_VDPControlPort=render_vdp_reg2;
    SMS_VDPControlPort=0x82;
    frame_irq_restore(irq);
}
void render_write_name(unsigned char x,unsigned char y,unsigned int tile)
{ SMS_VRAMmemcpy(render_target_names+((unsigned int)y*32+x)*2,&tile,2); }
void render_reset(void)
{
    extern void render_video_invalidate(void);
    render_video_invalidate();
    render_active=render_ready=render_front=initialized=0;
    render_generation=displayed_generation=0;
    render_target_names=0x3800;render_target_patterns=102;
    table_select(0);
}
void render_clone_names(void)
{
    unsigned int offset;
    unsigned char bytes[32];
    for(offset=0;offset<1792;offset+=32) {
        SMS_readVRAM(bytes,0x3800+offset,32);
        SMS_VRAMmemcpy(0x3000+offset,bytes,32);
    }
    initialized=1;
}
void render_capture(void)
{
    unsigned char i,back=GEARRAY_COHERENT && initialized?!render_front:render_front;
    scene_capture(&render_snapshot.scene);
    render_snapshot.actor_count=world_sprite_get_count();
    for(i=0;i<render_snapshot.actor_count;++i) render_snapshot.actors[i]=*world_sprite_get(i);
    render_snapshot.pickup=SHOTGUN_PICKUP_PRESENT?1:0;
    render_snapshot.cell_x=shotgun_cell_x; render_snapshot.cell_y=shotgun_cell_y;
    render_snapshot.weapon=selected_weapon; render_snapshot.hud=game_gear_hud_weapon_pose();
    render_snapshot.health=player_get_health();render_snapshot.shake=game_gear_damage_shake_phase;
    ++render_generation;
    { extern unsigned int simulation_tick_id; render_snapshot.generation=simulation_tick_id; }render_snapshot.captured=frame_clock_now();
    render_target_names=back?0x3000:0x3800; render_target_patterns=back?214:102;
    render_phase=ray_index=ray_started=0;render_active=1;render_ready=0;
    if(raycaster_copy_cached(&render_snapshot.scene,render_snapshot.rays)) {
        render_projection_begin();render_phase=1;
    }
    render_hold_until=frame_clock_now();
}
void render_step(void)
{
    switch(render_phase) {
    case 0:
        if(!ray_started) {
            scene_ray_begin(&render_ray_work,&render_snapshot.scene,ray_index,&render_snapshot.rays[ray_index]);
            ray_started=1;
        }
        if(scene_ray_step(&render_ray_work)) { ++ray_index;ray_started=0; }
        if(ray_index==28) { render_projection_begin(); render_phase=1; }
        break;
    case 1:
        if(render_projection_step()) render_phase=2;
        break;
    case 2:
        render_video_begin();render_phase=3;break;
    case 3:
        if(render_video_step()) render_phase=4;
        break;
    default:
        raycaster_adopt_complete(&render_snapshot.scene,render_snapshot.rays);
        game_gear_health_hud_names(render_snapshot.health);
        render_ready=1;render_active=0;break;
    }
    /* All table/near-art readers finish before this explicit ownership boundary. */
    SMS_mapROMBank(2);
}
unsigned char render_publish(void)
{
    unsigned char v;
    if(!render_ready) return 0;
    /* VCount 200..220 is within blanking before the NTSC counter discontinuity.
     * The short IRQ-protected R2/scroll commit has >30 scanlines of margin. */
    v=SMS_getVCount();
    if(v<200 || v>220) return 0;
    if(GEARRAY_COHERENT) render_front=render_target_names==0x3000;
    table_select(render_front);
    SMS_setBGScrollX(game_gear_damage_shake_offsets[render_snapshot.shake]);
    displayed_generation=render_snapshot.generation;render_ready=0;
    return 1;
}
