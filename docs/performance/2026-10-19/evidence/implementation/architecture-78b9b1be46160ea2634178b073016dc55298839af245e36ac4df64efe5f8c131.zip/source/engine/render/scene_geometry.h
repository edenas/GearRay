#ifndef GEAR_RAY_SCENE_GEOMETRY_H
#define GEAR_RAY_SCENE_GEOMETRY_H
#include "raycaster.h"
typedef struct {
    signed int x,y,dx,dy,px,py;
    unsigned char doors[3], material;
} RayScene;
typedef struct {
    const RayScene *scene;
    RaycasterRay *out;
    unsigned char index;
} RayWork;
typedef struct { unsigned int depth[4]; } CombatWallSamples;
#define COMBAT_PISTOL_LEFT 0
#define COMBAT_CENTER 1
#define COMBAT_SHOTGUN_LEFT 2
#define COMBAT_SHOTGUN_RIGHT 3
void scene_capture(RayScene *scene);
void scene_ray_begin(RayWork *work, const RayScene *scene,
                     unsigned char index, RaycasterRay *out);
unsigned char scene_ray_step(RayWork *work);
unsigned char ray_kernel_step(RayWork *work);
const CombatWallSamples *raycaster_current_combat_samples(unsigned char shotgun);
unsigned char raycaster_copy_cached(const RayScene *scene,RaycasterRay *out);
void raycaster_adopt_complete(const RayScene *scene,const RaycasterRay *rays);
#endif
