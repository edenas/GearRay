#include "SMSlib.h"
#include "camera.h"
#include "scene_geometry.h"
#include "door_states.h"
#include "red_door_switch.h"
#include "world.h"
#include <string.h>
static RaycasterRay rendered_rays[RAYCASTER_RAY_COUNT];
static RayScene full_scene;
static unsigned char full_valid,full_hits_switch[RAYCASTER_RAY_COUNT];
static CombatWallSamples combat_samples;
static RaycasterRay combat_ray;
static RayScene combat_scene;
static RayWork combat_work;
static unsigned char combat_valid;
void scene_capture(RayScene *s)
{
    s->x=camera_get_position_x(); s->y=camera_get_position_y();
    s->dx=camera_get_direction_x(); s->dy=camera_get_direction_y();
    s->px=camera_get_plane_x(); s->py=camera_get_plane_y();
    s->doors[0]=door_state_get(0); s->doors[1]=door_state_get(1);
    s->doors[2]=door_state_get(2); s->material=red_door_switch_get_texture();
}
void scene_ray_begin(RayWork *w,const RayScene *scene,
                     unsigned char index,RaycasterRay *out)
{ w->scene=scene; w->out=out; w->index=index; }
unsigned char scene_ray_step(RayWork *w)
{
    /* Exact kernel and camera graph both reside in normal slot-2 page 2. */
    return ray_kernel_step(w);
}
void raycaster_initialize(void)
{
    unsigned char i;
    combat_valid=full_valid=0;
    for(i=0;i<RAYCASTER_RAY_COUNT;++i) {
        rendered_rays[i].wall_height=1;rendered_rays[i].hit_side=WALL_SIDE_X;
        rendered_rays[i].hit_offset=0;rendered_rays[i].texture_id=WORLD_TILE_STONE;
        rendered_rays[i].wall_distance=1;
    }
}
static unsigned char full_matches(const RayScene *scene)
{
    unsigned char i;
    /* Six scalars and three door bytes; resolved material is refreshed below.
     * RayScene is exactly 16 target bytes, with material last. */
    typedef char SceneKeyIs16[sizeof(RayScene)==16?1:-1];
    if(!full_valid || memcmp(scene,&full_scene,15)) return 0;
    if(scene->material!=full_scene.material) {
        for(i=0;i<RAYCASTER_RAY_COUNT;++i)
            if(full_hits_switch[i]) rendered_rays[i].texture_id=scene->material;
        full_scene.material=scene->material;
    }
    return 1;
}
unsigned char raycaster_copy_cached(const RayScene *scene,RaycasterRay *out)
{
    if(!full_matches(scene)) return 0;
    memcpy(out,rendered_rays,sizeof(rendered_rays));return 1;
}
void raycaster_adopt_complete(const RayScene *scene,const RaycasterRay *rays)
{
    unsigned char i;
    full_scene=*scene;memcpy(rendered_rays,rays,sizeof(rendered_rays));
    for(i=0;i<RAYCASTER_RAY_COUNT;++i)
        /* Current material IDs7..10 belong exclusively to the switch. */
        full_hits_switch[i]=rays[i].texture_id>=RED_DOOR_SWITCH_TEXTURE_OFF_FRAME_1
            && rays[i].texture_id<=RED_DOOR_SWITCH_TEXTURE_ON_FRAME_2;
    full_valid=1;
}
void raycaster_update(void)
{
    RayScene scene;
    unsigned char i;
    scene_capture(&scene);if(full_matches(&scene)) return;
    for(i=0;i<RAYCASTER_RAY_COUNT;++i) {
        scene_ray_begin(&combat_work,&scene,i,&rendered_rays[i]);
        scene_ray_step(&combat_work);
    }
    raycaster_adopt_complete(&scene,rendered_rays);
}
const RaycasterRay *raycaster_get_rendered_rays(void) { return rendered_rays; }
const CombatWallSamples *raycaster_current_combat_samples(unsigned char shotgun)
{
    RayScene scene;
    unsigned char i,index,bit;
    scene_capture(&scene);
    if(full_matches(&scene)) {
        combat_samples.depth[0]=rendered_rays[13].wall_distance;
        combat_samples.depth[1]=rendered_rays[14].wall_distance;
        combat_samples.depth[2]=rendered_rays[10].wall_distance;
        combat_samples.depth[3]=rendered_rays[18].wall_distance;
        combat_scene=scene;combat_valid=15;return &combat_samples;
    }
    if(memcmp(&scene,&combat_scene,sizeof(RayScene))) combat_valid=0;
    combat_scene=scene;
    for(i=0;i<4;++i) {
        if(shotgun?i==0:i>=2) continue;
        bit=1U<<i;
        if(combat_valid&bit) continue;
        index=i==0?13:i==1?14:i==2?10:18;
        scene_ray_begin(&combat_work,&combat_scene,index,&combat_ray);
        scene_ray_step(&combat_work);
        combat_samples.depth[i]=combat_ray.wall_distance;
        combat_valid|=bit;
    }
    return &combat_samples;
}
