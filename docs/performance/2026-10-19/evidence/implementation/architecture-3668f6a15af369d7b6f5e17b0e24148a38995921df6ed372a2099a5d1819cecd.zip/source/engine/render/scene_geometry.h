#ifndef GEAR_RAY_SCENE_GEOMETRY_H
#define GEAR_RAY_SCENE_GEOMETRY_H
#include "raycaster.h"
typedef struct {
    signed int x,y,dx,dy,px,py;
    unsigned char doors[3], material;
} RayScene;
typedef struct {
    const RayScene *scene;
    RaycasterRay *out;
    signed int dx,dy,mx,my,sx,sy;
    unsigned long delta_x,delta_y,side_x,side_y,distance;
    unsigned char phase,index;
} RayWork;
void scene_capture(RayScene *scene);
void scene_ray_begin(RayWork *work, const RayScene *scene,
                     unsigned char index, RaycasterRay *out);
unsigned char scene_ray_step(RayWork *work);
unsigned char ray_kernel_step(RayWork *work);
const RaycasterRay *raycaster_current_combat_samples(unsigned char shotgun);
#endif
