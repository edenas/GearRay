#include "scene_geometry.h"
#include "wall_textures.h"
#include "wall_texture.h"
#include "wall_schedules.h"
#include "native_wall.h"
#include <string.h>
/* Physical page 4 is owned only during this leaf. Texture bytes and palettes
 * remain in page 1; the row schedule pointer never escapes to a caller. */
unsigned char wall_schedule_palette(const RaycasterRay *ray,unsigned char y)
{
    unsigned char row=wall_source_rows[ray->wall_height-17][y>>1];
    unsigned char column=ray->hit_offset>>5,color;
    if(y&1) row&=15;else row>>=4;
    if(row==15) return 255;
    color=wall_textures[ray->texture_id-1][row*4+(column>>1)];
    if(!(column&1)) color>>=4;
    color&=15;
    if(color>=WALL_TEXTURE_COLOR_COUNT) color=0;
    return ray->hit_side==WALL_SIDE_X?wall_palette_x_indices[color]:wall_palette_y_indices[color];
}

static const unsigned char left_lod1_x_rows[8][4] = {
    {0xa0, 0x50, 0x00, 0xa0}, {0x50, 0xa0, 0x00, 0x50},
    {0xa0, 0x50, 0x00, 0xa0}, {0x50, 0xa0, 0x00, 0x50},
    {0xa0, 0x50, 0x00, 0xa0}, {0x50, 0xa0, 0x00, 0x50},
    {0xa0, 0x50, 0x00, 0xa0}, {0x50, 0xa0, 0x00, 0x50}
};
static const unsigned char right_lod1_x_rows[8][4] = {
    {0x0a, 0x05, 0x00, 0x0a}, {0x05, 0x0a, 0x00, 0x05},
    {0x0a, 0x05, 0x00, 0x0a}, {0x05, 0x0a, 0x00, 0x05},
    {0x0a, 0x05, 0x00, 0x0a}, {0x05, 0x0a, 0x00, 0x05},
    {0x0a, 0x05, 0x00, 0x0a}, {0x05, 0x0a, 0x00, 0x05}
};
static const unsigned char left_lod1_y_rows[8][4] = {
    {0x00, 0xf0, 0x00, 0xa0}, {0x00, 0xf0, 0x00, 0x50},
    {0x00, 0xf0, 0x00, 0xa0}, {0x00, 0xf0, 0x00, 0x50},
    {0x00, 0xf0, 0x00, 0xa0}, {0x00, 0xf0, 0x00, 0x50},
    {0x00, 0xf0, 0x00, 0xa0}, {0x00, 0xf0, 0x00, 0x50}
};
static const unsigned char right_lod1_y_rows[8][4] = {
    {0x00, 0x0f, 0x00, 0x0a}, {0x00, 0x0f, 0x00, 0x05},
    {0x00, 0x0f, 0x00, 0x0a}, {0x00, 0x0f, 0x00, 0x05},
    {0x00, 0x0f, 0x00, 0x0a}, {0x00, 0x0f, 0x00, 0x05},
    {0x00, 0x0f, 0x00, 0x0a}, {0x00, 0x0f, 0x00, 0x05}
};

static const unsigned char left_lod2_rows[2][8][4] = {
    {
        {0x00, 0xb0, 0x00, 0xa0}, {0x00, 0xf0, 0x00, 0x70},
        {0x00, 0x70, 0x00, 0x50}, {0x00, 0xf0, 0x00, 0xb0},
        {0x00, 0x70, 0x00, 0x60}, {0x00, 0xf0, 0x00, 0x70},
        {0x00, 0xb0, 0x00, 0x90}, {0x00, 0xf0, 0x00, 0xb0}
    },
    {
        {0x00, 0xf0, 0x00, 0xb0}, {0x00, 0x70, 0x00, 0x50},
        {0x00, 0xf0, 0x00, 0x70}, {0x00, 0xb0, 0x00, 0xa0},
        {0x00, 0xf0, 0x00, 0xb0}, {0x00, 0xb0, 0x00, 0x90},
        {0x00, 0xf0, 0x00, 0x70}, {0x00, 0x70, 0x00, 0x60}
    }
};
static const unsigned char right_lod2_rows[2][8][4] = {
    {
        {0x00, 0x0b, 0x00, 0x0a}, {0x00, 0x0f, 0x00, 0x07},
        {0x00, 0x07, 0x00, 0x05}, {0x00, 0x0f, 0x00, 0x0b},
        {0x00, 0x07, 0x00, 0x06}, {0x00, 0x0f, 0x00, 0x07},
        {0x00, 0x0b, 0x00, 0x09}, {0x00, 0x0f, 0x00, 0x0b}
    },
    {
        {0x00, 0x0f, 0x00, 0x0b}, {0x00, 0x07, 0x00, 0x05},
        {0x00, 0x0f, 0x00, 0x07}, {0x00, 0x0b, 0x00, 0x0a},
        {0x00, 0x0f, 0x00, 0x0b}, {0x00, 0x0b, 0x00, 0x09},
        {0x00, 0x0f, 0x00, 0x07}, {0x00, 0x07, 0x00, 0x06}
    }
};

/* Four native rows per call amortize address setup while keeping a bounded
 * continuation. The lookup tables are read only while slot 2 maps page 4. */
void wall_native_rows(unsigned char *dst,const RaycasterRay *left,
                     unsigned char y,unsigned char column,unsigned char count)
{
    const RaycasterRay *right=left+1;
    const unsigned char *ls=0,*rs=0,*lc=0,*rc=0,*lflat=0,*rflat=0,*lp,*rp;
    const unsigned char *pair;
    unsigned char lnear=left->wall_height>16,rnear=right->wall_height>16;
    unsigned char lrow,rrow,background,left_color,right_color;
    signed int ltop=(64-(signed int)left->wall_height)/2;
    signed int rtop=(64-(signed int)right->wall_height)/2;
    if(lnear) {
        ls=wall_source_rows[left->wall_height-17];
        lc=wall_color_columns[left->texture_id-1][left->hit_side][left->hit_offset>>5];
    } else lflat=left->wall_height<=8?&left_lod2_rows[column&1][0][0]:
        left->hit_side==WALL_SIDE_X?&left_lod1_x_rows[0][0]:&left_lod1_y_rows[0][0];
    if(rnear) {
        rs=wall_source_rows[right->wall_height-17];
        rc=wall_color_columns[right->texture_id-1][right->hit_side][right->hit_offset>>5];
    } else rflat=right->wall_height<=8?&right_lod2_rows[column&1][0][0]:
        right->hit_side==WALL_SIDE_X?&right_lod1_x_rows[0][0]:&right_lod1_y_rows[0][0];
    while(count--) {
        background=y<32?3:10;
        left_color=right_color=background;
        if(lnear) {
            lrow=ls[y>>1];if(y&1) lrow&=15;else lrow>>=4;
            if(lrow!=15) left_color=lc[lrow];
        }
        if(rnear) {
            rrow=rs[y>>1];if(y&1) rrow&=15;else rrow>>=4;
            if(rrow!=15) right_color=rc[rrow];
        }
        pair=native_wall_pairs[(left_color<<4)|right_color];
        if(lnear && rnear) {
            dst[0]=pair[0];dst[1]=pair[1];dst[2]=pair[2];dst[3]=pair[3];
        } else {
            lp=!lnear && y>=ltop && y<ltop+left->wall_height?lflat+(y&7)*4:pair;
            rp=!rnear && y>=rtop && y<rtop+right->wall_height?rflat+(y&7)*4:pair;
            dst[0]=(lp[0]&240)|(rp[0]&15);dst[1]=(lp[1]&240)|(rp[1]&15);
            dst[2]=(lp[2]&240)|(rp[2]&15);dst[3]=(lp[3]&240)|(rp[3]&15);
        }
        dst+=4;++y;
    }
}

void wall_plan_prepare(const RaycasterRay *ray,NativeWallPlan *plan,unsigned char column)
{
    if(ray->wall_height>16) {
        memcpy(plan->rows,wall_source_rows[ray->wall_height-17],32);
        memcpy(plan->colors,wall_color_columns[ray->texture_id-1][ray->hit_side][ray->hit_offset>>5],8);
        plan->mode=0;
    } else {
        plan->mode=ray->wall_height<=8?3+(column&1):1+ray->hit_side;
        plan->top=(64-ray->wall_height)/2;
        plan->bottom=plan->top+ray->wall_height;
    }
}
void wall_plan_rows(unsigned char *dst,NativeWallPlan *left,NativeWallPlan *right,
                    unsigned char y,unsigned char count)
{
    const unsigned char *pair,*lp,*rp,*lflat=0,*rflat=0;
    unsigned char lr,rr,background=y<32?3:10,lc,rc;
    left->colors[15]=right->colors[15]=background;
    if(!left->mode && !right->mode) {
        while(count--) {
            lr=left->rows[y>>1];rr=right->rows[y>>1];
            if(y&1) {lr&=15;rr&=15;} else {lr>>=4;rr>>=4;}
            pair=native_wall_pairs[(left->colors[lr]<<4)|right->colors[rr]];
            dst[0]=pair[0];dst[1]=pair[1];dst[2]=pair[2];dst[3]=pair[3];
            dst+=4;++y;
        }
        return;
    }
    if(left->mode) lflat=left->mode>=3?&left_lod2_rows[left->mode-3][0][0]:
        left->mode==1?&left_lod1_x_rows[0][0]:&left_lod1_y_rows[0][0];
    if(right->mode) rflat=right->mode>=3?&right_lod2_rows[right->mode-3][0][0]:
        right->mode==1?&right_lod1_x_rows[0][0]:&right_lod1_y_rows[0][0];
    while(count--) {
        lc=rc=background;
        if(!left->mode) {lr=left->rows[y>>1];if(y&1)lr&=15;else lr>>=4;lc=left->colors[lr];}
        if(!right->mode) {rr=right->rows[y>>1];if(y&1)rr&=15;else rr>>=4;rc=right->colors[rr];}
        pair=native_wall_pairs[(lc<<4)|rc];
        lp=left->mode && y>=left->top && y<left->bottom?lflat+(y&7)*4:pair;
        rp=right->mode && y>=right->top && y<right->bottom?rflat+(y&7)*4:pair;
        dst[0]=(lp[0]&240)|(rp[0]&15);dst[1]=(lp[1]&240)|(rp[1]&15);
        dst[2]=(lp[2]&240)|(rp[2]&15);dst[3]=(lp[3]&240)|(rp[3]&15);
        dst+=4;++y;
    }
}

