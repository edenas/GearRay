#include "SMSlib.h"
#include "camera.h"
#include "scene_geometry.h"
#include "door_states.h"
#include "red_door_switch.h"
#include <string.h>
static RaycasterRay rendered_rays[RAYCASTER_RAY_COUNT];
static RaycasterRay combat_rays[RAYCASTER_RAY_COUNT];
static RayScene cached_scene;
static unsigned char valid;
static RayWork combat_work;
void scene_capture(RayScene *s)
{
    s->x=camera_get_position_x(); s->y=camera_get_position_y();
    s->dx=camera_get_direction_x(); s->dy=camera_get_direction_y();
    s->px=camera_get_plane_x(); s->py=camera_get_plane_y();
    s->doors[0]=door_state_get(0); s->doors[1]=door_state_get(1);
    s->doors[2]=door_state_get(2); s->material=red_door_switch_get_texture();
}
void scene_ray_begin(RayWork *w,const RayScene *scene,
                     unsigned char index,RaycasterRay *out)
{ w->scene=scene; w->out=out; w->index=index; w->phase=0; }
unsigned char scene_ray_step(RayWork *w)
{
    unsigned char done;
    SMS_mapROMBank(4);
    done=ray_kernel_step(w);
    SMS_mapROMBank(2);
    return done;
}
void raycaster_initialize(void) { valid=0; }
void raycaster_update(void)
{
    RayScene scene;
    unsigned char i;
    scene_capture(&scene);
    if(valid && !memcmp(&scene,&cached_scene,sizeof(RayScene))) return;
    for(i=0;i<RAYCASTER_RAY_COUNT;++i) {
        scene_ray_begin(&combat_work,&scene,i,&rendered_rays[i]);
        while(!scene_ray_step(&combat_work)) { }
    }
    cached_scene=scene; valid=1;
}
const RaycasterRay *raycaster_get_rendered_rays(void) { return rendered_rays; }
const RaycasterRay *raycaster_current_combat_samples(unsigned char shotgun)
{
    RayScene scene;
    unsigned char i,index;
    scene_capture(&scene);
    if(valid && !memcmp(&scene,&cached_scene,sizeof(RayScene))) return rendered_rays;
    for(i=0;i<(shotgun?3:2);++i) {
        index=shotgun?(i==0?10:i==1?14:18):(i==0?13:14);
        scene_ray_begin(&combat_work,&scene,index,&combat_rays[index]);
        while(!scene_ray_step(&combat_work)) { }
    }
    return combat_rays;
}
