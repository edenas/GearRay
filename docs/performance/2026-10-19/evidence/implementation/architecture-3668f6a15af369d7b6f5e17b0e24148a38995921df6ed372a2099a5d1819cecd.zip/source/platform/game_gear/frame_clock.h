#ifndef GEAR_RAY_FRAME_CLOCK_H
#define GEAR_RAY_FRAME_CLOCK_H
#define CAP_UP 1
#define CAP_DOWN 2
#define CAP_LEFT 4
#define CAP_RIGHT 8
#define CAP_FIRE 16
#define CAP_STRAFE 32
#define CAP_START 64
typedef struct { unsigned int sequence; unsigned char mask; } FrameSample;
extern volatile unsigned int frame_sequence;
extern volatile unsigned char frame_overflow, frame_capture_enabled;
extern volatile unsigned char frame_head,frame_tail,frame_latest;
void frame_clock_initialize(void);
unsigned int frame_clock_now(void);
unsigned char frame_clock_pop(FrameSample *sample,unsigned int cutoff);
void frame_clock_epoch(unsigned char enabled);
unsigned char frame_irq_save(void);
void frame_irq_restore(unsigned char enabled);
/* Critical helpers are MAIN-ONLY with interrupts enabled on entry. They must
 * never be called by IRQ/NMI or from an already-masked critical region. The
 * NMOS Z80 LD A,I interrupt race makes the usual IFF-probing idiom unsafe. */
void frame_capture_hook(void);
#endif
