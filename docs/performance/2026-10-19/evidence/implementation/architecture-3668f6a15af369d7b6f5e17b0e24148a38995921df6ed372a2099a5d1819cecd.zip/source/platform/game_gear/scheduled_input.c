#include "frame_clock.h"
#include "scheduled_input.h"
#include "input_internal.h"
typedef struct { unsigned int sequence; unsigned char type,flags; } InputAction;
static InputAction actions[16];
static unsigned char head,tail,held,blocked,b2_used;
static signed char previous_forward,previous_horizontal;
static signed char tap_forward,tap_turn,tap_strafe;
static unsigned char forward_used,horizontal_used;
unsigned char scheduled_pause,action_overflow;
unsigned int captured_fire_edges,consumed_fire_edges,captured_interactions;
unsigned char scheduled_fire,scheduled_interact;
signed char scheduled_forward,scheduled_strafe,scheduled_turn;
static void enqueue(unsigned int sequence,unsigned char type)
{
    unsigned char i;
    if((unsigned char)(head-tail)==16) { action_overflow=1; return; }
    i=head&15; actions[i].sequence=sequence; actions[i].type=type; actions[i].flags=0;
    ++head;
}
void scheduled_input_epoch(void)
{
    head=tail=0; held=0; blocked=frame_latest;
    b2_used=scheduled_pause=scheduled_fire=scheduled_interact=0;
    previous_forward=previous_horizontal=0;
    tap_forward=tap_turn=tap_strafe=0;
    forward_used=horizontal_used=0;
    frame_clock_epoch(1);
}
void scheduled_input_drain(unsigned int cutoff)
{
    FrameSample sample;
    unsigned char next,old;
    signed char forward,horizontal;
    if(frame_overflow || action_overflow) {
        head=tail=0; held=0; blocked=frame_latest;
        tap_forward=tap_turn=tap_strafe=0;
        frame_clock_epoch(1);
        /* Sticky diagnostics survive; scheduler treats these as admission fail. */
        return;
    }
    while(frame_clock_pop(&sample,cutoff)) {
        old=held;
        blocked&=sample.mask;
        next=sample.mask&~blocked;
        if((next&CAP_START) && !(old&CAP_START)) scheduled_pause=1;
        if((next&CAP_FIRE) && !(old&CAP_FIRE)) {
            enqueue(sample.sequence,1); ++captured_fire_edges;
        }
        if((next&CAP_STRAFE) && !(old&CAP_STRAFE)) b2_used=0;
        if((next&CAP_STRAFE) && (next&(CAP_LEFT|CAP_RIGHT))) b2_used=1;
        if(!(next&CAP_STRAFE) && (old&CAP_STRAFE) && !b2_used) {
            enqueue(sample.sequence,2); ++captured_interactions;
        }
        forward=((next&CAP_UP)!=0)-((next&CAP_DOWN)!=0);
        horizontal=((next&CAP_RIGHT)!=0)-((next&CAP_LEFT)!=0);
        if(forward && forward!=previous_forward) {
            forward_used=0;
            if(tap_forward==-forward) tap_forward=0;
        }
        if(!forward && previous_forward && !forward_used) tap_forward=previous_forward;
        if(horizontal && horizontal!=previous_horizontal) {
            horizontal_used=0;
            if(next&CAP_STRAFE) { if(tap_strafe==-horizontal) tap_strafe=0; }
            else if(tap_turn==-horizontal) tap_turn=0;
        }
        if(!horizontal && previous_horizontal && !horizontal_used) {
            if(old&CAP_STRAFE) tap_strafe=previous_horizontal;
            else tap_turn=previous_horizontal;
        }
        previous_forward=forward; previous_horizontal=horizontal; held=next;
    }
}
void scheduled_input_tick(void)
{
    signed char horizontal;
    unsigned char type;
    scheduled_fire=scheduled_interact=0;
    while(tail!=head) {
        type=actions[tail&15].type;
        if((type==1 && scheduled_fire) || (type==2 && scheduled_interact)) break;
        ++tail;
        if(type==1) { scheduled_fire=1; ++consumed_fire_edges; }
        else scheduled_interact=1;
    }
    scheduled_forward=((held&CAP_UP)!=0)-((held&CAP_DOWN)!=0);
    if(scheduled_forward) forward_used=1; else scheduled_forward=tap_forward;
    horizontal=((held&CAP_RIGHT)!=0)-((held&CAP_LEFT)!=0);
    if(horizontal) horizontal_used=1;
    scheduled_strafe=held&CAP_STRAFE?(horizontal?horizontal:tap_strafe):tap_strafe;
    scheduled_turn=held&CAP_STRAFE?0:(horizontal?horizontal:tap_turn);
    tap_forward=tap_strafe=tap_turn=0;
}
