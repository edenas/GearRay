#include "render_job.h"
#include "SMSlib.h"
#include "../../engine/render/raycaster.h"
#define GEAR_RAY_WORLD_SPRITE_NO_DISTANCE_METRIC
#include "../../game/world_sprite.h"
#include "hud_weapon.h"
#include "near_zombie_textures.h"
#include "render_textures.h"
#include "renderer_profile.h"
#include "sprite_projection.h"
#include "../../game/weapons.h"
#include "video.h"
#include "video_internal.h"
#include "vram_layout.h"
#include "wall_textures.h"

#define WALL_PATTERN_TILE_BASE WALL_X_NEAR_TILE_INDEX_BASE
#define NATIVE_TILE_ROW_BYTES 4
#define NATIVE_TILE_BYTES 32
#define CEILING_PALETTE_INDEX (GAME_GEAR_WALL_PALETTE_BASE + 2)
#define FLOOR_PALETTE_INDEX (GAME_GEAR_WALL_PALETTE_BASE + 9)
#define WALL_COLUMN_VALID_FLAG 0x80
#define WALL_COLUMN_LEFT_SIDE_Y_FLAG 0x01
#define WALL_COLUMN_RIGHT_SIDE_Y_FLAG 0x02
#define DISTANT_WALL_MAX_PROJECTED_HEIGHT 16
#define VERY_DISTANT_WALL_MAX_PROJECTED_HEIGHT 8
#define SPRITE_TRANSPARENT_INDEX 15
#define SMS_MAPPER_SLOT2_REGISTER (*(volatile unsigned char *)0xFFFF)
#define NEAR_ZOMBIE_ROM_PAGE 2

static const unsigned char left_lod1_x_rows[8][4] = {
    {0xa0, 0x50, 0x00, 0xa0}, {0x50, 0xa0, 0x00, 0x50},
    {0xa0, 0x50, 0x00, 0xa0}, {0x50, 0xa0, 0x00, 0x50},
    {0xa0, 0x50, 0x00, 0xa0}, {0x50, 0xa0, 0x00, 0x50},
    {0xa0, 0x50, 0x00, 0xa0}, {0x50, 0xa0, 0x00, 0x50}
};
static const unsigned char right_lod1_x_rows[8][4] = {
    {0x0a, 0x05, 0x00, 0x0a}, {0x05, 0x0a, 0x00, 0x05},
    {0x0a, 0x05, 0x00, 0x0a}, {0x05, 0x0a, 0x00, 0x05},
    {0x0a, 0x05, 0x00, 0x0a}, {0x05, 0x0a, 0x00, 0x05},
    {0x0a, 0x05, 0x00, 0x0a}, {0x05, 0x0a, 0x00, 0x05}
};
static const unsigned char left_lod1_y_rows[8][4] = {
    {0x00, 0xf0, 0x00, 0xa0}, {0x00, 0xf0, 0x00, 0x50},
    {0x00, 0xf0, 0x00, 0xa0}, {0x00, 0xf0, 0x00, 0x50},
    {0x00, 0xf0, 0x00, 0xa0}, {0x00, 0xf0, 0x00, 0x50},
    {0x00, 0xf0, 0x00, 0xa0}, {0x00, 0xf0, 0x00, 0x50}
};
static const unsigned char right_lod1_y_rows[8][4] = {
    {0x00, 0x0f, 0x00, 0x0a}, {0x00, 0x0f, 0x00, 0x05},
    {0x00, 0x0f, 0x00, 0x0a}, {0x00, 0x0f, 0x00, 0x05},
    {0x00, 0x0f, 0x00, 0x0a}, {0x00, 0x0f, 0x00, 0x05},
    {0x00, 0x0f, 0x00, 0x0a}, {0x00, 0x0f, 0x00, 0x05}
};

static const unsigned char left_lod2_rows[2][8][4] = {
    {
        {0x00, 0xb0, 0x00, 0xa0}, {0x00, 0xf0, 0x00, 0x70},
        {0x00, 0x70, 0x00, 0x50}, {0x00, 0xf0, 0x00, 0xb0},
        {0x00, 0x70, 0x00, 0x60}, {0x00, 0xf0, 0x00, 0x70},
        {0x00, 0xb0, 0x00, 0x90}, {0x00, 0xf0, 0x00, 0xb0}
    },
    {
        {0x00, 0xf0, 0x00, 0xb0}, {0x00, 0x70, 0x00, 0x50},
        {0x00, 0xf0, 0x00, 0x70}, {0x00, 0xb0, 0x00, 0xa0},
        {0x00, 0xf0, 0x00, 0xb0}, {0x00, 0xb0, 0x00, 0x90},
        {0x00, 0xf0, 0x00, 0x70}, {0x00, 0x70, 0x00, 0x60}
    }
};
static const unsigned char right_lod2_rows[2][8][4] = {
    {
        {0x00, 0x0b, 0x00, 0x0a}, {0x00, 0x0f, 0x00, 0x07},
        {0x00, 0x07, 0x00, 0x05}, {0x00, 0x0f, 0x00, 0x0b},
        {0x00, 0x07, 0x00, 0x06}, {0x00, 0x0f, 0x00, 0x07},
        {0x00, 0x0b, 0x00, 0x09}, {0x00, 0x0f, 0x00, 0x0b}
    },
    {
        {0x00, 0x0f, 0x00, 0x0b}, {0x00, 0x07, 0x00, 0x05},
        {0x00, 0x0f, 0x00, 0x07}, {0x00, 0x0b, 0x00, 0x0a},
        {0x00, 0x0f, 0x00, 0x0b}, {0x00, 0x0b, 0x00, 0x09},
        {0x00, 0x0f, 0x00, 0x07}, {0x00, 0x07, 0x00, 0x06}
    }
};

#if GEARRAY_DEBUG_VIEWPORT_BORDER
#define DEBUG_BORDER_HORIZONTAL_TILE_INDEX 97
#define DEBUG_BORDER_VERTICAL_TILE_INDEX 98
#define DEBUG_BORDER_CORNER_TILE_INDEX 99

static const unsigned char debug_border_tiles[3][8] = {
    { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xff },
    { 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01 },
    { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01 }
};
#endif

static unsigned char projected_wall_column[
    NATIVE_TILE_BYTES];
unsigned char viewport_tile_states[
    GAME_GEAR_VIEWPORT_TILE_COLUMNS * GAME_GEAR_VIEWPORT_TILE_ROWS];
GameGearWallColumnSignature previous_wall_columns[
    GAME_GEAR_VIEWPORT_TILE_COLUMNS];

static GameGearProjectedSprite previous_projected_sprites[
    PROJECTED_SPRITE_MAX_COUNT];
unsigned char previous_projected_sprite_count;
unsigned char game_gear_damage_shake_phase;

void game_gear_damage_shake_update(void)
{
    if (game_gear_damage_shake_phase == 0)
        return;

    --game_gear_damage_shake_phase;

}

static const unsigned char left_palette_bitplanes[16][4] = {
    {0x00, 0x00, 0x00, 0x00}, {0xf0, 0x00, 0x00, 0x00},
    {0x00, 0xf0, 0x00, 0x00}, {0xf0, 0xf0, 0x00, 0x00},
    {0x00, 0x00, 0xf0, 0x00}, {0xf0, 0x00, 0xf0, 0x00},
    {0x00, 0xf0, 0xf0, 0x00}, {0xf0, 0xf0, 0xf0, 0x00},
    {0x00, 0x00, 0x00, 0xf0}, {0xf0, 0x00, 0x00, 0xf0},
    {0x00, 0xf0, 0x00, 0xf0}, {0xf0, 0xf0, 0x00, 0xf0},
    {0x00, 0x00, 0xf0, 0xf0}, {0xf0, 0x00, 0xf0, 0xf0},
    {0x00, 0xf0, 0xf0, 0xf0}, {0xf0, 0xf0, 0xf0, 0xf0}
};

static const unsigned char right_palette_bitplanes[16][4] = {
    {0x00, 0x00, 0x00, 0x00}, {0x0f, 0x00, 0x00, 0x00},
    {0x00, 0x0f, 0x00, 0x00}, {0x0f, 0x0f, 0x00, 0x00},
    {0x00, 0x00, 0x0f, 0x00}, {0x0f, 0x00, 0x0f, 0x00},
    {0x00, 0x0f, 0x0f, 0x00}, {0x0f, 0x0f, 0x0f, 0x00},
    {0x00, 0x00, 0x00, 0x0f}, {0x0f, 0x00, 0x00, 0x0f},
    {0x00, 0x0f, 0x00, 0x0f}, {0x0f, 0x0f, 0x00, 0x0f},
    {0x00, 0x00, 0x0f, 0x0f}, {0x0f, 0x00, 0x0f, 0x0f},
    {0x00, 0x0f, 0x0f, 0x0f}, {0x0f, 0x0f, 0x0f, 0x0f}
};

static unsigned char game_gear_get_background_palette_index(
    unsigned char screen_y)
{
    return screen_y < GAME_GEAR_VIEWPORT_PIXEL_HEIGHT / 2
        ? CEILING_PALETTE_INDEX
        : FLOOR_PALETTE_INDEX;
}

static unsigned char game_gear_sprite_covers_tile_column(
    const GameGearProjectedSprite *sprite,
    unsigned char tile_column)
{
    signed int tile_left = tile_column * 8;
    signed int tile_right = tile_left + 8;

    return sprite->visible
        && sprite->right > tile_left
        && sprite->left < tile_right;
}

static unsigned char game_gear_sprite_covers_tile(
    const GameGearProjectedSprite *sprite,
    unsigned char tile_column,
    unsigned char tile_row)
{
    signed int tile_top = tile_row * 8;

    return game_gear_sprite_covers_tile_column(sprite, tile_column)
        && sprite->bottom > tile_top
        && sprite->top < tile_top + 8;
}

static void game_gear_overlay_sprite_tile(
    unsigned char *destination,
    unsigned char tile_column,
    unsigned char tile_row,
    const GameGearProjectedSprite *projected,
    const RaycasterRay *rays)
{
    const unsigned char *pixels =
        projected->near_texture_id == NEAR_ZOMBIE_TEXTURE_NONE
        ? projected->pixels
        : near_zombie_texture_pixels[projected->near_texture_id];
    unsigned int source_size = projected->near_texture_id
        == NEAR_ZOMBIE_TEXTURE_NONE ? projected->source_size : 32;
    unsigned char packed_row_stride = (unsigned char)source_size >> 1;
    signed int tile_left = tile_column * 8;
    signed int tile_top = tile_row * 8;
    signed int screen_x;
    signed int screen_y;
    unsigned int texture_x;
    unsigned int texture_y;
    const unsigned char *source_row;
    unsigned char pixel_x;
    unsigned char pixel_y;
    unsigned char palette_index;
    unsigned char mask;

    for (pixel_y = 0; pixel_y < 8; ++pixel_y)
    {
        screen_y = tile_top + pixel_y;
        if (screen_y < projected->top || screen_y >= projected->bottom)
            continue;
        texture_y =
            ((unsigned int)(screen_y - projected->top)
             * projected->texture_step) >> 8;
        if (texture_y >= source_size)
            texture_y = source_size - 1;
        source_row = pixels + texture_y * packed_row_stride;

        for (pixel_x = 0; pixel_x < 8; ++pixel_x)
        {
            screen_x = tile_left + pixel_x;
            if (screen_x < projected->left || screen_x >= projected->right)
                continue;
            if (projected->depth
                >= rays[(unsigned char)screen_x >> 2].wall_distance)
            {
                continue;
            }

            texture_x =
                ((unsigned int)(screen_x - projected->left)
                 * projected->texture_step) >> 8;
            if (texture_x >= source_size)
                texture_x = source_size - 1;
            palette_index = source_row[texture_x >> 1];
            if (texture_x & 1)
                palette_index &= 15;
            else
                palette_index >>= 4;
            if (palette_index == SPRITE_TRANSPARENT_INDEX)
                continue;

            mask = (unsigned char)(0x80U >> pixel_x);
            if (palette_index & 1U)
                destination[pixel_y * 4 + 0] |= mask;
            else
                destination[pixel_y * 4 + 0] &= (unsigned char)~mask;
            if (palette_index & 2U)
                destination[pixel_y * 4 + 1] |= mask;
            else
                destination[pixel_y * 4 + 1] &= (unsigned char)~mask;
            if (palette_index & 4U)
                destination[pixel_y * 4 + 2] |= mask;
            else
                destination[pixel_y * 4 + 2] &= (unsigned char)~mask;
            if (palette_index & 8U)
                destination[pixel_y * 4 + 3] |= mask;
            else
                destination[pixel_y * 4 + 3] &= (unsigned char)~mask;
        }
    }
}

static unsigned char game_gear_wall_column_is_unchanged(
    const GameGearWallColumnSignature *previous,
    unsigned char left_wall_height,
    unsigned char right_wall_height,
    unsigned char left_hit_offset,
    unsigned char right_hit_offset,
    unsigned char left_texture_id,
    unsigned char right_texture_id,
    WallSide left_wall_side,
    WallSide right_wall_side)
{
    unsigned char side_flags = 0;

    if ((previous->side_and_valid_flags & WALL_COLUMN_VALID_FLAG) == 0)
        return 0;

    if (left_wall_side == WALL_SIDE_Y)
        side_flags |= WALL_COLUMN_LEFT_SIDE_Y_FLAG;

    if (right_wall_side == WALL_SIDE_Y)
        side_flags |= WALL_COLUMN_RIGHT_SIDE_Y_FLAG;

    return previous->left_wall_height == left_wall_height
        && previous->right_wall_height == right_wall_height
        && previous->left_hit_offset == left_hit_offset
        && previous->right_hit_offset == right_hit_offset
        && previous->left_texture_id == left_texture_id
        && previous->right_texture_id == right_texture_id
        && (previous->side_and_valid_flags
            & (WALL_COLUMN_LEFT_SIDE_Y_FLAG
               | WALL_COLUMN_RIGHT_SIDE_Y_FLAG)) == side_flags;
}

static void game_gear_store_wall_column_signature(
    GameGearWallColumnSignature *previous,
    unsigned char left_wall_height,
    unsigned char right_wall_height,
    unsigned char left_hit_offset,
    unsigned char right_hit_offset,
    unsigned char left_texture_id,
    unsigned char right_texture_id,
    WallSide left_wall_side,
    WallSide right_wall_side)
{
    unsigned char side_and_valid_flags = WALL_COLUMN_VALID_FLAG;

    previous->left_wall_height = left_wall_height;
    previous->right_wall_height = right_wall_height;
    previous->left_hit_offset = left_hit_offset;
    previous->right_hit_offset = right_hit_offset;
    previous->left_texture_id = left_texture_id;
    previous->right_texture_id = right_texture_id;
    if (left_wall_side == WALL_SIDE_Y)
        side_and_valid_flags |= WALL_COLUMN_LEFT_SIDE_Y_FLAG;

    if (right_wall_side == WALL_SIDE_Y)
        side_and_valid_flags |= WALL_COLUMN_RIGHT_SIDE_Y_FLAG;

    previous->side_and_valid_flags = side_and_valid_flags;
}

static void game_gear_build_native_wall_tile(
    unsigned char *destination,
    GameGearWallTextureSampler *left_sampler,
    unsigned char left_wall_is_far,
    const unsigned char *left_flat_rows,
    unsigned char left_wall_top,
    unsigned char left_wall_height,
    GameGearWallTextureSampler *right_sampler,
    unsigned char right_wall_is_far,
    const unsigned char *right_flat_rows,
    unsigned char right_wall_top,
    unsigned char right_wall_height,
    unsigned char tile_pixel_y)
{
    unsigned char tile_row;
    unsigned char screen_y;
    unsigned char background_palette_index;
    unsigned char left_palette_index;
    unsigned char right_palette_index;
    const unsigned char *left_bitplanes;
    const unsigned char *right_bitplanes;

    left_wall_height += left_wall_top;
    right_wall_height += right_wall_top;

    if (!left_wall_is_far && !right_wall_is_far)
    {
        for (tile_row = 0; tile_row < 8; ++tile_row)
        {
            screen_y = tile_pixel_y + tile_row;
            background_palette_index =
                game_gear_get_background_palette_index(screen_y);
            left_palette_index = game_gear_wall_texture_palette_sample_next(
                left_sampler, screen_y);
            right_palette_index = game_gear_wall_texture_palette_sample_next(
                right_sampler, screen_y);

            if (left_palette_index == GAME_GEAR_WALL_TEXTURE_OUTSIDE)
                left_palette_index = background_palette_index;
            if (right_palette_index == GAME_GEAR_WALL_TEXTURE_OUTSIDE)
                right_palette_index = background_palette_index;

            left_bitplanes = left_palette_bitplanes[left_palette_index];
            right_bitplanes = right_palette_bitplanes[right_palette_index];
            destination[0] = left_bitplanes[0] | right_bitplanes[0];
            destination[1] = left_bitplanes[1] | right_bitplanes[1];
            destination[2] = left_bitplanes[2] | right_bitplanes[2];
            destination[3] = left_bitplanes[3] | right_bitplanes[3];
            destination += NATIVE_TILE_ROW_BYTES;
        }
        return;
    }

    for (tile_row = 0; tile_row < 8; ++tile_row)
    {
        screen_y = tile_pixel_y + tile_row;
        background_palette_index =
            game_gear_get_background_palette_index(screen_y);
        left_palette_index = background_palette_index;
        right_palette_index = background_palette_index;

        if (left_wall_is_far)
        {
            if (screen_y >= left_wall_top
                && screen_y < left_wall_height)
            {
                left_bitplanes = left_flat_rows;
            }
            else
                left_bitplanes =
                    left_palette_bitplanes[background_palette_index];
            left_flat_rows += NATIVE_TILE_ROW_BYTES;
        }
        else
        {
            left_palette_index = game_gear_wall_texture_palette_sample_next(
                left_sampler, screen_y);
            if (left_palette_index == GAME_GEAR_WALL_TEXTURE_OUTSIDE)
                left_palette_index = background_palette_index;
            left_bitplanes = left_palette_bitplanes[left_palette_index];
        }

        if (right_wall_is_far)
        {
            if (screen_y >= right_wall_top
                && screen_y < right_wall_height)
            {
                right_bitplanes = right_flat_rows;
            }
            else
                right_bitplanes =
                    right_palette_bitplanes[background_palette_index];
            right_flat_rows += NATIVE_TILE_ROW_BYTES;
        }
        else
        {
            right_palette_index = game_gear_wall_texture_palette_sample_next(
                right_sampler, screen_y);
            if (right_palette_index == GAME_GEAR_WALL_TEXTURE_OUTSIDE)
                right_palette_index = background_palette_index;
            right_bitplanes = right_palette_bitplanes[right_palette_index];
        }

        destination[0] = left_bitplanes[0] | right_bitplanes[0];
        destination[1] = left_bitplanes[1] | right_bitplanes[1];
        destination[2] = left_bitplanes[2] | right_bitplanes[2];
        destination[3] = left_bitplanes[3] | right_bitplanes[3];
        destination += NATIVE_TILE_ROW_BYTES;
    }
}

static unsigned char game_gear_get_visible_wall_pixels(
    signed int wall_top,
    unsigned char wall_height,
    signed int *visible_top,
    signed int *visible_bottom)
{
    signed int wall_bottom = wall_top + wall_height;

    if (wall_bottom <= 0 || wall_top >= GAME_GEAR_VIEWPORT_PIXEL_HEIGHT)
        return 0;

    *visible_top = wall_top;
    *visible_bottom = wall_bottom;

    if (*visible_top < 0)
        *visible_top = 0;

    if (*visible_bottom > GAME_GEAR_VIEWPORT_PIXEL_HEIGHT)
        *visible_bottom = GAME_GEAR_VIEWPORT_PIXEL_HEIGHT;

    return 1;
}

static unsigned char game_gear_get_active_wall_rows(
    signed int left_wall_top,
    unsigned char left_wall_height,
    signed int right_wall_top,
    unsigned char right_wall_height,
    unsigned char *first_row,
    unsigned char *last_row)
{
    signed int left_top;
    signed int left_bottom;
    signed int right_top;
    signed int right_bottom;
    signed int combined_top = GAME_GEAR_VIEWPORT_PIXEL_HEIGHT;
    signed int combined_bottom = 0;
    unsigned char has_left_wall;
    unsigned char has_right_wall;

    has_left_wall = game_gear_get_visible_wall_pixels(
        left_wall_top, left_wall_height, &left_top, &left_bottom);
    has_right_wall = game_gear_get_visible_wall_pixels(
        right_wall_top, right_wall_height, &right_top, &right_bottom);

    if (has_left_wall)
    {
        combined_top = left_top;
        combined_bottom = left_bottom;
    }

    if (has_right_wall)
    {
        if (right_top < combined_top)
            combined_top = right_top;

        if (right_bottom > combined_bottom)
            combined_bottom = right_bottom;
    }

    if (!has_left_wall && !has_right_wall)
        return 0;

    *first_row = (unsigned char)(combined_top / 8);
    *last_row = (unsigned char)((combined_bottom - 1) / 8);
    return 1;
}


#if GEARRAY_DEBUG_VIEWPORT_BORDER
void game_gear_video_draw_viewport_border(void)
{
    unsigned char tile_offset;

    SMS_load1bppTiles(debug_border_tiles,
                      DEBUG_BORDER_HORIZONTAL_TILE_INDEX,
                      sizeof(debug_border_tiles),
                      0,
                      12);

    SMS_setTileatXY(GAME_GEAR_VIEWPORT_BORDER_TILE_LEFT,
                    GAME_GEAR_VIEWPORT_BORDER_TILE_TOP,
                    DEBUG_BORDER_CORNER_TILE_INDEX);
    SMS_setTileatXY(GAME_GEAR_VIEWPORT_BORDER_TILE_RIGHT,
                    GAME_GEAR_VIEWPORT_BORDER_TILE_TOP,
                    DEBUG_BORDER_CORNER_TILE_INDEX | TILE_FLIPPED_X);
    SMS_setTileatXY(GAME_GEAR_VIEWPORT_BORDER_TILE_LEFT,
                    GAME_GEAR_VIEWPORT_BORDER_TILE_BOTTOM,
                    DEBUG_BORDER_CORNER_TILE_INDEX | TILE_FLIPPED_Y);
    SMS_setTileatXY(GAME_GEAR_VIEWPORT_BORDER_TILE_RIGHT,
                    GAME_GEAR_VIEWPORT_BORDER_TILE_BOTTOM,
                    DEBUG_BORDER_CORNER_TILE_INDEX
                    | TILE_FLIPPED_X | TILE_FLIPPED_Y);

    for (tile_offset = 0;
         tile_offset < GAME_GEAR_VIEWPORT_TILE_COLUMNS;
         ++tile_offset)
    {
        SMS_setTileatXY(GAME_GEAR_VIEWPORT_TILE_ORIGIN_X + tile_offset,
                        GAME_GEAR_VIEWPORT_BORDER_TILE_TOP,
                        DEBUG_BORDER_HORIZONTAL_TILE_INDEX);
        SMS_setTileatXY(GAME_GEAR_VIEWPORT_TILE_ORIGIN_X + tile_offset,
                        GAME_GEAR_VIEWPORT_BORDER_TILE_BOTTOM,
                        DEBUG_BORDER_HORIZONTAL_TILE_INDEX | TILE_FLIPPED_Y);
    }

    for (tile_offset = 0;
         tile_offset < GAME_GEAR_VIEWPORT_TILE_ROWS;
         ++tile_offset)
    {
        SMS_setTileatXY(GAME_GEAR_VIEWPORT_BORDER_TILE_LEFT,
                        GAME_GEAR_VIEWPORT_TILE_ORIGIN_Y + tile_offset,
                        DEBUG_BORDER_VERTICAL_TILE_INDEX);
        SMS_setTileatXY(GAME_GEAR_VIEWPORT_BORDER_TILE_RIGHT,
                        GAME_GEAR_VIEWPORT_TILE_ORIGIN_Y + tile_offset,
                        DEBUG_BORDER_VERTICAL_TILE_INDEX | TILE_FLIPPED_X);
    }

}
#endif

#include "render_compositor.inc"
