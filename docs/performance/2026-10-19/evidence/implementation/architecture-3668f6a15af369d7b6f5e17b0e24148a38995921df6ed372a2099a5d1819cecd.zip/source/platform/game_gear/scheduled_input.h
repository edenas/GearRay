#ifndef GEAR_RAY_SCHEDULED_INPUT_H
#define GEAR_RAY_SCHEDULED_INPUT_H
extern unsigned char scheduled_pause, action_overflow;
extern unsigned int captured_fire_edges, consumed_fire_edges, captured_interactions;
void scheduled_input_epoch(void);
void scheduled_input_drain(unsigned int cutoff);
void scheduled_input_tick(void);
#endif
