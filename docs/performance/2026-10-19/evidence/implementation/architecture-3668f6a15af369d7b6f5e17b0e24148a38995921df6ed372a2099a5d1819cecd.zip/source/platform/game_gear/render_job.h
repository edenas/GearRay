#ifndef GEAR_RAY_RENDER_JOB_H
#define GEAR_RAY_RENDER_JOB_H
#include "../../engine/render/scene_geometry.h"
#include "../../game/world_sprite.h"
typedef struct {
    RayScene scene;
    WorldSprite actors[8];
    RaycasterRay rays[28];
    unsigned int generation, captured;
    unsigned char actor_count,pickup,cell_x,cell_y,weapon,hud,health,shake;
} RenderSnapshot;
extern RenderSnapshot render_snapshot;
extern unsigned int render_generation, displayed_generation;
extern unsigned char render_active, render_ready, render_front;
extern unsigned int render_target_names, render_target_patterns;
void render_capture(void);
void render_reset(void);
void render_step(void);
void render_clone_names(void);
unsigned char render_publish(void);
void render_write_name(unsigned char x,unsigned char y,unsigned int tile);
unsigned char game_gear_hud_weapon_pose(void);
void render_video_begin(void);
unsigned char render_video_step(void);
void render_projection_begin(void);
unsigned char render_projection_step(void);
unsigned int render_select_sprites(void);
void render_hud_tile(unsigned char *destination,unsigned char x,unsigned char y);
#endif
