#include "SMSlib.h"
#include "frame_clock.h"
volatile unsigned int frame_sequence;
volatile unsigned char frame_overflow,frame_capture_enabled;
volatile unsigned char frame_head,frame_tail,frame_latest;
static volatile FrameSample frame_samples[64];
/* Normal callback, not an ISR. SMSlib saves BC/DE/IY; SDCC preserves its IX.
 * No mapper, VDP, gameplay or multiplication/division calls. Payload precedes
 * the 8-bit publication index. Head/tail are modulo-256 occupancy counters. */
void frame_capture_hook(void)
{
    unsigned int raw=SMS_getKeysStatus();
    unsigned char index;
    frame_latest=(unsigned char)raw&63;
    if(raw&GG_KEY_START) frame_latest|=CAP_START;
    ++frame_sequence;
    if(!frame_capture_enabled) return;
    if((unsigned char)(frame_head-frame_tail)==64) { frame_overflow=1; return; }
    index=frame_head&63;
    frame_samples[index].sequence=frame_sequence;
    frame_samples[index].mask=frame_latest;
    ++frame_head;
}
unsigned char frame_irq_save(void) __naked
{
__asm
    di
    ld a,#1
    ret
__endasm;
}
void frame_irq_restore(unsigned char enabled) __naked
{
    enabled;
__asm
    or a
    ret z
    ei
    ret
__endasm;
}
unsigned int frame_clock_now(void)
{
    volatile unsigned char *bytes=(volatile unsigned char *)&frame_sequence;
    unsigned char high,low;
    do { high=bytes[1]; low=bytes[0]; } while(high!=bytes[1]);
    return ((unsigned int)high<<8)|low;
}
unsigned char frame_clock_pop(FrameSample *sample,unsigned int cutoff)
{
    unsigned char index;
    /* SPSC ownership: an occupied slot cannot be written by the producer.
     * Payload is published before head and remains stable until tail release.
     * Overflow never overwrites an occupied slot, so timestamp reads cannot tear. */
    if(frame_tail==frame_head) return 0;
    index=frame_tail&63;
    if((signed int)(frame_samples[index].sequence-cutoff)>0) return 0;
    sample->sequence=frame_samples[index].sequence;
    sample->mask=frame_samples[index].mask;
    ++frame_tail;
    return 1;
}
void frame_clock_epoch(unsigned char enabled)
{
    unsigned char irq=frame_irq_save();
    frame_capture_enabled=enabled;
    frame_tail=frame_head;
    frame_irq_restore(irq);
}
void frame_clock_initialize(void)
{
    unsigned char irq=frame_irq_save();
    frame_head=frame_tail=frame_overflow=0;
    frame_sequence=0; frame_latest=0; frame_capture_enabled=0;
    SMS_setFrameInterruptHandler(frame_capture_hook);
    frame_irq_restore(irq);
}
