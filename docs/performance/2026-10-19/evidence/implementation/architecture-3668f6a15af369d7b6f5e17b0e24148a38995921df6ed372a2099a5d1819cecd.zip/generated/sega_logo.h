#ifndef GEAR_RAY_GENERATED_SEGA_LOGO_H
#define GEAR_RAY_GENERATED_SEGA_LOGO_H

#define SEGA_LOGO_TILE_COLUMNS 12
#define SEGA_LOGO_TILE_ROWS 4
#define SEGA_LOGO_TILE_ORIGIN_X 10
#define SEGA_LOGO_TILE_ORIGIN_Y 10
#define SEGA_LOGO_TILE_COUNT 48
#define SEGA_LOGO_TILE_BYTE_COUNT 1536

extern const unsigned char sega_logo_tiles[SEGA_LOGO_TILE_BYTE_COUNT];
extern const unsigned int sega_logo_palette[16];
extern const unsigned int sega_logo_tilemap[SEGA_LOGO_TILE_COUNT];

#endif
