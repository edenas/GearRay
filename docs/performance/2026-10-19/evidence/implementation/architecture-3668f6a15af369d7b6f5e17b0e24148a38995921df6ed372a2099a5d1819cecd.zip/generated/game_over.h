#ifndef GEAR_RAY_GENERATED_GAME_OVER_H
#define GEAR_RAY_GENERATED_GAME_OVER_H
#define GAME_OVER_TILE_COLUMNS 20
#define GAME_OVER_TILE_ROWS 4
#define GAME_OVER_TILE_COUNT 80
#define GAME_OVER_TILE_BYTE_COUNT 2560
#define GAME_OVER_TILE_ORIGIN_X 6
#define GAME_OVER_TILE_ORIGIN_Y 10
extern const unsigned char game_over_tiles[GAME_OVER_TILE_BYTE_COUNT];
extern const unsigned int game_over_palette[16];
extern const unsigned int game_over_tilemap[GAME_OVER_TILE_COUNT];
#endif
