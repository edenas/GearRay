#ifndef GEAR_RAY_GENERATED_HUD_WEAPON_PIXELS_H
#define GEAR_RAY_GENERATED_HUD_WEAPON_PIXELS_H

#define hud_weapon_pixels_WIDTH 12
#define hud_weapon_pixels_HEIGHT 12
#define hud_weapon_pixels_PACKED_ROW_STRIDE 8
#define hud_weapon_pixels_TRANSPARENT_INDEX 14
#define hud_weapon_pixels_BYTE_COUNT 96

extern const unsigned char hud_weapon_pixels[hud_weapon_pixels_BYTE_COUNT];


#endif
