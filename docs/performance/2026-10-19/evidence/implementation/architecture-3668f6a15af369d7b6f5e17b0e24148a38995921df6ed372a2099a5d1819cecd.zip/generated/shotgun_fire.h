#ifndef GEAR_RAY_GENERATED_SHOTGUN_FIRE_PIXELS_H
#define GEAR_RAY_GENERATED_SHOTGUN_FIRE_PIXELS_H

#define shotgun_fire_pixels_WIDTH 20
#define shotgun_fire_pixels_HEIGHT 16
#define shotgun_fire_pixels_PACKED_ROW_STRIDE 10
#define shotgun_fire_pixels_TRANSPARENT_INDEX 14
#define shotgun_fire_pixels_BYTE_COUNT 160

extern const unsigned char shotgun_fire_pixels[shotgun_fire_pixels_BYTE_COUNT];


#endif
