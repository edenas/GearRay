#ifndef GEAR_RAY_GENERATED_WALL_TEXTURE_H
#define GEAR_RAY_GENERATED_WALL_TEXTURE_H

#define WALL_TEXTURE_WIDTH 8
#define WALL_TEXTURE_HEIGHT 8
#define WALL_TEXTURE_PACKED_ROW_STRIDE 4
#define WALL_TEXTURE_PACKED_ROW_SHIFT 2
#define WALL_TEXTURE_COLOR_COUNT 10
#define WALL_TEXTURE_BYTE_COUNT 32
#define WALL_TEXTURE_COUNT 10
#define WALL_TEXTURE_SAMPLER_MINIMUM_HEIGHT 17
#define WALL_TEXTURE_SAMPLER_HEIGHT_COUNT 128
#define WALL_PALETTE_COLOR_COUNT 15

extern const unsigned char wall_textures[WALL_TEXTURE_COUNT][WALL_TEXTURE_BYTE_COUNT];
extern const unsigned int wall_texture_steps[WALL_TEXTURE_SAMPLER_HEIGHT_COUNT];
extern const unsigned char wall_texture_step_remainders[WALL_TEXTURE_SAMPLER_HEIGHT_COUNT];
extern const unsigned int wall_palette_colors[WALL_PALETTE_COLOR_COUNT];
extern const unsigned char wall_palette_x_indices[WALL_TEXTURE_COLOR_COUNT];
extern const unsigned char wall_palette_y_indices[WALL_TEXTURE_COLOR_COUNT];

#endif