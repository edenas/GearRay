/* Generated exact graph declarations. */
extern const signed int camera_graph_vectors[242][4];
extern const unsigned char camera_graph_edges[242][2];
