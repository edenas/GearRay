# GearRay current behavior and architecture

This is the source of truth for the current working game. Dated sprint and checkpoint documents are historical evidence and may describe superseded code.

## Gameplay contracts

- The player starts with the pistol.
- The first shotgun pickup grants ownership and immediately equips the shotgun.
- Touching an already-owned pickup preserves the current weapon selection.
- Firing is press-edge driven; held input does not auto-fire.
- The renderer supports eight zombie slots plus the independent shotgun pickup.
- Out-of-bounds map coordinates behave as solid VOID. Doors keep their registered open/closed collision behavior.

## Z80 and banking contracts

- Bank 0 contains resident main-loop, raycaster, and renderer code.
- CPU slot 1 normally maps page 1. Hot Bank 1 entries use direct calls under that invariant. True page switches, including startup logo and game-over presentation in Bank 3, retain SDCC banked dispatch.
- CPU slot 2 normally maps page 2. Pause and corpse-management code execute directly there; near-sprite rendering may page slot 2 temporarily and must restore its prior page before returning.
- The current ROM is 64 KiB. Supported ROM size is derived from the image and SEGA header; 64 KiB and four populated banks are current measurements rather than permanent ceilings.
- Bank capacity and placement are hard failures. Free-space targets are planning warnings.

## Production hot-path decisions

- Ray hit offsets use exact 16-bit modular arithmetic.
- Player movement uses bounded signed 16-bit intermediates.
- `world_is_wall` relies on the bounds-safe tile accessor rather than repeating its guard.
- Shooting rejects candidates farther than the current nearest target before wall sampling.
- Sprite projection snapshots camera invariants once per frame and passes them as scalars to the per-entity projector.
- The sprite compositor calculates a packed source-row base once per output row.
- Invisible projected sprites are compared and ordered without reading irrelevant fields.

## Authoritative weapon artwork

- `assets/sprites/weapons/shotgun.png` is the authoritative 16x16 pause icon.
- `shotgun_held.png` and `shotgun_held_shoot.png` are the authoritative 20x16 held idle/fire sources. They are presented at 2x without changing HUD anchoring or timing.
- `pick_up_shotgun.png` remains the independent world-pickup source. Pause, held, and world-pickup artwork are not interchangeable.
- Transparent source pixels are no-overwrite pixels. Validators compare generated payloads and composites to the current sources instead of freezing historical opaque masks.

## Current Release baseline

The 2026-09-21 clean Release build uses 15,629 / 13,516 / 9,317 / 4,605 bytes in Banks 0..3, leaving 755 / 2,852 / 7,067 / 11,779 bytes. Persistent RAM is 1,239 bytes. Makesms reports 43,083 used bytes; the packaged ROM is 65,536 bytes with checksum `0xFFC4` and SHA-256 `2AEC907F992617EF9C220D810AB87CB78DC51FA76A0C65CC36D4DA6754C6D1B4`.

`WorldSprite` remains 9 bytes, zombie capacity remains 8, and the renderer's ninth projected entry is reserved for the independent pickup.

Run `build.bat`, `tools/validate_z80_hardening.ps1`, and `tools/validate_bank_call_topology.ps1` after changing these contracts.
