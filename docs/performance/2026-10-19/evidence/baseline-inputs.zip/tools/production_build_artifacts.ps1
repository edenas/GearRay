# The generated SDCC linker command file defines production object membership.
# Files merely present beside those objects can be retained development artifacts.
function Get-ProductionBuildObjects([string]$BuildDirectory) {
    $directory=[IO.Path]::GetFullPath($BuildDirectory).TrimEnd('\','/')
    $linkPath=Join-Path $directory 'GearRay.lk'
    if (!(Test-Path -LiteralPath $linkPath)) { throw "Production linker inputs missing: $linkPath" }
    $objects=@()
    foreach($line in Get-Content -LiteralPath $linkPath) {
        if($line -notmatch '^(.+\.rel)\s*$') { continue }
        $path=$Matches[1].Trim()
        if(![IO.Path]::IsPathRooted($path)) { $path=Join-Path $directory $path }
        $path=[IO.Path]::GetFullPath($path)
        # External crt0/library code is audited separately from local C modules.
        if(!$path.StartsWith($directory+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)) { continue }
        if(!(Test-Path -LiteralPath $path)) { throw "Linked production object missing: $path" }
        $objects+=Get-Item -LiteralPath $path
    }
    foreach($required in @('main','pause_map','startup_logo')) {
        if($required -notin $objects.BaseName) { throw "Required production linker input missing: $required" }
    }
    $objects
}

function Get-ProductionBuildAssembly([string]$BuildDirectory) {
    foreach($object in Get-ProductionBuildObjects $BuildDirectory) {
        $path=[IO.Path]::ChangeExtension($object.FullName,'.asm')
        if(!(Test-Path -LiteralPath $path)) { throw "Linked production assembly missing: $path" }
        Get-Item -LiteralPath $path
    }
}
