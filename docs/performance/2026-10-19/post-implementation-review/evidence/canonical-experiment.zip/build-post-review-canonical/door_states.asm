;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (MINGW64)
;--------------------------------------------------------
	.module door_states
	
	.optsdcc -mz80 sdcccall(1)
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _door_states_initialize
	.globl _door_state_get
	.globl _door_state_toggle
	.globl _door_state_open
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
_door_states:
	.ds 3
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute ram data
;--------------------------------------------------------
	.area _DABS (ABS)
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/door_states.c:5: void door_states_initialize(void)
;	---------------------------------
; Function door_states_initialize
; ---------------------------------
_door_states_initialize::
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/door_states.c:9: for (door_id = 0; door_id < DOOR_INSTANCE_COUNT; ++door_id)
	ld	c, #0x00
00102$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/door_states.c:10: door_states[door_id] = DOOR_STATE_CLOSED;
	ld	hl, #_door_states
	ld	b, #0x00
	add	hl, bc
	ld	(hl), #0x00
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/door_states.c:9: for (door_id = 0; door_id < DOOR_INSTANCE_COUNT; ++door_id)
	inc	c
	ld	a, c
	sub	a, #0x03
	jr	c, 00102$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/door_states.c:11: }
	ret
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/door_states.c:13: DoorState door_state_get(DoorInstanceId door_id)
;	---------------------------------
; Function door_state_get
; ---------------------------------
_door_state_get::
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/door_states.c:15: if (door_id >= DOOR_INSTANCE_COUNT)
	ld	e, a
	sub	a, #0x03
	jr	c, 00102$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/door_states.c:16: return DOOR_STATE_CLOSED;
	xor	a, a
	ret
00102$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/door_states.c:18: return door_states[door_id];
	ld	hl, #_door_states+0
	ld	d, #0x00
	add	hl, de
	ld	a, (hl)
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/door_states.c:19: }
	ret
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/door_states.c:21: void door_state_toggle(DoorInstanceId instance_id)
;	---------------------------------
; Function door_state_toggle
; ---------------------------------
_door_state_toggle::
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/door_states.c:23: if (instance_id >= DOOR_INSTANCE_COUNT)
	ld	e, a
	sub	a, #0x03
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/door_states.c:24: return;
	ret	nc
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/door_states.c:26: if (door_states[instance_id] == DOOR_STATE_CLOSED)
	ld	hl, #_door_states+0
	ld	d, #0x00
	add	hl, de
	ld	a, (hl)
	or	a, a
	jr	nz, 00104$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/door_states.c:27: door_states[instance_id] = DOOR_STATE_OPEN;
	ld	(hl), #0x01
	ret
00104$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/door_states.c:29: door_states[instance_id] = DOOR_STATE_CLOSED;
	ld	(hl), #0x00
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/door_states.c:30: }
	ret
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/door_states.c:32: void door_state_open(DoorInstanceId instance_id)
;	---------------------------------
; Function door_state_open
; ---------------------------------
_door_state_open::
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/door_states.c:34: if (instance_id >= DOOR_INSTANCE_COUNT)
	ld	e, a
	sub	a, #0x03
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/door_states.c:35: return;
	ret	nc
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/door_states.c:37: door_states[instance_id] = DOOR_STATE_OPEN;
	ld	hl, #_door_states+0
	ld	d, #0x00
	add	hl, de
	ld	(hl), #0x01
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/door_states.c:38: }
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
