;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (MINGW64)
;--------------------------------------------------------
	.module wall_textures
	
	.optsdcc -mz80 sdcccall(1)
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _game_gear_get_wall_palette_color
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute ram data
;--------------------------------------------------------
	.area _DABS (ABS)
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/wall_textures.c:4: unsigned int game_gear_get_wall_palette_color(
;	---------------------------------
; Function game_gear_get_wall_palette_color
; ---------------------------------
_game_gear_get_wall_palette_color::
	ld	l, a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/wall_textures.c:7: return wall_palette_colors[wall_palette_offset];
	ld	bc, #_wall_palette_colors+0
	ld	h, #0x00
	add	hl, hl
	add	hl, bc
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/wall_textures.c:8: }
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
