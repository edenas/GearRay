;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (MINGW64)
;--------------------------------------------------------
	.module game_over_presentation
	
	.optsdcc -mz80 sdcccall(1)
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _SMS_VRAMmemsetW
	.globl _SMS_VRAMmemcpy
	.globl _GG_loadBGPalette
	.globl _SMS_loadTileMapAreaatAddr
	.globl _SMS_waitForVBlank
	.globl _SMS_setBGScrollY
	.globl _SMS_setBGScrollX
	.globl _SMS_VDPturnOffFeature
	.globl _SMS_VDPturnOnFeature
	.globl _SMS_SRAM
	.globl _SRAM_bank_to_be_mapped_on_slot2
	.globl _ROM_bank_to_be_mapped_on_slot0
	.globl _ROM_bank_to_be_mapped_on_slot1
	.globl _ROM_bank_to_be_mapped_on_slot2
	.globl b_game_gear_video_present_player_death
	.globl _game_gear_video_present_player_death
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
_SMS_VDPControlPort	=	0x00bf
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
_ROM_bank_to_be_mapped_on_slot2	=	0xffff
_ROM_bank_to_be_mapped_on_slot1	=	0xfffe
_ROM_bank_to_be_mapped_on_slot0	=	0xfffd
_SRAM_bank_to_be_mapped_on_slot2	=	0xfffc
_SMS_SRAM	=	0x8000
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute ram data
;--------------------------------------------------------
	.area _DABS (ABS)
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _BANK3
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/game_over_presentation.c:9: void game_gear_video_present_player_death(void) __banked
;	---------------------------------
; Function game_gear_video_present_player_death
; ---------------------------------
	b_game_gear_video_present_player_death	= 3
_game_gear_video_present_player_death::
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/game_over_presentation.c:13: game_gear_damage_shake_phase = 0;
	xor	a, a
	ld	(#_game_gear_damage_shake_phase), a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/game_over_presentation.c:14: SMS_setBGScrollX(0);
	ld	l, #0x00
	call	_SMS_setBGScrollX
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/game_over_presentation.c:15: SMS_setBGScrollY(0);
	ld	l, #0x00
	call	_SMS_setBGScrollY
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/game_over_presentation.c:16: SMS_displayOff();
	ld	hl, #0x0140
	call	_SMS_VDPturnOffFeature
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/game_over_presentation.c:17: SMS_VRAMmemsetW(0, 0x0000, 16384);
	ld	hl, #0x4000
	push	hl
	ld	de, #0x0000
	ld	h, l
	call	_SMS_VRAMmemsetW
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/game_over_presentation.c:18: GG_loadBGPalette(game_over_palette);
	ld	hl, #_game_over_palette
	call	_GG_loadBGPalette
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/game_over_presentation.c:19: SMS_loadTiles(game_over_tiles, GAME_OVER_FIRST_TILE,
	ld	hl, #0x0a00
	push	hl
	ld	de, #_game_over_tiles
	ld	hl, #0x0020
	call	_SMS_VRAMmemcpy
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/game_over_presentation.c:21: SMS_loadTileMapArea(GAME_OVER_TILE_ORIGIN_X, GAME_OVER_TILE_ORIGIN_Y,
	ld	hl, #0x414
	push	hl
	ld	de, #_game_over_tilemap
	ld	hl, #0x7a8c
	call	_SMS_loadTileMapAreaatAddr
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/game_over_presentation.c:24: SMS_waitForVBlank();
	call	_SMS_waitForVBlank
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/game_over_presentation.c:25: SMS_displayOn();
	ld	hl, #0x0140
	call	_SMS_VDPturnOnFeature
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/game_over_presentation.c:26: for (frame = GAME_OVER_DISPLAY_FRAME_COUNT; frame != 0; --frame)
	ld	b, #0xb4
00102$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/game_over_presentation.c:27: SMS_waitForVBlank();
	push	bc
	call	_SMS_waitForVBlank
	pop	bc
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/game_over_presentation.c:26: for (frame = GAME_OVER_DISPLAY_FRAME_COUNT; frame != 0; --frame)
	djnz	00102$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/game_over_presentation.c:28: SMS_displayOff();
	ld	hl, #0x0140
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/game_over_presentation.c:29: }
	jp	_SMS_VDPturnOffFeature
	.area _BANK3
	.area _BANK3
	.area _BANK3
	.area _BANK3
	.area _INITIALIZER
	.area _CABS (ABS)
