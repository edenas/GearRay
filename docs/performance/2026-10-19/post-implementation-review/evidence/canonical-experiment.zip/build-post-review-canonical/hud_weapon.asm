;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (MINGW64)
;--------------------------------------------------------
	.module hud_weapon
	
	.optsdcc -mz80 sdcccall(1)
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _player_get_position_y
	.globl _player_get_position_x
	.globl _game_gear_hud_weapon_initialize
	.globl _game_gear_hud_weapon_update
	.globl _game_gear_hud_weapon_changed
	.globl _game_gear_hud_weapon_render_complete
	.globl _game_gear_overlay_hud_weapon_tile
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
_weapon_state:
	.ds 1
_rendered_weapon_state:
	.ds 1
_animation_timer:
	.ds 1
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute ram data
;--------------------------------------------------------
	.area _DABS (ABS)
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _BANK1
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:15: void game_gear_hud_weapon_initialize(void)
;	---------------------------------
; Function game_gear_hud_weapon_initialize
; ---------------------------------
_game_gear_hud_weapon_initialize::
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:17: weapon_state = IDLE;
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:18: rendered_weapon_state = IDLE;
	xor	a, a
	ld	(#_weapon_state), a
	ld	(#_rendered_weapon_state), a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:19: animation_timer = 0;
	xor	a, a
	ld	(#_animation_timer), a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:20: }
	ret
	.area _BANK1
	.area _BANK1
_hud_mask_weapon_texture:
	.db #0xc3	; 195
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x0c	; 12
	.db #0x3c	; 60
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x30	; 48	'0'
	.db #0x03	; 3
	.db #0x30	; 48	'0'
	.db #0x30	; 48	'0'
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x3f	; 63
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x03	; 3
	.db #0xc0	; 192
	.db #0xc0	; 192
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0x0c	; 12
	.db #0x0c	; 12
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xc0	; 192
	.db #0x0c	; 12
	.db #0x00	; 0
	.db #0x0c	; 12
	.db #0x0c	; 12
	.db #0xf0	; 240
	.db #0x03	; 3
	.db #0x00	; 0
	.db #0x03	; 3
	.db #0x03	; 3
	.db #0xfc	; 252
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xfc	; 252
	.db #0x03	; 3
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x33	; 51	'3'
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x33	; 51	'3'
	.db #0x3f	; 63
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xc0	; 192
	.db #0x00	; 0
	.db #0xc0	; 192
	.db #0xc0	; 192
	.db #0x00	; 0
	.db #0x33	; 51	'3'
	.db #0x0f	; 15
	.db #0x30	; 48	'0'
	.db #0x30	; 48	'0'
	.db #0x3f	; 63
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x30	; 48	'0'
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x03	; 3
	.db #0x0c	; 12
	.db #0x00	; 0
	.db #0x30	; 48	'0'
	.db #0x30	; 48	'0'
	.db #0x00	; 0
	.db #0x33	; 51	'3'
	.db #0x30	; 48	'0'
	.db #0x0c	; 12
	.db #0x3c	; 60
	.db #0xf0	; 240
	.db #0x0f	; 15
	.db #0x03	; 3
	.db #0x00	; 0
	.db #0x03	; 3
	.db #0xc0	; 192
	.db #0x3f	; 63
	.db #0x03	; 3
	.db #0x03	; 3
	.db #0x03	; 3
	.db #0xc0	; 192
	.db #0x3f	; 63
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0x0f	; 15
	.db #0x03	; 3
	.db #0x03	; 3
	.db #0x03	; 3
	.db #0x00	; 0
	.db #0xc0	; 192
	.db #0xc0	; 192
	.db #0x00	; 0
	.db #0xc0	; 192
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xfc	; 252
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x0f	; 15
	.db #0x0f	; 15
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0xfc	; 252
	.db #0x0c	; 12
	.db #0xfc	; 252
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0xfc	; 252
	.db #0x0c	; 12
	.db #0xfc	; 252
	.db #0x00	; 0
	.db #0xf3	; 243
	.db #0xf0	; 240
	.db #0x0c	; 12
	.db #0xfc	; 252
	.db #0x00	; 0
	.db #0xf3	; 243
	.db #0xf0	; 240
	.db #0x0c	; 12
	.db #0xfc	; 252
	.area _BANK1
	.area _BANK1
_hud_mask_weapon_shoot_texture:
	.db #0x03	; 3
	.db #0xfc	; 252
	.db #0x00	; 0
	.db #0x3c	; 60
	.db #0x30	; 48	'0'
	.db #0x00	; 0
	.db #0xc0	; 192
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0xf0	; 240
	.db #0x00	; 0
	.db #0xc0	; 192
	.db #0x0f	; 15
	.db #0xcc	; 204
	.db #0x00	; 0
	.db #0xc0	; 192
	.db #0x00	; 0
	.db #0x03	; 3
	.db #0x03	; 3
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x3f	; 63
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xc0	; 192
	.db #0xc0	; 192
	.db #0x03	; 3
	.db #0x00	; 0
	.db #0xc0	; 192
	.db #0x30	; 48	'0'
	.db #0x30	; 48	'0'
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xc0	; 192
	.db #0x00	; 0
	.db #0x03	; 3
	.db #0x03	; 3
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0x03	; 3
	.db #0x00	; 0
	.db #0x03	; 3
	.db #0x03	; 3
	.db #0xfc	; 252
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x0c	; 12
	.db #0xfc	; 252
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0xc0	; 192
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x3c	; 60
	.db #0x03	; 3
	.db #0x03	; 3
	.db #0x00	; 0
	.db #0xcc	; 204
	.db #0x0f	; 15
	.db #0xc0	; 192
	.db #0xc0	; 192
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x3f	; 63
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0xc0	; 192
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x03	; 3
	.db #0xcc	; 204
	.db #0xc0	; 192
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xfc	; 252
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xfc	; 252
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xfc	; 252
	.db #0x03	; 3
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x03	; 3
	.db #0x03	; 3
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xfc	; 252
	.db #0xf0	; 240
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xc3	; 195
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x3f	; 63
	.db #0x30	; 48	'0'
	.db #0x3f	; 63
	.db #0x00	; 0
	.db #0x03	; 3
	.db #0xc0	; 192
	.db #0x0c	; 12
	.db #0x0c	; 12
	.db #0x00	; 0
	.db #0x3f	; 63
	.db #0x0c	; 12
	.db #0x0c	; 12
	.db #0x0c	; 12
	.db #0x00	; 0
	.db #0xf3	; 243
	.db #0x30	; 48	'0'
	.db #0x3c	; 60
	.db #0x3c	; 60
	.db #0x00	; 0
	.db #0xf3	; 243
	.db #0xf0	; 240
	.db #0x0c	; 12
	.db #0xfc	; 252
	.area _BANK1
	.area _BANK1
_hud_mask_shotgun_held:
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xcf	; 207
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x0c	; 12
	.db #0x3c	; 60
	.db #0x03	; 3
	.db #0x03	; 3
	.db #0xc0	; 192
	.db #0x00	; 0
	.db #0x03	; 3
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xc0	; 192
	.db #0x0c	; 12
	.db #0x00	; 0
	.db #0x0c	; 12
	.db #0x0c	; 12
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x0f	; 15
	.db #0x0f	; 15
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0xf0	; 240
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x3f	; 63
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x3f	; 63
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xc0	; 192
	.db #0xc0	; 192
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0x0f	; 15
	.db #0x0c	; 12
	.db #0x0f	; 15
	.db #0x0f	; 15
	.db #0xf0	; 240
	.db #0x0c	; 12
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xfc	; 252
	.db #0x03	; 3
	.db #0x03	; 3
	.db #0x03	; 3
	.db #0x03	; 3
	.db #0xf0	; 240
	.db #0x0f	; 15
	.db #0x0f	; 15
	.db #0x0f	; 15
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0xc0	; 192
	.db #0x03	; 3
	.db #0xc0	; 192
	.db #0xc0	; 192
	.db #0x00	; 0
	.db #0x3c	; 60
	.db #0x00	; 0
	.db #0x3c	; 60
	.db #0x3c	; 60
	.db #0x00	; 0
	.db #0xcf	; 207
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0xc0	; 192
	.db #0xc0	; 192
	.db #0xc0	; 192
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0xf0	; 240
	.db #0x0f	; 15
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x3f	; 63
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xc0	; 192
	.db #0x03	; 3
	.db #0xc0	; 192
	.db #0xc0	; 192
	.db #0x00	; 0
	.db #0xfc	; 252
	.db #0x00	; 0
	.db #0xfc	; 252
	.db #0xfc	; 252
	.db #0x03	; 3
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x3c	; 60
	.db #0xfc	; 252
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x33	; 51	'3'
	.db #0xf3	; 243
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x33	; 51	'3'
	.db #0x33	; 51	'3'
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x3f	; 63
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x3f	; 63
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0x0f	; 15
	.db #0x0f	; 15
	.db #0x0f	; 15
	.db #0x0f	; 15
	.db #0xc0	; 192
	.db #0x3f	; 63
	.db #0x3f	; 63
	.db #0x3f	; 63
	.db #0x3f	; 63
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0xfc	; 252
	.db #0xfc	; 252
	.db #0xfc	; 252
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0xfc	; 252
	.db #0xfc	; 252
	.db #0xfc	; 252
	.db #0x3c	; 60
	.db #0xc0	; 192
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x3c	; 60
	.db #0xc0	; 192
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x30	; 48	'0'
	.db #0x00	; 0
	.db #0x30	; 48	'0'
	.db #0x30	; 48	'0'
	.db #0x00	; 0
	.db #0xc0	; 192
	.db #0xc0	; 192
	.db #0xc0	; 192
	.db #0xc0	; 192
	.db #0x00	; 0
	.db #0x03	; 3
	.db #0x00	; 0
	.db #0x03	; 3
	.db #0x03	; 3
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0xc0	; 192
	.db #0xc0	; 192
	.db #0xc0	; 192
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xcc	; 204
	.db #0x00	; 0
	.db #0xcc	; 204
	.db #0xcc	; 204
	.db #0x00	; 0
	.db #0x3f	; 63
	.db #0x00	; 0
	.db #0x3f	; 63
	.db #0x3f	; 63
	.db #0x00	; 0
	.db #0x3f	; 63
	.db #0x00	; 0
	.db #0x3f	; 63
	.db #0x3f	; 63
	.db #0x3f	; 63
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x30	; 48	'0'
	.db #0x30	; 48	'0'
	.db #0x30	; 48	'0'
	.db #0x30	; 48	'0'
	.db #0x03	; 3
	.db #0x00	; 0
	.db #0xc0	; 192
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0x0c	; 12
	.db #0xf0	; 240
	.db #0xf0	; 240
	.area _BANK1
	.area _BANK1
_hud_mask_shotgun_fire:
	.db #0x3f	; 63
	.db #0xc0	; 192
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xc3	; 195
	.db #0x3c	; 60
	.db #0x00	; 0
	.db #0x30	; 48	'0'
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xc3	; 195
	.db #0x00	; 0
	.db #0x30	; 48	'0'
	.db #0x30	; 48	'0'
	.db #0x00	; 0
	.db #0xc0	; 192
	.db #0x00	; 0
	.db #0xc0	; 192
	.db #0x00	; 0
	.db #0xcf	; 207
	.db #0x30	; 48	'0'
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x33	; 51	'3'
	.db #0xcc	; 204
	.db #0x00	; 0
	.db #0xcc	; 204
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x30	; 48	'0'
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xc0	; 192
	.db #0x0f	; 15
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0xc0	; 192
	.db #0x30	; 48	'0'
	.db #0x00	; 0
	.db #0x30	; 48	'0'
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0x03	; 3
	.db #0x00	; 0
	.db #0x03	; 3
	.db #0x03	; 3
	.db #0xcc	; 204
	.db #0x30	; 48	'0'
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x03	; 3
	.db #0x03	; 3
	.db #0xc3	; 195
	.db #0xc3	; 195
	.db #0x00	; 0
	.db #0x3c	; 60
	.db #0xfc	; 252
	.db #0xc0	; 192
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x3f	; 63
	.db #0x30	; 48	'0'
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xc0	; 192
	.db #0x0f	; 15
	.db #0xcc	; 204
	.db #0xc0	; 192
	.db #0x3f	; 63
	.db #0xc0	; 192
	.db #0xc0	; 192
	.db #0xc0	; 192
	.db #0xc0	; 192
	.db #0x3f	; 63
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x03	; 3
	.db #0xc0	; 192
	.db #0xc0	; 192
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xcc	; 204
	.db #0xcc	; 204
	.db #0x30	; 48	'0'
	.db #0x30	; 48	'0'
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x3f	; 63
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xfc	; 252
	.db #0x03	; 3
	.db #0x03	; 3
	.db #0x03	; 3
	.db #0x03	; 3
	.db #0xfc	; 252
	.db #0x03	; 3
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0x0f	; 15
	.db #0x03	; 3
	.db #0x0f	; 15
	.db #0x03	; 3
	.db #0xfc	; 252
	.db #0x03	; 3
	.db #0x03	; 3
	.db #0x03	; 3
	.db #0x03	; 3
	.db #0x00	; 0
	.db #0x33	; 51	'3'
	.db #0x00	; 0
	.db #0x33	; 51	'3'
	.db #0x33	; 51	'3'
	.db #0x00	; 0
	.db #0xcc	; 204
	.db #0x00	; 0
	.db #0x0c	; 12
	.db #0x0c	; 12
	.db #0x00	; 0
	.db #0xf3	; 243
	.db #0xc0	; 192
	.db #0xc3	; 195
	.db #0xc3	; 195
	.db #0x00	; 0
	.db #0xfc	; 252
	.db #0xf0	; 240
	.db #0xf0	; 240
	.db #0xf0	; 240
	.db #0x00	; 0
	.db #0x3c	; 60
	.db #0xfc	; 252
	.db #0x03	; 3
	.db #0x03	; 3
	.db #0x00	; 0
	.db #0xc3	; 195
	.db #0x3f	; 63
	.db #0xc0	; 192
	.db #0xc0	; 192
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x03	; 3
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0xf0	; 240
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xc0	; 192
	.db #0xc0	; 192
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x3f	; 63
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x33	; 51	'3'
	.db #0x33	; 51	'3'
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x3f	; 63
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x3f	; 63
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xf0	; 240
	.db #0x0f	; 15
	.db #0x0f	; 15
	.db #0x0f	; 15
	.db #0x0f	; 15
	.db #0xf0	; 240
	.db #0x0f	; 15
	.db #0x0f	; 15
	.db #0x0f	; 15
	.db #0x0f	; 15
	.db #0xc0	; 192
	.db #0x3f	; 63
	.db #0x3c	; 60
	.db #0x3c	; 60
	.db #0x3c	; 60
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0xfc	; 252
	.db #0xfc	; 252
	.db #0xfc	; 252
	.db #0x3f	; 63
	.db #0xc0	; 192
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x3c	; 60
	.db #0xc0	; 192
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x3c	; 60
	.db #0xc3	; 195
	.db #0x03	; 3
	.db #0x03	; 3
	.db #0x03	; 3
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xc0	; 192
	.db #0xc0	; 192
	.db #0xc0	; 192
	.db #0xc0	; 192
	.db #0x00	; 0
	.db #0x0c	; 12
	.db #0x00	; 0
	.db #0x0c	; 12
	.db #0x0c	; 12
	.db #0x00	; 0
	.db #0xc0	; 192
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x33	; 51	'3'
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x3f	; 63
	.db #0x00	; 0
	.db #0x3f	; 63
	.db #0x3f	; 63
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x0f	; 15
	.db #0x3f	; 63
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x30	; 48	'0'
	.db #0x30	; 48	'0'
	.db #0x30	; 48	'0'
	.db #0x30	; 48	'0'
	.db #0x03	; 3
	.db #0x0c	; 12
	.db #0xcc	; 204
	.db #0x0c	; 12
	.db #0x0c	; 12
	.db #0x00	; 0
	.db #0xc0	; 192
	.db #0x30	; 48	'0'
	.db #0xc0	; 192
	.db #0xc0	; 192
	.area _BANK1
	.area _BANK1
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:22: void game_gear_hud_weapon_update(unsigned char shoot_requested)
;	---------------------------------
; Function game_gear_hud_weapon_update
; ---------------------------------
_game_gear_hud_weapon_update::
	ld	c, a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:25: if (SHOTGUN_PICKUP_PRESENT
	ld	a, (_owned_weapons)
	bit	1, a
	jr	nz, 00102$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:26: && (unsigned int)(player_get_position_x()
	push	bc
	call	_player_get_position_x
	ex	de, hl
	pop	bc
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:27: - ((unsigned int)shotgun_cell_x << 8)
	ld	a, (_shotgun_cell_x+0)
	ld	d, a
	ld	e, #0x00
	cp	a, a
	sbc	hl, de
	ld	de, #0x0094
	add	hl, de
	ld	a, #0x28
	cp	a, l
	ld	a, #0x02
	sbc	a, h
	jr	c, 00102$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:30: && (unsigned int)(player_get_position_y()
	push	bc
	call	_player_get_position_y
	ex	de, hl
	pop	bc
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:31: - ((unsigned int)shotgun_cell_y << 8)
	ld	a, (_shotgun_cell_y+0)
	ld	d, a
	ld	e, #0x00
	cp	a, a
	sbc	hl, de
	ld	de, #0x0094
	add	hl, de
	ld	a, #0x28
	cp	a, l
	ld	a, #0x02
	sbc	a, h
	jr	c, 00102$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:37: owned_weapons |= WEAPON_OWNED_SHOTGUN;
	ld	a, (_owned_weapons+0)
	or	a, #0x02
	ld	(_owned_weapons+0), a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:38: selected_weapon = WEAPON_SHOTGUN;
	ld	hl, #_selected_weapon
	ld	(hl), #0x01
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:39: weapon_state = IDLE;
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:40: animation_timer = 0;
	xor	a, a
	ld	(#_weapon_state), a
	ld	(#_animation_timer), a
00102$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:42: if (shoot_requested)
	ld	a, c
	or	a, a
	jr	z, 00110$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:44: weapon_state = SHOOT;
	ld	hl, #_weapon_state
	ld	(hl), #0x01
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:45: animation_timer = HUD_WEAPON_SHOOT_FRAME_COUNT;
	ld	hl, #_animation_timer
	ld	(hl), #0x02
	ret
00110$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:47: else if (weapon_state == SHOOT)
	ld	a, (_weapon_state)
	dec	a
	ret	nz
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:49: --animation_timer;
	ld	hl, #_animation_timer
	dec	(hl)
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:50: if (animation_timer == 0)
	ld	a, (_animation_timer+0)
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:51: weapon_state = IDLE;
	or	a,a
	ret	nz
	ld	(#_weapon_state), a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:53: }
	ret
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:55: unsigned char game_gear_hud_weapon_changed(void)
;	---------------------------------
; Function game_gear_hud_weapon_changed
; ---------------------------------
_game_gear_hud_weapon_changed::
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:57: return (weapon_state | (selected_weapon << 1)) != rendered_weapon_state;
	ld	a, (_selected_weapon)
	ld	h, #0x00
	ld	l, a
	add	hl, hl
	ld	a, (_weapon_state+0)
	or	a, l
	ld	l, a
	ld	a, (_rendered_weapon_state+0)
	ld	c, a
	xor	a, a
	ld	b, a
	sbc	hl, bc
	ld	a, #0x01
	jr	z, 00104$
	xor	a, a
00104$:
	xor	a, #0x01
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:58: }
	ret
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:60: void game_gear_hud_weapon_render_complete(void)
;	---------------------------------
; Function game_gear_hud_weapon_render_complete
; ---------------------------------
_game_gear_hud_weapon_render_complete::
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:62: rendered_weapon_state = weapon_state | (selected_weapon << 1);
	ld	a, (_selected_weapon+0)
	add	a, a
	ld	c, a
	ld	a, (_weapon_state+0)
	or	a, c
	ld	(#_rendered_weapon_state), a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:63: }
	ret
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:66: void game_gear_overlay_hud_weapon_tile(
;	---------------------------------
; Function game_gear_overlay_hud_weapon_tile
; ---------------------------------
_game_gear_overlay_hud_weapon_tile::
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	iy, #-16
	add	iy, sp
	ld	sp, iy
	ld	-7 (ix), l
	ld	-6 (ix), h
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:81: || tile_row < HUD_SHOTGUN_TOP / 8
	ld	a, 4 (ix)
	sub	a, #0x0d
	ld	a, #0x00
	rla
	ld	-3 (ix), a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:82: || tile_row >= HUD_WEAPON_BOTTOM / 8)
	ld	a, 5 (ix)
	sub	a, #0x08
	ld	a, #0x00
	rla
	ld	-1 (ix), a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:87: ? hud_mask_shotgun_fire : hud_mask_shotgun_held;
	ld	a, (_weapon_state)
	dec	a
	ld	a, #0x01
	jr	z, 00226$
	xor	a, a
00226$:
	ld	-2 (ix), a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:77: if (selected_weapon == WEAPON_SHOTGUN)
	ld	a, (_selected_weapon)
	dec	a
	jr	nz, 00112$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:80: || tile_column >= HUD_WEAPON_RIGHT / 8
	ld	a, 4 (ix)
	sub	a, #0x08
	jp	c, 00121$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:81: || tile_row < HUD_SHOTGUN_TOP / 8
	bit	0, -3 (ix)
	jp	z, 00121$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:82: || tile_row >= HUD_WEAPON_BOTTOM / 8)
	ld	a, 5 (ix)
	sub	a, #0x04
	jp	c, 00121$
	bit	0, -1 (ix)
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:83: return;
	jp	z, 00121$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:84: tile_index = (tile_row - HUD_SHOTGUN_TOP / 8)
	ld	a, 5 (ix)
	add	a, #0xfc
	ld	-1 (ix), a
	ld	c, a
	add	a, a
	add	a, a
	add	a, c
	ld	-1 (ix), a
	add	a, 4 (ix)
	ld	-1 (ix), a
	add	a, #0xf8
	ld	-1 (ix), a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:87: ? hud_mask_shotgun_fire : hud_mask_shotgun_held;
	ld	a, -2 (ix)
	or	a, a
	jr	z, 00123$
	ld	hl, #_hud_mask_shotgun_fire+0
	ld	-3 (ix), l
	ld	-2 (ix), h
	jr	00124$
00123$:
	ld	hl, #_hud_mask_shotgun_held+0
	ld	-3 (ix), l
	ld	-2 (ix), h
00124$:
	ld	a, -3 (ix)
	ld	-9 (ix), a
	ld	a, -2 (ix)
	ld	-8 (ix), a
	jr	00113$
00112$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:92: || tile_column >= HUD_WEAPON_RIGHT / 8
	ld	a, 4 (ix)
	sub	a, #0x0a
	jp	c, 00121$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:93: || tile_row < HUD_WEAPON_TOP / 8
	bit	0, -3 (ix)
	jp	z, 00121$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:94: || tile_row >= HUD_WEAPON_BOTTOM / 8)
	ld	a, 5 (ix)
	sub	a, #0x05
	jp	c, 00121$
	bit	0, -1 (ix)
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:95: return;
	jp	z, 00121$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:96: tile_index = (tile_row - HUD_WEAPON_TOP / 8)
	ld	a, 5 (ix)
	add	a, #0xfb
	ld	-1 (ix), a
	ld	c, a
	add	a, a
	add	a, c
	ld	-1 (ix), a
	add	a, 4 (ix)
	ld	-1 (ix), a
	add	a, #0xf6
	ld	-1 (ix), a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:99: ? hud_mask_weapon_shoot_texture : hud_mask_weapon_texture;
	ld	a, -2 (ix)
	or	a, a
	jr	z, 00125$
	ld	hl, #_hud_mask_weapon_shoot_texture+0
	ld	-3 (ix), l
	ld	-2 (ix), h
	jr	00126$
00125$:
	ld	hl, #_hud_mask_weapon_texture+0
	ld	-3 (ix), l
	ld	-2 (ix), h
00126$:
	ld	a, -3 (ix)
	ld	-9 (ix), a
	ld	a, -2 (ix)
	ld	-8 (ix), a
00113$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:101: mask += (unsigned int)tile_index * 20;
	ld	c, -1 (ix)
	ld	b, #0x00
	ld	l, c
	ld	h, b
	add	hl, hl
	add	hl, hl
	add	hl, bc
	add	hl, hl
	add	hl, hl
	ld	-2 (ix), l
	ld	-1 (ix), h
	ld	e, -9 (ix)
	ld	d, -8 (ix)
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	add	hl, de
	ld	-5 (ix), l
	ld	-4 (ix), h
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:102: for (row = 0; row < 4; ++row)
	ld	-3 (ix), #0x00
00119$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:104: keep = mask[0];
	ld	l, -5 (ix)
	ld	h, -4 (ix)
	ld	a, (hl)
	ld	-16 (ix), a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:105: for (repeat = 0; repeat < 2; ++repeat)
	ld	a, -5 (ix)
	ld	-15 (ix), a
	ld	a, -4 (ix)
	ld	-14 (ix), a
	ld	a, -5 (ix)
	ld	-13 (ix), a
	ld	a, -4 (ix)
	ld	-12 (ix), a
	ld	a, -5 (ix)
	ld	-11 (ix), a
	ld	a, -4 (ix)
	ld	-10 (ix), a
	ld	a, -5 (ix)
	ld	-9 (ix), a
	ld	a, -4 (ix)
	ld	-8 (ix), a
	ld	a, -7 (ix)
	ld	-2 (ix), a
	ld	a, -6 (ix)
	ld	-1 (ix), a
	ld	b, #0x02
00118$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:107: destination[0] = (destination[0] & keep) | mask[1];
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	ld	a, (hl)
	and	a, -16 (ix)
	ld	l, -15 (ix)
	ld	h, -14 (ix)
	inc	hl
	or	a, (hl)
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:108: destination[1] = (destination[1] & keep) | mask[2];
	ld	e, -2 (ix)
	ld	d, -1 (ix)
	inc	de
	ld	a, (de)
	and	a, -16 (ix)
	ld	l, -13 (ix)
	ld	h, -12 (ix)
	inc	hl
	inc	hl
	or	a, (hl)
	ld	(de), a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:109: destination[2] = (destination[2] & keep) | mask[3];
	ld	e, -2 (ix)
	ld	d, -1 (ix)
	inc	de
	inc	de
	ld	a, (de)
	and	a, -16 (ix)
	ld	l, -11 (ix)
	ld	h, -10 (ix)
	inc	hl
	inc	hl
	inc	hl
	or	a, (hl)
	ld	(de), a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:110: destination[3] = (destination[3] & keep) | mask[4];
	ld	e, -2 (ix)
	ld	d, -1 (ix)
	inc	de
	inc	de
	inc	de
	ld	a, (de)
	and	a, -16 (ix)
	ld	l, -9 (ix)
	ld	h, -8 (ix)
	inc	hl
	inc	hl
	inc	hl
	inc	hl
	ld	c, (hl)
	or	a, c
	ld	(de), a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:111: destination += 4;
	ld	de, #0x0004
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	add	hl, de
	ld	-2 (ix), l
	ld	-1 (ix), h
	djnz	00118$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:105: for (repeat = 0; repeat < 2; ++repeat)
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:113: mask += 5;
	ld	a, -2 (ix)
	ld	-7 (ix), a
	ld	a, -1 (ix)
	ld	-6 (ix), a
	ld	de, #0x0005
	ld	l, -5 (ix)
	ld	h, -4 (ix)
	add	hl, de
	ld	-5 (ix), l
	ld	-4 (ix), h
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:102: for (row = 0; row < 4; ++row)
	inc	-3 (ix)
	ld	a, -3 (ix)
	sub	a, #0x04
	jp	c, 00119$
00121$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/hud_weapon.c:115: }
	ld	sp, ix
	pop	ix
	pop	hl
	pop	af
	jp	(hl)
	.area _BANK1
	.area _BANK1
	.area _INITIALIZER
	.area _CABS (ABS)
