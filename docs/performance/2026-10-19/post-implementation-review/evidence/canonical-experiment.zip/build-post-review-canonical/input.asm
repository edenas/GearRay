;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (MINGW64)
;--------------------------------------------------------
	.module input
	
	.optsdcc -mz80 sdcccall(1)
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _SMS_getKeysStatus
	.globl _input_blocked
	.globl _previous_keys
	.globl _keys
	.globl _SMS_SRAM
	.globl _SRAM_bank_to_be_mapped_on_slot2
	.globl _ROM_bank_to_be_mapped_on_slot0
	.globl _ROM_bank_to_be_mapped_on_slot1
	.globl _ROM_bank_to_be_mapped_on_slot2
	.globl _game_gear_input_initialize
	.globl _game_gear_input_update
	.globl _input_get_forward_intent
	.globl _input_get_strafe_intent
	.globl _input_get_rotation_intent
	.globl _input_interaction_requested
	.globl _input_shoot_requested
	.globl _input_pause_requested
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
_SMS_VDPControlPort	=	0x00bf
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
_ROM_bank_to_be_mapped_on_slot2	=	0xffff
_ROM_bank_to_be_mapped_on_slot1	=	0xfffe
_ROM_bank_to_be_mapped_on_slot0	=	0xfffd
_SRAM_bank_to_be_mapped_on_slot2	=	0xfffc
_SMS_SRAM	=	0x8000
_keys::
	.ds 2
_previous_keys::
	.ds 2
_input_blocked::
	.ds 1
_button_2_strafe_used:
	.ds 1
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute ram data
;--------------------------------------------------------
	.area _DABS (ABS)
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:10: void game_gear_input_initialize(void)
;	---------------------------------
; Function game_gear_input_initialize
; ---------------------------------
_game_gear_input_initialize::
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:12: keys = 0;
	ld	hl, #0x0000
	ld	(_keys), hl
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:13: previous_keys = 0;
	ld	(_previous_keys), hl
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:14: input_blocked = 0;
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:15: button_2_strafe_used = 0;
	xor	a, a
	ld	(#_input_blocked), a
	ld	(#_button_2_strafe_used), a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:16: }
	ret
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:18: void game_gear_input_update(void)
;	---------------------------------
; Function game_gear_input_update
; ---------------------------------
_game_gear_input_update::
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:20: previous_keys = keys;
	ld	hl, (_keys)
	ld	(_previous_keys), hl
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:21: keys = SMS_getKeysStatus();
	call	_SMS_getKeysStatus
	ld	(_keys), de
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:22: input_blocked &= (unsigned char)keys;
	ld	hl, (_keys)
	ld	a, (_input_blocked+0)
	and	a, l
	ld	(_input_blocked+0), a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:23: keys &= ~(unsigned int)input_blocked;
	ld	a, (_input_blocked)
	ld	c, #0x00
	cpl
	ld	b, a
	ld	a, c
	cpl
	ld	a, (_keys+0)
	and	a, b
	ld	(_keys+0), a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:25: if (keys & PORT_A_KEY_2)
	ld	hl, #_keys
	bit	5, (hl)
	ret	z
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:27: if (!(previous_keys & PORT_A_KEY_2))
	ld	hl, #_previous_keys
	bit	5, (hl)
	jr	nz, 00102$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:29: button_2_strafe_used = 0;
	xor	a, a
	ld	(#_button_2_strafe_used), a
00102$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:32: if (keys & (PORT_A_KEY_LEFT | PORT_A_KEY_RIGHT))
	ld	a, (_keys+0)
	and	a, #0x0c
	ret	z
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:33: button_2_strafe_used = 1;
	ld	hl, #_button_2_strafe_used
	ld	(hl), #0x01
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:35: }
	ret
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:37: signed char input_get_forward_intent(void)
;	---------------------------------
; Function input_get_forward_intent
; ---------------------------------
_input_get_forward_intent::
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:39: signed char intent = 0;
	xor	a, a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:41: if (keys & PORT_A_KEY_UP)
	ld	hl, #_keys
	bit	0, (hl)
	jr	z, 00102$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:42: ++intent;
	ld	a, #0x01
00102$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:43: if (keys & PORT_A_KEY_DOWN)
	ld	hl, #_keys
	bit	1, (hl)
	ret	z
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:44: --intent;
	dec	a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:46: return intent;
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:47: }
	ret
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:49: signed char input_get_strafe_intent(void)
;	---------------------------------
; Function input_get_strafe_intent
; ---------------------------------
_input_get_strafe_intent::
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:51: signed char intent = 0;
	xor	a, a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:53: if (!(keys & PORT_A_KEY_2))
	ld	hl, #_keys
	bit	5, (hl)
	jr	nz, 00102$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:54: return 0;
	xor	a, a
	ret
00102$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:56: if (keys & PORT_A_KEY_LEFT)
	ld	hl, #_keys
	bit	2, (hl)
	jr	z, 00104$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:57: --intent;
	ld	a, #0xff
00104$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:58: if (keys & PORT_A_KEY_RIGHT)
	ld	hl, #_keys
	bit	3, (hl)
	ret	z
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:59: ++intent;
	inc	a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:61: return intent;
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:62: }
	ret
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:64: signed char input_get_rotation_intent(void)
;	---------------------------------
; Function input_get_rotation_intent
; ---------------------------------
_input_get_rotation_intent::
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:66: signed char intent = 0;
	xor	a, a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:68: if (keys & PORT_A_KEY_2)
	ld	hl, #_keys
	bit	5, (hl)
	jr	z, 00102$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:69: return 0;
	xor	a, a
	ret
00102$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:71: if (keys & PORT_A_KEY_LEFT)
	ld	hl, #_keys
	bit	2, (hl)
	jr	z, 00104$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:72: --intent;
	ld	a, #0xff
00104$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:73: if (keys & PORT_A_KEY_RIGHT)
	ld	hl, #_keys
	bit	3, (hl)
	ret	z
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:74: ++intent;
	inc	a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:76: return intent;
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:77: }
	ret
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:79: unsigned char input_interaction_requested(void)
;	---------------------------------
; Function input_interaction_requested
; ---------------------------------
_input_interaction_requested::
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:81: return (keys & PORT_A_KEY_2) == 0
	ld	hl, #_keys
	bit	5, (hl)
	jr	nz, 00103$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:82: && (previous_keys & PORT_A_KEY_2) != 0
	ld	hl, #_previous_keys
	bit	5, (hl)
	jr	z, 00103$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:83: && !button_2_strafe_used;
	ld	a, (_button_2_strafe_used+0)
	or	a, a
	jr	z, 00104$
00103$:
	xor	a, a
	ret
00104$:
	ld	a, #0x01
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:84: }
	ret
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:86: unsigned char input_shoot_requested(void)
;	---------------------------------
; Function input_shoot_requested
; ---------------------------------
_input_shoot_requested::
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:88: return (keys & PORT_A_KEY_1) != 0
	ld	hl, #_keys
	bit	4, (hl)
	jr	z, 00103$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:89: && (previous_keys & PORT_A_KEY_1) == 0;
	ld	hl, #_previous_keys
	bit	4, (hl)
	jr	z, 00104$
00103$:
	xor	a, a
	ret
00104$:
	ld	a, #0x01
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:90: }
	ret
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:92: unsigned char input_pause_requested(void)
;	---------------------------------
; Function input_pause_requested
; ---------------------------------
_input_pause_requested::
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:94: return (keys & GG_KEY_START) != 0
	ld	hl, #_keys + 1
	bit	7, (hl)
	jr	z, 00103$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:95: && (previous_keys & GG_KEY_START) == 0;
	ld	hl, #_previous_keys + 1
	bit	7, (hl)
	jr	z, 00104$
00103$:
	xor	a, a
	ret
00104$:
	ld	a, #0x01
;D:/mano_projektai/GearRay/build-post-review-canonical-source/platform/game_gear/input.c:96: }
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
