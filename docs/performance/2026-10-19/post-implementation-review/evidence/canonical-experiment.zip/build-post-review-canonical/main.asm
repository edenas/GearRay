;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (MINGW64)
;--------------------------------------------------------
	.module main
	
	.optsdcc -mz80 sdcccall(1)
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl ___SMS__SEGA_signature
	.globl _main
	.globl _zombie_ai_update_all
	.globl _zombie_shooting_process
	.globl _world_sprites_update
	.globl b_world_initialize
	.globl _world_initialize
	.globl b_game_gear_startup_logo_show
	.globl _game_gear_startup_logo_show
	.globl _raycaster_update
	.globl _raycaster_initialize
	.globl _red_door_switch_update
	.globl _game_gear_pause_map_show
	.globl _player_is_dead
	.globl _player_get_position_y
	.globl _player_get_position_x
	.globl _player_process_interaction
	.globl _player_move_combined
	.globl _player_initialize
	.globl _game_gear_hud_weapon_update
	.globl _game_gear_hud_weapon_initialize
	.globl _game_gear_video_draw_viewport_border
	.globl _game_gear_video_draw_wall_columns
	.globl _game_gear_damage_shake_update
	.globl b_game_gear_video_present_player_death
	.globl _game_gear_video_present_player_death
	.globl b_game_gear_video_restore_gameplay
	.globl _game_gear_video_restore_gameplay
	.globl b_game_gear_video_initialize
	.globl _game_gear_video_initialize
	.globl _input_pause_requested
	.globl _input_shoot_requested
	.globl _input_get_rotation_intent
	.globl _input_get_strafe_intent
	.globl _input_get_forward_intent
	.globl _game_gear_input_update
	.globl _game_gear_input_initialize
	.globl _camera_rotate_right
	.globl _camera_rotate_left
	.globl _camera_set_fixed_position
	.globl _camera_initialize
	.globl _SMS_waitForVBlank
	.globl _SMS_VDPturnOffFeature
	.globl _SMS_VDPturnOnFeature
	.globl _SMS_SRAM
	.globl _SRAM_bank_to_be_mapped_on_slot2
	.globl _ROM_bank_to_be_mapped_on_slot0
	.globl _ROM_bank_to_be_mapped_on_slot1
	.globl _ROM_bank_to_be_mapped_on_slot2
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
_SMS_VDPControlPort	=	0x00bf
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
_ROM_bank_to_be_mapped_on_slot2	=	0xffff
_ROM_bank_to_be_mapped_on_slot1	=	0xfffe
_ROM_bank_to_be_mapped_on_slot0	=	0xfffd
_SRAM_bank_to_be_mapped_on_slot2	=	0xfffc
_SMS_SRAM	=	0x8000
_pending_shot:
	.ds 1
_zombie_ai_frame_counter:
	.ds 1
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute ram data
;--------------------------------------------------------
	.area _DABS (ABS)
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:26: void main(void)
;	---------------------------------
; Function main
; ---------------------------------
_main::
	dec	sp
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:33: while (1)
00121$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:35: game_gear_startup_logo_show();
	ld	e, #b_game_gear_startup_logo_show
	ld	hl, #_game_gear_startup_logo_show
	call	___sdcc_bcall_ehl
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:36: game_gear_video_initialize();
	ld	e, #b_game_gear_video_initialize
	ld	hl, #_game_gear_video_initialize
	call	___sdcc_bcall_ehl
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:37: game_gear_input_initialize();
	call	_game_gear_input_initialize
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:38: game_gear_hud_weapon_initialize();
	call	_game_gear_hud_weapon_initialize
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:39: pending_shot = 0;
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:40: zombie_ai_frame_counter = 0;
	xor	a, a
	ld	(#_pending_shot), a
	ld	(#_zombie_ai_frame_counter), a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:41: world_initialize();
	ld	e, #b_world_initialize
	ld	hl, #_world_initialize
	call	___sdcc_bcall_ehl
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:42: player_initialize();
	call	_player_initialize
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:43: camera_initialize();
	call	_camera_initialize
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:45: player_get_position_y());
	call	_player_get_position_y
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:44: camera_set_fixed_position(player_get_position_x(),
	push	de
	call	_player_get_position_x
	ex	de, hl
	pop	de
	call	_camera_set_fixed_position
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:46: raycaster_initialize();
	call	_raycaster_initialize
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:56: raycaster_update();
	call	_raycaster_update
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:57: game_gear_video_draw_wall_columns();
	call	_game_gear_video_draw_wall_columns
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:59: game_gear_video_draw_viewport_border();
	call	_game_gear_video_draw_viewport_border
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:61: SMS_displayOff();
	ld	hl, #0x0140
	call	_SMS_VDPturnOffFeature
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:62: SMS_waitForVBlank();
	call	_SMS_waitForVBlank
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:63: SMS_displayOn();
	ld	hl, #0x0140
	call	_SMS_VDPturnOnFeature
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:65: while (!player_is_dead())
00117$:
	call	_player_is_dead
	or	a, a
	jp	nz, 00119$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:70: game_gear_input_update();
	call	_game_gear_input_update
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:71: if (input_pause_requested())
	call	_input_pause_requested
	or	a, a
	jr	z, 00102$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:73: game_gear_pause_map_show();
	call	_game_gear_pause_map_show
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:74: game_gear_video_restore_gameplay();
	ld	e, #b_game_gear_video_restore_gameplay
	ld	hl, #_game_gear_video_restore_gameplay
	call	___sdcc_bcall_ehl
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:75: continue;
	jr	00117$
00102$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:77: world_sprites_update();
	call	_world_sprites_update
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:78: shoot_requested = input_shoot_requested();
	call	_input_shoot_requested
	ld	iy, #0
	add	iy, sp
	ld	0 (iy), a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:79: rotation_direction = input_get_rotation_intent();
	call	_input_get_rotation_intent
	ld	c, a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:81: if (rotation_direction < 0)
	bit	7, c
	jr	z, 00106$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:82: camera_rotate_left();
	call	_camera_rotate_left
	jr	00107$
00106$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:83: else if (rotation_direction > 0)
	xor	a, a
	sub	a, c
	jp	po, 00205$
	xor	a, #0x80
00205$:
	jp	p, 00107$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:84: camera_rotate_right();
	call	_camera_rotate_right
00107$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:90: forward_direction = input_get_forward_intent();
	call	_input_get_forward_intent
	ld	c, a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:91: strafe_direction = input_get_strafe_intent();
	push	bc
	call	_input_get_strafe_intent
	pop	bc
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:93: if (forward_direction != 0 || strafe_direction != 0)
	inc	c
	dec	c
	jr	nz, 00108$
	or	a, a
	jr	z, 00109$
00108$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:95: player_move_combined(forward_direction, strafe_direction);
	ld	l, a
	ld	a, c
	call	_player_move_combined
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:97: player_get_position_y());
	call	_player_get_position_y
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:96: camera_set_fixed_position(player_get_position_x(),
	push	de
	call	_player_get_position_x
	ex	de, hl
	pop	de
	call	_camera_set_fixed_position
00109$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:100: game_gear_hud_weapon_update(shoot_requested);
	ld	hl, #0
	add	hl, sp
	ld	a, (hl)
	call	_game_gear_hud_weapon_update
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:101: if (++zombie_ai_frame_counter >= ZOMBIE_AI_UPDATE_INTERVAL)
	ld	hl, #_zombie_ai_frame_counter
	inc	(hl)
	ld	a, (_zombie_ai_frame_counter+0)
	sub	a, #0x04
	jr	c, 00112$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:103: zombie_ai_frame_counter = 0;
	ld	(hl), #0x00
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:104: zombie_ai_update_all();
	call	_zombie_ai_update_all
00112$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:107: if (player_is_dead())
	call	_player_is_dead
	or	a, a
	jr	nz, 00119$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:110: player_process_interaction();
	call	_player_process_interaction
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:111: red_door_switch_update();
	call	_red_door_switch_update
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:113: raycaster_update();
	call	_raycaster_update
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:114: if (pending_shot)
	ld	a, (_pending_shot+0)
	or	a, a
	jr	z, 00116$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:115: zombie_shooting_process();
	call	_zombie_shooting_process
00116$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:116: pending_shot = shoot_requested;
	ld	hl, #0
	add	hl, sp
	ld	a, (hl)
	ld	(#_pending_shot), a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:117: SMS_waitForVBlank();
	call	_SMS_waitForVBlank
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:118: game_gear_damage_shake_update();
	call	_game_gear_damage_shake_update
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:119: game_gear_video_draw_wall_columns();
	call	_game_gear_video_draw_wall_columns
	jp	00117$
00119$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:122: pending_shot = 0;
	xor	a, a
	ld	(#_pending_shot), a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:123: game_gear_video_present_player_death();
	ld	e, #b_game_gear_video_present_player_death
	ld	hl, #_game_gear_video_present_player_death
	call	___sdcc_bcall_ehl
	jp	00121$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/main.c:125: }
	inc	sp
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
	.org 0x7FF0
___SMS__SEGA_signature:
	.db #0x54	; 84	'T'
	.db #0x4d	; 77	'M'
	.db #0x52	; 82	'R'
	.db #0x20	; 32
	.db #0x53	; 83	'S'
	.db #0x45	; 69	'E'
	.db #0x47	; 71	'G'
	.db #0x41	; 65	'A'
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x7e	; 126
