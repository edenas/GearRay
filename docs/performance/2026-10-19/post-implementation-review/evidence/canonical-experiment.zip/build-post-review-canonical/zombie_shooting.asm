;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (MINGW64)
;--------------------------------------------------------
	.module zombie_shooting
	
	.optsdcc -mz80 sdcccall(1)
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _raycaster_get_rendered_rays
	.globl _world_sprite_get
	.globl _world_sprite_get_count
	.globl _world_sprite_apply_damage
	.globl _camera_get_plane_y
	.globl _camera_get_plane_x
	.globl _camera_get_direction_y
	.globl _camera_get_direction_x
	.globl _camera_get_position_y
	.globl _camera_get_position_x
	.globl _zombie_shooting_process
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute ram data
;--------------------------------------------------------
	.area _DABS (ABS)
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _BANK1
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:42: static unsigned int shotgun_sample_wall_depth(const RaycasterRay *rays,
;	---------------------------------
; Function shotgun_sample_wall_depth
; ---------------------------------
_shotgun_sample_wall_depth:
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	iy, #-16
	add	iy, sp
	ld	sp, iy
	ld	-2 (ix), l
	ld	-1 (ix), h
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:46: unsigned long scaled_lateral = (lateral << 6) + (lateral << 4);
	ld	l, 4 (ix)
	ld	h, 5 (ix)
	ld	c, 6 (ix)
	ld	e, 7 (ix)
	ld	b, #0x06
00183$:
	add	hl, hl
	rl	c
	rl	e
	djnz	00183$
	ld	a, 4 (ix)
	ld	-6 (ix), a
	ld	a, 5 (ix)
	ld	-5 (ix), a
	ld	a, 6 (ix)
	ld	-4 (ix), a
	ld	a, 7 (ix)
	ld	-3 (ix), a
	ld	b, #0x04
00185$:
	sla	-6 (ix)
	rl	-5 (ix)
	rl	-4 (ix)
	rl	-3 (ix)
	djnz	00185$
	ld	a, l
	add	a, -6 (ix)
	ld	-16 (ix), a
	ld	a, h
	adc	a, -5 (ix)
	ld	-15 (ix), a
	ld	a, c
	adc	a, -4 (ix)
	ld	-14 (ix), a
	ld	a, e
	adc	a, -3 (ix)
	ld	-13 (ix), a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:47: unsigned long side_center = depth_cross << 4;
	ld	a, 8 (ix)
	ld	-12 (ix), a
	ld	a, 9 (ix)
	ld	-11 (ix), a
	ld	a, 10 (ix)
	ld	-10 (ix), a
	ld	a, 11 (ix)
	ld	-9 (ix), a
	ld	b, #0x04
00187$:
	sla	-12 (ix)
	rl	-11 (ix)
	rl	-10 (ix)
	rl	-9 (ix)
	djnz	00187$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:48: unsigned long body_half_width = determinant_magnitude << 5;
	ld	a, 12 (ix)
	ld	-8 (ix), a
	ld	a, 13 (ix)
	ld	-7 (ix), a
	ld	a, 14 (ix)
	ld	-6 (ix), a
	ld	a, 15 (ix)
	ld	-5 (ix), a
	ld	b, #0x05
00189$:
	sla	-8 (ix)
	rl	-7 (ix)
	rl	-6 (ix)
	rl	-5 (ix)
	djnz	00189$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:51: unsigned int wall_depth = 0;
	xor	a, a
	ld	-4 (ix), a
	ld	-3 (ix), a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:53: if (scaled_lateral <= body_half_width)
	ld	a, -8 (ix)
	sub	a, -16 (ix)
	ld	a, -7 (ix)
	sbc	a, -15 (ix)
	ld	a, -6 (ix)
	sbc	a, -14 (ix)
	ld	a, -5 (ix)
	sbc	a, -13 (ix)
	jr	c, 00102$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:54: wall_depth = rays[SHOTGUN_SAMPLE_CENTER_RAY].wall_distance;
	ld	c, -2 (ix)
	ld	b, -1 (ix)
	ld	hl, #88
	add	hl, bc
	ld	a, (hl)
	ld	-4 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-3 (ix), a
00102$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:56: ? scaled_lateral - side_center : side_center - scaled_lateral;
	ld	a, -12 (ix)
	sub	a, -16 (ix)
	ld	a, -11 (ix)
	sbc	a, -15 (ix)
	ld	a, -10 (ix)
	sbc	a, -14 (ix)
	ld	a, -9 (ix)
	sbc	a, -13 (ix)
	jr	nc, 00113$
	ld	a, -16 (ix)
	sub	a, -12 (ix)
	ld	c, a
	ld	a, -15 (ix)
	sbc	a, -11 (ix)
	ld	b, a
	ld	a, -14 (ix)
	sbc	a, -10 (ix)
	ld	e, a
	ld	a, -13 (ix)
	sbc	a, -9 (ix)
	jr	00114$
00113$:
	ld	a, -12 (ix)
	sub	a, -16 (ix)
	ld	c, a
	ld	a, -11 (ix)
	sbc	a, -15 (ix)
	ld	b, a
	ld	a, -10 (ix)
	sbc	a, -14 (ix)
	ld	e, a
	ld	a, -9 (ix)
	sbc	a, -13 (ix)
00114$:
	ld	d, a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:57: if (near_side_distance <= body_half_width)
	ld	a, -8 (ix)
	sub	a, c
	ld	a, -7 (ix)
	sbc	a, b
	ld	a, -6 (ix)
	sbc	a, e
	ld	a, -5 (ix)
	sbc	a, d
	jr	c, 00106$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:59: unsigned int side_wall_depth = rays[right
	ld	a, 16 (ix)
	or	a, a
	ld	a, #0x12
	jr	nz, 00116$
	ld	a, #0x0a
00116$:
	ld	c, a
	add	a, a
	add	a, c
	add	a, a
	add	a, -2 (ix)
	ld	c, a
	ld	a, #0x00
	adc	a, -1 (ix)
	ld	b, a
	ld	hl, #4
	add	hl, bc
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:61: if (side_wall_depth > wall_depth)
	ld	a, -4 (ix)
	sub	a, c
	ld	a, -3 (ix)
	sbc	a, b
	jr	nc, 00106$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:62: wall_depth = side_wall_depth;
	ld	-4 (ix), c
	ld	-3 (ix), b
00106$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:64: far_side_distance = scaled_lateral + side_center;
	ld	a, -16 (ix)
	add	a, -12 (ix)
	ld	c, a
	ld	a, -15 (ix)
	adc	a, -11 (ix)
	ld	b, a
	ld	a, -14 (ix)
	adc	a, -10 (ix)
	ld	e, a
	ld	a, -13 (ix)
	adc	a, -9 (ix)
	ld	d, a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:65: if (far_side_distance <= body_half_width)
	ld	a, -8 (ix)
	sub	a, c
	ld	a, -7 (ix)
	sbc	a, b
	ld	a, -6 (ix)
	sbc	a, e
	ld	a, -5 (ix)
	sbc	a, d
	jr	c, 00110$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:67: unsigned int side_wall_depth = rays[right
	ld	a, 16 (ix)
	or	a, a
	ld	a, #0x0a
	jr	nz, 00118$
	ld	a, #0x12
00118$:
	ld	c, a
	add	a, a
	add	a, c
	add	a, a
	add	a, -2 (ix)
	ld	-6 (ix), a
	ld	a, #0x00
	adc	a, -1 (ix)
	ld	-5 (ix), a
	ld	l, -6 (ix)
	ld	h, -5 (ix)
	ld	de, #0x0004
	add	hl, de
	ld	a, (hl)
	ld	-6 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-5 (ix), a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:69: if (side_wall_depth > wall_depth)
	ld	a, -4 (ix)
	sub	a, -6 (ix)
	ld	a, -3 (ix)
	sbc	a, -5 (ix)
	jr	nc, 00110$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:70: wall_depth = side_wall_depth;
	ld	a, -6 (ix)
	ld	-4 (ix), a
	ld	a, -5 (ix)
	ld	-3 (ix), a
00110$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:72: return wall_depth;
	ld	e, -4 (ix)
	ld	d, -3 (ix)
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:73: }
	ld	sp, ix
	pop	ix
	pop	hl
	pop	af
	pop	af
	pop	af
	pop	af
	pop	af
	pop	af
	inc	sp
	jp	(hl)
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:75: static unsigned char zombie_shooting_find_aimed_target(
;	---------------------------------
; Function zombie_shooting_find_aimed_target
; ---------------------------------
_zombie_shooting_find_aimed_target:
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	iy, #-55
	add	iy, sp
	ld	sp, iy
	ld	-3 (ix), l
	ld	-2 (ix), h
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:79: unsigned char nearest_index = NO_ZOMBIE_TARGET;
	ld	-51 (ix), #0x08
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:80: unsigned int nearest_depth = ZOMBIE_MAX_SHOOTING_DISTANCE + 1;
	ld	-50 (ix), #0x01
	ld	-49 (ix), #0x08
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:81: signed int position_x = camera_get_position_x();
	call	_camera_get_position_x
	ld	-48 (ix), e
	ld	-47 (ix), d
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:82: signed int position_y = camera_get_position_y();
	call	_camera_get_position_y
	ld	-46 (ix), e
	ld	-45 (ix), d
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:83: signed int direction_x = camera_get_direction_x();
	call	_camera_get_direction_x
	ld	-9 (ix), e
	ld	-8 (ix), d
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:84: signed int direction_y = camera_get_direction_y();
	call	_camera_get_direction_y
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:85: signed int plane_x = camera_get_plane_x();
	push	de
	call	_camera_get_plane_x
	ex	de, hl
	pop	de
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:86: signed int plane_y = camera_get_plane_y();
	push	hl
	push	de
	call	_camera_get_plane_y
	ld	c, e
	ld	b, d
	pop	de
	pop	hl
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:87: signed long determinant =
	ld	-44 (ix), l
	ld	a, h
	ld	-43 (ix), a
	rlca
	sbc	a, a
	ld	-42 (ix), a
	ld	-41 (ix), e
	ld	a, d
	ld	-40 (ix), a
	rlca
	sbc	a, a
	ld	-39 (ix), a
	ld	l, -44 (ix)
	ld	h, -43 (ix)
	ld	e, -41 (ix)
	ld	d, -40 (ix)
	push	bc
	call	___mulsint2slong
	ld	-7 (ix), e
	ld	-6 (ix), d
	ld	-5 (ix), l
	ld	-4 (ix), h
	pop	bc
	ld	a, -9 (ix)
	ld	-38 (ix), a
	ld	a, -8 (ix)
	ld	-37 (ix), a
	rlca
	sbc	a, a
	ld	-36 (ix), a
	ld	-35 (ix), c
	ld	a, b
	ld	-34 (ix), a
	rlca
	sbc	a, a
	ld	-33 (ix), a
	ld	l, -38 (ix)
	ld	h, -37 (ix)
	ld	e, -35 (ix)
	ld	d, -34 (ix)
	call	___mulsint2slong
	ld	a, -7 (ix)
	sub	a, e
	ld	-32 (ix), a
	ld	a, -6 (ix)
	sbc	a, d
	ld	-31 (ix), a
	ld	a, -5 (ix)
	sbc	a, l
	ld	-30 (ix), a
	ld	a, -4 (ix)
	sbc	a, h
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:90: unsigned long determinant_magnitude = determinant < 0
	ld	-29 (ix), a
	rlca
	and	a, #0x01
	ld	-28 (ix), a
	or	a, a
	jr	z, 00125$
	xor	a, a
	sub	a, -32 (ix)
	ld	c, a
	ld	a, #0x00
	sbc	a, -31 (ix)
	ld	b, a
	ld	a, #0x00
	sbc	a, -30 (ix)
	ld	e, a
	sbc	a, a
	sub	a, -29 (ix)
	jr	00126$
00125$:
	ld	c, -32 (ix)
	ld	b, -31 (ix)
	ld	e, -30 (ix)
	ld	a, -29 (ix)
00126$:
	ld	-27 (ix), c
	ld	-26 (ix), b
	ld	-25 (ix), e
	ld	-24 (ix), a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:93: const RaycasterRay *rays = raycaster_get_rendered_rays();
	call	_raycaster_get_rendered_rays
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:94: unsigned int wall_depth = rays[PISTOL_CENTER_RAY_LEFT].wall_distance;
	ld	-23 (ix), e
	ld	-22 (ix), d
	ld	c, e
	ld	b, d
	ld	hl, #82
	add	hl, bc
	ld	a, (hl)
	ld	-21 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-20 (ix), a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:96: if (rays[PISTOL_CENTER_RAY_RIGHT].wall_distance < wall_depth)
	ld	c, -23 (ix)
	ld	b, -22 (ix)
	ld	hl, #88
	add	hl, bc
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	ld	a, c
	sub	a, -21 (ix)
	ld	a, b
	sbc	a, -20 (ix)
	jr	nc, 00158$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:97: wall_depth = rays[PISTOL_CENTER_RAY_RIGHT].wall_distance;
	ld	-21 (ix), c
	ld	-20 (ix), b
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:99: for (sprite_index = 0;
00158$:
	ld	a, -27 (ix)
	ld	-19 (ix), a
	ld	a, -26 (ix)
	ld	-18 (ix), a
	ld	a, -25 (ix)
	ld	-17 (ix), a
	ld	a, -24 (ix)
	ld	-16 (ix), a
	sla	-19 (ix)
	rl	-18 (ix)
	rl	-17 (ix)
	rl	-16 (ix)
	ld	-1 (ix), #0x00
00122$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:100: sprite_index < world_sprite_get_count();
	call	_world_sprite_get_count
	ld	c, a
	ld	a, -1 (ix)
	sub	a, c
	jp	nc, 00120$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:103: const WorldSprite *sprite = world_sprite_get(sprite_index);
	ld	a, -1 (ix)
	call	_world_sprite_get
	ld	-7 (ix), e
	ld	-6 (ix), d
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:113: if (WORLD_SPRITE_LIFE_STATE(sprite) != ZOMBIE_STATE_ALIVE)
	ld	a, -7 (ix)
	ld	-5 (ix), a
	ld	a, -6 (ix)
	ld	-4 (ix), a
	ld	l, -5 (ix)
	ld	h, -4 (ix)
	ld	de, #0x0006
	add	hl, de
	ld	a, (hl)
	and	a, #0x03
	jp	nz, 00119$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:116: relative_x = sprite->world_x - position_x;
	ld	l, -7 (ix)
	ld	h, -6 (ix)
	ld	a, (hl)
	inc	hl
	ld	c, (hl)
	sub	a, -48 (ix)
	ld	e, a
	ld	a, c
	sbc	a, -47 (ix)
	ld	d, a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:117: relative_y = sprite->world_y - position_y;
	ld	l, -7 (ix)
	ld	h, -6 (ix)
	inc	hl
	inc	hl
	ld	a, (hl)
	inc	hl
	ld	b, (hl)
	sub	a, -46 (ix)
	ld	c, a
	ld	a, b
	sbc	a, -45 (ix)
	ld	b, a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:118: depth_product = (signed long)relative_x * direction_x
	ld	-6 (ix), e
	ld	a, d
	ld	-5 (ix), a
	rlca
	sbc	a, a
	ld	-4 (ix), a
	ld	l, -6 (ix)
	ld	h, -5 (ix)
	ld	e, -38 (ix)
	ld	d, -37 (ix)
	push	bc
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:119: + (signed long)relative_y * direction_y;
	call	___mulsint2slong
	ld	-13 (ix), e
	ld	-12 (ix), d
	ld	-11 (ix), l
	ld	-10 (ix), h
	pop	bc
	ld	-9 (ix), c
	ld	a, b
	ld	-8 (ix), a
	rlca
	sbc	a, a
	ld	-7 (ix), a
	ld	l, -9 (ix)
	ld	h, -8 (ix)
	ld	e, -41 (ix)
	ld	d, -40 (ix)
	call	___mulsint2slong
	ld	a, e
	add	a, -13 (ix)
	ld	c, a
	ld	a, d
	adc	a, -12 (ix)
	ld	b, a
	ld	a, l
	adc	a, -11 (ix)
	ld	e, a
	ld	a, h
	adc	a, -10 (ix)
	ld	d, a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:120: if (depth_product <= 0)
	xor	a, a
	cp	a, c
	sbc	a, b
	ld	a, #0x00
	sbc	a, e
	ld	a, #0x00
	sbc	a, d
	jp	po, 00248$
	xor	a, #0x80
00248$:
	jp	p, 00119$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:123: lateral_product = (signed long)relative_x * direction_y
	ld	l, -6 (ix)
	ld	h, -5 (ix)
	ld	e, -41 (ix)
	ld	d, -40 (ix)
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:124: - (signed long)relative_y * direction_x;
	call	___mulsint2slong
	inc	sp
	inc	sp
	push	de
	ld	-53 (ix), l
	ld	-52 (ix), h
	ld	l, -9 (ix)
	ld	h, -8 (ix)
	ld	e, -38 (ix)
	ld	d, -37 (ix)
	call	___mulsint2slong
	ld	a, -55 (ix)
	sub	a, e
	ld	-13 (ix), a
	ld	a, -54 (ix)
	sbc	a, d
	ld	-12 (ix), a
	ld	a, -53 (ix)
	sbc	a, l
	ld	-11 (ix), a
	ld	a, -52 (ix)
	sbc	a, h
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:126: ? (unsigned long)-lateral_product
	ld	-10 (ix), a
	rlca
	and	a, #0x01
	ld	-15 (ix), a
	or	a, a
	jr	z, 00127$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:127: : (unsigned long)lateral_product;
	xor	a, a
	sub	a, -13 (ix)
	ld	c, a
	ld	a, #0x00
	sbc	a, -12 (ix)
	ld	b, a
	ld	a, #0x00
	sbc	a, -11 (ix)
	ld	e, a
	sbc	a, a
	sub	a, -10 (ix)
	ld	d, a
	jr	00128$
00127$:
	ld	c, -13 (ix)
	ld	b, -12 (ix)
	ld	e, -11 (ix)
	ld	d, -10 (ix)
00128$:
	ld	-14 (ix), c
	ld	-13 (ix), b
	ld	-12 (ix), e
	ld	-11 (ix), d
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:129: && lateral * ZOMBIE_AIM_LATERAL_SCALE
	ld	a, (_selected_weapon)
	dec	a
	ld	a, #0x01
	jr	z, 00250$
	xor	a, a
00250$:
	ld	-10 (ix), a
	bit	0, -10 (ix)
	jr	nz, 00108$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:130: > determinant_magnitude * ZOMBIE_AIM_DETERMINANT_SCALE)
	ld	l, -12 (ix)
	ld	h, -11 (ix)
	push	hl
	ld	l, -14 (ix)
	ld	h, -13 (ix)
	push	hl
	ld	de, #0x0005
	ld	hl, #0x0000
	call	__mullong
	pop	af
	pop	af
	ld	a, -19 (ix)
	sub	a, e
	ld	a, -18 (ix)
	sbc	a, d
	ld	a, -17 (ix)
	sbc	a, l
	ld	a, -16 (ix)
	sbc	a, h
	jp	c, 00119$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:131: continue;
00108$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:133: depth_cross = (signed long)plane_x * relative_y
	ld	l, -44 (ix)
	ld	h, -43 (ix)
	ld	e, -9 (ix)
	ld	d, -8 (ix)
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:134: - (signed long)relative_x * plane_y;
	call	___mulsint2slong
	inc	sp
	inc	sp
	push	de
	ld	-53 (ix), l
	ld	-52 (ix), h
	ld	l, -6 (ix)
	ld	h, -5 (ix)
	ld	e, -35 (ix)
	ld	d, -34 (ix)
	call	___mulsint2slong
	ld	a, -55 (ix)
	sub	a, e
	ld	-9 (ix), a
	ld	a, -54 (ix)
	sbc	a, d
	ld	-8 (ix), a
	ld	a, -53 (ix)
	sbc	a, l
	ld	-7 (ix), a
	ld	a, -52 (ix)
	sbc	a, h
	ld	-6 (ix), a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:135: exact_depth = depth_cross * FIXED_POINT_SCALE / determinant;
	ld	d, -9 (ix)
	ld	l, -8 (ix)
	ld	h, -7 (ix)
	ld	e, #0x00
	ld	c, -30 (ix)
	ld	b, -29 (ix)
	push	bc
	ld	c, -32 (ix)
	ld	b, -31 (ix)
	push	bc
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:137: || exact_depth > ZOMBIE_MAX_SHOOTING_DISTANCE)
	call	__divslong
	pop	af
	pop	af
	ld	a, e
	sub	a, #0x21
	ld	a, d
	sbc	a, #0x00
	ld	a, l
	sbc	a, #0x00
	ld	a, h
	rla
	ccf
	rra
	sbc	a, #0x80
	jp	c, 00119$
	xor	a, a
	cp	a, e
	ld	a, #0x08
	sbc	a, d
	ld	a, #0x00
	sbc	a, l
	ld	a, #0x00
	sbc	a, h
	jp	c, 00119$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:141: depth = (unsigned int)exact_depth;
	ld	-5 (ix), e
	ld	-4 (ix), d
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:142: if (depth >= nearest_depth)
	ld	a, -5 (ix)
	sub	a, -50 (ix)
	ld	a, -4 (ix)
	sbc	a, -49 (ix)
	jp	nc, 00119$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:144: if (selected_weapon == WEAPON_SHOTGUN)
	ld	a, -10 (ix)
	or	a, a
	jr	z, 00116$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:148: (lateral_product < 0) == (determinant < 0));
	ld	a, -28 (ix)
	sub	a, -15 (ix)
	ld	a, #0x01
	jr	z, 00254$
	xor	a, a
00254$:
	ld	-10 (ix), a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:146: depth_cross < 0 ? (unsigned long)-depth_cross : (unsigned long)depth_cross,
	bit	7, -6 (ix)
	jr	z, 00129$
	xor	a, a
	sub	a, -9 (ix)
	ld	c, a
	ld	a, #0x00
	sbc	a, -8 (ix)
	ld	b, a
	ld	a, #0x00
	sbc	a, -7 (ix)
	ld	e, a
	sbc	a, a
	sub	a, -6 (ix)
	ld	-9 (ix), c
	ld	-8 (ix), b
	ld	-7 (ix), e
	ld	-6 (ix), a
00129$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:145: wall_depth = shotgun_sample_wall_depth(rays, lateral,
	ld	a, -10 (ix)
	push	af
	inc	sp
	ld	l, -25 (ix)
	ld	h, -24 (ix)
	push	hl
	ld	l, -27 (ix)
	ld	h, -26 (ix)
	push	hl
	ld	l, -7 (ix)
	ld	h, -6 (ix)
	push	hl
	ld	l, -9 (ix)
	ld	h, -8 (ix)
	push	hl
	ld	l, -12 (ix)
	ld	h, -11 (ix)
	push	hl
	ld	l, -14 (ix)
	ld	h, -13 (ix)
	push	hl
	ld	l, -23 (ix)
	ld	h, -22 (ix)
	call	_shotgun_sample_wall_depth
	ld	-21 (ix), e
	ld	-20 (ix), d
00116$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:149: if (depth >= wall_depth)
	ld	a, -5 (ix)
	sub	a, -21 (ix)
	ld	a, -4 (ix)
	sbc	a, -20 (ix)
	jr	nc, 00119$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:152: nearest_index = sprite_index;
	ld	a, -1 (ix)
	ld	-51 (ix), a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:153: nearest_depth = depth;
	ld	a, -5 (ix)
	ld	-50 (ix), a
	ld	a, -4 (ix)
	ld	-49 (ix), a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:154: *target_depth = depth;
	ld	l, -3 (ix)
	ld	h, -2 (ix)
	ld	a, -5 (ix)
	ld	(hl), a
	inc	hl
	ld	a, -4 (ix)
	ld	(hl), a
00119$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:101: ++sprite_index)
	inc	-1 (ix)
	jp	00122$
00120$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:157: return nearest_index;
	ld	a, -51 (ix)
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:158: }
	ld	sp, ix
	pop	ix
	ret
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:160: void zombie_shooting_process(void)
;	---------------------------------
; Function zombie_shooting_process
; ---------------------------------
_zombie_shooting_process::
	push	af
	dec	sp
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:164: unsigned char target = zombie_shooting_find_aimed_target(&target_depth);
	ld	hl, #0
	add	hl, sp
	call	_zombie_shooting_find_aimed_target
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:166: if (target == NO_ZOMBIE_TARGET)
	ld	c, a
	sub	a, #0x08
	jp	z, 00123$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:167: return;
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:169: if (target_depth > PISTOL_VISIBLE_MAX_DEPTH)
	ld	a, #0xec
	ld	iy, #0
	add	iy, sp
	cp	a, 0 (iy)
	ld	a, #0x04
	sbc	a, 1 (iy)
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:170: return;
	jp	c, 00123$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:174: if (target_depth <= PISTOL_TWO_SHOT_MAX_DEPTH)
	ld	a, #0x49
	ld	iy, #0
	add	iy, sp
	cp	a, 0 (iy)
	ld	a, #0x02
	sbc	a, 1 (iy)
	ld	a, #0x00
	rla
	ld	b, a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:176: else if (target_depth <= PISTOL_THREE_SHOT_MAX_DEPTH)
	ld	a, #0xc3
	cp	a, 0 (iy)
	ld	a, #0x03
	sbc	a, 1 (iy)
	ld	a, #0x00
	rla
	ld	e, a
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:172: if (selected_weapon == WEAPON_SHOTGUN)
	ld	a, (_selected_weapon)
	dec	a
	jr	nz, 00121$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:174: if (target_depth <= PISTOL_TWO_SHOT_MAX_DEPTH)
	bit	0, b
	jr	nz, 00109$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:175: damage = SHOTGUN_CLOSE_DAMAGE;
	ld	2 (iy), #0x0c
	jr	00122$
00109$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:176: else if (target_depth <= PISTOL_THREE_SHOT_MAX_DEPTH)
	bit	0, e
	jr	nz, 00106$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:177: damage = SHOTGUN_MEDIUM_DAMAGE;
	ld	iy, #2
	add	iy, sp
	ld	0 (iy), #0x06
	jr	00122$
00106$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:179: damage = SHOTGUN_FAR_DAMAGE;
	ld	iy, #2
	add	iy, sp
	ld	0 (iy), #0x02
	jr	00122$
00121$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:181: else if (target_depth <= PISTOL_ONE_SHOT_MAX_DEPTH)
	ld	a, #0xc7
	ld	iy, #0
	add	iy, sp
	cp	a, 0 (iy)
	ld	a, #0x01
	sbc	a, 1 (iy)
	jr	c, 00118$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:182: damage = PISTOL_ONE_SHOT_DAMAGE;
	ld	2 (iy), #0x0c
	jr	00122$
00118$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:183: else if (target_depth <= PISTOL_TWO_SHOT_MAX_DEPTH)
	bit	0, b
	jr	nz, 00115$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:184: damage = PISTOL_TWO_SHOT_DAMAGE;
	ld	iy, #2
	add	iy, sp
	ld	0 (iy), #0x06
	jr	00122$
00115$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:185: else if (target_depth <= PISTOL_THREE_SHOT_MAX_DEPTH)
	bit	0, e
	jr	nz, 00112$
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:186: damage = PISTOL_THREE_SHOT_DAMAGE;
	ld	iy, #2
	add	iy, sp
	ld	0 (iy), #0x04
	jr	00122$
00112$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:188: damage = PISTOL_FOUR_SHOT_DAMAGE;
	ld	iy, #2
	add	iy, sp
	ld	0 (iy), #0x03
00122$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:190: world_sprite_apply_damage(target, damage);
	ld	iy, #2
	add	iy, sp
	ld	l, 0 (iy)
	ld	a, c
	call	_world_sprite_apply_damage
00123$:
;D:/mano_projektai/GearRay/build-post-review-canonical-source/game/zombie_shooting.c:191: }
	pop	af
	inc	sp
	ret
	.area _BANK1
	.area _INITIALIZER
	.area _CABS (ABS)
