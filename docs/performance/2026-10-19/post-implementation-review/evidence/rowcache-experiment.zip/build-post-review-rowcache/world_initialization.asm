;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (MINGW64)
;--------------------------------------------------------
	.module world_initialization
	
	.optsdcc -mz80 sdcccall(1)
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _world_sprite_initialize
	.globl _world_sprites_initialize
	.globl _workshop_map_get_tile
	.globl _door_states_initialize
	.globl _red_door_switch_initialize
	.globl _shotgun_cell_y
	.globl _shotgun_cell_x
	.globl _selected_weapon
	.globl _owned_weapons
	.globl b_world_initialize
	.globl _world_initialize
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
_owned_weapons::
	.ds 1
_selected_weapon::
	.ds 1
_shotgun_cell_x::
	.ds 1
_shotgun_cell_y::
	.ds 1
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute ram data
;--------------------------------------------------------
	.area _DABS (ABS)
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _BANK1
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world_initialization.c:12: void world_initialize(void) __banked
;	---------------------------------
; Function world_initialize
; ---------------------------------
	b_world_initialize	= 1
_world_initialize::
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world_initialization.c:18: door_states_initialize();
	call	_door_states_initialize
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world_initialization.c:19: red_door_switch_initialize();
	call	_red_door_switch_initialize
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world_initialization.c:20: world_sprites_initialize();
	call	_world_sprites_initialize
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world_initialization.c:21: owned_weapons = WEAPON_OWNED_PISTOL;
	ld	hl, #_owned_weapons
	ld	(hl), #0x01
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world_initialization.c:22: selected_weapon = WEAPON_PISTOL;
	xor	a, a
	ld	(#_selected_weapon), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world_initialization.c:24: for (y = 0; y < WORLD_HEIGHT; ++y)
	ld	l, #0x00
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world_initialization.c:26: for (x = 0; x < WORLD_WIDTH; ++x)
00121$:
	ld	h, #0x00
00108$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world_initialization.c:28: tile = workshop_map_get_tile(x, y);
	push	hl
	ld	a, h
	call	_workshop_map_get_tile
	pop	hl
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world_initialization.c:29: if (tile == WORLD_TILE_SPRITE_MARKER)
	cp	a, #0x09
	jr	nz, 00104$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world_initialization.c:30: world_sprite_initialize(x, y);
	push	hl
	ld	a, h
	call	_world_sprite_initialize
	pop	hl
	jr	00109$
00104$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world_initialization.c:31: else if (tile == WORLD_TILE_SHOTGUN_MARKER)
	cp	a, #0x0a
	jr	nz, 00109$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world_initialization.c:33: shotgun_cell_x = x;
	ld	a, h
	ld	(_shotgun_cell_x+0), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world_initialization.c:34: shotgun_cell_y = y;
	ld	a, l
	ld	(_shotgun_cell_y+0), a
00109$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world_initialization.c:26: for (x = 0; x < WORLD_WIDTH; ++x)
	inc	h
	ld	a, h
	sub	a, #0x0d
	jr	c, 00108$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world_initialization.c:24: for (y = 0; y < WORLD_HEIGHT; ++y)
	inc	l
	ld	a, l
	sub	a, #0x0d
	jr	c, 00121$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world_initialization.c:38: }
	ret
	.area _BANK1
	.area _INITIALIZER
	.area _CABS (ABS)
