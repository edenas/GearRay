;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (MINGW64)
;--------------------------------------------------------
	.module enemy_collision
	
	.optsdcc -mz80 sdcccall(1)
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _world_is_wall
	.globl _enemy_position_is_walkable
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute ram data
;--------------------------------------------------------
	.area _DABS (ABS)
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _BANK1
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/enemy_collision.c:6: unsigned char enemy_position_is_walkable(signed int world_x,
;	---------------------------------
; Function enemy_position_is_walkable
; ---------------------------------
_enemy_position_is_walkable::
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	iy, #-9
	add	iy, sp
	ld	sp, iy
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/enemy_collision.c:10: signed int left = world_x - radius;
	ld	c, 4 (ix)
	ld	b, #0x00
	ld	a, l
	sub	a, c
	ld	-8 (ix), a
	ld	a, h
	sbc	a, b
	ld	-7 (ix), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/enemy_collision.c:11: signed int right = world_x + radius;
	add	hl, bc
	ld	-2 (ix), l
	ld	-1 (ix), h
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/enemy_collision.c:12: signed int top = world_y - radius;
	ld	a, e
	sub	a, c
	ld	-4 (ix), a
	ld	a, d
	sbc	a, b
	ld	-3 (ix), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/enemy_collision.c:13: signed int bottom = world_y + radius;
	ld	a, e
	add	a, c
	ld	-6 (ix), a
	ld	a, d
	adc	a, b
	ld	-5 (ix), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/enemy_collision.c:15: if (left < 0 || top < 0 ||
	bit	7, -7 (ix)
	jr	nz, 00101$
	bit	7, -3 (ix)
	jr	nz, 00101$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/enemy_collision.c:16: right >= (signed int)WORLD_WIDTH * FIXED_POINT_SCALE ||
	ld	a, -1 (ix)
	xor	a, #0x80
	sub	a, #0x8d
	jr	nc, 00101$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/enemy_collision.c:17: bottom >= (signed int)WORLD_HEIGHT * FIXED_POINT_SCALE)
	ld	a, -5 (ix)
	xor	a, #0x80
	sub	a, #0x8d
	jr	c, 00102$
00101$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/enemy_collision.c:18: return 0;
	xor	a, a
	jr	00106$
00102$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/enemy_collision.c:21: (unsigned char)((unsigned int)top >> 8))
	ld	c, -3 (ix)
	ld	-4 (ix), c
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/enemy_collision.c:20: return !world_is_wall((unsigned char)((unsigned int)left >> 8),
	ld	c, -7 (ix)
	ld	-3 (ix), c
	ld	l, -4 (ix)
	ld	a, -3 (ix)
	call	_world_is_wall
	ld	-7 (ix), a
	or	a, a
	jr	nz, 00108$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/enemy_collision.c:22: && !world_is_wall((unsigned char)((unsigned int)right >> 8),
	ld	l, -4 (ix)
	ld	a, -1 (ix)
	call	_world_is_wall
	ld	-2 (ix), a
	or	a, a
	jr	nz, 00108$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/enemy_collision.c:25: (unsigned char)((unsigned int)bottom >> 8))
	ld	a, -6 (ix)
	ld	-9 (ix), a
	ld	a, -5 (ix)
	ld	-8 (ix), a
	ld	l, a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/enemy_collision.c:24: && !world_is_wall((unsigned char)((unsigned int)left >> 8),
	push	hl
	ld	a, -3 (ix)
	call	_world_is_wall
	pop	hl
	or	a, a
	jr	nz, 00108$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/enemy_collision.c:26: && !world_is_wall((unsigned char)((unsigned int)right >> 8),
	ld	a, -1 (ix)
	call	_world_is_wall
	or	a, a
	jr	z, 00109$
00108$:
	ld	-1 (ix), #0x00
	jr	00110$
00109$:
	ld	-1 (ix), #0x01
00110$:
	ld	a, -1 (ix)
00106$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/enemy_collision.c:28: }
	ld	sp, ix
	pop	ix
	pop	hl
	inc	sp
	jp	(hl)
	.area _BANK1
	.area _INITIALIZER
	.area _CABS (ABS)
