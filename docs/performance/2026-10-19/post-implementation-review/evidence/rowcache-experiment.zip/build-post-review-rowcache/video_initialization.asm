;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (MINGW64)
;--------------------------------------------------------
	.module video_initialization
	
	.optsdcc -mz80 sdcccall(1)
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _game_gear_sprite_projection_invalidate
	.globl _player_get_health
	.globl _game_gear_get_wall_palette_color
	.globl _game_gear_video_draw_viewport_border
	.globl _game_gear_video_draw_wall_columns
	.globl _SMS_VRAMmemsetW
	.globl _GG_setSpritePaletteColor
	.globl _GG_setBGPaletteColor
	.globl _SMS_load1bppTiles
	.globl _SMS_crt0_RST18
	.globl _SMS_crt0_RST08
	.globl _SMS_waitForVBlank
	.globl _SMS_setBackdropColor
	.globl _SMS_setBGScrollY
	.globl _SMS_setBGScrollX
	.globl _SMS_VDPturnOffFeature
	.globl _SMS_VDPturnOnFeature
	.globl _SMS_SRAM
	.globl _SRAM_bank_to_be_mapped_on_slot2
	.globl _ROM_bank_to_be_mapped_on_slot0
	.globl _ROM_bank_to_be_mapped_on_slot1
	.globl _ROM_bank_to_be_mapped_on_slot2
	.globl _game_gear_damage_shake_offsets
	.globl _game_gear_health_hud_update
	.globl b_game_gear_video_initialize
	.globl _game_gear_video_initialize
	.globl b_game_gear_video_restore_gameplay
	.globl _game_gear_video_restore_gameplay
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
_SMS_VDPControlPort	=	0x00bf
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
_ROM_bank_to_be_mapped_on_slot2	=	0xffff
_ROM_bank_to_be_mapped_on_slot1	=	0xfffe
_ROM_bank_to_be_mapped_on_slot0	=	0xfffd
_SRAM_bank_to_be_mapped_on_slot2	=	0xfffc
_SMS_SRAM	=	0x8000
_health_hud_rendered_bar_count:
	.ds 1
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute ram data
;--------------------------------------------------------
	.area _DABS (ABS)
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _BANK1
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world_sprite.h:25: static unsigned int zombie_distance_metric(signed int delta_x,
;	---------------------------------
; Function zombie_distance_metric
; ---------------------------------
_zombie_distance_metric:
	ld	c, l
	ld	b, h
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world_sprite.h:28: unsigned int distance_x = delta_x < 0
	bit	7, b
	jr	z, 00103$
	xor	a, a
	sub	a, c
	ld	c, a
	sbc	a, a
	sub	a, b
	ld	b, a
00103$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world_sprite.h:30: unsigned int distance_y = delta_y < 0
	bit	7, d
	jr	z, 00105$
	xor	a, a
	sub	a, e
	ld	l, a
	sbc	a, a
	sub	a, d
	ld	h, a
	jr	00106$
00105$:
	ex	de, hl
00106$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world_sprite.h:34: ? distance_x + (distance_y >> 1)
	ld	a, l
	sub	a, c
	ld	a, h
	sbc	a, b
	jr	nc, 00107$
	srl	h
	rr	l
	add	hl, bc
	ex	de, hl
	ret
00107$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world_sprite.h:35: : distance_y + (distance_x >> 1);
	srl	b
	rr	c
	add	hl, bc
	ex	de, hl
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world_sprite.h:36: }
	ret
	.area _BANK1
	.area _BANK1
_health_hud_tiles:
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0x08	; 8
	.db #0x09	; 9
	.db #0x0b	; 11
	.db #0x09	; 9
	.db #0x08	; 8
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0xe0	; 224
	.db #0x20	; 32
	.db #0x20	; 32
	.db #0xa0	; 160
	.db #0x20	; 32
	.db #0x20	; 32
	.db #0xe0	; 224
	.db #0x00	; 0
	.db #0xe4	; 228
	.db #0x24	; 36
	.db #0x24	; 36
	.db #0xa4	; 164
	.db #0x24	; 36
	.db #0x24	; 36
	.db #0xe4	; 228
	.db #0x00	; 0
	.db #0xe5	; 229
	.db #0x25	; 37
	.db #0x25	; 37
	.db #0xa5	; 165
	.db #0x25	; 37
	.db #0x25	; 37
	.db #0xe5	; 229
	.db #0x00	; 0
	.db #0x40	; 64
	.db #0x40	; 64
	.db #0x40	; 64
	.db #0x40	; 64
	.db #0x40	; 64
	.db #0x40	; 64
	.db #0x40	; 64
	.db #0x00	; 0
	.db #0x50	; 80	'P'
	.db #0x50	; 80	'P'
	.db #0x50	; 80	'P'
	.db #0x50	; 80	'P'
	.db #0x50	; 80	'P'
	.db #0x50	; 80	'P'
	.db #0x50	; 80	'P'
	.db #0x00	; 0
	.db #0x54	; 84	'T'
	.db #0x54	; 84	'T'
	.db #0x54	; 84	'T'
	.db #0x54	; 84	'T'
	.db #0x54	; 84	'T'
	.db #0x54	; 84	'T'
	.db #0x54	; 84	'T'
	.db #0x00	; 0
	.db #0x55	; 85	'U'
	.db #0x55	; 85	'U'
	.db #0x55	; 85	'U'
	.db #0x55	; 85	'U'
	.db #0x55	; 85	'U'
	.db #0x55	; 85	'U'
	.db #0x55	; 85	'U'
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.area _BANK1
	.area _BANK1
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:32: static unsigned char game_gear_health_hud_cell_tile(
;	---------------------------------
; Function game_gear_health_hud_cell_tile
; ---------------------------------
_game_gear_health_hud_cell_tile:
	push	ix
	ld	ix,	#0
	add	ix, sp
	dec	sp
	ld	-1 (ix), a
	ld	c, l
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:38: unsigned char first_bar = first_bars[cell];
	ld	de, #_game_gear_health_hud_cell_tile_first_bars_10000_120+0
	ld	l, c
	ld	h, #0x00
	add	hl, de
	ld	e, (hl)
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:41: remaining = bar_count <= first_bar ? 0 : bar_count - first_bar;
	ld	a, e
	sub	a, -1 (ix)
	jr	c, 00109$
	xor	a, a
	jr	00110$
00109$:
	ld	a, -1 (ix)
	sub	a, e
00110$:
	ld	e, a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:42: if (remaining > capacities[cell])
	ld	hl, #_game_gear_health_hud_cell_tile_capacities_10000_120
	ld	b, #0x00
	add	hl, bc
	ld	b, (hl)
	ld	a, b
	sub	a, e
	jr	nc, 00102$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:43: remaining = capacities[cell];
	ld	e, b
00102$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:45: return HEALTH_HUD_BAR_TILE_INDEX_BASE + remaining;
	ld	a, e
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:44: if (cell == 0)
	inc	c
	dec	c
	jr	nz, 00104$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:45: return HEALTH_HUD_BAR_TILE_INDEX_BASE + remaining;
	add	a, #0x57
	jr	00107$
00104$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:46: if (remaining == 0)
	inc	e
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:47: return 0;
	dec	e
	jr	nz, 00106$
	ld	a, e
	jr	00107$
00106$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:48: return HEALTH_HUD_BAR_TILE_INDEX_BASE + 2 + remaining;
	add	a, #0x59
00107$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:49: }
	inc	sp
	pop	ix
	ret
	.area _BANK1
	.area _BANK1
_ceiling_tile:
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.area _BANK1
	.area _BANK1
_floor_tile:
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.area _BANK1
	.area _BANK1
_game_gear_damage_shake_offsets:
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0xfe	; 254
	.db #0x02	; 2
	.area _BANK1
	.area _BANK1
_game_gear_health_hud_cell_tile_first_bars_10000_120:
	.db #0x00	; 0
	.db #0x02	; 2
	.db #0x06	; 6
	.area _BANK1
	.area _BANK1
_game_gear_health_hud_cell_tile_capacities_10000_120:
	.db #0x02	; 2
	.db #0x04	; 4
	.db #0x04	; 4
	.area _BANK1
	.area _BANK1
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:51: void game_gear_health_hud_update(unsigned char health)
;	---------------------------------
; Function game_gear_health_hud_update
; ---------------------------------
_game_gear_health_hud_update::
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:53: unsigned char bar_count = health / 10;
	ld	l, #0x0a
	call	__divuchar
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:56: if (bar_count == health_hud_rendered_bar_count)
	ld	a, (_health_hud_rendered_bar_count)
	sub	a, e
	ret	z
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:57: return;
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:59: for (cell = 0; cell < HEALTH_HUD_BAR_CELL_COUNT; ++cell)
	ld	d, #0x00
00109$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:61: unsigned char tile = game_gear_health_hud_cell_tile(bar_count, cell);
	push	de
	ld	l, d
	ld	a, e
	call	_game_gear_health_hud_cell_tile
	ld	b, a
	pop	de
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:64: health_hud_rendered_bar_count, cell))
	push	bc
	push	de
	ld	l, d
	ld	a, (_health_hud_rendered_bar_count)
	call	_game_gear_health_hud_cell_tile
	pop	de
	pop	bc
	sub	a, b
	jr	z, 00110$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:66: SMS_setTileatXY(HEALTH_HUD_BAR_TILE_X + cell,
	ld	a, d
	add	a, #0x14
	ld	l, a
	ld	h, #0x00
	push	de
	ld	de, #0x00a0
	add	hl, de
	pop	de
	add	hl, hl
	ld	a, h
	or	a, #0x78
	ld	h, a
	rst	#0x08
	ld	l, b
	ld	h, #0x00
	rst	#0x18
00110$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:59: for (cell = 0; cell < HEALTH_HUD_BAR_CELL_COUNT; ++cell)
	inc	d
	ld	a, d
	sub	a, #0x03
	jr	c, 00109$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:72: health_hud_rendered_bar_count = bar_count;
	ld	hl, #_health_hud_rendered_bar_count
	ld	(hl), e
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:73: }
	ret
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:75: static void game_gear_health_hud_initialize(void)
;	---------------------------------
; Function game_gear_health_hud_initialize
; ---------------------------------
_game_gear_health_hud_initialize:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:77: SMS_load1bppTiles(health_hud_tiles,
	ld	hl, #0xc00
	push	hl
	ld	hl, #0x0058
	push	hl
	ld	de, #0x0056
	ld	hl, #_health_hud_tiles
	call	_SMS_load1bppTiles
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:82: SMS_setTileatXY(HEALTH_HUD_ICON_TILE_X,
	ld	hl, #0x7966
	rst	#0x08
	ld	hl, #0x0056
	rst	#0x18
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:85: health_hud_rendered_bar_count = 0;
	xor	a, a
	ld	(#_health_hud_rendered_bar_count), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:86: game_gear_health_hud_update(100);
	ld	a, #0x64
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:87: }
	jp	_game_gear_health_hud_update
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:89: static void game_gear_video_load_background_palette(void)
;	---------------------------------
; Function game_gear_video_load_background_palette
; ---------------------------------
_game_gear_video_load_background_palette:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:93: GG_setBGPaletteColor(0, RGB(0, 0, 0));
	ld	de, #0x0000
	xor	a, a
	call	_GG_setBGPaletteColor
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:94: SMS_setBackdropColor(0);
	ld	l, #0x00
	call	_SMS_setBackdropColor
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:95: for (wall_palette_offset = 0;
	ld	c, #0x00
00102$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:101: game_gear_get_wall_palette_color(wall_palette_offset));
	push	bc
	ld	a, c
	call	_game_gear_get_wall_palette_color
	pop	bc
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:100: GAME_GEAR_WALL_PALETTE_BASE + wall_palette_offset,
	ld	a, c
	inc	a
	push	bc
	call	_GG_setBGPaletteColor
	pop	bc
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:97: ++wall_palette_offset)
	inc	c
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:96: wall_palette_offset < GAME_GEAR_WALL_PALETTE_COLOR_COUNT;
	ld	a, c
	sub	a, #0x0f
	jr	c, 00102$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:103: }
	ret
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:105: void game_gear_video_initialize(void) __banked
;	---------------------------------
; Function game_gear_video_initialize
; ---------------------------------
	b_game_gear_video_initialize	= 1
_game_gear_video_initialize::
	push	ix
	ld	ix,	#0
	add	ix, sp
	push	af
	push	af
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:111: SMS_displayOff();
	ld	hl, #0x0140
	call	_SMS_VDPturnOffFeature
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:112: SMS_VRAMmemsetW(0, 0x0000, 16384);
	ld	hl, #0x4000
	push	hl
	ld	de, #0x0000
	ld	h, l
	call	_SMS_VRAMmemsetW
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:115: SMS_VRAMmemsetW(PAUSE_MAP_SAT_Y, 0x00d0, 2);
	ld	hl, #0x0002
	push	hl
	ld	de, #0x00d0
	ld	hl, #0x3f00
	call	_SMS_VRAMmemsetW
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:117: game_gear_get_wall_palette_color(PAUSE_MAP_PLAYER_COLOR - GAME_GEAR_WALL_PALETTE_BASE));
	ld	a, #0x06
	call	_game_gear_get_wall_palette_color
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:116: GG_setSpritePaletteColor(PAUSE_MAP_PLAYER_COLOR,
	ld	a, #0x07
	call	_GG_setSpritePaletteColor
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:118: game_gear_damage_shake_phase = 0;
	xor	a, a
	ld	(#_game_gear_damage_shake_phase), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:119: SMS_setBGScrollX(0);
	ld	l, #0x00
	call	_SMS_setBGScrollX
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:120: SMS_setBGScrollY(0);
	ld	l, #0x00
	call	_SMS_setBGScrollY
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:121: previous_projected_sprite_count = 0;
	xor	a, a
	ld	(#_previous_projected_sprite_count), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:122: game_gear_sprite_projection_invalidate();
	call	_game_gear_sprite_projection_invalidate
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:123: game_gear_video_load_background_palette();
	call	_game_gear_video_load_background_palette
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:124: game_gear_health_hud_initialize();
	call	_game_gear_health_hud_initialize
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:125: SMS_load1bppTiles(ceiling_tile,
	ld	hl, #0x300
	push	hl
	ld	hl, #0x0008
	push	hl
	ld	de, #0x0064
	ld	hl, #_ceiling_tile
	call	_SMS_load1bppTiles
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:130: SMS_load1bppTiles(floor_tile,
	ld	hl, #0xa00
	push	hl
	ld	hl, #0x0008
	push	hl
	ld	de, #0x0065
	ld	hl, #_floor_tile
	call	_SMS_load1bppTiles
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:136: for (tile_column = 0;
	ld	bc, #_viewport_tile_states+0
	ld	e, #0x00
00108$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:140: previous_wall_columns[tile_column].side_and_valid_flags = 0;
	push	de
	ld	d, #0x00
	ld	l, e
	ld	h, d
	add	hl, hl
	add	hl, de
	add	hl, hl
	add	hl, de
	ld	de, #_previous_wall_columns
	add	hl, de
	ld	de, #0x0006
	add	hl, de
	pop	de
	ld	(hl), #0x00
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:142: for (row = 0; row < GAME_GEAR_VIEWPORT_TILE_ROWS; ++row)
	ld	-1 (ix), #0x00
00106$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:145: (unsigned int)tile_column * GAME_GEAR_VIEWPORT_TILE_ROWS
	ld	a, e
	add	a, a
	add	a, a
	add	a, a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:146: + row;
	ld	d, -1 (ix)
	add	a, d
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:147: viewport_tile_states[cell_index] = row < VIEWPORT_HORIZON_TILE_ROW
	add	a, c
	ld	-4 (ix), a
	ld	a, #0x00
	adc	a, b
	ld	-3 (ix), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:148: ? VIEWPORT_TILE_STATE_CEILING
	ld	a, -1 (ix)
	sub	a, #0x04
	ld	a, #0x00
	rla
	ld	-2 (ix), a
	or	a, a
	jr	z, 00112$
	xor	a, a
	jr	00113$
00112$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:149: : VIEWPORT_TILE_STATE_FLOOR;
	ld	a, #0x01
00113$:
	pop	hl
	push	hl
	ld	(hl), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:150: SMS_setTileatXY(GAME_GEAR_VIEWPORT_TILE_ORIGIN_X + tile_column,
	ld	a, d
	add	a, #0x08
	ld	l, a
	ld	h, #0x00
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	ld	a, e
	add	a, #0x09
	ld	d, #0x00
	add	a, l
	ld	l, a
	ld	a, d
	adc	a, h
	ld	h, a
	add	hl, hl
	ld	a, h
	or	a, #0x78
	ld	h, a
	push	bc
	rst	#0x08
	pop	bc
	ld	a, -2 (ix)
	or	a, a
	jr	z, 00114$
	ld	-3 (ix), #0x64
	ld	-2 (ix), #0
	jr	00115$
00114$:
	ld	-3 (ix), #0x65
	ld	-2 (ix), #0
00115$:
	ld	l, -3 (ix)
	ld	h, #0x00
	rst	#0x18
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:142: for (row = 0; row < GAME_GEAR_VIEWPORT_TILE_ROWS; ++row)
	inc	-1 (ix)
	ld	a, -1 (ix)
	sub	a, #0x08
	jr	c, 00106$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:138: ++tile_column)
	inc	e
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:137: tile_column < GAME_GEAR_VIEWPORT_TILE_COLUMNS;
	ld	a, e
	sub	a, #0x0e
	jp	c, 00108$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:157: }
	ld	sp, ix
	pop	ix
	ret
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:159: void game_gear_video_restore_gameplay(void) __banked
;	---------------------------------
; Function game_gear_video_restore_gameplay
; ---------------------------------
	b_game_gear_video_restore_gameplay	= 1
_game_gear_video_restore_gameplay::
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:161: unsigned char shake_phase = game_gear_damage_shake_phase;
	ld	a, (_game_gear_damage_shake_phase)
	ld	c, a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:164: game_gear_video_initialize();
	push	bc
	ld	e, #b_game_gear_video_initialize
	ld	hl, #_game_gear_video_initialize
	call	___sdcc_bcall_ehl
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:165: game_gear_health_hud_update(player_get_health());
	call	_player_get_health
	call	_game_gear_health_hud_update
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:167: game_gear_video_draw_wall_columns();
	call	_game_gear_video_draw_wall_columns
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:169: game_gear_video_draw_viewport_border();
	call	_game_gear_video_draw_viewport_border
	pop	bc
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:171: game_gear_damage_shake_phase = shake_phase;
	ld	hl, #_game_gear_damage_shake_phase
	ld	(hl), c
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:172: SMS_setBGScrollX(game_gear_damage_shake_offsets[shake_phase]);
	ld	hl, #_game_gear_damage_shake_offsets
	ld	b, #0x00
	add	hl, bc
	ld	l, (hl)
	call	_SMS_setBGScrollX
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:173: SMS_waitForVBlank();
	call	_SMS_waitForVBlank
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:174: SMS_displayOn();
	ld	hl, #0x0140
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/video_initialization.c:175: }
	jp	_SMS_VDPturnOnFeature
	.area _BANK1
	.area _BANK1
	.area _INITIALIZER
	.area _CABS (ABS)
