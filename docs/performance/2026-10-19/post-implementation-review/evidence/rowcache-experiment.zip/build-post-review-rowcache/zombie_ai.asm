;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (MINGW64)
;--------------------------------------------------------
	.module zombie_ai
	
	.optsdcc -mz80 sdcccall(1)
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _game_gear_health_hud_update
	.globl _world_sprite_get
	.globl _world_sprite_get_count
	.globl _world_is_wall
	.globl _player_is_dead
	.globl _player_apply_damage
	.globl _player_get_health
	.globl _player_get_position_y
	.globl _player_get_position_x
	.globl _enemy_position_is_walkable
	.globl _zombie_ai_wall_negative_mask
	.globl _zombie_ai_wall_following_mask
	.globl _zombie_ai_update_all
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
_zombie_ai_wall_following_mask::
	.ds 1
_zombie_ai_wall_negative_mask::
	.ds 1
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute ram data
;--------------------------------------------------------
	.area _DABS (ABS)
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _BANK1
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world_sprite.h:25: static unsigned int zombie_distance_metric(signed int delta_x,
;	---------------------------------
; Function zombie_distance_metric
; ---------------------------------
_zombie_distance_metric:
	ld	c, l
	ld	b, h
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world_sprite.h:28: unsigned int distance_x = delta_x < 0
	bit	7, b
	jr	z, 00103$
	xor	a, a
	sub	a, c
	ld	c, a
	sbc	a, a
	sub	a, b
	ld	b, a
00103$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world_sprite.h:30: unsigned int distance_y = delta_y < 0
	bit	7, d
	jr	z, 00105$
	xor	a, a
	sub	a, e
	ld	l, a
	sbc	a, a
	sub	a, d
	ld	h, a
	jr	00106$
00105$:
	ex	de, hl
00106$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world_sprite.h:34: ? distance_x + (distance_y >> 1)
	ld	a, l
	sub	a, c
	ld	a, h
	sbc	a, b
	jr	nc, 00107$
	srl	h
	rr	l
	add	hl, bc
	ex	de, hl
	ret
00107$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world_sprite.h:35: : distance_y + (distance_x >> 1);
	srl	b
	rr	c
	add	hl, bc
	ex	de, hl
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world_sprite.h:36: }
	ret
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:22: static unsigned char zombie_ai_get_attack_cooldown(
;	---------------------------------
; Function zombie_ai_get_attack_cooldown
; ---------------------------------
_zombie_ai_get_attack_cooldown:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:25: return (sprite->state & ZOMBIE_ATTACK_COOLDOWN_MASK)
	ld	de, #0x0006
	add	hl, de
	ld	a, (hl)
	and	a, #0x3c
	ld	b, #0x00
	ld	c, a
	sra	b
	rr	c
	sra	b
	rr	c
	ld	a, c
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:27: }
	ret
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:29: static void zombie_ai_set_attack_cooldown(WorldSprite *sprite,
;	---------------------------------
; Function zombie_ai_set_attack_cooldown
; ---------------------------------
_zombie_ai_set_attack_cooldown:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:32: sprite->state = (ZombieState)(
	ld	bc, #0x0006
	add	hl, bc
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:33: (sprite->state & ~ZOMBIE_ATTACK_COOLDOWN_MASK)
	ld	a, (hl)
	and	a, #0xc3
	ld	c, a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:34: | (cooldown << ZOMBIE_ATTACK_COOLDOWN_SHIFT));
	ld	iy, #2
	add	iy, sp
	ld	a, 0 (iy)
	add	a, a
	add	a, a
	or	a, c
	ld	(hl), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:35: }
	pop	hl
	inc	sp
	jp	(hl)
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:37: static unsigned int zombie_ai_absolute(signed int value)
;	---------------------------------
; Function zombie_ai_absolute
; ---------------------------------
_zombie_ai_absolute:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:39: return value < 0 ? (unsigned int)-value : (unsigned int)value;
	bit	7, h
	jr	z, 00103$
	xor	a, a
	sub	a, l
	ld	e, a
	sbc	a, a
	sub	a, h
	ld	d, a
	ret
00103$:
	ex	de, hl
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:40: }
	ret
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:42: static unsigned char world_has_clear_line_of_sight(signed int start_x,
;	---------------------------------
; Function world_has_clear_line_of_sight
; ---------------------------------
_world_has_clear_line_of_sight:
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	iy, #-16
	add	iy, sp
	ld	sp, iy
	ld	-6 (ix), e
	ld	-5 (ix), d
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:47: signed char map_x = (signed char)((unsigned int)start_x >> 8);
	ld	-1 (ix), h
	ld	-4 (ix), h
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:48: signed char map_y = (signed char)((unsigned int)start_y >> 8);
	ld	a, -6 (ix)
	ld	-2 (ix), a
	ld	a, -5 (ix)
	ld	-1 (ix), a
	ld	-3 (ix), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:49: signed char end_map_x = (signed char)((unsigned int)end_x >> 8);
	ld	a, 4 (ix)
	ld	-2 (ix), a
	ld	a, 5 (ix)
	ld	-1 (ix), a
	ld	-16 (ix), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:50: signed char end_map_y = (signed char)((unsigned int)end_y >> 8);
	ld	a, 6 (ix)
	ld	-2 (ix), a
	ld	a, 7 (ix)
	ld	-1 (ix), a
	ld	-15 (ix), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:51: signed char delta_x = end_map_x > map_x
	ld	a, -4 (ix)
	sub	a, -16 (ix)
	jp	po, 00203$
	xor	a, #0x80
00203$:
	jp	p, 00115$
	ld	a, -16 (ix)
	sub	a, -4 (ix)
	jr	00116$
00115$:
	ld	a, -4 (ix)
	sub	a, -16 (ix)
00116$:
	ld	-2 (ix), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:53: signed char delta_y = end_map_y > map_y
	ld	a, -3 (ix)
	sub	a, -15 (ix)
	jp	po, 00204$
	xor	a, #0x80
00204$:
	jp	p, 00117$
	ld	a, -3 (ix)
	sub	a, -15 (ix)
	jr	00118$
00117$:
	ld	a, -15 (ix)
	sub	a, -3 (ix)
00118$:
	ld	-1 (ix), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:55: signed char step_x = map_x < end_map_x ? 1 : -1;
	ld	a, -4 (ix)
	sub	a, -16 (ix)
	jp	po, 00205$
	xor	a, #0x80
00205$:
	jp	p, 00119$
	ld	a, #0x01
	jr	00120$
00119$:
	ld	a, #0xff
00120$:
	ld	-14 (ix), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:56: signed char step_y = map_y < end_map_y ? 1 : -1;
	ld	a, -3 (ix)
	sub	a, -15 (ix)
	jp	po, 00206$
	xor	a, #0x80
00206$:
	jp	p, 00121$
	ld	-7 (ix), #0x01
	jr	00122$
00121$:
	ld	-7 (ix), #0xff
00122$:
	ld	a, -7 (ix)
	ld	-13 (ix), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:57: signed int error = delta_x + delta_y;
	ld	a, -2 (ix)
	ld	-12 (ix), a
	rlca
	sbc	a, a
	ld	-11 (ix), a
	ld	a, -1 (ix)
	ld	-10 (ix), a
	rlca
	sbc	a, a
	ld	-9 (ix), a
	ld	e, -12 (ix)
	ld	d, -11 (ix)
	ld	l, -10 (ix)
	ld	h, -9 (ix)
	add	hl, de
	ld	-2 (ix), l
	ld	-1 (ix), h
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:59: while (1)
00111$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:63: if (world_is_wall((unsigned char)map_x, (unsigned char)map_y))
	ld	l, -3 (ix)
	ld	a, -4 (ix)
	call	_world_is_wall
	ld	-7 (ix), a
	or	a, a
	jr	z, 00102$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:64: return 0;
	xor	a, a
	jp	00113$
00102$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:65: if (map_x == end_map_x && map_y == end_map_y)
	ld	a, -4 (ix)
	sub	a, -16 (ix)
	jr	nz, 00104$
	ld	a, -3 (ix)
	sub	a, -15 (ix)
	jr	nz, 00104$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:66: return 1;
	ld	a, #0x01
	jr	00113$
00104$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:68: doubled_error = error << 1;
	ld	a, -2 (ix)
	ld	-8 (ix), a
	ld	a, -1 (ix)
	ld	-7 (ix), a
	sla	-8 (ix)
	rl	-7 (ix)
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:69: if (doubled_error >= delta_y)
	ld	a, -8 (ix)
	sub	a, -10 (ix)
	ld	a, -7 (ix)
	sbc	a, -9 (ix)
	jp	po, 00212$
	xor	a, #0x80
00212$:
	jp	m, 00107$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:71: error += delta_y;
	ld	e, -10 (ix)
	ld	d, -9 (ix)
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	add	hl, de
	ld	-2 (ix), l
	ld	-1 (ix), h
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:72: map_x += step_x;
	ld	a, -4 (ix)
	add	a, -14 (ix)
	ld	-4 (ix), a
00107$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:74: if (doubled_error <= delta_x)
	ld	a, -12 (ix)
	sub	a, -8 (ix)
	ld	a, -11 (ix)
	sbc	a, -7 (ix)
	jp	po, 00213$
	xor	a, #0x80
00213$:
	jp	m, 00111$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:76: error += delta_x;
	ld	e, -12 (ix)
	ld	d, -11 (ix)
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	add	hl, de
	ld	-2 (ix), l
	ld	-1 (ix), h
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:77: map_y += step_y;
	ld	a, -3 (ix)
	add	a, -13 (ix)
	ld	-3 (ix), a
	jp	00111$
00113$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:80: }
	ld	sp, ix
	pop	ix
	pop	hl
	pop	bc
	pop	bc
	jp	(hl)
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:82: static unsigned char zombie_ai_position_is_clear(
;	---------------------------------
; Function zombie_ai_position_is_clear
; ---------------------------------
_zombie_ai_position_is_clear:
	push	ix
	ld	ix,	#0
	add	ix, sp
	push	af
	dec	sp
	ld	-2 (ix), a
	ld	c, e
	ld	b, d
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:92: if (!enemy_position_is_walkable(position_x, position_y,
	push	bc
	ld	a, #0x20
	push	af
	inc	sp
	ld	e, 4 (ix)
	ld	d, 5 (ix)
	ld	l, c
	ld	h, b
	call	_enemy_position_is_walkable
	ld	e, a
	pop	bc
	ld	a, e
	or	a, a
	jr	nz, 00102$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:94: return 0;
	xor	a, a
	jp	00117$
00102$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:96: if (zombie_ai_absolute(position_x - player_x)
	ld	a, c
	sub	a, 6 (ix)
	ld	l, a
	ld	a, b
	sbc	a, 7 (ix)
	push	bc
	ld	h, a
	call	_zombie_ai_absolute
	pop	bc
	ld	a, e
	sub	a, #0x40
	ld	a, d
	sbc	a, #0x00
	jr	nc, 00104$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:98: zombie_ai_absolute(position_y - player_y)
	ld	a, 4 (ix)
	sub	a, 8 (ix)
	ld	l, a
	ld	a, 5 (ix)
	sbc	a, 9 (ix)
	push	bc
	ld	h, a
	call	_zombie_ai_absolute
	pop	bc
	ld	a, e
	sub	a, #0x40
	ld	a, d
	sbc	a, #0x00
	jr	nc, 00104$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:100: return 0;
	xor	a, a
	jr	00117$
00104$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:102: sprite_count = world_sprite_get_count();
	push	bc
	call	_world_sprite_get_count
	ld	-3 (ix), a
	pop	bc
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:103: for (other_index = 0; other_index < sprite_count; ++other_index)
	ld	-1 (ix), #0x00
00116$:
	ld	a, -1 (ix)
	sub	a, -3 (ix)
	jr	nc, 00114$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:107: if (other_index == moving_index)
	ld	a, -2 (ix)
	sub	a, -1 (ix)
	jr	z, 00113$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:109: other = world_sprite_get(other_index);
	push	bc
	ld	a, -1 (ix)
	call	_world_sprite_get
	pop	bc
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:110: if (WORLD_SPRITE_LIFE_STATE(other) != ZOMBIE_STATE_ALIVE)
	ld	l, e
	ld	h, d
	push	bc
	ld	bc, #0x0006
	add	hl, bc
	pop	bc
	ld	a, (hl)
	and	a, #0x03
	jr	nz, 00113$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:112: if (zombie_ai_absolute(position_x - other->world_x)
	ld	l, e
	ld	h, d
	ld	a, (hl)
	inc	hl
	ld	h, (hl)
	ld	l, a
	ld	a, c
	sub	a, l
	ld	l, a
	ld	a, b
	sbc	a, h
	push	bc
	push	de
	ld	h, a
	call	_zombie_ai_absolute
	ex	de, hl
	pop	de
	pop	bc
	ld	a, l
	sub	a, #0x40
	ld	a, h
	sbc	a, #0x00
	jr	nc, 00113$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:114: zombie_ai_absolute(position_y - other->world_y)
	ex	de, hl
	inc	hl
	inc	hl
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	ld	l, 4 (ix)
	ld	h, 5 (ix)
	cp	a, a
	sbc	hl, de
	push	bc
	call	_zombie_ai_absolute
	pop	bc
	ld	a, e
	sub	a, #0x40
	ld	a, d
	sbc	a, #0x00
	jr	nc, 00113$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:116: return 0;
	xor	a, a
	jr	00117$
00113$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:103: for (other_index = 0; other_index < sprite_count; ++other_index)
	inc	-1 (ix)
	jr	00116$
00114$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:119: return 1;
	ld	a, #0x01
00117$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:120: }
	ld	sp, ix
	pop	ix
	pop	hl
	pop	bc
	pop	bc
	pop	bc
	jp	(hl)
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:122: static void zombie_ai_move(unsigned char sprite_index,
;	---------------------------------
; Function zombie_ai_move
; ---------------------------------
_zombie_ai_move:
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	hl, #-12
	add	hl, sp
	ld	sp, hl
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:129: signed int step_x = delta_x < 0
	bit	7, 12 (ix)
	jr	z, 00124$
	ld	bc, #0xffc8
	jr	00125$
00124$:
	ld	bc, #0x0038
00125$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:131: signed int step_y = delta_y < 0
	bit	7, 14 (ix)
	jr	z, 00126$
	ld	de, #0xffc8
	jr	00127$
00126$:
	ld	de, #0x0038
00127$:
	pop	hl
	push	de
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:133: signed int candidate_x = sprite->world_x;
	ld	a, 5 (ix)
	ld	-2 (ix), a
	ld	a, 6 (ix)
	ld	-1 (ix), a
	ld	e, -2 (ix)
	ld	d, -1 (ix)
	ld	a, (de)
	ld	-4 (ix), a
	inc	de
	ld	a, (de)
	ld	-3 (ix), a
	dec	de
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:134: signed int candidate_y = sprite->world_y;
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	inc	hl
	inc	hl
	ld	-10 (ix), l
	ld	-9 (ix), h
	ld	a, (hl)
	ld	-2 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-1 (ix), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:136: unsigned char sprite_mask = 1U << sprite_index;
	ld	a, 4 (ix)
	ld	-8 (ix), #0x01
	inc	a
	jr	00229$
00228$:
	sla	-8 (ix)
00229$:
	dec	a
	jr	nz, 00228$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:138: unsigned char move_x =
	push	bc
	push	de
	ld	l, 11 (ix)
	ld	h, 12 (ix)
	call	_zombie_ai_absolute
	ld	-6 (ix), e
	ld	-5 (ix), d
	ld	l, 13 (ix)
	ld	h, 14 (ix)
	call	_zombie_ai_absolute
	ex	de, hl
	pop	de
	pop	bc
	ld	a, -6 (ix)
	sub	a, l
	ld	a, -5 (ix)
	sbc	a, h
	ld	a, #0x00
	rla
	xor	a, #0x01
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:141: if (move_x)
	ld	-7 (ix), a
	or	a, a
	jr	z, 00102$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:142: candidate_x += step_x;
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	add	hl, bc
	ld	-4 (ix), l
	ld	-3 (ix), h
	jr	00103$
00102$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:144: candidate_y += step_y;
	ld	a, -2 (ix)
	add	a, -12 (ix)
	ld	-2 (ix), a
	ld	a, -1 (ix)
	adc	a, -11 (ix)
	ld	-1 (ix), a
00103$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:146: if (zombie_ai_position_is_clear(sprite_index, candidate_x, candidate_y,
	push	bc
	push	de
	ld	l, 9 (ix)
	ld	h, 10 (ix)
	push	hl
	ld	l, 7 (ix)
	ld	h, 8 (ix)
	push	hl
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	push	hl
	ld	e, -4 (ix)
	ld	d, -3 (ix)
	ld	a, 4 (ix)
	call	_zombie_ai_position_is_clear
	ld	l, a
	pop	de
	pop	bc
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:151: zombie_ai_wall_following_mask &= ~sprite_mask;
	ld	a, -8 (ix)
	cpl
	ld	-5 (ix), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:146: if (zombie_ai_position_is_clear(sprite_index, candidate_x, candidate_y,
	ld	a, l
	or	a, a
	jr	z, 00105$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:149: sprite->world_x = candidate_x;
	ld	a, -4 (ix)
	ld	(de), a
	inc	de
	ld	a, -3 (ix)
	ld	(de), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:150: sprite->world_y = candidate_y;
	pop	de
	pop	hl
	push	hl
	push	de
	ld	a, -2 (ix)
	ld	(hl), a
	inc	hl
	ld	a, -1 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:151: zombie_ai_wall_following_mask &= ~sprite_mask;
	ld	a, (_zombie_ai_wall_following_mask+0)
	and	a, -5 (ix)
	ld	(_zombie_ai_wall_following_mask+0), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:152: return;
	jp	00122$
00105$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:155: if (zombie_ai_wall_following_mask & sprite_mask)
	ld	a, (_zombie_ai_wall_following_mask+0)
	and	a, -8 (ix)
	jr	z, 00110$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:158: ? -ZOMBIE_MOVEMENT_STEP : ZOMBIE_MOVEMENT_STEP;
	ld	a, (_zombie_ai_wall_negative_mask+0)
	and	a, -8 (ix)
	jr	z, 00128$
	ld	bc, #0xffc8
	jr	00111$
00128$:
	ld	bc, #0x0038
	jr	00111$
00110$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:162: slide_step = move_x ? step_y : step_x;
	ld	a, -7 (ix)
	or	a, a
	jr	z, 00130$
	ld	a, -12 (ix)
	ld	-2 (ix), a
	ld	a, -11 (ix)
	ld	-1 (ix), a
	jr	00131$
00130$:
	ld	-2 (ix), c
	ld	-1 (ix), b
00131$:
	ld	c, -2 (ix)
	ld	b, -1 (ix)
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:163: zombie_ai_wall_following_mask |= sprite_mask;
	ld	a, (_zombie_ai_wall_following_mask+0)
	or	a, -8 (ix)
	ld	(_zombie_ai_wall_following_mask+0), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:164: if (slide_step < 0)
	bit	7, b
	jr	z, 00107$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:165: zombie_ai_wall_negative_mask |= sprite_mask;
	ld	a, (_zombie_ai_wall_negative_mask+0)
	or	a, -8 (ix)
	ld	(_zombie_ai_wall_negative_mask+0), a
	jr	00111$
00107$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:167: zombie_ai_wall_negative_mask &= ~sprite_mask;
	ld	a, (_zombie_ai_wall_negative_mask+0)
	and	a, -5 (ix)
	ld	(_zombie_ai_wall_negative_mask+0), a
00111$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:169: for (slide_attempt = 0; slide_attempt != 2; ++slide_attempt)
	ld	-6 (ix), #0x00
	ld	-5 (ix), #0x00
00120$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:171: candidate_x = sprite->world_x;
	ld	a, (de)
	ld	-4 (ix), a
	inc	de
	ld	a, (de)
	ld	-3 (ix), a
	dec	de
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:172: candidate_y = sprite->world_y;
	ld	l, -10 (ix)
	ld	h, -9 (ix)
	ld	a, (hl)
	ld	-2 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-1 (ix), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:173: if (move_x)
	ld	a, -7 (ix)
	or	a, a
	jr	z, 00113$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:174: candidate_y += slide_step;
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	add	hl, bc
	ld	-2 (ix), l
	ld	-1 (ix), h
	jr	00114$
00113$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:176: candidate_x += slide_step;
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	add	hl, bc
	ld	-4 (ix), l
	ld	-3 (ix), h
00114$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:178: sprite_index, candidate_x, candidate_y,
	push	bc
	push	de
	ld	l, 9 (ix)
	ld	h, 10 (ix)
	push	hl
	ld	l, 7 (ix)
	ld	h, 8 (ix)
	push	hl
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	push	hl
	ld	e, -4 (ix)
	ld	d, -3 (ix)
	ld	a, 4 (ix)
	call	_zombie_ai_position_is_clear
	pop	de
	pop	bc
	or	a, a
	jr	z, 00118$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:181: sprite->world_x = candidate_x;
	ld	a, -4 (ix)
	ld	(de), a
	inc	de
	ld	a, -3 (ix)
	ld	(de), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:182: sprite->world_y = candidate_y;
	pop	de
	pop	hl
	push	hl
	push	de
	ld	a, -2 (ix)
	ld	(hl), a
	inc	hl
	ld	a, -1 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:183: if (slide_attempt != 0)
	ld	a, -6 (ix)
	or	a, a
	jr	z, 00122$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:184: zombie_ai_wall_negative_mask ^= sprite_mask;
	ld	a, (_zombie_ai_wall_negative_mask+0)
	xor	a, -8 (ix)
	ld	(_zombie_ai_wall_negative_mask+0), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:185: return;
	jr	00122$
00118$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:187: slide_step = -slide_step;
	xor	a, a
	sub	a, c
	ld	c, a
	sbc	a, a
	sub	a, b
	ld	b, a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:169: for (slide_attempt = 0; slide_attempt != 2; ++slide_attempt)
	inc	-5 (ix)
	ld	a, -5 (ix)
	ld	-6 (ix), a
	sub	a, #0x02
	jp	nz, 00120$
00122$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:189: }
	ld	sp, ix
	pop	ix
	ret
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:191: void zombie_ai_update_all(void)
;	---------------------------------
; Function zombie_ai_update_all
; ---------------------------------
_zombie_ai_update_all::
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	hl, #-30
	add	hl, sp
	ld	sp, hl
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:198: sprite_count = world_sprite_get_count();
	call	_world_sprite_get_count
	ld	-30 (ix), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:199: player_x = player_get_position_x();
	call	_player_get_position_x
	ld	-29 (ix), e
	ld	-28 (ix), d
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:200: player_y = player_get_position_y();
	call	_player_get_position_y
	ld	-27 (ix), e
	ld	-26 (ix), d
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:202: if (player_is_dead())
	call	_player_is_dead
	ld	-1 (ix), a
	or	a, a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:203: return;
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:205: for (sprite_index = 0; sprite_index < sprite_count; ++sprite_index)
	jp	nz, 00144$
	ld	-2 (ix), #0x00
00143$:
	ld	a, -2 (ix)
	sub	a, -30 (ix)
	jp	nc, 00144$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:207: WorldSprite *sprite = world_sprite_get(sprite_index);
	ld	a, -2 (ix)
	call	_world_sprite_get
	ld	-25 (ix), e
	ld	-24 (ix), d
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:215: if (WORLD_SPRITE_LIFE_STATE(sprite) != ZOMBIE_STATE_ALIVE)
	ld	de, #0x0006
	ld	l, -25 (ix)
	ld	h, -24 (ix)
	add	hl, de
	ld	-23 (ix), l
	ld	-22 (ix), h
	ld	a, (hl)
	ld	-3 (ix), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:217: zombie_ai_wall_following_mask &= ~(1U << sprite_index);
	ld	b, -2 (ix)
	ld	-1 (ix), #0x01
	inc	b
	jr	00345$
00344$:
	sla	-1 (ix)
00345$:
	djnz	00344$
	ld	a, -1 (ix)
	cpl
	ld	-21 (ix), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:215: if (WORLD_SPRITE_LIFE_STATE(sprite) != ZOMBIE_STATE_ALIVE)
	ld	a, -3 (ix)
	and	a, #0x03
	jr	z, 00104$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:217: zombie_ai_wall_following_mask &= ~(1U << sprite_index);
	ld	a, (_zombie_ai_wall_following_mask+0)
	and	a, -21 (ix)
	ld	(_zombie_ai_wall_following_mask+0), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:218: continue;
	jp	00140$
00104$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:221: attack_cooldown = zombie_ai_get_attack_cooldown(sprite);
	ld	l, -25 (ix)
	ld	h, -24 (ix)
	call	_zombie_ai_get_attack_cooldown
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:222: if (attack_cooldown != 0)
	ld	-1 (ix), a
	or	a, a
	jr	z, 00106$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:224: --attack_cooldown;
	dec	-1 (ix)
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:225: zombie_ai_set_attack_cooldown(sprite, attack_cooldown);
	ld	a, -1 (ix)
	push	af
	inc	sp
	ld	l, -25 (ix)
	ld	h, -24 (ix)
	call	_zombie_ai_set_attack_cooldown
00106$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:228: delta_x = player_x - sprite->world_x;
	ld	a, -25 (ix)
	ld	-20 (ix), a
	ld	a, -24 (ix)
	ld	-19 (ix), a
	ld	l, -20 (ix)
	ld	h, -19 (ix)
	ld	a, (hl)
	ld	-18 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-17 (ix), a
	ld	a, -29 (ix)
	sub	a, -18 (ix)
	ld	-16 (ix), a
	ld	a, -28 (ix)
	sbc	a, -17 (ix)
	ld	-15 (ix), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:229: delta_y = player_y - sprite->world_y;
	ld	l, -25 (ix)
	ld	h, -24 (ix)
	inc	hl
	inc	hl
	ld	-14 (ix), l
	ld	-13 (ix), h
	ld	a, (hl)
	ld	-12 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-11 (ix), a
	ld	a, -27 (ix)
	sub	a, -12 (ix)
	ld	-10 (ix), a
	ld	a, -26 (ix)
	sbc	a, -11 (ix)
	ld	-9 (ix), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:230: distance = zombie_distance_metric(delta_x, delta_y);
	ld	e, -10 (ix)
	ld	d, -9 (ix)
	ld	l, -16 (ix)
	ld	h, -15 (ix)
	call	_zombie_distance_metric
	ld	-8 (ix), e
	ld	-7 (ix), d
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:231: chasing = sprite->health_and_hit_count & ZOMBIE_AI_CHASING_MASK;
	ld	l, -25 (ix)
	ld	h, -24 (ix)
	ld	de, #0x0007
	add	hl, de
	ld	c, (hl)
	ld	a, c
	and	a, #0x80
	ld	b, a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:238: if (sprite->state_timer == 0)
	ld	a, -25 (ix)
	add	a, #0x08
	ld	-6 (ix), a
	ld	a, -24 (ix)
	adc	a, #0x00
	ld	-5 (ix), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:239: sprite->pixels = zombie_01_standing_pixels;
	ld	a, -25 (ix)
	add	a, #0x04
	ld	-4 (ix), a
	ld	a, -24 (ix)
	adc	a, #0x00
	ld	-3 (ix), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:233: if ((!chasing && distance > ZOMBIE_ACTIVATION_DISTANCE)
	ld	a, b
	or	a, a
	jr	nz, 00113$
	ld	a, #0xc3
	cp	a, -8 (ix)
	ld	a, #0x03
	sbc	a, -7 (ix)
	jr	c, 00109$
00113$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:234: || (chasing && distance > ZOMBIE_LOSE_DISTANCE))
	ld	a, b
	or	a, a
	jr	z, 00110$
	ld	a, #0xec
	cp	a, -8 (ix)
	ld	a, #0x04
	sbc	a, -7 (ix)
	jr	nc, 00110$
00109$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:236: sprite->health_and_hit_count &= ~ZOMBIE_AI_CHASING_MASK;
	res	7, c
	ld	(hl), c
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:237: zombie_ai_wall_following_mask &= ~(1U << sprite_index);
	ld	a, (_zombie_ai_wall_following_mask+0)
	and	a, -21 (ix)
	ld	(_zombie_ai_wall_following_mask+0), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:238: if (sprite->state_timer == 0)
	ld	l, -6 (ix)
	ld	h, -5 (ix)
	ld	a, (hl)
	or	a, a
	jp	nz, 00140$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:239: sprite->pixels = zombie_01_standing_pixels;
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	ld	(hl), #<(_zombie_01_standing_pixels)
	inc	hl
	ld	(hl), #>(_zombie_01_standing_pixels)
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:240: continue;
	jp	00140$
00110$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:243: if (!chasing
	ld	a, b
	or	a, a
	jr	nz, 00117$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:245: sprite->world_x, sprite->world_y, player_x, player_y))
	push	hl
	ld	e, -27 (ix)
	ld	d, -26 (ix)
	push	de
	ld	e, -29 (ix)
	ld	d, -28 (ix)
	push	de
	ld	e, -12 (ix)
	ld	d, -11 (ix)
	ld	l, -18 (ix)
	ld	h, -17 (ix)
	call	_world_has_clear_line_of_sight
	pop	hl
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:231: chasing = sprite->health_and_hit_count & ZOMBIE_AI_CHASING_MASK;
	ld	c, (hl)
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:245: sprite->world_x, sprite->world_y, player_x, player_y))
	or	a, a
	jr	nz, 00117$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:247: sprite->health_and_hit_count &= ~ZOMBIE_AI_CHASING_MASK;
	res	7, c
	ld	(hl), c
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:248: zombie_ai_wall_following_mask &= ~(1U << sprite_index);
	ld	a, (_zombie_ai_wall_following_mask+0)
	and	a, -21 (ix)
	ld	(_zombie_ai_wall_following_mask+0), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:249: if (sprite->state_timer == 0)
	ld	l, -6 (ix)
	ld	h, -5 (ix)
	ld	a, (hl)
	or	a, a
	jp	nz, 00140$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:250: sprite->pixels = zombie_01_standing_pixels;
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	ld	(hl), #<(_zombie_01_standing_pixels)
	inc	hl
	ld	(hl), #>(_zombie_01_standing_pixels)
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:251: continue;
	jp	00140$
00117$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:254: sprite->health_and_hit_count |= ZOMBIE_AI_CHASING_MASK;
	set	7, c
	ld	(hl), c
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:256: if (distance <= ZOMBIE_ATTACK_DISTANCE)
	ld	a, #0x18
	cp	a, -8 (ix)
	ld	a, #0x01
	sbc	a, -7 (ix)
	jr	c, 00126$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:258: if (sprite->state_timer == 0)
	ld	l, -6 (ix)
	ld	h, -5 (ix)
	ld	a, (hl)
	or	a, a
	jr	nz, 00122$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:260: if (attack_cooldown == 0)
	ld	a, -1 (ix)
	or	a, a
	jr	nz, 00122$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:262: player_apply_damage(ZOMBIE_ATTACK_DAMAGE);
	ld	a, #0x14
	call	_player_apply_damage
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:263: game_gear_health_hud_update(player_get_health());
	call	_player_get_health
	call	_game_gear_health_hud_update
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:264: game_gear_damage_shake_phase = 4;
	ld	hl, #_game_gear_damage_shake_phase
	ld	(hl), #0x04
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:265: sprite->state_timer =
	ld	l, -6 (ix)
	ld	h, -5 (ix)
	ld	(hl), #0x04
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:268: sprite, ZOMBIE_ATTACK_COOLDOWN_AI_TICKS);
	ld	a, #0x02
	push	af
	inc	sp
	ld	l, -25 (ix)
	ld	h, -24 (ix)
	call	_zombie_ai_set_attack_cooldown
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:269: sprite->state ^= ZOMBIE_ATTACK_PHASE_MASK;
	ld	l, -23 (ix)
	ld	h, -22 (ix)
	ld	a, (hl)
	xor	a, #0x40
	ld	l, -23 (ix)
	ld	h, -22 (ix)
	ld	(hl), a
00122$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:272: if (player_is_dead())
	call	_player_is_dead
	or	a, a
	jp	z, 00140$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:273: return;
	jp	00144$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:274: continue;
00126$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:277: sprite->state ^= ZOMBIE_WALKING_PHASE_MASK;
	ld	l, -23 (ix)
	ld	h, -22 (ix)
	ld	a, (hl)
	xor	a, #0x80
	ld	l, -23 (ix)
	ld	h, -22 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:279: if (sprite->state_timer != 0)
	ld	l, -6 (ix)
	ld	h, -5 (ix)
	ld	a, (hl)
	or	a, a
	jr	z, 00131$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:281: if (sprite->pixels == zombie_01_shot_01_pixels
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	ld	hl, #_zombie_01_shot_01_pixels
	xor	a, a
	sbc	hl, bc
	jp	z, 00140$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:282: || sprite->pixels == zombie_01_shot_02_pixels)
	ld	hl, #_zombie_01_shot_02_pixels
	xor	a, a
	sbc	hl, bc
	jp	z, 00140$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:284: sprite->state_timer = 0;
	ld	l, -6 (ix)
	ld	h, -5 (ix)
	ld	(hl), #0x00
00131$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:287: sprite->pixels = sprite->state & ZOMBIE_WALKING_PHASE_MASK
	ld	l, -23 (ix)
	ld	h, -22 (ix)
	ld	a, (hl)
	rlca
	jr	nc, 00146$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:288: ? zombie_01_walking_02_pixels
	ld	bc, #_zombie_01_walking_02_pixels
	jr	00147$
00146$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:289: : zombie_01_walking_01_pixels;
	ld	bc, #_zombie_01_walking_01_pixels
00147$:
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	ld	(hl), c
	inc	hl
	ld	(hl), b
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:291: if (distance >= ZOMBIE_ATTACK_DISTANCE + ZOMBIE_MOVEMENT_STEP)
	ld	a, -8 (ix)
	sub	a, #0x50
	ld	a, -7 (ix)
	sbc	a, #0x01
	jr	c, 00138$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:292: zombie_ai_move(sprite_index, sprite, player_x, player_y,
	ld	l, -10 (ix)
	ld	h, -9 (ix)
	push	hl
	ld	l, -16 (ix)
	ld	h, -15 (ix)
	push	hl
	ld	l, -27 (ix)
	ld	h, -26 (ix)
	push	hl
	ld	l, -29 (ix)
	ld	h, -28 (ix)
	push	hl
	ld	l, -25 (ix)
	ld	h, -24 (ix)
	push	hl
	ld	a, -2 (ix)
	push	af
	inc	sp
	call	_zombie_ai_move
	ld	hl, #11
	add	hl, sp
	ld	sp, hl
	jp	00140$
00138$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:296: signed int candidate_x = sprite->world_x;
	ld	l, -20 (ix)
	ld	h, -19 (ix)
	ld	a, (hl)
	ld	-6 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-5 (ix), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:297: signed int candidate_y = sprite->world_y;
	ld	l, -14 (ix)
	ld	h, -13 (ix)
	ld	a, (hl)
	ld	-4 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-3 (ix), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:298: signed int final_step =
	ld	a, -8 (ix)
	add	a, #0xe8
	ld	c, a
	ld	a, -7 (ix)
	adc	a, #0xfe
	ld	-12 (ix), c
	ld	-11 (ix), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:301: if (zombie_ai_absolute(delta_x) >= zombie_ai_absolute(delta_y))
	ld	l, -16 (ix)
	ld	h, -15 (ix)
	call	_zombie_ai_absolute
	push	de
	ld	l, -10 (ix)
	ld	h, -9 (ix)
	call	_zombie_ai_absolute
	pop	hl
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:302: candidate_x += delta_x < 0 ? -final_step : final_step;
	xor	a, a
	sub	a, -12 (ix)
	ld	-8 (ix), a
	sbc	a, a
	ld	-7 (ix), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:301: if (zombie_ai_absolute(delta_x) >= zombie_ai_absolute(delta_y))
	xor	a, a
	sbc	hl, de
	jr	c, 00133$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:302: candidate_x += delta_x < 0 ? -final_step : final_step;
	bit	7, -15 (ix)
	jr	nz, 00149$
	ld	a, -12 (ix)
	ld	-8 (ix), a
	ld	-7 (ix), #0x00
00149$:
	ld	e, -6 (ix)
	ld	d, -5 (ix)
	ld	l, -8 (ix)
	ld	h, -7 (ix)
	add	hl, de
	ld	-6 (ix), l
	ld	-5 (ix), h
	jr	00134$
00133$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:304: candidate_y += delta_y < 0 ? -final_step : final_step;
	bit	7, -9 (ix)
	jr	nz, 00151$
	ld	a, -12 (ix)
	ld	-8 (ix), a
	ld	-7 (ix), #0x00
00151$:
	ld	e, -4 (ix)
	ld	d, -3 (ix)
	ld	l, -8 (ix)
	ld	h, -7 (ix)
	add	hl, de
	ld	-4 (ix), l
	ld	-3 (ix), h
00134$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:307: sprite_index, candidate_x, candidate_y,
	ld	l, -27 (ix)
	ld	h, -26 (ix)
	push	hl
	ld	l, -29 (ix)
	ld	h, -28 (ix)
	push	hl
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	push	hl
	ld	e, -6 (ix)
	ld	d, -5 (ix)
	ld	a, -2 (ix)
	call	_zombie_ai_position_is_clear
	or	a, a
	jr	z, 00140$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:310: sprite->world_x = candidate_x;
	ld	l, -20 (ix)
	ld	h, -19 (ix)
	ld	a, -6 (ix)
	ld	(hl), a
	inc	hl
	ld	a, -5 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:311: sprite->world_y = candidate_y;
	ld	l, -14 (ix)
	ld	h, -13 (ix)
	ld	a, -4 (ix)
	ld	(hl), a
	inc	hl
	ld	a, -3 (ix)
	ld	(hl), a
00140$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:205: for (sprite_index = 0; sprite_index < sprite_count; ++sprite_index)
	inc	-2 (ix)
	jp	00143$
00144$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/zombie_ai.c:315: }
	ld	sp, ix
	pop	ix
	ret
	.area _BANK1
	.area _INITIALIZER
	.area _CABS (ABS)
