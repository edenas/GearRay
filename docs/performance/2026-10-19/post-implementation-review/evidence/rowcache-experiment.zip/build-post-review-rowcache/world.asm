;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (MINGW64)
;--------------------------------------------------------
	.module world
	
	.optsdcc -mz80 sdcccall(1)
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _red_door_switch_get_texture
	.globl _workshop_map_get_spawn_y
	.globl _workshop_map_get_spawn_x
	.globl _workshop_map_get_tile
	.globl _door_state_get
	.globl _door_instance_find_at
	.globl _world_get_tile
	.globl _world_get_spawn_x
	.globl _world_get_spawn_y
	.globl _world_get_texture
	.globl _world_get_object
	.globl _world_is_wall
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute ram data
;--------------------------------------------------------
	.area _DABS (ABS)
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world.c:6: unsigned char world_get_tile(unsigned char x, unsigned char y)
;	---------------------------------
; Function world_get_tile
; ---------------------------------
_world_get_tile::
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world.c:8: if (x >= WORLD_WIDTH || y >= WORLD_HEIGHT)
	ld	c, a
	sub	a, #0x0d
	jr	nc, 00101$
	ld	a, l
	sub	a, #0x0d
	jr	c, 00102$
00101$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world.c:9: return WORLD_TILE_VOID;
	ld	a, #0x08
	ret
00102$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world.c:12: unsigned char tile_id = workshop_map_get_tile(x, y);
	ld	a, c
	call	_workshop_map_get_tile
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world.c:14: || tile_id == WORLD_TILE_SHOTGUN_MARKER)
	cp	a, #0x09
	jr	z, 00109$
	cp	a, #0x0a
	ret	nz
00109$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world.c:15: ? WORLD_TILE_EMPTY
	xor	a, a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world.c:16: : tile_id;
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world.c:18: }
	ret
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world.c:20: unsigned char world_get_spawn_x(void)
;	---------------------------------
; Function world_get_spawn_x
; ---------------------------------
_world_get_spawn_x::
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world.c:22: return workshop_map_get_spawn_x();
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world.c:23: }
	jp	_workshop_map_get_spawn_x
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world.c:25: unsigned char world_get_spawn_y(void)
;	---------------------------------
; Function world_get_spawn_y
; ---------------------------------
_world_get_spawn_y::
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world.c:27: return workshop_map_get_spawn_y();
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world.c:28: }
	jp	_workshop_map_get_spawn_y
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world.c:30: unsigned char world_get_texture(unsigned char tile_id)
;	---------------------------------
; Function world_get_texture
; ---------------------------------
_world_get_texture::
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world.c:32: if (tile_id > WORLD_TILE_RED_DOOR_SWITCH)
	cp	a, #0x08
	jr	c, 00102$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world.c:33: return WORLD_TILE_STONE;
	ld	a, #0x01
	ret
00102$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world.c:35: if (tile_id == WORLD_TILE_RED_DOOR_SWITCH)
	cp	a, #0x07
	jp	z, _red_door_switch_get_texture
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world.c:36: return red_door_switch_get_texture();
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world.c:38: return tile_id;
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world.c:39: }
	ret
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world.c:41: unsigned char world_get_object(unsigned char tile_id)
;	---------------------------------
; Function world_get_object
; ---------------------------------
_world_get_object::
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world.c:43: if (tile_id == WORLD_TILE_DOOR ||
	cp	a, #0x05
	jr	z, 00101$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world.c:44: tile_id == WORLD_TILE_RED_DOOR)
	cp	a, #0x06
	jr	nz, 00102$
00101$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world.c:45: return WORLD_OBJECT_DOOR;
	ld	a, #0x01
	ret
00102$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world.c:47: if (tile_id == WORLD_TILE_RED_DOOR_SWITCH)
	cp	a, #0x07
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world.c:48: return WORLD_OBJECT_RED_DOOR_SWITCH;
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world.c:50: return WORLD_OBJECT_NONE;
	ld	a, #0x02
	ret	z
	xor	a, a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world.c:51: }
	ret
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world.c:53: unsigned char world_is_wall(unsigned char x, unsigned char y)
;	---------------------------------
; Function world_is_wall
; ---------------------------------
_world_is_wall::
	ld	h, a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world.c:58: tile_id = world_get_tile(x, y);
	push	hl
	ld	a, h
	call	_world_get_tile
	pop	hl
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world.c:60: if (tile_id == WORLD_TILE_EMPTY)
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world.c:61: return 0;
	or	a,a
	ret	z
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world.c:64: if (tile_id != WORLD_TILE_DOOR &&
	cp	a, #0x05
	jr	z, 00104$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world.c:65: tile_id != WORLD_TILE_RED_DOOR)
	cp	a, #0x06
	jr	z, 00104$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world.c:66: return 1;
	ld	a, #0x01
	ret
00104$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world.c:68: door_instance = door_instance_find_at(x, y);
	ld	a, h
	call	_door_instance_find_at
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world.c:70: if (door_instance >= DOOR_INSTANCE_COUNT)
	cp	a, #0x03
	jr	c, 00107$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world.c:71: return 1;
	ld	a, #0x01
	ret
00107$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world.c:73: return door_state_get(door_instance) == DOOR_STATE_CLOSED;
	call	_door_state_get
	or	a, a
	ld	a, #0x01
	ret	z
	xor	a, a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/game/world.c:74: }
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
