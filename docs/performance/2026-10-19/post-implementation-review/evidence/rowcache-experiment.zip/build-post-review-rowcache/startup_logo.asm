;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (MINGW64)
;--------------------------------------------------------
	.module startup_logo
	
	.optsdcc -mz80 sdcccall(1)
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _SMS_VRAMmemsetW
	.globl _SMS_VRAMmemcpy
	.globl _GG_loadBGPalette
	.globl _SMS_loadTileMapAreaatAddr
	.globl _SMS_waitForVBlank
	.globl _SMS_setBGScrollY
	.globl _SMS_setBGScrollX
	.globl _SMS_VDPturnOffFeature
	.globl _SMS_VDPturnOnFeature
	.globl _SMS_SRAM
	.globl _SRAM_bank_to_be_mapped_on_slot2
	.globl _ROM_bank_to_be_mapped_on_slot0
	.globl _ROM_bank_to_be_mapped_on_slot1
	.globl _ROM_bank_to_be_mapped_on_slot2
	.globl b_game_gear_startup_logo_show
	.globl _game_gear_startup_logo_show
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
_SMS_VDPControlPort	=	0x00bf
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
_ROM_bank_to_be_mapped_on_slot2	=	0xffff
_ROM_bank_to_be_mapped_on_slot1	=	0xfffe
_ROM_bank_to_be_mapped_on_slot0	=	0xfffd
_SRAM_bank_to_be_mapped_on_slot2	=	0xfffc
_SMS_SRAM	=	0x8000
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute ram data
;--------------------------------------------------------
	.area _DABS (ABS)
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _BANK3
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/startup_logo.c:9: void game_gear_startup_logo_show(void) __banked
;	---------------------------------
; Function game_gear_startup_logo_show
; ---------------------------------
	b_game_gear_startup_logo_show	= 3
_game_gear_startup_logo_show::
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/startup_logo.c:13: game_gear_damage_shake_phase = 0;
	xor	a, a
	ld	(#_game_gear_damage_shake_phase), a
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/startup_logo.c:14: SMS_setBGScrollX(0);
	ld	l, #0x00
	call	_SMS_setBGScrollX
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/startup_logo.c:15: SMS_setBGScrollY(0);
	ld	l, #0x00
	call	_SMS_setBGScrollY
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/startup_logo.c:16: SMS_displayOff();
	ld	hl, #0x0140
	call	_SMS_VDPturnOffFeature
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/startup_logo.c:17: SMS_VRAMmemsetW(0, 0x0000, 16384);
	ld	hl, #0x4000
	push	hl
	ld	de, #0x0000
	ld	h, l
	call	_SMS_VRAMmemsetW
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/startup_logo.c:18: GG_loadBGPalette(sega_logo_palette);
	ld	hl, #_sega_logo_palette
	call	_GG_loadBGPalette
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/startup_logo.c:19: SMS_loadTiles(sega_logo_tiles,
	ld	hl, #0x0600
	push	hl
	ld	de, #_sega_logo_tiles
	ld	hl, #0x0020
	call	_SMS_VRAMmemcpy
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/startup_logo.c:22: SMS_loadTileMapArea(SEGA_LOGO_TILE_ORIGIN_X,
	ld	hl, #0x40c
	push	hl
	ld	de, #_sega_logo_tilemap
	ld	hl, #0x7a94
	call	_SMS_loadTileMapAreaatAddr
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/startup_logo.c:27: SMS_waitForVBlank();
	call	_SMS_waitForVBlank
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/startup_logo.c:28: SMS_displayOn();
	ld	hl, #0x0140
	call	_SMS_VDPturnOnFeature
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/startup_logo.c:30: for (frame = STARTUP_LOGO_FRAME_COUNT; frame != 0; --frame)
	ld	b, #0xb4
00102$:
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/startup_logo.c:31: SMS_waitForVBlank();
	push	bc
	call	_SMS_waitForVBlank
	pop	bc
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/startup_logo.c:30: for (frame = STARTUP_LOGO_FRAME_COUNT; frame != 0; --frame)
	djnz	00102$
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/startup_logo.c:33: SMS_displayOff();
	ld	hl, #0x0140
	call	_SMS_VDPturnOffFeature
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/startup_logo.c:34: SMS_waitForVBlank();
	call	_SMS_waitForVBlank
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/startup_logo.c:35: SMS_VRAMmemsetW(0, 0x0000, 16384);
	ld	hl, #0x4000
	push	hl
	ld	de, #0x0000
	ld	h, l
	call	_SMS_VRAMmemsetW
;D:/mano_projektai/GearRay/build-post-review-rowcache-source/platform/game_gear/startup_logo.c:36: }
	ret
	.area _BANK3
	.area _BANK3
	.area _BANK3
	.area _BANK3
	.area _INITIALIZER
	.area _CABS (ABS)
