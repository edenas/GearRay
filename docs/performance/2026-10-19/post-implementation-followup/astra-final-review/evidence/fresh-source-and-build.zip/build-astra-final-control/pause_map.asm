;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (MINGW64)
;--------------------------------------------------------
	.module pause_map
	
	.optsdcc -mz80 sdcccall(1)
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _world_sprite_get
	.globl _world_sprite_get_count
	.globl _camera_get_direction_y
	.globl _camera_get_direction_x
	.globl _world_get_tile
	.globl _door_state_get
	.globl _door_instance_find_at
	.globl _player_get_position_y
	.globl _player_get_position_x
	.globl _input_pause_requested
	.globl _game_gear_input_update
	.globl _SMS_VRAMmemsetW
	.globl _SMS_VRAMmemcpy
	.globl _SMS_load1bppTiles
	.globl _SMS_crt0_RST18
	.globl _SMS_crt0_RST08
	.globl _SMS_waitForVBlank
	.globl _SMS_setBGScrollY
	.globl _SMS_setBGScrollX
	.globl _SMS_VDPturnOffFeature
	.globl _SMS_VDPturnOnFeature
	.globl _SMS_SRAM
	.globl _SRAM_bank_to_be_mapped_on_slot2
	.globl _ROM_bank_to_be_mapped_on_slot0
	.globl _ROM_bank_to_be_mapped_on_slot1
	.globl _ROM_bank_to_be_mapped_on_slot2
	.globl _game_gear_pause_map_show
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
_SMS_VDPControlPort	=	0x00bf
_pause_data_port	=	0x00be
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
_ROM_bank_to_be_mapped_on_slot2	=	0xffff
_ROM_bank_to_be_mapped_on_slot1	=	0xfffe
_ROM_bank_to_be_mapped_on_slot0	=	0xfffd
_SRAM_bank_to_be_mapped_on_slot2	=	0xfffc
_SMS_SRAM	=	0x8000
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute ram data
;--------------------------------------------------------
	.area _DABS (ABS)
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _BANK2
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:115: static unsigned char window_origin(unsigned char player_cell,
;	---------------------------------
; Function window_origin
; ---------------------------------
_window_origin:
	push	ix
	ld	ix,	#0
	add	ix, sp
	dec	sp
	ld	-1 (ix), a
	ld	c, l
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:120: if (extent <= capacity || player_cell < (capacity >> 1)) return 0;
	ld	a, 4 (ix)
	sub	a, c
	jr	nc, 00101$
	ld	b, 4 (ix)
	srl	b
	ld	a, -1 (ix)
	sub	a, b
	jr	nc, 00102$
00101$:
	xor	a, a
	jr	00106$
00102$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:121: origin = player_cell - (capacity >> 1);
	ld	a, -1 (ix)
	sub	a, b
	ld	b, a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:122: if (origin > extent - capacity) origin = extent - capacity;
	ld	l, c
	ld	h, #0x00
	ld	e, 4 (ix)
	ld	d, #0x00
	cp	a, a
	sbc	hl, de
	ld	e, b
	ld	d, #0x00
	ld	a, l
	sub	a, e
	ld	a, h
	sbc	a, d
	jp	po, 00124$
	xor	a, #0x80
00124$:
	jp	p, 00105$
	ld	a, c
	sub	a, 4 (ix)
	ld	b, a
00105$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:123: return origin;
	ld	a, b
00106$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:124: }
	inc	sp
	pop	ix
	pop	hl
	inc	sp
	jp	(hl)
	.area _BANK2
	.area _BANK2
_pause_empty_rows:
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x04	; 4
	.db #0x04	; 4
	.db #0x04	; 4
	.db #0x04	; 4
	.db #0x04	; 4
	.db #0x04	; 4
	.db #0x04	; 4
	.db #0x04	; 4
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xfc	; 252
	.db #0x04	; 4
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x04	; 4
	.db #0xfc	; 252
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x20	; 32
	.db #0x20	; 32
	.db #0x20	; 32
	.db #0x20	; 32
	.db #0x20	; 32
	.db #0x20	; 32
	.db #0x20	; 32
	.db #0x20	; 32
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x3f	; 63
	.db #0x20	; 32
	.db #0x20	; 32
	.db #0x3f	; 63
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.area _BANK2
	.area _BANK2
_pause_pistol_tiles_rows:
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x3f	; 63
	.db #0x3f	; 63
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x20	; 32
	.db #0x20	; 32
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xfc	; 252
	.db #0xfc	; 252
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x04	; 4
	.db #0x04	; 4
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x21	; 33
	.db #0x21	; 33
	.db #0xfe	; 254
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x81	; 129
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x7b	; 123
	.db #0x02	; 2
	.db #0xf9	; 249
	.db #0xf9	; 249
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x84	; 132
	.db #0x84	; 132
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x69	; 105	'i'
	.db #0x69	; 105	'i'
	.db #0x01	; 1
	.db #0x0c	; 12
	.db #0x11	; 17
	.db #0x11	; 17
	.db #0x02	; 2
	.db #0x04	; 4
	.db #0x0a	; 10
	.db #0x0a	; 10
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x07	; 7
	.db #0x07	; 7
	.db #0x00	; 0
	.db #0x3f	; 63
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x20	; 32
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xfc	; 252
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x04	; 4
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x20	; 32
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x04	; 4
	.db #0x80	; 128
	.db #0x80	; 128
	.area _BANK2
	.area _BANK2
_pause_pistol_tiles:
	.db #0x80	; 128
	.db #0x05	; 5
	.db #0x01	; 1
	.db #0x02	; 2
	.db #0x80	; 128
	.db #0x05	; 5
	.db #0x03	; 3
	.db #0x80	; 128
	.db #0x06	; 6
	.db #0x04	; 4
	.db #0x05	; 5
	.db #0x82	; 130
	.db #0x04	; 4
	.db #0x86	; 134
	.db #0x01	; 1
	.db #0x02	; 2
	.db #0x80	; 128
	.db #0x03	; 3
	.db #0x03	; 3
	.db #0x07	; 7
	.db #0x08	; 8
	.db #0x09	; 9
	.db #0x85	; 133
	.db #0x04	; 4
	.db #0x8a	; 138
	.db #0x02	; 2
	.db #0x82	; 130
	.db #0x07	; 7
	.db #0x0b	; 11
	.db #0x0c	; 12
	.db #0x8d	; 141
	.db #0x01	; 1
	.db #0x0e	; 14
	.db #0x80	; 128
	.db #0x02	; 2
	.db #0x05	; 5
	.db #0x8a	; 138
	.db #0x02	; 2
	.db #0x85	; 133
	.db #0x03	; 3
	.db #0x02	; 2
	.db #0x01	; 1
	.db #0x80	; 128
	.db #0x06	; 6
	.db #0x03	; 3
	.db #0x80	; 128
	.db #0x05	; 5
	.db #0x05	; 5
	.db #0x04	; 4
	.db #0x80	; 128
	.db #0x05	; 5
	.area _BANK2
	.area _BANK2
_pause_pistol_tiles_side:
	.db #0x80	; 128
	.db #0x05	; 5
	.db #0x0f	; 15
	.db #0x10	; 16
	.db #0x80	; 128
	.db #0x05	; 5
	.db #0x11	; 17
	.db #0x80	; 128
	.db #0x06	; 6
	.db #0x12	; 18
	.db #0x13	; 19
	.db #0x90	; 144
	.db #0x04	; 4
	.db #0x94	; 148
	.db #0x01	; 1
	.db #0x10	; 16
	.db #0x80	; 128
	.db #0x03	; 3
	.db #0x03	; 3
	.db #0x07	; 7
	.db #0x08	; 8
	.db #0x09	; 9
	.db #0x93	; 147
	.db #0x04	; 4
	.db #0x95	; 149
	.db #0x02	; 2
	.db #0x90	; 144
	.db #0x07	; 7
	.db #0x0b	; 11
	.db #0x0c	; 12
	.db #0x8d	; 141
	.db #0x01	; 1
	.db #0x0e	; 14
	.db #0x80	; 128
	.db #0x02	; 2
	.db #0x13	; 19
	.db #0x95	; 149
	.db #0x02	; 2
	.db #0x93	; 147
	.db #0x03	; 3
	.db #0x10	; 16
	.db #0x0f	; 15
	.db #0x80	; 128
	.db #0x06	; 6
	.db #0x11	; 17
	.db #0x80	; 128
	.db #0x05	; 5
	.db #0x13	; 19
	.db #0x12	; 18
	.db #0x80	; 128
	.db #0x05	; 5
	.area _BANK2
	.area _BANK2
_pause_shotgun_tiles_rows:
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x3f	; 63
	.db #0x3f	; 63
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x20	; 32
	.db #0x20	; 32
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xfc	; 252
	.db #0xfc	; 252
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x04	; 4
	.db #0x04	; 4
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x22	; 34
	.db #0x22	; 34
	.db #0x02	; 2
	.db #0x02	; 2
	.db #0x25	; 37
	.db #0x25	; 37
	.db #0x07	; 7
	.db #0x07	; 7
	.db #0x28	; 40
	.db #0x28	; 40
	.db #0x04	; 4
	.db #0x07	; 7
	.db #0x28	; 40
	.db #0x28	; 40
	.db #0x02	; 2
	.db #0x00	; 0
	.db #0x26	; 38
	.db #0x26	; 38
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xfe	; 254
	.db #0xfe	; 254
	.db #0xfe	; 254
	.db #0xfe	; 254
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x35	; 53	'5'
	.db #0xc9	; 201
	.db #0x34	; 52	'4'
	.db #0x34	; 52	'4'
	.db #0x0d	; 13
	.db #0x00	; 0
	.db #0x0d	; 13
	.db #0x0d	; 13
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xe4	; 228
	.db #0xe4	; 228
	.db #0x80	; 128
	.db #0x60	; 96
	.db #0x94	; 148
	.db #0x94	; 148
	.db #0x00	; 0
	.db #0xe0	; 224
	.db #0x14	; 20
	.db #0x14	; 20
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x21	; 33
	.db #0x21	; 33
	.db #0x09	; 9
	.db #0x08	; 8
	.db #0x11	; 17
	.db #0x11	; 17
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xe9	; 233
	.db #0xe9	; 233
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x06	; 6
	.db #0x06	; 6
	.db #0x80	; 128
	.db #0x00	; 0
	.db #0xa4	; 164
	.db #0xa4	; 164
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xc4	; 196
	.db #0xc4	; 196
	.db #0x00	; 0
	.db #0x3f	; 63
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x20	; 32
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xfc	; 252
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x04	; 4
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x20	; 32
	.db #0x02	; 2
	.db #0x02	; 2
	.db #0x02	; 2
	.db #0x22	; 34
	.db #0x05	; 5
	.db #0x05	; 5
	.db #0x07	; 7
	.db #0x27	; 39
	.db #0x08	; 8
	.db #0x08	; 8
	.db #0x04	; 4
	.db #0x27	; 39
	.db #0x08	; 8
	.db #0x08	; 8
	.db #0x02	; 2
	.db #0x20	; 32
	.db #0x06	; 6
	.db #0x06	; 6
	.db #0x00	; 0
	.db #0x04	; 4
	.db #0xe0	; 224
	.db #0xe0	; 224
	.db #0x80	; 128
	.db #0x64	; 100	'd'
	.db #0x90	; 144
	.db #0x90	; 144
	.db #0x00	; 0
	.db #0xe4	; 228
	.db #0x10	; 16
	.db #0x10	; 16
	.db #0x00	; 0
	.db #0x20	; 32
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x80	; 128
	.db #0x04	; 4
	.db #0xa0	; 160
	.db #0xa0	; 160
	.db #0x00	; 0
	.db #0x04	; 4
	.db #0xc0	; 192
	.db #0xc0	; 192
	.area _BANK2
	.area _BANK2
_pause_shotgun_tiles:
	.db #0x80	; 128
	.db #0x05	; 5
	.db #0x01	; 1
	.db #0x02	; 2
	.db #0x80	; 128
	.db #0x05	; 5
	.db #0x03	; 3
	.db #0x80	; 128
	.db #0x06	; 6
	.db #0x04	; 4
	.db #0x05	; 5
	.db #0x82	; 130
	.db #0x02	; 2
	.db #0x06	; 6
	.db #0x07	; 7
	.db #0x08	; 8
	.db #0x09	; 9
	.db #0x0a	; 10
	.db #0x80	; 128
	.db #0x03	; 3
	.db #0x0b	; 11
	.db #0x0c	; 12
	.db #0x0d	; 13
	.db #0x0e	; 14
	.db #0x85	; 133
	.db #0x04	; 4
	.db #0x0f	; 15
	.db #0x10	; 16
	.db #0x11	; 17
	.db #0x06	; 6
	.db #0x12	; 18
	.db #0x82	; 130
	.db #0x05	; 5
	.db #0x13	; 19
	.db #0x14	; 20
	.db #0x15	; 21
	.db #0x80	; 128
	.db #0x04	; 4
	.db #0x16	; 22
	.db #0x17	; 23
	.db #0x85	; 133
	.db #0x05	; 5
	.db #0x02	; 2
	.db #0x01	; 1
	.db #0x80	; 128
	.db #0x06	; 6
	.db #0x03	; 3
	.db #0x80	; 128
	.db #0x05	; 5
	.db #0x05	; 5
	.db #0x04	; 4
	.db #0x80	; 128
	.db #0x05	; 5
	.area _BANK2
	.area _BANK2
_pause_shotgun_tiles_side:
	.db #0x80	; 128
	.db #0x05	; 5
	.db #0x18	; 24
	.db #0x19	; 25
	.db #0x80	; 128
	.db #0x05	; 5
	.db #0x1a	; 26
	.db #0x80	; 128
	.db #0x06	; 6
	.db #0x1b	; 27
	.db #0x1c	; 28
	.db #0x99	; 153
	.db #0x02	; 2
	.db #0x1d	; 29
	.db #0x1e	; 30
	.db #0x1f	; 31
	.db #0x20	; 32
	.db #0x21	; 33
	.db #0x80	; 128
	.db #0x03	; 3
	.db #0x0b	; 11
	.db #0x0c	; 12
	.db #0x0d	; 13
	.db #0x0e	; 14
	.db #0x9c	; 156
	.db #0x04	; 4
	.db #0x22	; 34
	.db #0x23	; 35
	.db #0x24	; 36
	.db #0x1d	; 29
	.db #0x25	; 37
	.db #0x99	; 153
	.db #0x05	; 5
	.db #0x13	; 19
	.db #0x14	; 20
	.db #0x15	; 21
	.db #0x80	; 128
	.db #0x04	; 4
	.db #0x26	; 38
	.db #0x27	; 39
	.db #0x9c	; 156
	.db #0x05	; 5
	.db #0x19	; 25
	.db #0x18	; 24
	.db #0x80	; 128
	.db #0x06	; 6
	.db #0x1a	; 26
	.db #0x80	; 128
	.db #0x05	; 5
	.db #0x1c	; 28
	.db #0x1b	; 27
	.db #0x80	; 128
	.db #0x05	; 5
	.area _BANK2
	.area _BANK2
_empty_patterns:
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x02	; 2
	.db #0x03	; 3
	.db #0x04	; 4
	.db #0x00	; 0
	.db #0x05	; 5
	.db #0x00	; 0
	.db #0x06	; 6
	.db #0x07	; 7
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x08	; 8
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.area _BANK2
	.area _BANK2
_computer_rows:
	.db #0x3c	; 60
	.db #0x3c	; 60
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x03	; 3
	.db #0x03	; 3
	.db #0x03	; 3
	.db #0x03	; 3
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x3c	; 60
	.db #0x3c	; 60
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xc0	; 192
	.db #0xc0	; 192
	.db #0xc0	; 192
	.db #0xc0	; 192
	.db #0x00	; 0
	.db #0x00	; 0
	.area _BANK2
	.area _BANK2
_player_rows:
	.db #0x40	; 64
	.db #0xa0	; 160
	.db #0xa0	; 160
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x60	; 96
	.db #0x60	; 96
	.db #0x80	; 128
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xc0	; 192
	.db #0x20	; 32
	.db #0xc0	; 192
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x80	; 128
	.db #0x60	; 96
	.db #0x60	; 96
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xa0	; 160
	.db #0xa0	; 160
	.db #0x40	; 64
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x20	; 32
	.db #0xc0	; 192
	.db #0xc0	; 192
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x60	; 96
	.db #0x80	; 128
	.db #0x60	; 96
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xc0	; 192
	.db #0xc0	; 192
	.db #0x20	; 32
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.area _BANK2
	.area _BANK2
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:126: static unsigned char map_tile(unsigned char x, unsigned char y)
;	---------------------------------
; Function map_tile
; ---------------------------------
_map_tile:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:129: if (x >= WORLD_WIDTH || y >= WORLD_HEIGHT) return WORLD_TILE_VOID;
	ld	c, a
	sub	a, #0x0d
	jr	nc, 00101$
	ld	a, l
	sub	a, #0x0d
	jr	c, 00102$
00101$:
	ld	a, #0x08
	ret
00102$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:130: return world_get_tile(x, y);
	ld	a, c
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:131: }
	jp	_world_get_tile
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:133: static unsigned char passage(unsigned char x, unsigned char y)
;	---------------------------------
; Function passage
; ---------------------------------
_passage:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:135: unsigned char tile = map_tile(x, y);
	call	_map_tile
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:136: return tile == WORLD_TILE_EMPTY || tile == WORLD_TILE_DOOR
	or	a, a
	jr	z, 00104$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:137: || tile == WORLD_TILE_RED_DOOR;
	cp	a, #0x05
	jr	z, 00104$
	cp	a, #0x06
	jr	z, 00104$
	xor	a, a
	ret
00104$:
	ld	a, #0x01
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:138: }
	ret
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:140: static unsigned char cell_pattern(unsigned char x, unsigned char y)
;	---------------------------------
; Function cell_pattern
; ---------------------------------
_cell_pattern:
	push	ix
	ld	ix,	#0
	add	ix, sp
	push	af
	push	af
	push	af
	dec	sp
	ld	-2 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:142: unsigned char tile = world_get_tile(x, y);
	ld	-3 (ix), l
	ld	a, -2 (ix)
	call	_world_get_tile
	ld	-7 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:143: unsigned char edges = 0;
	ld	-1 (ix), #0x00
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:145: if (tile == WORLD_TILE_VOID)
	ld	a, -7 (ix)
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:146: return 0;
	sub	a, #0x08
	jp	z, 00126$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:147: if (tile == WORLD_TILE_DOOR || tile == WORLD_TILE_RED_DOOR)
	ld	a, -7 (ix)
	sub	a, #0x05
	ld	a, #0x01
	jr	z, 00251$
	xor	a, a
00251$:
	ld	-6 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:152: + (passage(x, y - 1) || passage(x, y + 1) ? 0 : 1);
	ld	c, -3 (ix)
	ld	a, c
	dec	a
	ld	-5 (ix), a
	ld	a, c
	inc	a
	ld	-4 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:147: if (tile == WORLD_TILE_DOOR || tile == WORLD_TILE_RED_DOOR)
	ld	a, -6 (ix)
	or	a, a
	jr	nz, 00105$
	ld	a, -7 (ix)
	sub	a, #0x06
	jr	nz, 00106$
00105$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:150: if (door_state_get(door_instance_find_at(x, y)) == DOOR_STATE_CLOSED)
	ld	l, -3 (ix)
	ld	a, -2 (ix)
	call	_door_instance_find_at
	call	_door_state_get
	or	a, a
	jr	nz, 00104$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:151: return (tile == WORLD_TILE_DOOR ? DOOR_HORIZONTAL : RED_HORIZONTAL)
	ld	a, -6 (ix)
	or	a, a
	jr	z, 00128$
	ld	-1 (ix), #0x10
	jr	00129$
00128$:
	ld	-1 (ix), #0x12
00129$:
	ld	c, -1 (ix)
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:152: + (passage(x, y - 1) || passage(x, y + 1) ? 0 : 1);
	push	bc
	ld	l, -5 (ix)
	ld	a, -2 (ix)
	call	_passage
	pop	bc
	or	a, a
	jr	nz, 00133$
	push	bc
	ld	l, -4 (ix)
	ld	a, -2 (ix)
	call	_passage
	pop	bc
	or	a, a
	jr	z, 00130$
00133$:
	xor	a, a
	jr	00131$
00130$:
	ld	a, #0x01
00131$:
	add	a, c
	jp	00126$
00104$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:153: tile = WORLD_TILE_EMPTY;
	ld	-7 (ix), #0x00
00106$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:160: if (map_tile(x + 1, y) == WORLD_TILE_RED_DOOR_SWITCH) return COMPUTER_PATTERN + 1;
	ld	b, -2 (ix)
	ld	c, b
	inc	c
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:162: if (map_tile(x - 1, y) == WORLD_TILE_RED_DOOR_SWITCH) return COMPUTER_PATTERN + 3;
	dec	b
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:155: if (tile == WORLD_TILE_EMPTY)
	ld	a, -7 (ix)
	or	a, a
	jr	nz, 00117$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:159: if (map_tile(x, y - 1) == WORLD_TILE_RED_DOOR_SWITCH) return COMPUTER_PATTERN;
	push	bc
	ld	l, -5 (ix)
	ld	a, -2 (ix)
	call	_map_tile
	pop	bc
	cp	a, #0x07
	jr	nz, 00109$
	ld	a, #0x14
	jp	00126$
00109$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:160: if (map_tile(x + 1, y) == WORLD_TILE_RED_DOOR_SWITCH) return COMPUTER_PATTERN + 1;
	push	bc
	ld	l, -3 (ix)
	ld	a, c
	call	_map_tile
	pop	bc
	cp	a, #0x07
	jr	nz, 00111$
	ld	a, #0x15
	jr	00126$
00111$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:161: if (map_tile(x, y + 1) == WORLD_TILE_RED_DOOR_SWITCH) return COMPUTER_PATTERN + 2;
	push	bc
	ld	l, -4 (ix)
	ld	a, -2 (ix)
	call	_map_tile
	pop	bc
	cp	a, #0x07
	jr	nz, 00113$
	ld	a, #0x16
	jr	00126$
00113$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:162: if (map_tile(x - 1, y) == WORLD_TILE_RED_DOOR_SWITCH) return COMPUTER_PATTERN + 3;
	ld	l, -3 (ix)
	ld	a, b
	call	_map_tile
	cp	a, #0x07
	jr	nz, 00115$
	ld	a, #0x17
	jr	00126$
00115$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:163: return 0;
	xor	a, a
	jr	00126$
00117$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:166: if (passage(x, y - 1)) edges |= EDGE_TOP;
	push	bc
	ld	l, -5 (ix)
	ld	a, -2 (ix)
	call	_passage
	pop	bc
	or	a, a
	jr	z, 00119$
	ld	-1 (ix), #0x01
00119$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:167: if (passage(x + 1, y)) edges |= EDGE_RIGHT;
	push	bc
	ld	l, -3 (ix)
	ld	a, c
	call	_passage
	ld	d, a
	pop	bc
	ld	a, d
	or	a, a
	jr	z, 00121$
	set	1, -1 (ix)
00121$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:168: if (passage(x, y + 1)) edges |= EDGE_BOTTOM;
	push	bc
	ld	l, -4 (ix)
	ld	a, -2 (ix)
	call	_passage
	ld	d, a
	pop	bc
	ld	a, d
	or	a, a
	jr	z, 00123$
	set	2, -1 (ix)
00123$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:169: if (passage(x - 1, y)) edges |= EDGE_LEFT;
	ld	l, -3 (ix)
	ld	a, b
	call	_passage
	or	a, a
	jr	z, 00125$
	set	3, -1 (ix)
00125$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:170: return edges;
	ld	a, -1 (ix)
00126$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:171: }
	ld	sp, ix
	pop	ix
	ret
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:173: static unsigned char pattern_color(unsigned char pattern)
;	---------------------------------
; Function pattern_color
; ---------------------------------
_pattern_color:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:175: if (pattern < DOOR_HORIZONTAL) return PAUSE_MAP_WHITE;
	cp	a, #0x10
	jr	nc, 00102$
	ld	a, #0x0c
	ret
00102$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:176: if (pattern < RED_HORIZONTAL) return PAUSE_MAP_DOOR_COLOR;
	cp	a, #0x12
	jr	nc, 00104$
	ld	a, #0x01
	ret
00104$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:177: if (pattern < COMPUTER_PATTERN) return PAUSE_MAP_RED_COLOR;
	sub	a, #0x14
	jr	nc, 00106$
	ld	a, #0x05
	ret
00106$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:178: return PAUSE_MAP_SWITCH_COLOR;
	ld	a, #0x04
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:179: }
	ret
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:181: static void pattern_rows(unsigned char *rows, unsigned char pattern)
;	---------------------------------
; Function pattern_rows
; ---------------------------------
_pattern_rows:
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	iy, #-12
	add	iy, sp
	ld	sp, iy
	ld	-4 (ix), l
	ld	-3 (ix), h
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:185: for (y = 0; y < 8; ++y)
	ld	a, 4 (ix)
	ld	-1 (ix), a
	and	a, #0x08
	ld	-12 (ix), a
	ld	a, -1 (ix)
	and	a, #0x02
	ld	-11 (ix), a
	ld	a, -1 (ix)
	and	a, #0x01
	ld	-10 (ix), a
	ld	-9 (ix), a
	ld	a, -1 (ix)
	and	a, #0x04
	ld	-8 (ix), a
	ld	a, -1 (ix)
	sub	a, #0x10
	ld	a, #0x00
	rla
	ld	-7 (ix), a
	ld	-2 (ix), #0x00
00117$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:187: bits = 0;
	ld	-1 (ix), #0x00
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:188: if (pattern < DOOR_HORIZONTAL)
	ld	a, -7 (ix)
	or	a, a
	jr	z, 00114$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:190: if ((pattern & EDGE_LEFT) != 0) bits |= 0x80;
	ld	a, -12 (ix)
	or	a, a
	jr	z, 00102$
	ld	-1 (ix), #0x80
00102$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:191: if ((pattern & EDGE_RIGHT) != 0) bits |= 0x01;
	ld	a, -11 (ix)
	or	a, a
	jr	z, 00104$
	set	0, -1 (ix)
00104$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:192: if ((y == 0 && (pattern & EDGE_TOP) != 0)
	ld	a, -2 (ix)
	or	a, a
	jr	nz, 00109$
	ld	a, -10 (ix)
	or	a, a
	jr	nz, 00105$
00109$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:193: || (y == 7 && (pattern & EDGE_BOTTOM) != 0)) bits = 0xff;
	ld	a, -2 (ix)
	sub	a, #0x07
	jr	nz, 00115$
	ld	a, -8 (ix)
	or	a, a
	jr	z, 00115$
00105$:
	ld	-1 (ix), #0xff
	jr	00115$
00114$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:195: else if ((pattern & 1) != 0)
	ld	a, -9 (ix)
	or	a, a
	jr	z, 00111$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:196: bits = 0x10;
	ld	-1 (ix), #0x10
	jr	00115$
00111$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:198: bits = y == 3 ? 0xff : 0;
	ld	a, -2 (ix)
	sub	a, #0x03
	ld	a, #0xff
	jr	z, 00122$
	xor	a, a
00122$:
	ld	-1 (ix), a
00115$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:199: rows[y] = bits;
	ld	e, -2 (ix)
	ld	d, #0x00
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	add	hl, de
	ld	-6 (ix), l
	ld	-5 (ix), h
	ld	a, -1 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:185: for (y = 0; y < 8; ++y)
	inc	-2 (ix)
	ld	a, -2 (ix)
	sub	a, #0x08
	jr	c, 00117$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:201: }
	ld	sp, ix
	pop	ix
	pop	hl
	inc	sp
	jp	(hl)
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:203: static unsigned char player_facing(void)
;	---------------------------------
; Function player_facing
; ---------------------------------
_player_facing:
	push	ix
	ld	ix,	#0
	add	ix, sp
	push	af
	dec	sp
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:205: signed int dx = camera_get_direction_x();
	call	_camera_get_direction_x
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:206: signed int dy = camera_get_direction_y();
	push	de
	call	_camera_get_direction_y
	pop	bc
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:207: unsigned int ax = dx < 0 ? -dx : dx;
	ld	a, b
	rlca
	and	a, #0x01
	ld	l, a
	or	a, a
	jr	z, 00109$
	xor	a, a
	sub	a, c
	ld	c, a
	sbc	a, a
	sub	a, b
	ld	b, a
00109$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:208: unsigned int ay = dy < 0 ? -dy : dy;
	ld	a, d
	rlca
	and	a, #0x01
	ld	-3 (ix), a
	or	a, a
	jr	z, 00111$
	xor	a, a
	sub	a, e
	ld	e, a
	sbc	a, a
	sub	a, d
	ld	d, a
00111$:
	ld	-2 (ix), e
	ld	-1 (ix), d
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:211: if (ax < 98) return dy < 0 ? 0 : 4;
	ld	a, c
	sub	a, #0x62
	ld	a, b
	sbc	a, #0x00
	jr	nc, 00102$
	ld	a, -3 (ix)
	or	a, a
	ld	c, #0x00
	jr	nz, 00114$
	ld	c, #0x04
00114$:
	ld	a, c
	jr	00107$
00102$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:212: if (ay < 98) return dx < 0 ? 6 : 2;
	ld	a, -2 (ix)
	sub	a, #0x62
	ld	a, -1 (ix)
	sbc	a, #0x00
	jr	nc, 00104$
	ld	a, l
	or	a, a
	jr	z, 00115$
	ld	a, #0x06
	jr	00107$
00115$:
	ld	a, #0x02
	jr	00107$
00104$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:213: if (dy < 0) return dx < 0 ? 7 : 1;
	ld	a, -3 (ix)
	or	a, a
	jr	z, 00106$
	ld	a, l
	or	a, a
	jr	z, 00117$
	ld	a, #0x07
	jr	00107$
00117$:
	ld	a, #0x01
	jr	00107$
00106$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:214: return dx < 0 ? 5 : 3;
	ld	a, l
	or	a, a
	ld	a, #0x05
	jr	nz, 00120$
	ld	a, #0x03
00120$:
00107$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:215: }
	ld	sp, ix
	pop	ix
	ret
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:217: static void draw_player(unsigned char x, unsigned char y, unsigned char facing)
;	---------------------------------
; Function draw_player
; ---------------------------------
_draw_player:
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	e, a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:223: 0xd000 | (y + PAUSE_LCD_BG_Y - 2), 2);
	ld	h, #0x00
	ld	bc, #0x0016
	add	hl, bc
	ld	a, h
	or	a, #0xd0
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:222: SMS_VRAMmemsetW(PAUSE_MAP_SAT_Y,
	push	de
	ld	bc, #0x0002
	push	bc
	ld	e, l
	ld	d, a
	ld	hl, #0x3f00
	call	_SMS_VRAMmemsetW
	pop	de
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:225: ((unsigned int)facing << 8) | (x + PAUSE_LCD_BG_X - 1), 2);
	ld	b, 4 (ix)
	ld	d, #0x00
	ld	hl, #0x002f
	add	hl, de
	ex	de, hl
	ld	a, b
	or	a, d
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:224: SMS_VRAMmemsetW(PAUSE_MAP_SAT_X_TILE,
	ld	hl, #0x0002
	push	hl
	ld	d, a
	ld	hl, #0x3f80
	call	_SMS_VRAMmemsetW
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:226: }
	pop	ix
	pop	hl
	inc	sp
	jp	(hl)
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:228: static void frame_rows(unsigned char *rows, unsigned char edges,
;	---------------------------------
; Function frame_rows
; ---------------------------------
_frame_rows:
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	iy, #-13
	add	iy, sp
	ld	sp, iy
	ld	-4 (ix), l
	ld	-3 (ix), h
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:233: unsigned char left_bit = scroll_x == 0 ? 0x80 : 0x08;
	ld	a, 5 (ix)
	or	a, a
	ld	a, #0x80
	jr	z, 00125$
	ld	a, #0x08
00125$:
	ld	-13 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:234: unsigned char right_bit = scroll_x == 0 ? 0x01 : 0x10;
	ld	a, 5 (ix)
	or	a, a
	ld	a, #0x01
	jr	z, 00127$
	ld	a, #0x10
00127$:
	ld	-12 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:235: unsigned char left_fill = scroll_x == 0 ? 0xff : 0x0f;
	ld	a, 5 (ix)
	or	a, a
	ld	a, #0xff
	jr	z, 00129$
	ld	a, #0x0f
00129$:
	ld	-11 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:236: unsigned char right_fill = scroll_x == 0 ? 0xff : 0xf0;
	ld	a, 5 (ix)
	or	a, a
	ld	a, #0xff
	jr	z, 00131$
	ld	a, #0xf0
00131$:
	ld	-10 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:237: unsigned char bottom = scroll_y == 0 ? 7 : 3;
	ld	a, 6 (ix)
	or	a, a
	ld	a, #0x07
	jr	z, 00133$
	ld	a, #0x03
00133$:
	ld	-9 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:238: for (y = 0; y < 8; ++y)
	ld	a, 4 (ix)
	ld	-8 (ix), a
	and	a, #0x01
	ld	-7 (ix), a
	ld	-2 (ix), #0x00
00120$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:240: bits = 0;
	ld	-1 (ix), #0x00
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:241: if (!(((edges & EDGE_TOP) != 0 && y < scroll_y)
	ld	a, -7 (ix)
	or	a, a
	jr	z, 00118$
	ld	a, -2 (ix)
	sub	a, 6 (ix)
	jr	c, 00115$
00118$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:242: || ((edges & EDGE_BOTTOM) != 0 && y > bottom)))
	ld	a, -8 (ix)
	and	a, #0x04
	ld	-6 (ix), a
	or	a, a
	jr	z, 00114$
	ld	a, -9 (ix)
	sub	a, -2 (ix)
	jr	c, 00115$
00114$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:244: if ((edges & EDGE_LEFT) != 0) bits |= left_bit;
	ld	a, -8 (ix)
	and	a, #0x08
	ld	e, a
	or	a, a
	jr	z, 00102$
	ld	a, -13 (ix)
	ld	-1 (ix), a
00102$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:245: if ((edges & EDGE_RIGHT) != 0) bits |= right_bit;
	ld	a, -8 (ix)
	and	a, #0x02
	ld	-5 (ix), a
	or	a, a
	jr	z, 00104$
	ld	a, -1 (ix)
	or	a, -12 (ix)
	ld	-1 (ix), a
00104$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:246: if (((edges & EDGE_TOP) != 0 && y == scroll_y)
	ld	a, -7 (ix)
	or	a, a
	jr	z, 00109$
	ld	a, -2 (ix)
	sub	a, 6 (ix)
	jr	z, 00105$
00109$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:247: || ((edges & EDGE_BOTTOM) != 0 && y == bottom)) bits = 0xff;
	ld	a, -6 (ix)
	or	a, a
	jr	z, 00106$
	ld	a, -2 (ix)
	sub	a, -9 (ix)
	jr	nz, 00106$
00105$:
	ld	-1 (ix), #0xff
00106$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:248: if ((edges & EDGE_LEFT) != 0) bits &= left_fill;
	ld	a, e
	or	a, a
	jr	z, 00111$
	ld	a, -1 (ix)
	and	a, -11 (ix)
	ld	-1 (ix), a
00111$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:249: if ((edges & EDGE_RIGHT) != 0) bits &= right_fill;
	ld	a, -5 (ix)
	or	a, a
	jr	z, 00115$
	ld	a, -1 (ix)
	and	a, -10 (ix)
	ld	-1 (ix), a
00115$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:251: rows[y] = bits;
	ld	e, -2 (ix)
	ld	d, #0x00
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	add	hl, de
	ld	-6 (ix), l
	ld	-5 (ix), h
	ld	a, -1 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:238: for (y = 0; y < 8; ++y)
	inc	-2 (ix)
	ld	a, -2 (ix)
	sub	a, #0x08
	jp	c, 00120$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:253: }
	ld	sp, ix
	pop	ix
	pop	hl
	pop	af
	inc	sp
	jp	(hl)
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:256: static void draw_rect(unsigned char px, unsigned char py,
;	---------------------------------
; Function draw_rect
; ---------------------------------
_draw_rect:
	push	ix
	ld	ix,	#0
	add	ix, sp
	push	af
	push	af
	dec	sp
	ld	c, l
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:263: unsigned char tile_x = (px + PAUSE_LCD_BG_X - SCROLL_X) >> 3;
	ld	e, a
	ld	d, #0x00
	ld	hl, #0x002c
	add	hl, de
	sra	h
	rr	l
	sra	h
	rr	l
	sra	h
	rr	l
	ld	-5 (ix), l
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:264: unsigned char tile_y = (py + PAUSE_LCD_BG_Y + SCROLL_Y) >> 3;
	ld	b, #0x00
	ld	hl, #0x0018
	add	hl, bc
	sra	h
	rr	l
	sra	h
	rr	l
	sra	h
	rr	l
	ld	-4 (ix), l
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:265: for (y = 0; y < rows; ++y)
	ld	a, 6 (ix)
	sub	a, #0xa0
	ld	a, #0x01
	jr	z, 00209$
	xor	a, a
00209$:
	ld	-3 (ix), a
	ld	-2 (ix), #0x00
00122$:
	ld	a, -2 (ix)
	sub	a, 5 (ix)
	jp	nc, 00124$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:266: for (x = 0; x < columns; ++x)
	ld	-1 (ix), #0x00
00119$:
	ld	a, -1 (ix)
	sub	a, 4 (ix)
	jr	nc, 00123$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:268: edges = 0;
	ld	e, #0x00
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:269: if (x == 0) edges |= EDGE_LEFT;
	ld	a, -1 (ix)
	or	a, a
	jr	nz, 00102$
	ld	e, #0x08
00102$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:270: if (x == columns - 1) edges |= EDGE_RIGHT;
	ld	c, 4 (ix)
	ld	b, #0x00
	dec	bc
	ld	l, -1 (ix)
	xor	a, a
	ld	h, a
	sbc	hl, bc
	jr	nz, 00104$
	set	1, e
00104$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:271: if (y == 0) edges |= EDGE_TOP;
	ld	a, -2 (ix)
	or	a, a
	jr	nz, 00106$
	set	0, e
00106$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:272: if (y == rows - 1) edges |= EDGE_BOTTOM;
	ld	l, 5 (ix)
	ld	h, #0x00
	dec	hl
	ld	c, -2 (ix)
	xor	a, a
	ld	b, a
	sbc	hl, bc
	jr	nz, 00108$
	set	2, e
00108$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:273: if (edges != 0)
	ld	a, e
	or	a, a
	jr	z, 00120$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:275: if (pattern_base == SIDE_FRAME_PATTERN) edges = empty_patterns[edges];
	ld	a, -3 (ix)
	or	a, a
	jr	z, 00111$
	ld	hl, #_empty_patterns
	ld	d, #0x00
	add	hl, de
	ld	e, (hl)
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:276: SMS_setTileatXY(tile_x + x, tile_y + y, pattern_base + edges);
00111$:
	ld	l, -4 (ix)
	ld	h, #0x00
	add	hl, bc
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	ld	a, -5 (ix)
	add	a, -1 (ix)
	ld	c, a
	ld	b, #0x00
	add	hl, bc
	add	hl, hl
	ld	a, h
	or	a, #0x78
	ld	h, a
	call	_SMS_crt0_RST08
	ld	l, 6 (ix)
	ld	h, #0x00
	ld	d, h
	add	hl, de
	call	_SMS_crt0_RST18
00120$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:266: for (x = 0; x < columns; ++x)
	inc	-1 (ix)
	jr	00119$
00123$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:265: for (y = 0; y < rows; ++y)
	inc	-2 (ix)
	jp	00122$
00124$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:279: }
	ld	sp, ix
	pop	ix
	pop	hl
	pop	af
	inc	sp
	jp	(hl)
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:282: static void draw_focus(unsigned char state, unsigned char visible)
;	---------------------------------
; Function draw_focus
; ---------------------------------
_draw_focus:
	push	ix
	ld	ix,	#0
	add	ix, sp
	push	af
	push	af
	ld	b, a
	ld	c, l
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:288: for (corner = 0; corner < 4; ++corner)
	ld	a, b
	dec	a
	ld	a, #0x01
	jr	z, 00189$
	xor	a, a
00189$:
	ld	e, a
	ld	a, b
	sub	a, #0x02
	ld	a, #0x01
	jr	z, 00191$
	xor	a, a
00191$:
	ld	-4 (ix), a
	ld	-1 (ix), #0x00
00109$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:290: x = (corner & 1) != 0 ? 145 : 12;
	bit	0, -1 (ix)
	ld	a, #0x91
	jr	nz, 00114$
	ld	a, #0x0c
00114$:
	ld	-2 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:291: y = state == WEAPONS_FOCUS ? 108 : 12;
	ld	a, e
	or	a, a
	ld	l, #0x6c
	jr	nz, 00116$
	ld	l, #0x0c
00116$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:292: if ((corner & 2) != 0) y += state == WEAPONS_FOCUS ? 21 : 85;
	bit	1, -1 (ix)
	jr	z, 00102$
	ld	a, e
	or	a, a
	ld	a, #0x15
	jr	nz, 00118$
	ld	a, #0x55
00118$:
	add	a, l
	ld	l, a
00102$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:293: tile = 0;
	ld	d, #0x00
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:299: if (visible != 0)
	ld	a, c
	or	a, a
	jr	z, 00105$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:300: tile = (state == WEAPONS_FOCUS ? WEAPON_FOCUS_PATTERN : FOCUS_PATTERN)
	ld	a, e
	or	a, a
	ld	a, #0x3a
	jr	nz, 00120$
	ld	a, #0x30
00120$:
	ld	b, -1 (ix)
	add	a, b
	ld	b, a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:301: + corner + (state == MAP_BROWSE ? 4 : 0);
	ld	a, -4 (ix)
	or	a, a
	ld	a, #0x04
	jr	nz, 00122$
	xor	a, a
00122$:
	add	a, b
	ld	d, a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:302: SMS_setTileatXY((x + PAUSE_LCD_BG_X - SCROLL_X) >> 3,
00105$:
	ld	h, #0x00
	push	de
	ld	de, #0x0018
	add	hl, de
	pop	de
	sra	h
	rr	l
	sra	h
	rr	l
	sra	h
	rr	l
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	ld	a, -2 (ix)
	ld	-3 (ix), a
	ld	-2 (ix), #0x00
	ld	a, -3 (ix)
	add	a, #0x2c
	ld	b, a
	ld	a, #0x00
	adc	a, #0x00
	sra	a
	rr	b
	sra	a
	rr	b
	sra	a
	rr	b
	ld	a, b
	ld	b, #0x00
	add	a, l
	ld	l, a
	ld	a, b
	adc	a, h
	ld	h, a
	add	hl, hl
	ld	a, h
	or	a, #0x78
	push	bc
	ld	h, a
	call	_SMS_crt0_RST08
	pop	bc
	ld	h, #0x00
	ld	l, d
	call	_SMS_crt0_RST18
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:288: for (corner = 0; corner < 4; ++corner)
	inc	-1 (ix)
	ld	a, -1 (ix)
	sub	a, #0x04
	jp	c, 00109$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:306: }
	ld	sp, ix
	pop	ix
	ret
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:315: static void load_arrows(void)
;	---------------------------------
; Function load_arrows
; ---------------------------------
_load_arrows:
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	hl, #-22
	add	hl, sp
	ld	sp, hl
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:326: for (arrow = 0; arrow < 2; ++arrow)
	ld	-4 (ix), #0x00
00123$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:328: x_offset = ((arrow == 0 ? 20 : 135) - SCROLL_X) & 7;
	ld	a, -4 (ix)
	or	a, a
	ld	a, #0x14
	jr	z, 00128$
	ld	a, #0x87
00128$:
	add	a, #0xfc
	and	a, #0x07
	ld	-14 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:331: if (part_y != 0 && y_offset <= 2) continue;
	ld	a, -4 (ix)
	add	a, a
	add	a, a
	ld	-13 (ix), a
	ld	a, #0x03
	sub	a, -14 (ix)
	ld	a, #0x00
	rla
	ld	-12 (ix), a
	ld	-3 (ix), #0x00
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:332: for (part_x = 0; part_x < 2; ++part_x)
00161$:
	ld	a, -3 (ix)
	add	a, a
	add	a, a
	add	a, a
	ld	-11 (ix), a
	ld	a, -3 (ix)
	add	a, a
	ld	-10 (ix), a
	ld	-2 (ix), #0x00
00121$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:334: if (part_x != 0 && x_offset <= 3) continue;
	ld	a, -2 (ix)
	or	a, a
	jr	z, 00157$
	bit	0, -12 (ix)
	jp	z, 00114$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:335: for (y = 0; y < 8; ++y)
00157$:
	ld	-1 (ix), #0x00
00119$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:337: bits = 0;
	ld	-9 (ix), #0x00
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:338: if (y + (part_y << 3) >= y_offset && y + (part_y << 3) < y_offset + 6)
	ld	c, -1 (ix)
	ld	b, #0x00
	ld	a, -3 (ix)
	ld	-8 (ix), a
	ld	-7 (ix), #0x00
	ld	l, -8 (ix)
	ld	h, #0x00
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, bc
	ld	-6 (ix), l
	ld	-5 (ix), h
	ld	a, -6 (ix)
	sub	a, #0x05
	jr	c, 00108$
	ld	a, -6 (ix)
	sub	a, #0x0b
	jr	nc, 00108$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:339: bits = arrow_rows[(arrow == 0 ? 0 : 6) + y + (part_y << 3) - y_offset];
	ld	a, -4 (ix)
	or	a,a
	jr	z, 00130$
	ld	a, #0x06
00130$:
	ld	c, -1 (ix)
	add	a, c
	ld	c, -11 (ix)
	add	a, c
	add	a, #0xfb
	ld	c, a
	rlca
	sbc	a, a
	ld	b, a
	ld	hl, #_arrow_rows
	add	hl, bc
	ld	a, (hl)
	ld	-9 (ix), a
00108$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:340: rows[y] = part_x == 0 ? bits >> x_offset : bits << (8 - x_offset);
	ld	e, -1 (ix)
	ld	d, #0x00
	ld	hl, #0
	add	hl, sp
	add	hl, de
	ld	-6 (ix), l
	ld	-5 (ix), h
	ld	a, -2 (ix)
	or	a, a
	jr	nz, 00131$
	ld	b, -14 (ix)
	ld	a, -9 (ix)
	inc	b
	jr	00256$
00255$:
	srl	a
00256$:
	djnz	00255$
	jr	00132$
00131$:
	ld	c, -14 (ix)
	ld	a, #0x08
	sub	a, c
	ld	b, a
	ld	a, -9 (ix)
00257$:
	add	a, a
	djnz	00257$
00132$:
	ld	l, -6 (ix)
	ld	h, -5 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:335: for (y = 0; y < 8; ++y)
	inc	-1 (ix)
	ld	a, -1 (ix)
	sub	a, #0x08
	jp	c, 00119$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:342: tile = ARROW_PATTERN + (arrow << 2) + (part_y << 1) + part_x;
	ld	a, -13 (ix)
	add	a, #0x40
	ld	c, -10 (ix)
	add	a, c
	ld	c, -2 (ix)
	add	a, c
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:343: SMS_load1bppTiles(rows, tile, sizeof(rows), 0, 3);
	ld	e, a
	ld	d, #0x00
	push	bc
	push	de
	ld	hl, #0x300
	push	hl
	ld	hl, #0x0008
	push	hl
	ld	hl, #8
	add	hl, sp
	call	_SMS_load1bppTiles
	pop	de
	pop	bc
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:344: SMS_setTileatXY(((arrow == 0 ? 20 : 135) + PAUSE_LCD_BG_X - SCROLL_X) / 8 + part_x,
	ld	a, -8 (ix)
	add	a, #0x11
	ld	l, a
	ld	a, #0x00
	adc	a, #0x00
	ld	h, a
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	ld	-6 (ix), l
	ld	-5 (ix), h
	ld	a, -4 (ix)
	or	a, a
	jr	nz, 00133$
	ld	hl, #0x0014
	jr	00134$
00133$:
	ld	hl, #0x0087
00134$:
	ld	a, l
	add	a, #0x2c
	ld	l, a
	ld	a, h
	adc	a, #0x00
	sra	a
	rr	l
	sra	a
	rr	l
	sra	a
	rr	l
	add	hl, bc
	ld	h, #0x00
	ld	c, -6 (ix)
	ld	b, -5 (ix)
	add	hl, bc
	add	hl, hl
	ld	a, h
	or	a, #0x78
	ld	h, a
	call	_SMS_crt0_RST08
	ex	de, hl
	call	_SMS_crt0_RST18
00114$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:332: for (part_x = 0; part_x < 2; ++part_x)
	inc	-2 (ix)
	ld	a, -2 (ix)
	sub	a, #0x02
	jp	c, 00121$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:329: for (part_y = 0; part_y < 2; ++part_y)
	inc	-3 (ix)
	ld	a, -3 (ix)
	sub	a, #0x02
	jp	c, 00161$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:326: for (arrow = 0; arrow < 2; ++arrow)
	inc	-4 (ix)
	ld	a, -4 (ix)
	sub	a, #0x02
	jp	c, 00123$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:349: }
	ld	sp, ix
	pop	ix
	ret
	.area _BANK2
	.area _BANK2
_arrow_rows:
	.db #0x08	; 8
	.db #0x30	; 48	'0'
	.db #0xc0	; 192
	.db #0xc0	; 192
	.db #0x30	; 48	'0'
	.db #0x08	; 8
	.db #0x80	; 128
	.db #0x60	; 96
	.db #0x18	; 24
	.db #0x18	; 24
	.db #0x60	; 96
	.db #0x80	; 128
	.area _BANK2
	.area _BANK2
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:351: static unsigned char adjacent_weapon(unsigned char current, unsigned char right)
;	---------------------------------
; Function adjacent_weapon
; ---------------------------------
_adjacent_weapon:
	push	ix
	ld	ix,	#0
	add	ix, sp
	dec	sp
	ld	b, a
	ld	c, l
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:354: while (remaining-- != 0)
	ld	-1 (ix), #0x02
00106$:
	ld	a, -1 (ix)
	dec	-1 (ix)
	or	a, a
	jr	z, 00108$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:356: if (right != 0) current = current + 1 == WEAPON_COUNT ? 0 : current + 1;
	ld	e, b
	ld	a, c
	or	a, a
	jr	z, 00102$
	ld	h, #0x00
	ld	l, b
	inc	hl
	ld	a, l
	sub	a, #0x02
	or	a, h
	jr	nz, 00111$
	xor	a, a
	ld	b, a
	jr	00103$
00111$:
	inc	e
	ld	a, e
	ld	b, a
	rlca
	sbc	a, a
	jr	00103$
00102$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:357: else current = current == 0 ? WEAPON_COUNT - 1 : current - 1;
	ld	a, b
	or	a, a
	jr	nz, 00113$
	ld	e, #0x01
	jr	00114$
00113$:
	dec	e
00114$:
	ld	b, e
00103$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:358: if ((owned_weapons & (1U << current)) != 0) return current;
	ld	a, b
	push	af
	ld	hl, #0x0001
	pop	af
	inc	a
	jr	00166$
00165$:
	add	hl, hl
00166$:
	dec	a
	jr	nz, 00165$
	ld	a, (_owned_weapons+0)
	and	a, l
	jr	z, 00106$
	ld	a, b
	jr	00109$
00108$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:360: return selected_weapon;
	ld	a, (_selected_weapon)
00109$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:361: }
	inc	sp
	pop	ix
	ret
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:363: static void draw_weapon_slot(unsigned char x, unsigned char weapon)
;	---------------------------------
; Function draw_weapon_slot
; ---------------------------------
_draw_weapon_slot:
	push	ix
	ld	ix,	#0
	add	ix, sp
	push	af
	push	af
	ld	c, a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:368: unsigned char pattern_base = weapon == WEAPON_PISTOL ? PISTOL_PATTERN : SHOTGUN_PATTERN;
	ld	a, l
	or	a, a
	ld	a, #0x48
	jr	z, 00117$
	ld	a, #0xb0
00117$:
	ld	-4 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:369: if (weapon == WEAPON_COUNT) { draw_rect(x - 2, 110, WEAPON_COLUMNS, WEAPON_ROWS, SIDE_FRAME_PATTERN); return; }
	ld	a, l
	sub	a, #0x02
	jr	nz, 00102$
	ld	a, c
	add	a, #0xfe
	ld	h, #0xa0
	push	hl
	inc	sp
	ld	h, #0x04
	push	hl
	inc	sp
	ld	h, #0x03
	push	hl
	inc	sp
	ld	l, #0x6e
	call	_draw_rect
	jr	00114$
00102$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:370: if (x != 72)
	ld	a, c
	sub	a, #0x48
	jr	z, 00133$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:371: pattern_base = weapon == WEAPON_PISTOL ? SIDE_PISTOL_PATTERN : SIDE_SHOTGUN_PATTERN;
	ld	a, l
	or	a, a
	ld	a, #0x80
	jr	z, 00119$
	ld	a, #0x90
00119$:
	ld	-4 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:372: for (row = 0; row < WEAPON_ROWS; ++row)
00133$:
	ld	e, #0x00
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:373: for (column = 0; column < WEAPON_COLUMNS; ++column)
00131$:
	ld	a, e
	add	a, a
	add	a, e
	ld	-3 (ix), a
	ld	b, #0x00
00110$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:375: offset = (row << 1) + (SCROLL_X == 0 ? (row << 1) : row) + column;
	ld	a, -3 (ix)
	add	a, b
	ld	d, a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:376: SMS_setTileatXY(((x - 2 + PAUSE_LCD_BG_X - SCROLL_X) >> 3) + column,
	ld	a, e
	add	a, #0x10
	ld	l, a
	ld	h, #0x00
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	ld	-2 (ix), l
	ld	-1 (ix), h
	ld	a, c
	ld	h, #0x00
	add	a, #0x2a
	ld	l, a
	jr	nc, 00181$
	inc	h
00181$:
	sra	h
	rr	l
	sra	h
	rr	l
	sra	h
	rr	l
	ld	a, b
	add	a, l
	ld	h, #0x00
	add	a, -2 (ix)
	ld	l, a
	ld	a, h
	adc	a, -1 (ix)
	ld	h, a
	add	hl, hl
	ld	a, h
	or	a, #0x78
	ld	h, a
	push	bc
	call	_SMS_crt0_RST08
	pop	bc
	ld	l, -4 (ix)
	ld	h, #0x00
	ld	a, d
	ld	d, #0x00
	add	a, l
	ld	l, a
	ld	a, d
	adc	a, h
	ld	h, a
	call	_SMS_crt0_RST18
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:373: for (column = 0; column < WEAPON_COLUMNS; ++column)
	inc	b
	ld	a, b
	sub	a, #0x03
	jr	c, 00110$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:372: for (row = 0; row < WEAPON_ROWS; ++row)
	inc	e
	ld	a, e
	sub	a, #0x04
	jr	c, 00131$
00114$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:380: }
	ld	sp, ix
	pop	ix
	ret
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:382: static void draw_weapons(void)
;	---------------------------------
; Function draw_weapons
; ---------------------------------
_draw_weapons:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:384: unsigned char previous = adjacent_weapon(selected_weapon, 0);
	ld	l, #0x00
	ld	a, (_selected_weapon)
	call	_adjacent_weapon
	ld	l, a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:385: unsigned char next = adjacent_weapon(selected_weapon, 1);
	push	hl
	ld	l, #0x01
	ld	a, (_selected_weapon)
	call	_adjacent_weapon
	ld	c, a
	pop	hl
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:386: draw_weapon_slot(40, previous == selected_weapon ? WEAPON_COUNT : previous);
	ld	a, (_selected_weapon)
	sub	a, l
	jr	nz, 00103$
	ld	l, #0x02
00103$:
	push	bc
	ld	a, #0x28
	call	_draw_weapon_slot
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:387: draw_weapon_slot(72, selected_weapon);
	ld	a, (_selected_weapon)
	ld	l, a
	ld	a, #0x48
	call	_draw_weapon_slot
	pop	bc
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:388: draw_weapon_slot(104, next == selected_weapon ? WEAPON_COUNT : next);
	ld	a, (_selected_weapon)
	sub	a, c
	jr	nz, 00105$
	ld	l, #0x02
	jr	00106$
00105$:
	ld	l, c
00106$:
	ld	a, #0x68
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:389: }
	jp	_draw_weapon_slot
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:393: static void load_weapon_patterns(const unsigned char *indices,
;	---------------------------------
; Function load_weapon_patterns
; ---------------------------------
_load_weapon_patterns:
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	iy, #-8
	add	iy, sp
	ld	sp, iy
	ld	-6 (ix), l
	ld	-5 (ix), h
	pop	hl
	push	de
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:399: unsigned char repeats = 0;
	ld	-4 (ix), #0x00
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:400: unsigned char index = 0;
	ld	-3 (ix), #0x00
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:401: for (tile = 0; tile < WEAPON_COLUMNS * WEAPON_ROWS; ++tile)
	ld	-2 (ix), #0x00
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:402: for (row = 0; row < 8; ++row)
00121$:
	ld	-1 (ix), #0x00
00108$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:404: if (repeats == 0)
	ld	a, -4 (ix)
	or	a, a
	jr	nz, 00104$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:406: index = *indices++;
	pop	bc
	pop	hl
	push	hl
	push	bc
	ld	a, (hl)
	ld	-3 (ix), a
	inc	-6 (ix)
	jr	nz, 00156$
	inc	-5 (ix)
00156$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:407: if (index & 0x80)
	bit	7, -3 (ix)
	jr	z, 00105$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:409: index &= 0x7f;
	res	7, -3 (ix)
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:410: repeats = *indices++;
	pop	bc
	pop	hl
	push	hl
	push	bc
	ld	a, (hl)
	ld	-4 (ix), a
	inc	-6 (ix)
	jr	nz, 00105$
	inc	-5 (ix)
	jr	00105$
00104$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:413: else --repeats;
	dec	-4 (ix)
00105$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:415: pixels + ((unsigned int)index << 2), 4);
	ld	l, -3 (ix)
	ld	h, #0x00
	add	hl, hl
	add	hl, hl
	ld	a, l
	add	a, -8 (ix)
	ld	e, a
	ld	a, h
	adc	a, -7 (ix)
	ld	d, a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:414: SMS_VRAMmemcpy(((unsigned int)(pattern_base + tile) << 5) + (row << 2),
	ld	c, 4 (ix)
	ld	b, #0x00
	ld	l, -2 (ix)
	ld	h, #0x00
	add	hl, bc
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	ld	c, l
	ld	b, h
	ld	l, -1 (ix)
	ld	h, #0x00
	add	hl, hl
	add	hl, hl
	add	hl, bc
	ld	bc, #0x0004
	push	bc
	call	_SMS_VRAMmemcpy
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:402: for (row = 0; row < 8; ++row)
	inc	-1 (ix)
	ld	a, -1 (ix)
	sub	a, #0x08
	jr	c, 00108$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:401: for (tile = 0; tile < WEAPON_COLUMNS * WEAPON_ROWS; ++tile)
	inc	-2 (ix)
	ld	a, -2 (ix)
	sub	a, #0x0c
	jp	c, 00121$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:417: }
	ld	sp, ix
	pop	ix
	pop	hl
	inc	sp
	jp	(hl)
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:419: static void load_ui(void)
;	---------------------------------
; Function load_ui
; ---------------------------------
_load_ui:
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	hl, #-17
	add	hl, sp
	ld	sp, hl
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:427: for (pattern = 0; pattern < COMPUTER_PATTERN; ++pattern)
	ld	-1 (ix), #0x00
00112$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:429: pattern_rows(rows, pattern);
	ld	a, -1 (ix)
	push	af
	inc	sp
	ld	hl, #1
	add	hl, sp
	call	_pattern_rows
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:430: SMS_load1bppTiles(rows, pattern, sizeof(rows), 0, pattern_color(pattern));
	ld	a, -1 (ix)
	call	_pattern_color
	ld	-4 (ix), a
	ld	a, -1 (ix)
	ld	-3 (ix), a
	ld	-2 (ix), #0x00
	ld	h, -4 (ix)
	ld	l, #0x00
	push	hl
	ld	hl, #0x0008
	push	hl
	ld	e, -3 (ix)
	ld	d, #0x00
	ld	hl, #4
	add	hl, sp
	call	_SMS_load1bppTiles
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:427: for (pattern = 0; pattern < COMPUTER_PATTERN; ++pattern)
	inc	-1 (ix)
	ld	a, -1 (ix)
	sub	a, #0x14
	jr	c, 00112$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:432: SMS_load1bppTiles(computer_rows, COMPUTER_PATTERN, sizeof(computer_rows), 0, PAUSE_MAP_SWITCH_COLOR);
	ld	hl, #0x400
	push	hl
	ld	hl, #0x0020
	push	hl
	ld	de, #0x0014
	ld	hl, #_computer_rows
	call	_SMS_load1bppTiles
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:433: SMS_load1bppTiles(player_rows, PAUSE_MAP_PLAYER_TILE, sizeof(player_rows), 0, PAUSE_MAP_PLAYER_COLOR);
	ld	hl, #0x700
	push	hl
	ld	hl, #0x0040
	push	hl
	ld	de, #0x0100
	ld	hl, #_player_rows
	call	_SMS_load1bppTiles
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:434: for (pattern = 1; pattern < 16; ++pattern)
	ld	-1 (ix), #0x01
00114$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:436: frame_rows(rows, pattern, SCROLL_X, SCROLL_Y);
	xor	a, a
	ld	h, a
	ld	l, #0x04
	push	hl
	ld	a, -1 (ix)
	push	af
	inc	sp
	ld	hl, #3
	add	hl, sp
	call	_frame_rows
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:437: SMS_load1bppTiles(rows, FRAME_PATTERN + pattern, sizeof(rows), 0, PAUSE_MAP_WHITE);
	ld	a, -1 (ix)
	ld	-5 (ix), a
	ld	-4 (ix), #0x00
	ld	de, #0x0020
	ld	l, -5 (ix)
	ld	h, #0x00
	add	hl, de
	ld	-3 (ix), l
	ld	-2 (ix), h
	ld	hl, #0xc00
	push	hl
	ld	hl, #0x0008
	push	hl
	ld	e, -3 (ix)
	ld	d, #0x00
	ld	hl, #4
	add	hl, sp
	call	_SMS_load1bppTiles
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:434: for (pattern = 1; pattern < 16; ++pattern)
	inc	-1 (ix)
	ld	a, -1 (ix)
	sub	a, #0x10
	jr	c, 00114$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:439: SMS_load1bppTiles(pause_empty_rows, SIDE_FRAME_PATTERN + 1, sizeof(pause_empty_rows), 0, 2);
	ld	hl, #0x200
	push	hl
	ld	hl, #0x0040
	push	hl
	ld	de, #0x00a1
	ld	hl, #_pause_empty_rows
	call	_SMS_load1bppTiles
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:440: for (pattern = 0; pattern < 4; ++pattern)
	ld	-2 (ix), #0x00
00120$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:442: x_offset = (((pattern & 1) != 0 ? 145 : 12) - SCROLL_X) & 7;
	ld	a, -2 (ix)
	and	a, #0x01
	ld	-1 (ix), a
	or	a, a
	jr	z, 00124$
	ld	-3 (ix), #0x91
	jr	00125$
00124$:
	ld	-3 (ix), #0x0c
00125$:
	ld	a, -3 (ix)
	add	a, #0xfc
	ld	-3 (ix), a
	and	a, #0x07
	ld	-9 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:443: y_offset = (((pattern & 2) != 0 ? 97 : 12) + SCROLL_Y) & 7;
	ld	a, -2 (ix)
	and	a, #0x02
	ld	-4 (ix), a
	or	a, a
	ld	a, #0x61
	jr	nz, 00127$
	ld	a, #0x0c
00127$:
	and	a, #0x07
	ld	-8 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:444: for (y = 0; y < 8; ++y) rows[y] = 0;
	ld	-3 (ix), #0x00
00116$:
	ld	e, -3 (ix)
	ld	d, #0x00
	ld	hl, #0
	add	hl, sp
	add	hl, de
	ld	-6 (ix), l
	ld	-5 (ix), h
	ld	(hl), #0x00
	inc	-3 (ix)
	ld	a, -3 (ix)
	sub	a, #0x08
	jr	c, 00116$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:445: for (y = 0; y < 3; ++y)
	ld	a, -4 (ix)
	ld	-7 (ix), a
	ld	a, -1 (ix)
	ld	-6 (ix), a
	ld	-1 (ix), #0x00
00118$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:447: bits = (pattern & 1) != 0 ? 0x20 : 0x80;
	ld	a, -6 (ix)
	or	a, a
	ld	a, #0x20
	jr	nz, 00129$
	ld	a, #0x80
00129$:
	ld	-3 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:448: if (y == ((pattern & 2) != 0 ? 2 : 0)) bits = 0xe0;
	ld	a, -7 (ix)
	or	a, a
	ld	a, #0x02
	jr	nz, 00131$
	xor	a, a
00131$:
	ld	c, -1 (ix)
	sub	a, c
	jr	nz, 00105$
	ld	-3 (ix), #0xe0
00105$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:449: rows[y_offset + y] = bits >> x_offset;
	ld	a, -8 (ix)
	add	a, -1 (ix)
	ld	e, a
	ld	d, #0x00
	ld	hl, #0
	add	hl, sp
	add	hl, de
	ld	-5 (ix), l
	ld	-4 (ix), h
	ld	b, -9 (ix)
	inc	b
	jr	00260$
00259$:
	srl	-3 (ix)
00260$:
	djnz	00259$
	ld	l, -5 (ix)
	ld	h, -4 (ix)
	ld	a, -3 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:445: for (y = 0; y < 3; ++y)
	inc	-1 (ix)
	ld	a, -1 (ix)
	sub	a, #0x03
	jr	c, 00118$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:451: SMS_load1bppTiles(rows, WEAPON_FOCUS_PATTERN + pattern, sizeof(rows), 0, PAUSE_MAP_WHITE);
	ld	a, -2 (ix)
	ld	-6 (ix), a
	ld	-5 (ix), #0x00
	ld	l, -6 (ix)
	ld	h, #0x00
	ld	de, #0x003a
	add	hl, de
	ld	de, #0xc00
	push	de
	ld	de, #0x0008
	ex	de, hl
	push	hl
	ld	hl, #4
	add	hl, sp
	call	_SMS_load1bppTiles
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:461: SMS_load1bppTiles(rows, FOCUS_PATTERN + pattern, sizeof(rows), 0, 3);
	ld	de, #0x0030
	ld	l, -6 (ix)
	ld	h, #0x00
	add	hl, de
	ld	-4 (ix), l
	ld	-3 (ix), h
	ld	hl, #0x300
	push	hl
	ld	hl, #0x0008
	push	hl
	ld	e, -4 (ix)
	ld	d, #0x00
	ld	hl, #4
	add	hl, sp
	call	_SMS_load1bppTiles
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:462: SMS_load1bppTiles(rows, FOCUS_PATTERN + pattern + 4, sizeof(rows), 0, PAUSE_MAP_WHITE);
	ld	de, #0x0034
	ld	l, -6 (ix)
	ld	h, #0x00
	add	hl, de
	ld	-4 (ix), l
	ld	-3 (ix), h
	ld	hl, #0xc00
	push	hl
	ld	hl, #0x0008
	push	hl
	ld	e, -4 (ix)
	ld	d, #0x00
	ld	hl, #4
	add	hl, sp
	call	_SMS_load1bppTiles
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:440: for (pattern = 0; pattern < 4; ++pattern)
	inc	-2 (ix)
	ld	a, -2 (ix)
	sub	a, #0x04
	jp	c, 00120$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:464: load_arrows();
	call	_load_arrows
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:465: draw_rect(AUTOMAP_FRAME_X, AUTOMAP_FRAME_Y,
	ld	hl, #0x200a
	push	hl
	ld	a, #0x11
	push	af
	inc	sp
	ld	a,#0x10
	ld	l,a
	call	_draw_rect
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:471: load_weapon_patterns(pause_pistol_tiles, pause_pistol_tiles_rows, PISTOL_PATTERN);
	ld	de, #_pause_pistol_tiles_rows
	push	de
	ld	a, #0x48
	push	af
	inc	sp
	ld	hl, #_pause_pistol_tiles
	call	_load_weapon_patterns
	pop	de
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:472: load_weapon_patterns(pause_pistol_tiles_side, pause_pistol_tiles_rows, SIDE_PISTOL_PATTERN);
	ld	hl, #_pause_pistol_tiles_side
	ld	a, #0x80
	push	af
	inc	sp
	call	_load_weapon_patterns
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:473: load_weapon_patterns(pause_shotgun_tiles, pause_shotgun_tiles_rows, SHOTGUN_PATTERN);
	ld	de, #_pause_shotgun_tiles_rows
	push	de
	ld	a, #0xb0
	push	af
	inc	sp
	ld	hl, #_pause_shotgun_tiles
	call	_load_weapon_patterns
	pop	de
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:474: load_weapon_patterns(pause_shotgun_tiles_side, pause_shotgun_tiles_rows, SIDE_SHOTGUN_PATTERN);
	ld	hl, #_pause_shotgun_tiles_side
	ld	a, #0x90
	push	af
	inc	sp
	call	_load_weapon_patterns
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:475: draw_weapons();
	call	_draw_weapons
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:476: draw_focus(WEAPONS_FOCUS, 1);
	ld	a,#0x01
	ld	l,a
	call	_draw_focus
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:477: }
	ld	sp, ix
	pop	ix
	ret
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:479: static void draw_window(unsigned char origin_x, unsigned char origin_y)
;	---------------------------------
; Function draw_window
; ---------------------------------
_draw_window:
	push	ix
	ld	ix,	#0
	add	ix, sp
	push	af
	dec	sp
	ld	-1 (ix), a
	ld	-2 (ix), l
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:483: for (y = 0; y < MAP_HEIGHT; ++y)
	ld	e, #0x00
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:485: SMS_setTileatXY(((MAP_X + PAUSE_LCD_BG_X - SCROLL_X) >> 3) + x,
00115$:
	ld	a, -2 (ix)
	add	a, e
	ld	-3 (ix), a
	ld	d, #0x00
00101$:
	ld	a, e
	add	a, #0x06
	ld	h, #0x00
	ld	l, a
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	ld	a, d
	add	a, #0x09
	ld	c, a
	ld	b, #0x00
	add	hl, bc
	add	hl, hl
	ld	a, h
	or	a, #0x78
	ld	h, a
	call	_SMS_crt0_RST08
	ld	a, -1 (ix)
	add	a, d
	push	de
	ld	l, -3 (ix)
	call	_cell_pattern
	pop	de
	ld	l, a
	ld	h, #0x00
	call	_SMS_crt0_RST18
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:484: for (x = 0; x < MAP_COLUMNS; ++x)
	inc	d
	ld	a, d
	sub	a, #0x0d
	jr	c, 00101$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:483: for (y = 0; y < MAP_HEIGHT; ++y)
	inc	e
	ld	a, e
	sub	a, #0x08
	jr	c, 00115$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:488: }
	ld	sp, ix
	pop	ix
	ret
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:490: static void place_player(unsigned int px, unsigned int py, unsigned char facing,
;	---------------------------------
; Function place_player
; ---------------------------------
_place_player:
	push	ix
	ld	ix,	#0
	add	ix, sp
	push	af
	push	af
	push	af
	ld	-2 (ix), l
	ld	-1 (ix), h
	ld	-4 (ix), e
	ld	-3 (ix), d
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:495: if ((px >> 8) < origin_x || (px >> 8) >= origin_x + MAP_COLUMNS
	ld	l, -1 (ix)
	ld	h, #0x00
	ld	c, 5 (ix)
	ld	a, l
	sub	a, c
	jr	c, 00101$
	ld	a, 5 (ix)
	ld	d, #0x00
	add	a, #0x0d
	ld	e, a
	jr	nc, 00132$
	inc	d
00132$:
	xor	a, a
	sbc	hl, de
	jr	nc, 00101$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:496: || (py >> 8) < origin_y || (py >> 8) >= origin_y + MAP_HEIGHT)
	ld	l, -3 (ix)
	ld	h, #0x00
	ld	a, 6 (ix)
	ld	-6 (ix), a
	ld	-5 (ix), #0x00
	ld	a, l
	sub	a, -6 (ix)
	jr	c, 00101$
	ld	a, 6 (ix)
	ld	d, #0x00
	add	a, #0x08
	ld	e, a
	jr	nc, 00133$
	inc	d
00133$:
	xor	a, a
	sbc	hl, de
	jr	c, 00102$
00101$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:498: SMS_VRAMmemsetW(PAUSE_MAP_SAT_Y, 0x00d0, 2);
	ld	hl, #0x0002
	push	hl
	ld	de, #0x00d0
	ld	hl, #0x3f00
	call	_SMS_VRAMmemsetW
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:499: return;
	jr	00106$
00102$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:502: MAP_Y + ((py - ((unsigned int)origin_y << 8)) >> PAUSE_MAP_WORLD_SHIFT), facing);
	ld	d, -6 (ix)
	ld	e, #0x00
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	cp	a, a
	sbc	hl, de
	add	hl, hl
	add	hl, hl
	add	hl, hl
	ld	a, h
	add	a, #0x18
	ld	l, a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:501: draw_player(MAP_X + ((px - ((unsigned int)origin_x << 8)) >> PAUSE_MAP_WORLD_SHIFT),
	ld	b, c
	ld	c, #0x00
	ld	a, -2 (ix)
	sub	a, c
	ld	c, a
	ld	a, -1 (ix)
	sbc	a, b
	ld	b, a
	ld	a, c
	srl	b
	rr	a
	srl	b
	rr	a
	srl	b
	rr	a
	srl	b
	rr	a
	srl	b
	rr	a
	add	a, #0x1c
	ld	h, 4 (ix)
	push	hl
	inc	sp
	call	_draw_player
00106$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:503: }
	ld	sp, ix
	pop	ix
	pop	hl
	pop	af
	inc	sp
	jp	(hl)
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:508: static void corpse_read_row(unsigned char *rows, unsigned int address)
;	---------------------------------
; Function corpse_read_row
; ---------------------------------
_corpse_read_row:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:511: SMS_setAddr(address);
	ex	de, hl
	push	de
	call	_SMS_crt0_RST08
	pop	bc
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:512: for (i = 0; i < 4; ++i) rows[i] = pause_data_port;
	ld	e, #0x00
00102$:
	ld	l, e
	ld	h, #0x00
	add	hl, bc
	in	a, (_pause_data_port)
	ld	(hl), a
	inc	e
	ld	a, e
	sub	a, #0x04
	jr	c, 00102$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:513: }
	ret
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:517: static unsigned char corpse_pixel(unsigned char x, unsigned char y,
;	---------------------------------
; Function corpse_pixel
; ---------------------------------
_corpse_pixel:
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	iy, #-10
	add	iy, sp
	ld	sp, iy
	ld	c, a
	ld	b, l
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:525: if (x >= (MAP_COLUMNS << 3) || y >= (MAP_HEIGHT << 3)) return next_tile;
	ld	a, c
	sub	a, #0x68
	jr	nc, 00101$
	ld	a, b
	sub	a, #0x40
	jr	c, 00102$
00101$:
	ld	a, 4 (ix)
	jp	00109$
00102$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:526: address = 0x3800 + (((unsigned int)(((MAP_Y + PAUSE_LCD_BG_Y + SCROLL_Y) >> 3) + (y >> 3))) << 6)
	ld	a, b
	rrca
	rrca
	rrca
	and	a, #0x1f
	add	a, #0x06
	ld	l, a
	ld	h, #0x00
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	ld	e, l
	ld	a, h
	add	a, #0x38
	ld	d, a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:527: + ((((MAP_X + PAUSE_LCD_BG_X - SCROLL_X) >> 3) + (x >> 3)) << 1);
	ld	a, c
	rrca
	rrca
	rrca
	and	a, #0x1f
	ld	l, a
	ld	h, #0x00
	push	de
	ld	de, #0x0009
	add	hl, de
	pop	de
	add	hl, hl
	add	hl, de
	ld	-6 (ix), l
	ld	-5 (ix), h
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:528: corpse_read_row(rows, address);
	push	bc
	ld	e, -6 (ix)
	ld	d, -5 (ix)
	ld	hl, #2
	add	hl, sp
	call	_corpse_read_row
	pop	bc
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:529: tile = rows[0];
	ld	a, -10 (ix)
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:535: SMS_VRAMmemcpy(((unsigned int)next_tile << 5) + offset, rows, 4);
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:530: if (tile < CORPSE_PATTERN)
	ld	-4 (ix), a
	sub	a, #0x60
	jr	nc, 00106$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:532: for (offset = 0; offset < 32; offset += 4)
	ld	-3 (ix), #0x00
00107$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:534: corpse_read_row(rows, ((unsigned int)tile << 5) + offset);
	ld	l, -4 (ix)
	ld	h, #0x00
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	ld	a, l
	ld	d, h
	ld	l, -3 (ix)
	ld	h, #0x00
	add	a, l
	ld	e, a
	jr	nc, 00143$
	inc	d
00143$:
	push	hl
	push	bc
	ld	hl, #4
	add	hl, sp
	call	_corpse_read_row
	pop	bc
	pop	hl
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:535: SMS_VRAMmemcpy(((unsigned int)next_tile << 5) + offset, rows, 4);
	ld	a, 4 (ix)
	ld	-2 (ix), a
	ld	-1 (ix), #0x00
	ld	e, -2 (ix)
	ld	d, #0x00
	ex	de, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	ex	de, hl
	add	hl, de
	push	bc
	ld	de, #0x0004
	ex	de, hl
	push	hl
	ld	hl, #4
	add	hl, sp
	ex	de, hl
	call	_SMS_VRAMmemcpy
	pop	bc
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:532: for (offset = 0; offset < 32; offset += 4)
	ld	a, -3 (ix)
	add	a, #0x04
	ld	-3 (ix), a
	sub	a, #0x20
	jr	c, 00107$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:537: SMS_VRAMmemsetW(address, next_tile, 2);
	push	bc
	ld	hl, #0x0002
	push	hl
	ld	e, -2 (ix)
	ld	d, #0x00
	ld	l, -6 (ix)
	ld	h, -5 (ix)
	call	_SMS_VRAMmemsetW
	pop	bc
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:538: tile = next_tile++;
	ld	e, 4 (ix)
	ld	a, e
	inc	a
	ld	4 (ix), a
	ld	-4 (ix), e
00106$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:540: address = ((unsigned int)tile << 5) + ((y & 7) << 2);
	ld	e, -4 (ix)
	ld	d, #0x00
	ex	de, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	ex	de, hl
	ld	a, b
	ld	b, #0x00
	and	a, #0x07
	ld	h, #0x00
	ld	l, a
	add	hl, hl
	add	hl, hl
	add	hl, de
	push	hl
	pop	iy
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:541: corpse_read_row(rows, address);
	push	bc
	push	iy
	push	iy
	pop	de
	ld	hl, #4
	add	hl, sp
	call	_corpse_read_row
	pop	iy
	pop	bc
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:542: mask = 0x80 >> (x & 7);
	ld	a, c
	and	a, #0x07
	ld	b, a
	ld	de, #0x0080
	inc	b
	jr	00145$
00144$:
	sra	d
	rr	e
00145$:
	djnz	00144$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:543: rows[0] |= mask;
	ld	a, -10 (ix)
	or	a, e
	ld	-10 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:544: rows[1] &= ~mask;
	ld	b, -9 (ix)
	ld	a, e
	cpl
	ld	c, a
	ld	a, b
	and	a, c
	ld	-9 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:545: rows[2] |= mask;
	ld	a, -8 (ix)
	or	a, e
	ld	-8 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:546: rows[3] &= ~mask;
	ld	a, -7 (ix)
	and	a, c
	ld	-7 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:547: SMS_VRAMmemcpy(address, rows, 4);
	ld	hl, #0x0004
	push	hl
	ld	hl, #2
	add	hl, sp
	push	iy
	ex	de, hl
	pop	hl
	call	_SMS_VRAMmemcpy
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:548: return next_tile;
	ld	a, 4 (ix)
00109$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:549: }
	ld	sp, ix
	pop	ix
	pop	hl
	inc	sp
	jp	(hl)
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:551: static void draw_corpses(unsigned char origin_x, unsigned char origin_y)
;	---------------------------------
; Function draw_corpses
; ---------------------------------
_draw_corpses:
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	iy, #-14
	add	iy, sp
	ld	sp, iy
	ld	-1 (ix), a
	ld	-2 (ix), l
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:554: unsigned char count = world_sprite_get_count();
	call	_world_sprite_get_count
	ld	c, a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:555: unsigned char next_tile = CORPSE_PATTERN;
	ld	e, #0x60
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:559: for (i = 0; i < count; ++i)
	ld	b, #0x00
00113$:
	ld	a, b
	sub	a, c
	jp	nc, 00114$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:561: sprite = world_sprite_get(i);
	push	bc
	push	de
	ld	a, b
	call	_world_sprite_get
	ld	-4 (ix), e
	ld	-3 (ix), d
	pop	de
	pop	bc
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:562: if (WORLD_SPRITE_LIFE_STATE(sprite) != ZOMBIE_STATE_CORPSE) continue;
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	push	bc
	ld	bc, #0x0006
	add	hl, bc
	pop	bc
	ld	a, (hl)
	and	a, #0x03
	cp	a, #0x02
	jp	nz, 00110$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:563: if (((unsigned int)sprite->world_x >> 8) < origin_x) continue;
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	ld	a, (hl)
	inc	hl
	ld	d, (hl)
	ld	-14 (ix), a
	ld	-13 (ix), d
	ld	-12 (ix), d
	ld	-11 (ix), #0x00
	ld	a, -1 (ix)
	ld	-10 (ix), a
	ld	-9 (ix), #0x00
	ld	a, -12 (ix)
	sub	a, -10 (ix)
	jp	c, 00110$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:564: if (((unsigned int)sprite->world_y >> 8) < origin_y) continue;
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	inc	hl
	inc	hl
	ld	a, (hl)
	inc	hl
	ld	d, (hl)
	ld	-8 (ix), a
	ld	-7 (ix), d
	ld	-6 (ix), d
	ld	-5 (ix), #0x00
	ld	a, -2 (ix)
	ld	-4 (ix), a
	ld	-3 (ix), #0x00
	ld	a, -6 (ix)
	sub	a, -4 (ix)
	jp	c, 00110$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:565: if (((unsigned int)sprite->world_x >> 8) >= origin_x + MAP_COLUMNS
	ld	a, -1 (ix)
	ld	h, #0x00
	add	a, #0x0d
	ld	l, a
	jr	nc, 00175$
	inc	h
00175$:
	ld	a, -12 (ix)
	sub	a, l
	ld	a, #0x00
	sbc	a, h
	jp	nc, 00110$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:566: || ((unsigned int)sprite->world_y >> 8) >= origin_y + MAP_HEIGHT) continue;
	ld	a, -2 (ix)
	ld	h, #0x00
	add	a, #0x08
	ld	l, a
	jr	nc, 00176$
	inc	h
00176$:
	ld	a, -6 (ix)
	sub	a, l
	ld	a, #0x00
	sbc	a, h
	jr	nc, 00110$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:567: x = ((unsigned int)sprite->world_x - ((unsigned int)origin_x << 8)) >> PAUSE_MAP_WORLD_SHIFT;
	ld	h, -10 (ix)
	ld	d, #0x00
	ld	a, -14 (ix)
	sub	a, d
	ld	l, a
	ld	a, -13 (ix)
	sbc	a, h
	ld	h, a
	add	hl, hl
	add	hl, hl
	add	hl, hl
	ld	-5 (ix), h
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:568: y = ((unsigned int)sprite->world_y - ((unsigned int)origin_y << 8)) >> PAUSE_MAP_WORLD_SHIFT;
	ld	h, -4 (ix)
	ld	l, #0x00
	ld	a, -8 (ix)
	sub	a, l
	ld	l, a
	ld	a, -7 (ix)
	sbc	a, h
	ld	h, a
	add	hl, hl
	add	hl, hl
	add	hl, hl
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:569: next_tile = corpse_pixel(x - 1, y - 1, next_tile);
	ld	-4 (ix), h
	ld	d, h
	ld	l, d
	dec	l
	ld	h, -5 (ix)
	ld	a, h
	add	a, #0xff
	ld	-3 (ix), a
	push	hl
	push	bc
	push	de
	ld	a, e
	push	af
	inc	sp
	ld	a, -3 (ix)
	call	_corpse_pixel
	pop	de
	pop	bc
	pop	hl
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:570: next_tile = corpse_pixel(x + 1, y - 1, next_tile);
	ld	e, h
	inc	e
	push	bc
	push	de
	push	af
	inc	sp
	ld	a, e
	call	_corpse_pixel
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:571: next_tile = corpse_pixel(x, y, next_tile);
	push	af
	inc	sp
	ld	l, -4 (ix)
	ld	a, -5 (ix)
	call	_corpse_pixel
	pop	de
	pop	bc
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:572: next_tile = corpse_pixel(x - 1, y + 1, next_tile);
	inc	d
	push	bc
	push	de
	push	af
	inc	sp
	ld	l, d
	ld	a, -3 (ix)
	call	_corpse_pixel
	pop	de
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:573: next_tile = corpse_pixel(x + 1, y + 1, next_tile);
	push	af
	inc	sp
	ld	l, d
	ld	a, e
	call	_corpse_pixel
	ld	e, a
	pop	bc
00110$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:559: for (i = 0; i < count; ++i)
	inc	b
	jp	00113$
00114$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:575: }
	ld	sp, ix
	pop	ix
	ret
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:576: static unsigned char pan_axis(unsigned char origin, unsigned char extent,
;	---------------------------------
; Function pan_axis
; ---------------------------------
_pan_axis:
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	c, a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:580: if (negative != 0 && positive == 0 && origin != 0) return origin - 1;
	ld	b, c
	ld	a, 5 (ix)
	or	a, a
	jr	z, 00102$
	ld	a, 6 (ix)
	or	a, a
	jr	nz, 00102$
	or	a, c
	jr	z, 00102$
	ld	a, b
	dec	a
	jr	00110$
00102$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:581: if (positive != 0 && negative == 0 && extent > capacity && origin < extent - capacity)
	ld	a, 6 (ix)
	or	a, a
	jr	z, 00106$
	ld	a, 5 (ix)
	or	a, a
	jr	nz, 00106$
	ld	a, 4 (ix)
	sub	a, l
	jr	nc, 00106$
	ld	h, #0x00
	ld	e, 4 (ix)
	ld	d, #0x00
	cp	a, a
	sbc	hl, de
	ld	e, c
	ld	d, #0x00
	ld	a, e
	sub	a, l
	ld	a, d
	sbc	a, h
	jp	po, 00168$
	xor	a, #0x80
00168$:
	jp	p, 00106$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:582: return origin + 1;
	ld	a, b
	inc	a
	jr	00110$
00106$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:583: return origin;
	ld	a, c
00110$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:584: }
	pop	ix
	pop	hl
	pop	bc
	inc	sp
	jp	(hl)
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:586: void game_gear_pause_map_show(void)
;	---------------------------------
; Function game_gear_pause_map_show
; ---------------------------------
_game_gear_pause_map_show::
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	hl, #-11
	add	hl, sp
	ld	sp, hl
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:588: unsigned int player_x = player_get_position_x();
	call	_player_get_position_x
	pop	hl
	push	de
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:589: unsigned int player_y = player_get_position_y();
	call	_player_get_position_y
	ld	-9 (ix), e
	ld	-8 (ix), d
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:590: unsigned char facing = player_facing();
	call	_player_facing
	ld	-7 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:591: unsigned char origin_x = window_origin(player_x >> 8, WORLD_WIDTH, AUTOMAP_COLUMNS);
	ld	a, -10 (ix)
	ld	h, #0x0e
	push	hl
	inc	sp
	ld	l, #0x0d
	call	_window_origin
	ld	-6 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:592: unsigned char origin_y = window_origin(player_y >> 8, WORLD_HEIGHT, AUTOMAP_ROWS);
	ld	a, -8 (ix)
	ld	h, #0x08
	push	hl
	inc	sp
	ld	l, #0x0d
	call	_window_origin
	ld	-5 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:593: unsigned char state = WEAPONS_FOCUS;
	ld	-4 (ix), #0x01
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:594: unsigned char repeat = 0;
	ld	-1 (ix), #0x00
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:595: unsigned char directions = 0;
	ld	-3 (ix), #0x00
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:600: SMS_displayOff();
	ld	hl, #0x0140
	call	_SMS_VDPturnOffFeature
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:601: SMS_setBGScrollX(SCROLL_X);
	ld	l, #0x04
	call	_SMS_setBGScrollX
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:602: SMS_setBGScrollY(SCROLL_Y);
	ld	l, #0x00
	call	_SMS_setBGScrollY
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:603: SMS_VRAMmemsetW(0, 0, 16384);
	ld	hl, #0x4000
	push	hl
	ld	de, #0x0000
	ld	h, l
	call	_SMS_VRAMmemsetW
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:604: load_ui();
	call	_load_ui
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:605: draw_window(origin_x, origin_y);
	ld	l, -5 (ix)
	ld	a, -6 (ix)
	call	_draw_window
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:606: draw_corpses(origin_x, origin_y);
	ld	l, -5 (ix)
	ld	a, -6 (ix)
	call	_draw_corpses
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:607: place_player(player_x, player_y, facing, origin_x, origin_y);
	ld	h, -5 (ix)
	ld	l, -6 (ix)
	push	hl
	ld	a, -7 (ix)
	push	af
	inc	sp
	ld	e, -9 (ix)
	ld	d, -8 (ix)
	ld	l, -11 (ix)
	ld	h, -10 (ix)
	call	_place_player
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:608: SMS_waitForVBlank();
	call	_SMS_waitForVBlank
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:609: SMS_displayOn();
	ld	hl, #0x0140
	call	_SMS_VDPturnOnFeature
00136$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:613: SMS_waitForVBlank();
	call	_SMS_waitForVBlank
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:614: game_gear_input_update();
	call	_game_gear_input_update
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:615: if (input_pause_requested()) break;
	call	_input_pause_requested
	ld	c, a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:616: pressed = (unsigned char)(keys & ~previous_keys);
	ld	a, (_keys+0)
	ld	-2 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:615: if (input_pause_requested()) break;
	ld	a, c
	or	a, a
	jp	nz, 00135$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:616: pressed = (unsigned char)(keys & ~previous_keys);
	ld	a, (_previous_keys)
	cpl
	and	a, -2 (ix)
	ld	c, a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:617: if (state != MAP_BROWSE)
	ld	a, -4 (ix)
	sub	a, #0x02
	jp	z, 00121$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:619: if ((pressed & PORT_A_KEY_UP) != 0 && state == WEAPONS_FOCUS)
	ld	a, -4 (ix)
	dec	a
	ld	a, #0x01
	jr	z, 00277$
	xor	a, a
00277$:
	ld	b, a
	bit	0, c
	jr	z, 00117$
	ld	a, b
	or	a, a
	jr	z, 00117$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:621: draw_focus(state, 0);
	ld	l, #0x00
	ld	a, -4 (ix)
	call	_draw_focus
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:622: state = MAP_FOCUS;
	ld	-4 (ix), #0x00
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:623: draw_focus(state, 1);
	ld	l, #0x01
	xor	a, a
	call	_draw_focus
	jr	00136$
00117$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:625: else if ((pressed & PORT_A_KEY_DOWN) != 0 && state == MAP_FOCUS)
	bit	1, c
	jr	z, 00113$
	ld	a, -4 (ix)
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:627: draw_focus(state, 0);
	or	a,a
	jr	nz, 00113$
	ld	l, a
	call	_draw_focus
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:628: state = WEAPONS_FOCUS;
	ld	-4 (ix), #0x01
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:629: draw_focus(state, 1);
	ld	a,#0x01
	ld	l,a
	call	_draw_focus
	jr	00136$
00113$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:631: else if ((pressed & PORT_A_KEY_1) != 0 && state == MAP_FOCUS)
	bit	4, c
	jr	z, 00109$
	ld	a, -4 (ix)
	or	a, a
	jr	nz, 00109$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:633: state = MAP_BROWSE;
	ld	-4 (ix), #0x02
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:634: directions = 0;
	ld	-3 (ix), #0x00
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:635: repeat = 0;
	ld	-1 (ix), #0x00
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:636: draw_focus(state, 1);
	ld	l, #0x01
	ld	a, #0x02
	call	_draw_focus
	jp	00136$
00109$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:639: && ((pressed & PORT_A_KEY_LEFT) != 0) != ((pressed & PORT_A_KEY_RIGHT) != 0))
	ld	a, b
	or	a, a
	jp	z, 00136$
	ld	e, c
	ld	a, e
	and	a, #0x04
	sub	a, #0x01
	ld	a, #0x00
	rla
	xor	a, #0x01
	ld	b, a
	ld	a, e
	and	a, #0x08
	sub	a, #0x01
	ld	a, #0x00
	rla
	xor	a, #0x01
	sub	a, b
	jp	z, 00136$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:641: unsigned char next_weapon = adjacent_weapon(selected_weapon,
	ld	a, c
	and	a, #0x08
	ld	l, a
	ld	a, (_selected_weapon)
	call	_adjacent_weapon
	ld	c, a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:643: if (next_weapon != selected_weapon)
	ld	a, (_selected_weapon)
	sub	a, c
	jp	z, 00136$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:645: selected_weapon = next_weapon;
	ld	hl, #_selected_weapon
	ld	(hl), c
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:646: draw_weapons();
	call	_draw_weapons
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:649: continue;
	jp	00136$
00121$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:651: if ((pressed & PORT_A_KEY_2) != 0)
	bit	5, c
	jr	z, 00123$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:653: state = MAP_FOCUS;
	ld	-4 (ix), #0x00
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:654: draw_focus(state, 1);
	ld	l, #0x01
	xor	a, a
	call	_draw_focus
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:655: continue;
	jp	00136$
00123$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:657: pressed = (unsigned char)keys & 15;
	ld	a, -2 (ix)
	and	a, #0x0f
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:658: if (pressed == 0)
	ld	c, a
	or	a, a
	jr	nz, 00125$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:660: directions = 0;
	ld	-3 (ix), #0x00
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:661: repeat = 0;
	ld	-1 (ix), #0x00
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:662: continue;
	jp	00136$
00125$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:664: if (pressed != directions)
	ld	a, -3 (ix)
	sub	a, c
	jr	z, 00129$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:666: directions = pressed;
	ld	-3 (ix), c
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:667: repeat = PAN_INITIAL_DELAY;
	ld	-1 (ix), #0x0c
	jr	00130$
00129$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:671: if (--repeat != 0) continue;
	dec	-1 (ix)
	jp	nz, 00136$
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:672: repeat = PAN_REPEAT_DELAY;
	ld	-1 (ix), #0x04
00130$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:675: pressed & PORT_A_KEY_LEFT, pressed & PORT_A_KEY_RIGHT);
	ld	a, c
	and	a, #0x08
	ld	b, a
	ld	a, c
	and	a, #0x04
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:674: next_x = pan_axis(origin_x, WORLD_WIDTH, AUTOMAP_COLUMNS,
	push	bc
	push	bc
	inc	sp
	ld	h, a
	ld	l, #0x0e
	push	hl
	ld	l, #0x0d
	ld	a, -6 (ix)
	call	_pan_axis
	ld	h, a
	pop	bc
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:677: pressed & PORT_A_KEY_UP, pressed & PORT_A_KEY_DOWN);
	ld	a, c
	and	a, #0x02
	ld	b, a
	ld	a, c
	and	a, #0x01
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:676: next_y = pan_axis(origin_y, WORLD_HEIGHT, AUTOMAP_ROWS,
	push	hl
	push	bc
	inc	sp
	ld	h, a
	ld	l, #0x08
	push	hl
	ld	l, #0x0d
	ld	a, -5 (ix)
	call	_pan_axis
	ld	l, a
	pop	af
	ld	h, a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:678: if (next_x == origin_x && next_y == origin_y) continue;
	ld	a, -6 (ix)
	sub	a, h
	jr	nz, 00132$
	ld	a, -5 (ix)
	sub	a, l
	jp	z, 00136$
00132$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:679: origin_x = next_x;
	ld	-6 (ix), h
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:680: origin_y = next_y;
	ld	-5 (ix), l
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:681: draw_window(origin_x, origin_y);
	push	hl
	ld	a, h
	call	_draw_window
	pop	hl
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:682: draw_corpses(origin_x, origin_y);
	push	hl
	ld	a, h
	call	_draw_corpses
	pop	hl
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:683: place_player(player_x, player_y, facing, origin_x, origin_y);
	ld	a, l
	push	af
	inc	sp
	push	hl
	inc	sp
	ld	a, -7 (ix)
	push	af
	inc	sp
	ld	e, -9 (ix)
	ld	d, -8 (ix)
	ld	l, -11 (ix)
	ld	h, -10 (ix)
	call	_place_player
	jp	00136$
00135$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:687: input_blocked |= (unsigned char)keys & 63;
	ld	a, -2 (ix)
	and	a, #0x3f
	ld	c, a
	ld	a, (_input_blocked)
	or	a, c
	ld	(#_input_blocked), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:688: keys &= GG_KEY_START;
	xor	a, a
	ld	(_keys+0), a
	ld	a, (_keys+1)
	and	a, #0x80
	ld	(_keys+1), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:689: previous_keys &= GG_KEY_START;
	xor	a, a
	ld	(_previous_keys+0), a
	ld	a, (_previous_keys+1)
	and	a, #0x80
	ld	(_previous_keys+1), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:690: SMS_displayOff();
	ld	hl, #0x0140
	call	_SMS_VDPturnOffFeature
;D:/mano_projektai/GearRay/build-astra-final-control-source/platform/game_gear/pause_map.c:691: }
	ld	sp, ix
	pop	ix
	ret
	.area _BANK2
	.area _BANK2
	.area _INITIALIZER
	.area _CABS (ABS)
