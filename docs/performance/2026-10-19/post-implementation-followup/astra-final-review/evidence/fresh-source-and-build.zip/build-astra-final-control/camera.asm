;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (MINGW64)
;--------------------------------------------------------
	.module camera
	
	.optsdcc -mz80 sdcccall(1)
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _SMS_SRAM
	.globl _SRAM_bank_to_be_mapped_on_slot2
	.globl _ROM_bank_to_be_mapped_on_slot0
	.globl _ROM_bank_to_be_mapped_on_slot1
	.globl _ROM_bank_to_be_mapped_on_slot2
	.globl _camera_initialize
	.globl _camera_set_fixed_position
	.globl _camera_rotate_left
	.globl _camera_rotate_right
	.globl _camera_get_position_x
	.globl _camera_get_position_y
	.globl _camera_get_direction_x
	.globl _camera_get_direction_y
	.globl _camera_get_plane_x
	.globl _camera_get_plane_y
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
_SMS_VDPControlPort	=	0x00bf
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
_position_x:
	.ds 2
_position_y:
	.ds 2
_direction_x:
	.ds 2
_direction_y:
	.ds 2
_plane_x:
	.ds 2
_plane_y:
	.ds 2
_ROM_bank_to_be_mapped_on_slot2	=	0xffff
_ROM_bank_to_be_mapped_on_slot1	=	0xfffe
_ROM_bank_to_be_mapped_on_slot0	=	0xfffd
_SRAM_bank_to_be_mapped_on_slot2	=	0xfffc
_SMS_SRAM	=	0x8000
_camera_graph_state:
	.ds 1
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute ram data
;--------------------------------------------------------
	.area _DABS (ABS)
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:20: static void camera_rotate(unsigned char right)
;	---------------------------------
; Function camera_rotate
; ---------------------------------
_camera_rotate:
	ld	e, a
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:24: SMS_mapROMBank(2);
	ld	hl, #_ROM_bank_to_be_mapped_on_slot2
	ld	(hl), #0x02
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:25: camera_graph_state = camera_graph_edges[camera_graph_state][right];
	ld	bc, #_camera_graph_edges+0
	ld	a, (_camera_graph_state)
	ld	l, a
	ld	h, #0x00
	add	hl, hl
	add	hl, bc
	ld	d, #0x00
	add	hl, de
	ld	a, (hl)
	ld	(#_camera_graph_state), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:26: state = camera_graph_vectors[camera_graph_state];
	ld	bc, #_camera_graph_vectors+0
	ld	a, (_camera_graph_state)
	ld	l, a
	ld	h, #0x00
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, bc
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:27: direction_x = state[0];
	ld	e, l
	ld	d, h
	ld	a, (hl)
	inc	hl
	ld	(_direction_x+0), a
	ld	a, (hl)
	ld	(_direction_x+1), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:28: direction_y = state[1];
	ld	l, e
	ld	h, d
	inc	hl
	inc	hl
	ld	a, (hl)
	inc	hl
	ld	(_direction_y+0), a
	ld	a, (hl)
	ld	(_direction_y+1), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:29: plane_x = state[2];
	ld	c, e
	ld	b, d
	ld	hl, #4
	add	hl, bc
	ld	a, (hl)
	inc	hl
	ld	(_plane_x+0), a
	ld	a, (hl)
	ld	(_plane_x+1), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:30: plane_y = state[3];
	ld	hl, #6
	add	hl, de
	ld	a, (hl)
	inc	hl
	ld	(_plane_y+0), a
	ld	a, (hl)
	ld	(_plane_y+1), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:31: }
	ret
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:33: void camera_initialize(void)
;	---------------------------------
; Function camera_initialize
; ---------------------------------
_camera_initialize::
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:35: camera_graph_state = 0;
	xor	a, a
	ld	(#_camera_graph_state), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:36: position_x = 1280;
	ld	hl, #0x0500
	ld	(_position_x), hl
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:37: position_y = 1024;
	ld	h, #0x04
	ld	(_position_y), hl
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:38: direction_x = 0;
	ld	h, l
	ld	(_direction_x), hl
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:39: direction_y = -DIRECTION_LENGTH;
	ld	h, #0xff
	ld	(_direction_y), hl
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:40: plane_x = CAMERA_PLANE_LENGTH;
	ld	hl, #0x00a9
	ld	(_plane_x), hl
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:41: plane_y = 0;
	ld	l, h
	ld	(_plane_y), hl
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:42: }
	ret
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:44: void camera_set_fixed_position(signed int fixed_position_x,
;	---------------------------------
; Function camera_set_fixed_position
; ---------------------------------
_camera_set_fixed_position::
	ld	(_position_x), hl
	ld	(_position_y), de
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:48: position_y = fixed_position_y;
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:49: }
	ret
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:51: void camera_rotate_left(void)
;	---------------------------------
; Function camera_rotate_left
; ---------------------------------
_camera_rotate_left::
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:53: camera_rotate(0);
	xor	a, a
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:54: }
	jp	_camera_rotate
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:56: void camera_rotate_right(void)
;	---------------------------------
; Function camera_rotate_right
; ---------------------------------
_camera_rotate_right::
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:58: camera_rotate(1);
	ld	a, #0x01
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:59: }
	jp	_camera_rotate
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:61: signed int camera_get_position_x(void)
;	---------------------------------
; Function camera_get_position_x
; ---------------------------------
_camera_get_position_x::
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:63: return position_x;
	ld	de, (_position_x)
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:64: }
	ret
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:66: signed int camera_get_position_y(void)
;	---------------------------------
; Function camera_get_position_y
; ---------------------------------
_camera_get_position_y::
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:68: return position_y;
	ld	de, (_position_y)
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:69: }
	ret
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:71: signed int camera_get_direction_x(void)
;	---------------------------------
; Function camera_get_direction_x
; ---------------------------------
_camera_get_direction_x::
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:73: return direction_x;
	ld	de, (_direction_x)
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:74: }
	ret
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:76: signed int camera_get_direction_y(void)
;	---------------------------------
; Function camera_get_direction_y
; ---------------------------------
_camera_get_direction_y::
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:78: return direction_y;
	ld	de, (_direction_y)
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:79: }
	ret
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:81: signed int camera_get_plane_x(void)
;	---------------------------------
; Function camera_get_plane_x
; ---------------------------------
_camera_get_plane_x::
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:83: return plane_x;
	ld	de, (_plane_x)
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:84: }
	ret
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:86: signed int camera_get_plane_y(void)
;	---------------------------------
; Function camera_get_plane_y
; ---------------------------------
_camera_get_plane_y::
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:88: return plane_y;
	ld	de, (_plane_y)
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/camera.c:89: }
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
