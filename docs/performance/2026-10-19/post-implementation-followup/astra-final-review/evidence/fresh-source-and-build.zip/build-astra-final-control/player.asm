;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (MINGW64)
;--------------------------------------------------------
	.module player
	
	.optsdcc -mz80 sdcccall(1)
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl b_world_interact
	.globl _world_interact
	.globl _world_get_spawn_y
	.globl _world_get_spawn_x
	.globl _world_is_wall
	.globl b_interaction_ray_cast
	.globl _interaction_ray_cast
	.globl _input_interaction_requested
	.globl _camera_get_plane_y
	.globl _camera_get_plane_x
	.globl _camera_get_direction_y
	.globl _camera_get_direction_x
	.globl _player_initialize
	.globl _player_move_combined
	.globl _player_process_interaction
	.globl _player_get_position_x
	.globl _player_get_position_y
	.globl _player_get_health
	.globl _player_apply_damage
	.globl _player_is_dead
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
_player_position_x:
	.ds 2
_player_position_y:
	.ds 2
_player_health:
	.ds 1
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute ram data
;--------------------------------------------------------
	.area _DABS (ABS)
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:16: static signed int player_scale_movement(signed int direction,
;	---------------------------------
; Function player_scale_movement
; ---------------------------------
_player_scale_movement:
	push	ix
	ld	ix,	#0
	add	ix, sp
	push	af
	push	af
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:19: signed int movement = direction * PLAYER_MOVE_SPEED;
	ld	c, l
	ld	b, h
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, bc
	add	hl, hl
	add	hl, hl
	add	hl, bc
	add	hl, hl
	ex	(sp), hl
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:22: movement -= direction_scale / 2;
	ld	a, d
	rlca
	and	a, #0x01
	ld	c, a
	ld	l, e
	ld	h, d
	inc	hl
	ld	-2 (ix), l
	ld	-1 (ix), h
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:21: if (movement < 0)
	bit	7, -3 (ix)
	jr	z, 00102$
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:22: movement -= direction_scale / 2;
	ld	l, e
	ld	h, d
	ld	a, c
	or	a, a
	jr	z, 00106$
	ld	l, -2 (ix)
	ld	h, -1 (ix)
00106$:
	sra	h
	rr	l
	ld	a, -4 (ix)
	sub	a, l
	ld	l, a
	ld	a, -3 (ix)
	sbc	a, h
	ld	h, a
	jr	00103$
00102$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:24: movement += direction_scale / 2;
	ld	a, e
	ld	b, d
	inc	c
	dec	c
	jr	z, 00107$
	ld	a, -2 (ix)
	ld	b, -1 (ix)
00107$:
	ld	c, a
	sra	b
	rr	c
	pop	hl
	push	hl
	add	hl, bc
00103$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:26: return (signed int)(movement / direction_scale);
	call	__divsint
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:27: }
	ld	sp, ix
	pop	ix
	ret
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:29: static signed int player_scale_diagonal(signed int movement)
;	---------------------------------
; Function player_scale_diagonal
; ---------------------------------
_player_scale_diagonal:
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:31: signed int scaled_movement = movement * PLAYER_DIAGONAL_SCALE;
	ld	c, l
	ld	b, h
	add	hl, hl
	add	hl, hl
	add	hl, bc
	add	hl, hl
	add	hl, bc
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, bc
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:33: if (scaled_movement < 0)
	bit	7, h
	jr	z, 00102$
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:34: scaled_movement -= FIXED_POINT_SCALE / 2;
	ld	a, l
	add	a, #0x80
	ld	l, a
	ld	a, h
	adc	a, #0xff
	ld	h, a
	jr	00103$
00102$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:36: scaled_movement += FIXED_POINT_SCALE / 2;
	ld	bc, #0x0080
	add	hl, bc
00103$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:38: return (signed int)(scaled_movement / FIXED_POINT_SCALE);
	ld	b, h
	bit	7, h
	jr	z, 00106$
	ld	c, l
	ld	b, h
	dec	bc
	inc	b
00106$:
	ld	a, b
	rlca
	sbc	a, a
	ld	d, a
	ld	e, b
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:39: }
	ret
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:41: static unsigned char player_position_is_clear(signed int position_x,
;	---------------------------------
; Function player_position_is_clear
; ---------------------------------
_player_position_is_clear:
	push	ix
	ld	ix,	#0
	add	ix, sp
	push	af
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:44: unsigned char left_map_x = (unsigned char)(
	ld	a, l
	add	a, #0xe0
	ld	-2 (ix), a
	ld	a, h
	adc	a, #0xff
	ld	-1 (ix), a
	pop	bc
	push	bc
	bit	7, -1 (ix)
	jr	z, 00103$
	pop	bc
	push	bc
	dec	bc
	inc	b
00103$:
	ld	-2 (ix), b
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:46: unsigned char right_map_x = (unsigned char)(
	ld	bc, #0x0020
	add	hl, bc
	ld	b, h
	bit	7, h
	jr	z, 00104$
	ld	c, l
	ld	b, h
	dec	bc
	inc	b
00104$:
	ld	-1 (ix), b
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:48: unsigned char top_map_y = (unsigned char)(
	ld	a, e
	add	a, #0xe0
	ld	c, a
	ld	a, d
	adc	a, #0xff
	ld	b, a
	ld	h, b
	bit	7, b
	jr	z, 00105$
	ld	l, c
	ld	h, b
	dec	hl
	inc	h
00105$:
	ld	c, h
	ld	a, c
	rlca
	sbc	a, a
	ld	b, a
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:50: unsigned char bottom_map_y = (unsigned char)(
	ld	hl, #0x0020
	add	hl, de
	ld	d, h
	bit	7, h
	jr	z, 00106$
	ex	de, hl
	dec	de
	inc	d
00106$:
	ld	e, d
	ld	a, e
	rlca
	sbc	a, a
	ld	d, a
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:53: return !world_is_wall(left_map_x, top_map_y)
	push	bc
	push	de
	ld	l, c
	ld	a, -2 (ix)
	call	_world_is_wall
	pop	de
	pop	bc
	or	a, a
	jr	nz, 00107$
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:54: && !world_is_wall(right_map_x, top_map_y)
	push	de
	ld	l, c
	ld	a, -1 (ix)
	call	_world_is_wall
	pop	de
	or	a, a
	jr	nz, 00107$
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:55: && !world_is_wall(left_map_x, bottom_map_y)
	push	de
	ld	l, e
	ld	a, -2 (ix)
	call	_world_is_wall
	pop	de
	or	a, a
	jr	nz, 00107$
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:56: && !world_is_wall(right_map_x, bottom_map_y);
	ld	l, e
	ld	a, -1 (ix)
	call	_world_is_wall
	or	a, a
	jr	z, 00108$
00107$:
	xor	a, a
	jr	00109$
00108$:
	ld	a, #0x01
00109$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:57: }
	ld	sp, ix
	pop	ix
	ret
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:59: static void player_move_by(signed int movement_x, signed int movement_y)
;	---------------------------------
; Function player_move_by
; ---------------------------------
_player_move_by:
	push	ix
	ld	ix,	#0
	add	ix, sp
	push	af
	ld	c, l
	ld	b, h
	pop	hl
	push	de
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:63: candidate_position = player_position_x + movement_x;
	ld	hl, (_player_position_x)
	add	hl, bc
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:65: if (player_position_is_clear(candidate_position, player_position_y))
	push	hl
	ld	de, (_player_position_y)
	call	_player_position_is_clear
	pop	hl
	or	a, a
	jr	z, 00102$
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:66: player_position_x = candidate_position;
	ld	(_player_position_x), hl
00102$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:68: candidate_position = player_position_y + movement_y;
	ld	a, (_player_position_y+0)
	add	a, -2 (ix)
	ld	e, a
	ld	a, (_player_position_y+1)
	adc	a, -1 (ix)
	ld	d, a
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:70: if (player_position_is_clear(player_position_x, candidate_position))
	push	de
	ld	hl, (_player_position_x)
	call	_player_position_is_clear
	pop	de
	or	a, a
	jr	z, 00105$
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:71: player_position_y = candidate_position;
	ld	(_player_position_y), de
00105$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:72: }
	ld	sp, ix
	pop	ix
	ret
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:74: void player_initialize(void)
;	---------------------------------
; Function player_initialize
; ---------------------------------
_player_initialize::
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:76: player_position_x = world_get_spawn_x() * FIXED_POINT_SCALE
	call	_world_get_spawn_x
	ld	b, a
	ld	c, #0x00
	ld	hl, #0x0080
	add	hl, bc
	ld	(_player_position_x), hl
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:78: player_position_y = world_get_spawn_y() * FIXED_POINT_SCALE
	call	_world_get_spawn_y
	ld	b, a
	ld	c, #0x00
	ld	hl, #0x0080
	add	hl, bc
	ld	(_player_position_y), hl
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:80: player_health = PLAYER_MAX_HEALTH;
	ld	hl, #_player_health
	ld	(hl), #0x64
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:81: }
	ret
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:83: void player_move_combined(signed char forward_direction,
;	---------------------------------
; Function player_move_combined
; ---------------------------------
_player_move_combined::
	push	ix
	ld	ix,	#0
	add	ix, sp
	push	af
	push	af
	push	af
	ld	-5 (ix), a
	ld	-6 (ix), l
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:86: signed int movement_x = 0;
	xor	a, a
	ld	-4 (ix), a
	ld	-3 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:87: signed int movement_y = 0;
	xor	a, a
	ld	-2 (ix), a
	ld	-1 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:89: if (forward_direction != 0)
	ld	a, -5 (ix)
	or	a, a
	jr	z, 00104$
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:91: movement_x = player_scale_movement(camera_get_direction_x(),
	call	_camera_get_direction_x
	ld	-2 (ix), e
	ld	-1 (ix), d
	ld	de, #0x0100
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	call	_player_scale_movement
	ld	-4 (ix), e
	ld	-3 (ix), d
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:93: movement_y = player_scale_movement(camera_get_direction_y(),
	call	_camera_get_direction_y
	ex	de, hl
	ld	de, #0x0100
	call	_player_scale_movement
	ld	-2 (ix), e
	ld	-1 (ix), d
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:96: if (forward_direction < 0)
	bit	7, -5 (ix)
	jr	z, 00104$
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:98: movement_x = -movement_x;
	xor	a, a
	sub	a, -4 (ix)
	ld	-4 (ix), a
	sbc	a, a
	sub	a, -3 (ix)
	ld	-3 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:99: movement_y = -movement_y;
	xor	a, a
	sub	a, -2 (ix)
	ld	-2 (ix), a
	sbc	a, a
	sub	a, -1 (ix)
	ld	-1 (ix), a
00104$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:103: if (strafe_direction != 0)
	ld	a, -6 (ix)
	or	a, a
	jr	z, 00108$
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:105: signed int strafe_x = player_scale_movement(camera_get_plane_x(),
	call	_camera_get_plane_x
	ex	de, hl
	ld	de, #0x00a9
	call	_player_scale_movement
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:107: signed int strafe_y = player_scale_movement(camera_get_plane_y(),
	push	de
	call	_camera_get_plane_y
	ex	de, hl
	ld	de, #0x00a9
	call	_player_scale_movement
	pop	bc
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:110: if (strafe_direction < 0)
	bit	7, -6 (ix)
	jr	z, 00106$
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:112: strafe_x = -strafe_x;
	xor	a, a
	sub	a, c
	ld	c, a
	sbc	a, a
	sub	a, b
	ld	b, a
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:113: strafe_y = -strafe_y;
	ld	hl, #0x0000
	cp	a, a
	sbc	hl, de
	ex	de, hl
00106$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:116: movement_x += strafe_x;
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	add	hl, bc
	ld	-4 (ix), l
	ld	-3 (ix), h
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:117: movement_y += strafe_y;
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	add	hl, de
	ld	-2 (ix), l
	ld	-1 (ix), h
00108$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:120: if (forward_direction != 0 && strafe_direction != 0)
	ld	a, -5 (ix)
	or	a, a
	jr	z, 00110$
	ld	a, -6 (ix)
	or	a, a
	jr	z, 00110$
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:122: movement_x = player_scale_diagonal(movement_x);
	pop	de
	pop	hl
	push	hl
	push	de
	call	_player_scale_diagonal
	ld	-4 (ix), e
	ld	-3 (ix), d
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:123: movement_y = player_scale_diagonal(movement_y);
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	call	_player_scale_diagonal
	ld	-2 (ix), e
	ld	-1 (ix), d
00110$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:126: player_move_by(movement_x, movement_y);
	ld	e, -2 (ix)
	ld	d, -1 (ix)
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	call	_player_move_by
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:127: }
	ld	sp, ix
	pop	ix
	ret
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:129: void player_process_interaction(void)
;	---------------------------------
; Function player_process_interaction
; ---------------------------------
_player_process_interaction::
	push	ix
	ld	ix,	#0
	add	ix, sp
	push	af
	push	af
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:133: if (!input_interaction_requested())
	call	_input_interaction_requested
	or	a, a
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:134: return;
	jr	z, 00105$
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:140: &target))
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:139: camera_get_direction_y(),
	call	_camera_get_direction_y
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:138: camera_get_direction_x(),
	push	de
	call	_camera_get_direction_x
	pop	bc
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:136: if (!interaction_ray_cast(player_position_x,
	ld	hl, #0
	add	hl, sp
	push	hl
	push	bc
	push	de
	ld	hl, (_player_position_y)
	push	hl
	ld	hl, (_player_position_x)
	push	hl
	ld	e, #b_interaction_ray_cast
	ld	hl, #_interaction_ray_cast
	call	___sdcc_bcall_ehl
	ld	hl, #10
	add	hl, sp
	ld	sp, hl
	or	a, a
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:141: return;
	jr	z, 00105$
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:143: world_interact(&target);
	ld	hl, #0
	add	hl, sp
	push	hl
	ld	e, #b_world_interact
	ld	hl, #_world_interact
	call	___sdcc_bcall_ehl
	pop	af
00105$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:144: }
	ld	sp, ix
	pop	ix
	ret
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:146: signed int player_get_position_x(void)
;	---------------------------------
; Function player_get_position_x
; ---------------------------------
_player_get_position_x::
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:148: return player_position_x;
	ld	de, (_player_position_x)
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:149: }
	ret
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:151: signed int player_get_position_y(void)
;	---------------------------------
; Function player_get_position_y
; ---------------------------------
_player_get_position_y::
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:153: return player_position_y;
	ld	de, (_player_position_y)
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:154: }
	ret
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:156: unsigned char player_get_health(void)
;	---------------------------------
; Function player_get_health
; ---------------------------------
_player_get_health::
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:158: return player_health;
	ld	a, (_player_health)
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:159: }
	ret
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:161: void player_apply_damage(unsigned char damage)
;	---------------------------------
; Function player_apply_damage
; ---------------------------------
_player_apply_damage::
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:163: if (damage >= player_health)
	ld	c, a
	ld	hl, #_player_health
	sub	a, (hl)
	jr	c, 00102$
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:164: player_health = 0;
	xor	a, a
	ld	(#_player_health), a
	ret
00102$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:166: player_health -= damage;
	ld	hl, #_player_health
	ld	a, (hl)
	sub	a, c
	ld	(hl), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:167: }
	ret
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:169: unsigned char player_is_dead(void)
;	---------------------------------
; Function player_is_dead
; ---------------------------------
_player_is_dead::
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:171: return player_health == 0;
	ld	a, (_player_health+0)
	or	a, a
	ld	a, #0x01
	ret	z
	xor	a, a
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/player.c:172: }
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
