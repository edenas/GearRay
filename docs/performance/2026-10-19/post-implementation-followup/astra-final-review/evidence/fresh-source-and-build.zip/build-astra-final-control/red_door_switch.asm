;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (MINGW64)
;--------------------------------------------------------
	.module red_door_switch
	
	.optsdcc -mz80 sdcccall(1)
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _door_state_open
	.globl _red_door_switch_initialize
	.globl _red_door_switch_update
	.globl _red_door_switch_activate
	.globl _red_door_switch_get_texture
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
_red_door_switch_state:
	.ds 1
_red_door_switch_frame:
	.ds 1
_red_door_switch_frame_counter:
	.ds 1
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute ram data
;--------------------------------------------------------
	.area _DABS (ABS)
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/red_door_switch.c:11: void red_door_switch_initialize(void)
;	---------------------------------
; Function red_door_switch_initialize
; ---------------------------------
_red_door_switch_initialize::
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/red_door_switch.c:13: red_door_switch_state = RED_DOOR_SWITCH_WAITING;
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/red_door_switch.c:14: red_door_switch_frame = 0;
	xor	a, a
	ld	(#_red_door_switch_state), a
	ld	(#_red_door_switch_frame), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/red_door_switch.c:15: red_door_switch_frame_counter = 0;
	xor	a, a
	ld	(#_red_door_switch_frame_counter), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/red_door_switch.c:16: }
	ret
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/red_door_switch.c:18: void red_door_switch_update(void)
;	---------------------------------
; Function red_door_switch_update
; ---------------------------------
_red_door_switch_update::
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/red_door_switch.c:20: ++red_door_switch_frame_counter;
	ld	hl, #_red_door_switch_frame_counter
	inc	(hl)
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/red_door_switch.c:21: if (red_door_switch_frame_counter < RED_DOOR_SWITCH_FRAME_INTERVAL)
	ld	a, (_red_door_switch_frame_counter+0)
	sub	a, #0x06
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/red_door_switch.c:22: return;
	ret	c
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/red_door_switch.c:24: red_door_switch_frame_counter = 0;
	xor	a, a
	ld	(#_red_door_switch_frame_counter), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/red_door_switch.c:25: red_door_switch_frame ^= 1;
	ld	a, (_red_door_switch_frame+0)
	xor	a, #0x01
	ld	(_red_door_switch_frame+0), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/red_door_switch.c:26: }
	ret
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/red_door_switch.c:28: void red_door_switch_activate(void)
;	---------------------------------
; Function red_door_switch_activate
; ---------------------------------
_red_door_switch_activate::
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/red_door_switch.c:30: if (red_door_switch_state == RED_DOOR_SWITCH_ACTIVATED)
	ld	a, (_red_door_switch_state)
	dec	a
	ret	z
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/red_door_switch.c:31: return;
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/red_door_switch.c:33: red_door_switch_state = RED_DOOR_SWITCH_ACTIVATED;
	ld	hl, #_red_door_switch_state
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/red_door_switch.c:34: door_state_open(DOOR_INSTANCE_ROOM_INTERNAL);
	ld	a,#0x01
	ld	(hl),a
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/red_door_switch.c:35: }
	jp	_door_state_open
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/red_door_switch.c:37: unsigned char red_door_switch_get_texture(void)
;	---------------------------------
; Function red_door_switch_get_texture
; ---------------------------------
_red_door_switch_get_texture::
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/red_door_switch.c:39: if (red_door_switch_state == RED_DOOR_SWITCH_ACTIVATED)
	ld	a, (_red_door_switch_state)
	dec	a
	jr	nz, 00102$
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/red_door_switch.c:40: return red_door_switch_frame
	ld	a, (_red_door_switch_frame+0)
	or	a, a
	jr	z, 00105$
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/red_door_switch.c:41: ? RED_DOOR_SWITCH_TEXTURE_ON_FRAME_2
	ld	a, #0x0a
	ret
00105$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/red_door_switch.c:42: : RED_DOOR_SWITCH_TEXTURE_ON_FRAME_1;
	ld	a, #0x09
	ret
00102$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/red_door_switch.c:44: return red_door_switch_frame
	ld	a, (_red_door_switch_frame+0)
	or	a, a
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/red_door_switch.c:45: ? RED_DOOR_SWITCH_TEXTURE_OFF_FRAME_2
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/red_door_switch.c:46: : RED_DOOR_SWITCH_TEXTURE_OFF_FRAME_1;
	ld	a, #0x08
	ret	nz
	ld	a, #0x07
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/red_door_switch.c:47: }
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
