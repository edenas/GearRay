;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (MINGW64)
;--------------------------------------------------------
	.module raycaster
	
	.optsdcc -mz80 sdcccall(1)
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _red_door_switch_get_texture
	.globl _world_is_wall
	.globl _world_get_texture
	.globl _world_get_tile
	.globl _door_state_get
	.globl _camera_get_plane_y
	.globl _camera_get_plane_x
	.globl _camera_get_direction_y
	.globl _camera_get_direction_x
	.globl _camera_get_position_y
	.globl _camera_get_position_x
	.globl _raycaster_initialize
	.globl _raycaster_update
	.globl _raycaster_get_rendered_rays
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
_rendered_rays:
	.ds 168
_ray_direction_x_by_ray:
	.ds 56
_ray_direction_y_by_ray:
	.ds 56
_cached_camera_direction_x:
	.ds 2
_cached_camera_direction_y:
	.ds 2
_cached_camera_plane_x:
	.ds 2
_cached_camera_plane_y:
	.ds 2
_frame_position_x:
	.ds 2
_frame_position_y:
	.ds 2
_ray_directions_valid:
	.ds 1
_ray_output_valid:
	.ds 1
_cached_position_x:
	.ds 2
_cached_position_y:
	.ds 2
_cached_doors:
	.ds 3
_cached_switch_texture:
	.ds 1
_ray_hits_switch:
	.ds 28
_cast_hits_switch:
	.ds 1
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute ram data
;--------------------------------------------------------
	.area _DABS (ABS)
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:106: static unsigned long dda_get_reciprocal(unsigned int direction_magnitude)
;	---------------------------------
; Function dda_get_reciprocal
; ---------------------------------
_dda_get_reciprocal:
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:108: if (direction_magnitude == 0)
	ld	a, h
	or	a, l
	jr	nz, 00102$
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:109: return DDA_INFINITY;
	ld	de, #0xffff
	ld	l, e
	ld	h, e
	ret
00102$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:112: if (direction_magnitude > DDA_RECIPROCAL_MAX_MAGNITUDE)
	xor	a, a
	cp	a, l
	ld	a, #0x02
	sbc	a, h
	jr	nc, 00104$
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:113: direction_magnitude = DDA_RECIPROCAL_MAX_MAGNITUDE;
	ld	hl, #0x0200
00104$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:115: return dda_reciprocal_by_magnitude[direction_magnitude];
	ld	bc, #_dda_reciprocal_by_magnitude+0
	add	hl, hl
	add	hl, hl
	add	hl, bc
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	inc	hl
	ld	c, (hl)
	inc	hl
	ld	h, (hl)
	ld	l, c
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:116: }
	ret
_dda_reciprocal_by_magnitude:
	.byte #0x00, #0x00, #0x00, #0x00	; 0
	.byte #0x00, #0x00, #0x01, #0x00	; 65536
	.byte #0x00, #0x80, #0x00, #0x00	; 32768
	.byte #0x55, #0x55, #0x00, #0x00	; 21845
	.byte #0x00, #0x40, #0x00, #0x00	; 16384
	.byte #0x33, #0x33, #0x00, #0x00	; 13107
	.byte #0xaa, #0x2a, #0x00, #0x00	; 10922
	.byte #0x92, #0x24, #0x00, #0x00	; 9362
	.byte #0x00, #0x20, #0x00, #0x00	; 8192
	.byte #0x71, #0x1c, #0x00, #0x00	; 7281
	.byte #0x99, #0x19, #0x00, #0x00	; 6553
	.byte #0x45, #0x17, #0x00, #0x00	; 5957
	.byte #0x55, #0x15, #0x00, #0x00	; 5461
	.byte #0xb1, #0x13, #0x00, #0x00	; 5041
	.byte #0x49, #0x12, #0x00, #0x00	; 4681
	.byte #0x11, #0x11, #0x00, #0x00	; 4369
	.byte #0x00, #0x10, #0x00, #0x00	; 4096
	.byte #0x0f, #0x0f, #0x00, #0x00	; 3855
	.byte #0x38, #0x0e, #0x00, #0x00	; 3640
	.byte #0x79, #0x0d, #0x00, #0x00	; 3449
	.byte #0xcc, #0x0c, #0x00, #0x00	; 3276
	.byte #0x30, #0x0c, #0x00, #0x00	; 3120
	.byte #0xa2, #0x0b, #0x00, #0x00	; 2978
	.byte #0x21, #0x0b, #0x00, #0x00	; 2849
	.byte #0xaa, #0x0a, #0x00, #0x00	; 2730
	.byte #0x3d, #0x0a, #0x00, #0x00	; 2621
	.byte #0xd8, #0x09, #0x00, #0x00	; 2520
	.byte #0x7b, #0x09, #0x00, #0x00	; 2427
	.byte #0x24, #0x09, #0x00, #0x00	; 2340
	.byte #0xd3, #0x08, #0x00, #0x00	; 2259
	.byte #0x88, #0x08, #0x00, #0x00	; 2184
	.byte #0x42, #0x08, #0x00, #0x00	; 2114
	.byte #0x00, #0x08, #0x00, #0x00	; 2048
	.byte #0xc1, #0x07, #0x00, #0x00	; 1985
	.byte #0x87, #0x07, #0x00, #0x00	; 1927
	.byte #0x50, #0x07, #0x00, #0x00	; 1872
	.byte #0x1c, #0x07, #0x00, #0x00	; 1820
	.byte #0xeb, #0x06, #0x00, #0x00	; 1771
	.byte #0xbc, #0x06, #0x00, #0x00	; 1724
	.byte #0x90, #0x06, #0x00, #0x00	; 1680
	.byte #0x66, #0x06, #0x00, #0x00	; 1638
	.byte #0x3e, #0x06, #0x00, #0x00	; 1598
	.byte #0x18, #0x06, #0x00, #0x00	; 1560
	.byte #0xf4, #0x05, #0x00, #0x00	; 1524
	.byte #0xd1, #0x05, #0x00, #0x00	; 1489
	.byte #0xb0, #0x05, #0x00, #0x00	; 1456
	.byte #0x90, #0x05, #0x00, #0x00	; 1424
	.byte #0x72, #0x05, #0x00, #0x00	; 1394
	.byte #0x55, #0x05, #0x00, #0x00	; 1365
	.byte #0x39, #0x05, #0x00, #0x00	; 1337
	.byte #0x1e, #0x05, #0x00, #0x00	; 1310
	.byte #0x05, #0x05, #0x00, #0x00	; 1285
	.byte #0xec, #0x04, #0x00, #0x00	; 1260
	.byte #0xd4, #0x04, #0x00, #0x00	; 1236
	.byte #0xbd, #0x04, #0x00, #0x00	; 1213
	.byte #0xa7, #0x04, #0x00, #0x00	; 1191
	.byte #0x92, #0x04, #0x00, #0x00	; 1170
	.byte #0x7d, #0x04, #0x00, #0x00	; 1149
	.byte #0x69, #0x04, #0x00, #0x00	; 1129
	.byte #0x56, #0x04, #0x00, #0x00	; 1110
	.byte #0x44, #0x04, #0x00, #0x00	; 1092
	.byte #0x32, #0x04, #0x00, #0x00	; 1074
	.byte #0x21, #0x04, #0x00, #0x00	; 1057
	.byte #0x10, #0x04, #0x00, #0x00	; 1040
	.byte #0x00, #0x04, #0x00, #0x00	; 1024
	.byte #0xf0, #0x03, #0x00, #0x00	; 1008
	.byte #0xe0, #0x03, #0x00, #0x00	; 992
	.byte #0xd2, #0x03, #0x00, #0x00	; 978
	.byte #0xc3, #0x03, #0x00, #0x00	; 963
	.byte #0xb5, #0x03, #0x00, #0x00	; 949
	.byte #0xa8, #0x03, #0x00, #0x00	; 936
	.byte #0x9b, #0x03, #0x00, #0x00	; 923
	.byte #0x8e, #0x03, #0x00, #0x00	; 910
	.byte #0x81, #0x03, #0x00, #0x00	; 897
	.byte #0x75, #0x03, #0x00, #0x00	; 885
	.byte #0x69, #0x03, #0x00, #0x00	; 873
	.byte #0x5e, #0x03, #0x00, #0x00	; 862
	.byte #0x53, #0x03, #0x00, #0x00	; 851
	.byte #0x48, #0x03, #0x00, #0x00	; 840
	.byte #0x3d, #0x03, #0x00, #0x00	; 829
	.byte #0x33, #0x03, #0x00, #0x00	; 819
	.byte #0x29, #0x03, #0x00, #0x00	; 809
	.byte #0x1f, #0x03, #0x00, #0x00	; 799
	.byte #0x15, #0x03, #0x00, #0x00	; 789
	.byte #0x0c, #0x03, #0x00, #0x00	; 780
	.byte #0x03, #0x03, #0x00, #0x00	; 771
	.byte #0xfa, #0x02, #0x00, #0x00	; 762
	.byte #0xf1, #0x02, #0x00, #0x00	; 753
	.byte #0xe8, #0x02, #0x00, #0x00	; 744
	.byte #0xe0, #0x02, #0x00, #0x00	; 736
	.byte #0xd8, #0x02, #0x00, #0x00	; 728
	.byte #0xd0, #0x02, #0x00, #0x00	; 720
	.byte #0xc8, #0x02, #0x00, #0x00	; 712
	.byte #0xc0, #0x02, #0x00, #0x00	; 704
	.byte #0xb9, #0x02, #0x00, #0x00	; 697
	.byte #0xb1, #0x02, #0x00, #0x00	; 689
	.byte #0xaa, #0x02, #0x00, #0x00	; 682
	.byte #0xa3, #0x02, #0x00, #0x00	; 675
	.byte #0x9c, #0x02, #0x00, #0x00	; 668
	.byte #0x95, #0x02, #0x00, #0x00	; 661
	.byte #0x8f, #0x02, #0x00, #0x00	; 655
	.byte #0x88, #0x02, #0x00, #0x00	; 648
	.byte #0x82, #0x02, #0x00, #0x00	; 642
	.byte #0x7c, #0x02, #0x00, #0x00	; 636
	.byte #0x76, #0x02, #0x00, #0x00	; 630
	.byte #0x70, #0x02, #0x00, #0x00	; 624
	.byte #0x6a, #0x02, #0x00, #0x00	; 618
	.byte #0x64, #0x02, #0x00, #0x00	; 612
	.byte #0x5e, #0x02, #0x00, #0x00	; 606
	.byte #0x59, #0x02, #0x00, #0x00	; 601
	.byte #0x53, #0x02, #0x00, #0x00	; 595
	.byte #0x4e, #0x02, #0x00, #0x00	; 590
	.byte #0x49, #0x02, #0x00, #0x00	; 585
	.byte #0x43, #0x02, #0x00, #0x00	; 579
	.byte #0x3e, #0x02, #0x00, #0x00	; 574
	.byte #0x39, #0x02, #0x00, #0x00	; 569
	.byte #0x34, #0x02, #0x00, #0x00	; 564
	.byte #0x30, #0x02, #0x00, #0x00	; 560
	.byte #0x2b, #0x02, #0x00, #0x00	; 555
	.byte #0x26, #0x02, #0x00, #0x00	; 550
	.byte #0x22, #0x02, #0x00, #0x00	; 546
	.byte #0x1d, #0x02, #0x00, #0x00	; 541
	.byte #0x19, #0x02, #0x00, #0x00	; 537
	.byte #0x14, #0x02, #0x00, #0x00	; 532
	.byte #0x10, #0x02, #0x00, #0x00	; 528
	.byte #0x0c, #0x02, #0x00, #0x00	; 524
	.byte #0x08, #0x02, #0x00, #0x00	; 520
	.byte #0x04, #0x02, #0x00, #0x00	; 516
	.byte #0x00, #0x02, #0x00, #0x00	; 512
	.byte #0xfc, #0x01, #0x00, #0x00	; 508
	.byte #0xf8, #0x01, #0x00, #0x00	; 504
	.byte #0xf4, #0x01, #0x00, #0x00	; 500
	.byte #0xf0, #0x01, #0x00, #0x00	; 496
	.byte #0xec, #0x01, #0x00, #0x00	; 492
	.byte #0xe9, #0x01, #0x00, #0x00	; 489
	.byte #0xe5, #0x01, #0x00, #0x00	; 485
	.byte #0xe1, #0x01, #0x00, #0x00	; 481
	.byte #0xde, #0x01, #0x00, #0x00	; 478
	.byte #0xda, #0x01, #0x00, #0x00	; 474
	.byte #0xd7, #0x01, #0x00, #0x00	; 471
	.byte #0xd4, #0x01, #0x00, #0x00	; 468
	.byte #0xd0, #0x01, #0x00, #0x00	; 464
	.byte #0xcd, #0x01, #0x00, #0x00	; 461
	.byte #0xca, #0x01, #0x00, #0x00	; 458
	.byte #0xc7, #0x01, #0x00, #0x00	; 455
	.byte #0xc3, #0x01, #0x00, #0x00	; 451
	.byte #0xc0, #0x01, #0x00, #0x00	; 448
	.byte #0xbd, #0x01, #0x00, #0x00	; 445
	.byte #0xba, #0x01, #0x00, #0x00	; 442
	.byte #0xb7, #0x01, #0x00, #0x00	; 439
	.byte #0xb4, #0x01, #0x00, #0x00	; 436
	.byte #0xb2, #0x01, #0x00, #0x00	; 434
	.byte #0xaf, #0x01, #0x00, #0x00	; 431
	.byte #0xac, #0x01, #0x00, #0x00	; 428
	.byte #0xa9, #0x01, #0x00, #0x00	; 425
	.byte #0xa6, #0x01, #0x00, #0x00	; 422
	.byte #0xa4, #0x01, #0x00, #0x00	; 420
	.byte #0xa1, #0x01, #0x00, #0x00	; 417
	.byte #0x9e, #0x01, #0x00, #0x00	; 414
	.byte #0x9c, #0x01, #0x00, #0x00	; 412
	.byte #0x99, #0x01, #0x00, #0x00	; 409
	.byte #0x97, #0x01, #0x00, #0x00	; 407
	.byte #0x94, #0x01, #0x00, #0x00	; 404
	.byte #0x92, #0x01, #0x00, #0x00	; 402
	.byte #0x8f, #0x01, #0x00, #0x00	; 399
	.byte #0x8d, #0x01, #0x00, #0x00	; 397
	.byte #0x8a, #0x01, #0x00, #0x00	; 394
	.byte #0x88, #0x01, #0x00, #0x00	; 392
	.byte #0x86, #0x01, #0x00, #0x00	; 390
	.byte #0x83, #0x01, #0x00, #0x00	; 387
	.byte #0x81, #0x01, #0x00, #0x00	; 385
	.byte #0x7f, #0x01, #0x00, #0x00	; 383
	.byte #0x7d, #0x01, #0x00, #0x00	; 381
	.byte #0x7a, #0x01, #0x00, #0x00	; 378
	.byte #0x78, #0x01, #0x00, #0x00	; 376
	.byte #0x76, #0x01, #0x00, #0x00	; 374
	.byte #0x74, #0x01, #0x00, #0x00	; 372
	.byte #0x72, #0x01, #0x00, #0x00	; 370
	.byte #0x70, #0x01, #0x00, #0x00	; 368
	.byte #0x6e, #0x01, #0x00, #0x00	; 366
	.byte #0x6c, #0x01, #0x00, #0x00	; 364
	.byte #0x6a, #0x01, #0x00, #0x00	; 362
	.byte #0x68, #0x01, #0x00, #0x00	; 360
	.byte #0x66, #0x01, #0x00, #0x00	; 358
	.byte #0x64, #0x01, #0x00, #0x00	; 356
	.byte #0x62, #0x01, #0x00, #0x00	; 354
	.byte #0x60, #0x01, #0x00, #0x00	; 352
	.byte #0x5e, #0x01, #0x00, #0x00	; 350
	.byte #0x5c, #0x01, #0x00, #0x00	; 348
	.byte #0x5a, #0x01, #0x00, #0x00	; 346
	.byte #0x58, #0x01, #0x00, #0x00	; 344
	.byte #0x57, #0x01, #0x00, #0x00	; 343
	.byte #0x55, #0x01, #0x00, #0x00	; 341
	.byte #0x53, #0x01, #0x00, #0x00	; 339
	.byte #0x51, #0x01, #0x00, #0x00	; 337
	.byte #0x50, #0x01, #0x00, #0x00	; 336
	.byte #0x4e, #0x01, #0x00, #0x00	; 334
	.byte #0x4c, #0x01, #0x00, #0x00	; 332
	.byte #0x4a, #0x01, #0x00, #0x00	; 330
	.byte #0x49, #0x01, #0x00, #0x00	; 329
	.byte #0x47, #0x01, #0x00, #0x00	; 327
	.byte #0x46, #0x01, #0x00, #0x00	; 326
	.byte #0x44, #0x01, #0x00, #0x00	; 324
	.byte #0x42, #0x01, #0x00, #0x00	; 322
	.byte #0x41, #0x01, #0x00, #0x00	; 321
	.byte #0x3f, #0x01, #0x00, #0x00	; 319
	.byte #0x3e, #0x01, #0x00, #0x00	; 318
	.byte #0x3c, #0x01, #0x00, #0x00	; 316
	.byte #0x3b, #0x01, #0x00, #0x00	; 315
	.byte #0x39, #0x01, #0x00, #0x00	; 313
	.byte #0x38, #0x01, #0x00, #0x00	; 312
	.byte #0x36, #0x01, #0x00, #0x00	; 310
	.byte #0x35, #0x01, #0x00, #0x00	; 309
	.byte #0x33, #0x01, #0x00, #0x00	; 307
	.byte #0x32, #0x01, #0x00, #0x00	; 306
	.byte #0x30, #0x01, #0x00, #0x00	; 304
	.byte #0x2f, #0x01, #0x00, #0x00	; 303
	.byte #0x2e, #0x01, #0x00, #0x00	; 302
	.byte #0x2c, #0x01, #0x00, #0x00	; 300
	.byte #0x2b, #0x01, #0x00, #0x00	; 299
	.byte #0x29, #0x01, #0x00, #0x00	; 297
	.byte #0x28, #0x01, #0x00, #0x00	; 296
	.byte #0x27, #0x01, #0x00, #0x00	; 295
	.byte #0x25, #0x01, #0x00, #0x00	; 293
	.byte #0x24, #0x01, #0x00, #0x00	; 292
	.byte #0x23, #0x01, #0x00, #0x00	; 291
	.byte #0x21, #0x01, #0x00, #0x00	; 289
	.byte #0x20, #0x01, #0x00, #0x00	; 288
	.byte #0x1f, #0x01, #0x00, #0x00	; 287
	.byte #0x1e, #0x01, #0x00, #0x00	; 286
	.byte #0x1c, #0x01, #0x00, #0x00	; 284
	.byte #0x1b, #0x01, #0x00, #0x00	; 283
	.byte #0x1a, #0x01, #0x00, #0x00	; 282
	.byte #0x19, #0x01, #0x00, #0x00	; 281
	.byte #0x18, #0x01, #0x00, #0x00	; 280
	.byte #0x16, #0x01, #0x00, #0x00	; 278
	.byte #0x15, #0x01, #0x00, #0x00	; 277
	.byte #0x14, #0x01, #0x00, #0x00	; 276
	.byte #0x13, #0x01, #0x00, #0x00	; 275
	.byte #0x12, #0x01, #0x00, #0x00	; 274
	.byte #0x11, #0x01, #0x00, #0x00	; 273
	.byte #0x0f, #0x01, #0x00, #0x00	; 271
	.byte #0x0e, #0x01, #0x00, #0x00	; 270
	.byte #0x0d, #0x01, #0x00, #0x00	; 269
	.byte #0x0c, #0x01, #0x00, #0x00	; 268
	.byte #0x0b, #0x01, #0x00, #0x00	; 267
	.byte #0x0a, #0x01, #0x00, #0x00	; 266
	.byte #0x09, #0x01, #0x00, #0x00	; 265
	.byte #0x08, #0x01, #0x00, #0x00	; 264
	.byte #0x07, #0x01, #0x00, #0x00	; 263
	.byte #0x06, #0x01, #0x00, #0x00	; 262
	.byte #0x05, #0x01, #0x00, #0x00	; 261
	.byte #0x04, #0x01, #0x00, #0x00	; 260
	.byte #0x03, #0x01, #0x00, #0x00	; 259
	.byte #0x02, #0x01, #0x00, #0x00	; 258
	.byte #0x01, #0x01, #0x00, #0x00	; 257
	.byte #0x00, #0x01, #0x00, #0x00	; 256
	.byte #0xff, #0x00, #0x00, #0x00	; 255
	.byte #0xfe, #0x00, #0x00, #0x00	; 254
	.byte #0xfd, #0x00, #0x00, #0x00	; 253
	.byte #0xfc, #0x00, #0x00, #0x00	; 252
	.byte #0xfb, #0x00, #0x00, #0x00	; 251
	.byte #0xfa, #0x00, #0x00, #0x00	; 250
	.byte #0xf9, #0x00, #0x00, #0x00	; 249
	.byte #0xf8, #0x00, #0x00, #0x00	; 248
	.byte #0xf7, #0x00, #0x00, #0x00	; 247
	.byte #0xf6, #0x00, #0x00, #0x00	; 246
	.byte #0xf5, #0x00, #0x00, #0x00	; 245
	.byte #0xf4, #0x00, #0x00, #0x00	; 244
	.byte #0xf3, #0x00, #0x00, #0x00	; 243
	.byte #0xf2, #0x00, #0x00, #0x00	; 242
	.byte #0xf1, #0x00, #0x00, #0x00	; 241
	.byte #0xf0, #0x00, #0x00, #0x00	; 240
	.byte #0xf0, #0x00, #0x00, #0x00	; 240
	.byte #0xef, #0x00, #0x00, #0x00	; 239
	.byte #0xee, #0x00, #0x00, #0x00	; 238
	.byte #0xed, #0x00, #0x00, #0x00	; 237
	.byte #0xec, #0x00, #0x00, #0x00	; 236
	.byte #0xeb, #0x00, #0x00, #0x00	; 235
	.byte #0xea, #0x00, #0x00, #0x00	; 234
	.byte #0xea, #0x00, #0x00, #0x00	; 234
	.byte #0xe9, #0x00, #0x00, #0x00	; 233
	.byte #0xe8, #0x00, #0x00, #0x00	; 232
	.byte #0xe7, #0x00, #0x00, #0x00	; 231
	.byte #0xe6, #0x00, #0x00, #0x00	; 230
	.byte #0xe5, #0x00, #0x00, #0x00	; 229
	.byte #0xe5, #0x00, #0x00, #0x00	; 229
	.byte #0xe4, #0x00, #0x00, #0x00	; 228
	.byte #0xe3, #0x00, #0x00, #0x00	; 227
	.byte #0xe2, #0x00, #0x00, #0x00	; 226
	.byte #0xe1, #0x00, #0x00, #0x00	; 225
	.byte #0xe1, #0x00, #0x00, #0x00	; 225
	.byte #0xe0, #0x00, #0x00, #0x00	; 224
	.byte #0xdf, #0x00, #0x00, #0x00	; 223
	.byte #0xde, #0x00, #0x00, #0x00	; 222
	.byte #0xde, #0x00, #0x00, #0x00	; 222
	.byte #0xdd, #0x00, #0x00, #0x00	; 221
	.byte #0xdc, #0x00, #0x00, #0x00	; 220
	.byte #0xdb, #0x00, #0x00, #0x00	; 219
	.byte #0xdb, #0x00, #0x00, #0x00	; 219
	.byte #0xda, #0x00, #0x00, #0x00	; 218
	.byte #0xd9, #0x00, #0x00, #0x00	; 217
	.byte #0xd9, #0x00, #0x00, #0x00	; 217
	.byte #0xd8, #0x00, #0x00, #0x00	; 216
	.byte #0xd7, #0x00, #0x00, #0x00	; 215
	.byte #0xd6, #0x00, #0x00, #0x00	; 214
	.byte #0xd6, #0x00, #0x00, #0x00	; 214
	.byte #0xd5, #0x00, #0x00, #0x00	; 213
	.byte #0xd4, #0x00, #0x00, #0x00	; 212
	.byte #0xd4, #0x00, #0x00, #0x00	; 212
	.byte #0xd3, #0x00, #0x00, #0x00	; 211
	.byte #0xd2, #0x00, #0x00, #0x00	; 210
	.byte #0xd2, #0x00, #0x00, #0x00	; 210
	.byte #0xd1, #0x00, #0x00, #0x00	; 209
	.byte #0xd0, #0x00, #0x00, #0x00	; 208
	.byte #0xd0, #0x00, #0x00, #0x00	; 208
	.byte #0xcf, #0x00, #0x00, #0x00	; 207
	.byte #0xce, #0x00, #0x00, #0x00	; 206
	.byte #0xce, #0x00, #0x00, #0x00	; 206
	.byte #0xcd, #0x00, #0x00, #0x00	; 205
	.byte #0xcc, #0x00, #0x00, #0x00	; 204
	.byte #0xcc, #0x00, #0x00, #0x00	; 204
	.byte #0xcb, #0x00, #0x00, #0x00	; 203
	.byte #0xca, #0x00, #0x00, #0x00	; 202
	.byte #0xca, #0x00, #0x00, #0x00	; 202
	.byte #0xc9, #0x00, #0x00, #0x00	; 201
	.byte #0xc9, #0x00, #0x00, #0x00	; 201
	.byte #0xc8, #0x00, #0x00, #0x00	; 200
	.byte #0xc7, #0x00, #0x00, #0x00	; 199
	.byte #0xc7, #0x00, #0x00, #0x00	; 199
	.byte #0xc6, #0x00, #0x00, #0x00	; 198
	.byte #0xc5, #0x00, #0x00, #0x00	; 197
	.byte #0xc5, #0x00, #0x00, #0x00	; 197
	.byte #0xc4, #0x00, #0x00, #0x00	; 196
	.byte #0xc4, #0x00, #0x00, #0x00	; 196
	.byte #0xc3, #0x00, #0x00, #0x00	; 195
	.byte #0xc3, #0x00, #0x00, #0x00	; 195
	.byte #0xc2, #0x00, #0x00, #0x00	; 194
	.byte #0xc1, #0x00, #0x00, #0x00	; 193
	.byte #0xc1, #0x00, #0x00, #0x00	; 193
	.byte #0xc0, #0x00, #0x00, #0x00	; 192
	.byte #0xc0, #0x00, #0x00, #0x00	; 192
	.byte #0xbf, #0x00, #0x00, #0x00	; 191
	.byte #0xbf, #0x00, #0x00, #0x00	; 191
	.byte #0xbe, #0x00, #0x00, #0x00	; 190
	.byte #0xbd, #0x00, #0x00, #0x00	; 189
	.byte #0xbd, #0x00, #0x00, #0x00	; 189
	.byte #0xbc, #0x00, #0x00, #0x00	; 188
	.byte #0xbc, #0x00, #0x00, #0x00	; 188
	.byte #0xbb, #0x00, #0x00, #0x00	; 187
	.byte #0xbb, #0x00, #0x00, #0x00	; 187
	.byte #0xba, #0x00, #0x00, #0x00	; 186
	.byte #0xba, #0x00, #0x00, #0x00	; 186
	.byte #0xb9, #0x00, #0x00, #0x00	; 185
	.byte #0xb9, #0x00, #0x00, #0x00	; 185
	.byte #0xb8, #0x00, #0x00, #0x00	; 184
	.byte #0xb8, #0x00, #0x00, #0x00	; 184
	.byte #0xb7, #0x00, #0x00, #0x00	; 183
	.byte #0xb7, #0x00, #0x00, #0x00	; 183
	.byte #0xb6, #0x00, #0x00, #0x00	; 182
	.byte #0xb6, #0x00, #0x00, #0x00	; 182
	.byte #0xb5, #0x00, #0x00, #0x00	; 181
	.byte #0xb5, #0x00, #0x00, #0x00	; 181
	.byte #0xb4, #0x00, #0x00, #0x00	; 180
	.byte #0xb4, #0x00, #0x00, #0x00	; 180
	.byte #0xb3, #0x00, #0x00, #0x00	; 179
	.byte #0xb3, #0x00, #0x00, #0x00	; 179
	.byte #0xb2, #0x00, #0x00, #0x00	; 178
	.byte #0xb2, #0x00, #0x00, #0x00	; 178
	.byte #0xb1, #0x00, #0x00, #0x00	; 177
	.byte #0xb1, #0x00, #0x00, #0x00	; 177
	.byte #0xb0, #0x00, #0x00, #0x00	; 176
	.byte #0xb0, #0x00, #0x00, #0x00	; 176
	.byte #0xaf, #0x00, #0x00, #0x00	; 175
	.byte #0xaf, #0x00, #0x00, #0x00	; 175
	.byte #0xae, #0x00, #0x00, #0x00	; 174
	.byte #0xae, #0x00, #0x00, #0x00	; 174
	.byte #0xad, #0x00, #0x00, #0x00	; 173
	.byte #0xad, #0x00, #0x00, #0x00	; 173
	.byte #0xac, #0x00, #0x00, #0x00	; 172
	.byte #0xac, #0x00, #0x00, #0x00	; 172
	.byte #0xac, #0x00, #0x00, #0x00	; 172
	.byte #0xab, #0x00, #0x00, #0x00	; 171
	.byte #0xab, #0x00, #0x00, #0x00	; 171
	.byte #0xaa, #0x00, #0x00, #0x00	; 170
	.byte #0xaa, #0x00, #0x00, #0x00	; 170
	.byte #0xa9, #0x00, #0x00, #0x00	; 169
	.byte #0xa9, #0x00, #0x00, #0x00	; 169
	.byte #0xa8, #0x00, #0x00, #0x00	; 168
	.byte #0xa8, #0x00, #0x00, #0x00	; 168
	.byte #0xa8, #0x00, #0x00, #0x00	; 168
	.byte #0xa7, #0x00, #0x00, #0x00	; 167
	.byte #0xa7, #0x00, #0x00, #0x00	; 167
	.byte #0xa6, #0x00, #0x00, #0x00	; 166
	.byte #0xa6, #0x00, #0x00, #0x00	; 166
	.byte #0xa5, #0x00, #0x00, #0x00	; 165
	.byte #0xa5, #0x00, #0x00, #0x00	; 165
	.byte #0xa5, #0x00, #0x00, #0x00	; 165
	.byte #0xa4, #0x00, #0x00, #0x00	; 164
	.byte #0xa4, #0x00, #0x00, #0x00	; 164
	.byte #0xa3, #0x00, #0x00, #0x00	; 163
	.byte #0xa3, #0x00, #0x00, #0x00	; 163
	.byte #0xa3, #0x00, #0x00, #0x00	; 163
	.byte #0xa2, #0x00, #0x00, #0x00	; 162
	.byte #0xa2, #0x00, #0x00, #0x00	; 162
	.byte #0xa1, #0x00, #0x00, #0x00	; 161
	.byte #0xa1, #0x00, #0x00, #0x00	; 161
	.byte #0xa1, #0x00, #0x00, #0x00	; 161
	.byte #0xa0, #0x00, #0x00, #0x00	; 160
	.byte #0xa0, #0x00, #0x00, #0x00	; 160
	.byte #0x9f, #0x00, #0x00, #0x00	; 159
	.byte #0x9f, #0x00, #0x00, #0x00	; 159
	.byte #0x9f, #0x00, #0x00, #0x00	; 159
	.byte #0x9e, #0x00, #0x00, #0x00	; 158
	.byte #0x9e, #0x00, #0x00, #0x00	; 158
	.byte #0x9d, #0x00, #0x00, #0x00	; 157
	.byte #0x9d, #0x00, #0x00, #0x00	; 157
	.byte #0x9d, #0x00, #0x00, #0x00	; 157
	.byte #0x9c, #0x00, #0x00, #0x00	; 156
	.byte #0x9c, #0x00, #0x00, #0x00	; 156
	.byte #0x9c, #0x00, #0x00, #0x00	; 156
	.byte #0x9b, #0x00, #0x00, #0x00	; 155
	.byte #0x9b, #0x00, #0x00, #0x00	; 155
	.byte #0x9a, #0x00, #0x00, #0x00	; 154
	.byte #0x9a, #0x00, #0x00, #0x00	; 154
	.byte #0x9a, #0x00, #0x00, #0x00	; 154
	.byte #0x99, #0x00, #0x00, #0x00	; 153
	.byte #0x99, #0x00, #0x00, #0x00	; 153
	.byte #0x99, #0x00, #0x00, #0x00	; 153
	.byte #0x98, #0x00, #0x00, #0x00	; 152
	.byte #0x98, #0x00, #0x00, #0x00	; 152
	.byte #0x98, #0x00, #0x00, #0x00	; 152
	.byte #0x97, #0x00, #0x00, #0x00	; 151
	.byte #0x97, #0x00, #0x00, #0x00	; 151
	.byte #0x97, #0x00, #0x00, #0x00	; 151
	.byte #0x96, #0x00, #0x00, #0x00	; 150
	.byte #0x96, #0x00, #0x00, #0x00	; 150
	.byte #0x95, #0x00, #0x00, #0x00	; 149
	.byte #0x95, #0x00, #0x00, #0x00	; 149
	.byte #0x95, #0x00, #0x00, #0x00	; 149
	.byte #0x94, #0x00, #0x00, #0x00	; 148
	.byte #0x94, #0x00, #0x00, #0x00	; 148
	.byte #0x94, #0x00, #0x00, #0x00	; 148
	.byte #0x93, #0x00, #0x00, #0x00	; 147
	.byte #0x93, #0x00, #0x00, #0x00	; 147
	.byte #0x93, #0x00, #0x00, #0x00	; 147
	.byte #0x92, #0x00, #0x00, #0x00	; 146
	.byte #0x92, #0x00, #0x00, #0x00	; 146
	.byte #0x92, #0x00, #0x00, #0x00	; 146
	.byte #0x91, #0x00, #0x00, #0x00	; 145
	.byte #0x91, #0x00, #0x00, #0x00	; 145
	.byte #0x91, #0x00, #0x00, #0x00	; 145
	.byte #0x90, #0x00, #0x00, #0x00	; 144
	.byte #0x90, #0x00, #0x00, #0x00	; 144
	.byte #0x90, #0x00, #0x00, #0x00	; 144
	.byte #0x90, #0x00, #0x00, #0x00	; 144
	.byte #0x8f, #0x00, #0x00, #0x00	; 143
	.byte #0x8f, #0x00, #0x00, #0x00	; 143
	.byte #0x8f, #0x00, #0x00, #0x00	; 143
	.byte #0x8e, #0x00, #0x00, #0x00	; 142
	.byte #0x8e, #0x00, #0x00, #0x00	; 142
	.byte #0x8e, #0x00, #0x00, #0x00	; 142
	.byte #0x8d, #0x00, #0x00, #0x00	; 141
	.byte #0x8d, #0x00, #0x00, #0x00	; 141
	.byte #0x8d, #0x00, #0x00, #0x00	; 141
	.byte #0x8c, #0x00, #0x00, #0x00	; 140
	.byte #0x8c, #0x00, #0x00, #0x00	; 140
	.byte #0x8c, #0x00, #0x00, #0x00	; 140
	.byte #0x8c, #0x00, #0x00, #0x00	; 140
	.byte #0x8b, #0x00, #0x00, #0x00	; 139
	.byte #0x8b, #0x00, #0x00, #0x00	; 139
	.byte #0x8b, #0x00, #0x00, #0x00	; 139
	.byte #0x8a, #0x00, #0x00, #0x00	; 138
	.byte #0x8a, #0x00, #0x00, #0x00	; 138
	.byte #0x8a, #0x00, #0x00, #0x00	; 138
	.byte #0x89, #0x00, #0x00, #0x00	; 137
	.byte #0x89, #0x00, #0x00, #0x00	; 137
	.byte #0x89, #0x00, #0x00, #0x00	; 137
	.byte #0x89, #0x00, #0x00, #0x00	; 137
	.byte #0x88, #0x00, #0x00, #0x00	; 136
	.byte #0x88, #0x00, #0x00, #0x00	; 136
	.byte #0x88, #0x00, #0x00, #0x00	; 136
	.byte #0x87, #0x00, #0x00, #0x00	; 135
	.byte #0x87, #0x00, #0x00, #0x00	; 135
	.byte #0x87, #0x00, #0x00, #0x00	; 135
	.byte #0x87, #0x00, #0x00, #0x00	; 135
	.byte #0x86, #0x00, #0x00, #0x00	; 134
	.byte #0x86, #0x00, #0x00, #0x00	; 134
	.byte #0x86, #0x00, #0x00, #0x00	; 134
	.byte #0x86, #0x00, #0x00, #0x00	; 134
	.byte #0x85, #0x00, #0x00, #0x00	; 133
	.byte #0x85, #0x00, #0x00, #0x00	; 133
	.byte #0x85, #0x00, #0x00, #0x00	; 133
	.byte #0x84, #0x00, #0x00, #0x00	; 132
	.byte #0x84, #0x00, #0x00, #0x00	; 132
	.byte #0x84, #0x00, #0x00, #0x00	; 132
	.byte #0x84, #0x00, #0x00, #0x00	; 132
	.byte #0x83, #0x00, #0x00, #0x00	; 131
	.byte #0x83, #0x00, #0x00, #0x00	; 131
	.byte #0x83, #0x00, #0x00, #0x00	; 131
	.byte #0x83, #0x00, #0x00, #0x00	; 131
	.byte #0x82, #0x00, #0x00, #0x00	; 130
	.byte #0x82, #0x00, #0x00, #0x00	; 130
	.byte #0x82, #0x00, #0x00, #0x00	; 130
	.byte #0x82, #0x00, #0x00, #0x00	; 130
	.byte #0x81, #0x00, #0x00, #0x00	; 129
	.byte #0x81, #0x00, #0x00, #0x00	; 129
	.byte #0x81, #0x00, #0x00, #0x00	; 129
	.byte #0x81, #0x00, #0x00, #0x00	; 129
	.byte #0x80, #0x00, #0x00, #0x00	; 128
	.byte #0x80, #0x00, #0x00, #0x00	; 128
	.byte #0x80, #0x00, #0x00, #0x00	; 128
	.byte #0x80, #0x00, #0x00, #0x00	; 128
_camera_x_by_ray:
	.dw #0xff4e
	.dw #0xff5b
	.dw #0xff69
	.dw #0xff76
	.dw #0xff83
	.dw #0xff90
	.dw #0xff9d
	.dw #0xffaa
	.dw #0xffb7
	.dw #0xffc4
	.dw #0xffd2
	.dw #0xffdf
	.dw #0xffec
	.dw #0xfff9
	.dw #0x0006
	.dw #0x0013
	.dw #0x0020
	.dw #0x002d
	.dw #0x003b
	.dw #0x0048
	.dw #0x0055
	.dw #0x0062
	.dw #0x006f
	.dw #0x007c
	.dw #0x0089
	.dw #0x0096
	.dw #0x00a4
	.dw #0x00b1
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:118: static unsigned long dda_get_side_distance(unsigned int boundary_distance,
;	---------------------------------
; Function dda_get_side_distance
; ---------------------------------
_dda_get_side_distance:
	push	ix
	ld	ix,	#0
	add	ix, sp
	ex	de, hl
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:121: if (reciprocal == DDA_INFINITY)
	ld	a, 4 (ix)
	and	a, 5 (ix)
	and	a, 6 (ix)
	and	a, 7 (ix)
	inc	a
	jr	nz, 00102$
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:122: return DDA_INFINITY;
	ld	de, #0xffff
	ld	l, e
	ld	h, e
	jr	00103$
00102$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:124: return ((unsigned long)boundary_distance * reciprocal) >> 8;
	ld	hl, #0x0000
	ld	c, 6 (ix)
	ld	b, 7 (ix)
	push	bc
	ld	c, 4 (ix)
	ld	b, 5 (ix)
	push	bc
	call	__mullong
	pop	af
	pop	af
	ld	e, d
	ld	d, l
	ld	l, h
	ld	h, #0x00
00103$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:125: }
	pop	ix
	ret
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:148: static unsigned char raycaster_calculate_hit_offset(
;	---------------------------------
; Function raycaster_calculate_hit_offset
; ---------------------------------
_raycaster_calculate_hit_offset:
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	c, l
	ld	b, h
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:155: unsigned int fractional_product =
	ex	de, hl
	ld	e, 4 (ix)
	ld	d, 5 (ix)
	push	bc
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:159: + (fractional_product >> 8));
	call	__mulint
	pop	bc
	ld	a, d
	add	a, c
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:160: }
	pop	ix
	pop	hl
	pop	bc
	pop	bc
	jp	(hl)
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:162: static unsigned char cast_ray(signed int direction_x,
;	---------------------------------
; Function cast_ray
; ---------------------------------
_cast_ray:
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	iy, #-35
	add	iy, sp
	ld	sp, iy
	ld	-14 (ix), l
	ld	-13 (ix), h
	ld	-16 (ix), e
	ld	-15 (ix), d
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:175: signed int position_x = frame_position_x;
	ld	hl, (_frame_position_x)
	ex	(sp), hl
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:176: signed int position_y = frame_position_y;
	ld	hl, (_frame_position_y)
	ld	-33 (ix), l
	ld	-32 (ix), h
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:177: signed int map_x = position_x / FIXED_POINT_SCALE;
	pop	bc
	push	bc
	bit	7, -34 (ix)
	jr	z, 00139$
	pop	bc
	push	bc
	dec	bc
	inc	b
00139$:
	ld	-12 (ix), b
	ld	a, b
	rlca
	sbc	a, a
	ld	-11 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:178: signed int map_y = position_y / FIXED_POINT_SCALE;
	pop	hl
	pop	bc
	push	bc
	push	hl
	bit	7, -32 (ix)
	jr	z, 00140$
	ld	c, -33 (ix)
	ld	b, -32 (ix)
	dec	bc
	inc	b
00140$:
	ld	-10 (ix), b
	ld	a, b
	rlca
	sbc	a, a
	ld	-9 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:197: else if (direction_x < 0)
	ld	a, -13 (ix)
	rlca
	and	a, #0x01
	ld	-31 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:191: if (direction_x == 0)
	ld	a, -13 (ix)
	or	a, -14 (ix)
	jr	nz, 00105$
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:193: step_x = 1;
	ld	bc, #0x0001
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:194: delta_distance_x = DDA_INFINITY;
	ld	-30 (ix), #0xff
	ld	-29 (ix), #0xff
	ld	-28 (ix), #0xff
	ld	-27 (ix), #0xff
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:195: side_distance_x = DDA_INFINITY;
	ld	-8 (ix), #0xff
	ld	-7 (ix), #0xff
	ld	-6 (ix), #0xff
	ld	-5 (ix), #0xff
	jp	00106$
00105$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:197: else if (direction_x < 0)
	ld	a, -31 (ix)
	or	a, a
	jr	z, 00102$
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:199: step_x = -1;
	ld	bc, #0xffff
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:200: direction_magnitude_x = (unsigned int)(-(signed long)direction_x);
	ld	l, -14 (ix)
	ld	h, -13 (ix)
	xor	a, a
	sub	a, l
	ld	l, a
	sbc	a, a
	sub	a, h
	ld	h, a
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:201: delta_distance_x = dda_get_reciprocal(direction_magnitude_x);
	push	bc
	call	_dda_get_reciprocal
	ld	-30 (ix), e
	ld	-29 (ix), d
	ld	-28 (ix), l
	ld	-27 (ix), h
	pop	bc
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:203: (unsigned int)(position_x - map_x * FIXED_POINT_SCALE),
	ld	d, -12 (ix)
	ld	e, #0x00
	pop	hl
	push	hl
	cp	a, a
	sbc	hl, de
	push	bc
	ld	e, -28 (ix)
	ld	d, -27 (ix)
	push	de
	ld	e, -30 (ix)
	ld	d, -29 (ix)
	push	de
	call	_dda_get_side_distance
	pop	af
	pop	af
	ld	-8 (ix), e
	ld	-7 (ix), d
	ld	-6 (ix), l
	ld	-5 (ix), h
	pop	bc
	jr	00106$
00102$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:208: step_x = 1;
	ld	bc, #0x0001
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:209: direction_magnitude_x = (unsigned int)direction_x;
	ld	l, -14 (ix)
	ld	h, -13 (ix)
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:210: delta_distance_x = dda_get_reciprocal(direction_magnitude_x);
	push	bc
	call	_dda_get_reciprocal
	ld	-30 (ix), e
	ld	-29 (ix), d
	ld	-28 (ix), l
	ld	-27 (ix), h
	pop	bc
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:212: (unsigned int)((map_x + 1) * FIXED_POINT_SCALE - position_x),
	ld	e, -12 (ix)
	ld	d, -11 (ix)
	inc	de
	xor	a, a
	sub	a, -35 (ix)
	ld	l, a
	ld	a, e
	sbc	a, -34 (ix)
	ld	h, a
	push	bc
	ld	e, -28 (ix)
	ld	d, -27 (ix)
	push	de
	ld	e, -30 (ix)
	ld	d, -29 (ix)
	push	de
	call	_dda_get_side_distance
	pop	af
	pop	af
	ld	-8 (ix), e
	ld	-7 (ix), d
	ld	-6 (ix), l
	ld	-5 (ix), h
	pop	bc
00106$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:216: if (direction_y == 0)
	ld	a, -15 (ix)
	or	a, -16 (ix)
	jr	nz, 00111$
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:218: step_y = 1;
	ld	de, #0x0001
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:219: delta_distance_y = DDA_INFINITY;
	ld	-26 (ix), #0xff
	ld	-25 (ix), #0xff
	ld	-24 (ix), #0xff
	ld	-23 (ix), #0xff
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:220: side_distance_y = DDA_INFINITY;
	ld	-4 (ix), #0xff
	ld	-3 (ix), #0xff
	ld	-2 (ix), #0xff
	ld	-1 (ix), #0xff
	jp	00116$
00111$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:222: else if (direction_y < 0)
	bit	7, -15 (ix)
	jr	z, 00108$
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:224: step_y = -1;
	ld	de, #0xffff
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:225: direction_magnitude_y = (unsigned int)(-(signed long)direction_y);
	ld	a, -16 (ix)
	ld	h, -15 (ix)
	neg
	ld	l, a
	sbc	a, a
	sub	a, h
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:226: delta_distance_y = dda_get_reciprocal(direction_magnitude_y);
	push	bc
	push	de
	ld	h, a
	call	_dda_get_reciprocal
	ld	-26 (ix), e
	ld	-25 (ix), d
	ld	-24 (ix), l
	ld	-23 (ix), h
	pop	de
	pop	bc
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:228: (unsigned int)(position_y - map_y * FIXED_POINT_SCALE),
	ld	h, -10 (ix)
	ld	l, #0x00
	ld	a, -33 (ix)
	sub	a, l
	ld	l, a
	ld	a, -32 (ix)
	sbc	a, h
	push	bc
	push	de
	push	hl
	ld	l, -24 (ix)
	ld	h, -23 (ix)
	ex	(sp), hl
	push	hl
	ld	l, -26 (ix)
	ld	h, -25 (ix)
	ex	(sp), hl
	ld	h, a
	call	_dda_get_side_distance
	pop	af
	pop	af
	ld	-4 (ix), e
	ld	-3 (ix), d
	ld	-2 (ix), l
	ld	-1 (ix), h
	pop	de
	pop	bc
	jr	00116$
00108$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:233: step_y = 1;
	ld	de, #0x0001
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:234: direction_magnitude_y = (unsigned int)direction_y;
	ld	l, -16 (ix)
	ld	h, -15 (ix)
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:235: delta_distance_y = dda_get_reciprocal(direction_magnitude_y);
	push	bc
	push	de
	call	_dda_get_reciprocal
	ld	-26 (ix), e
	ld	-25 (ix), d
	ld	-24 (ix), l
	ld	-23 (ix), h
	pop	de
	pop	bc
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:237: (unsigned int)((map_y + 1) * FIXED_POINT_SCALE - position_y),
	ld	l, -10 (ix)
	ld	h, -9 (ix)
	inc	hl
	ld	h, l
	xor	a, a
	sub	a, -33 (ix)
	ld	l, a
	ld	a, h
	sbc	a, -32 (ix)
	push	bc
	push	de
	push	hl
	ld	l, -24 (ix)
	ld	h, -23 (ix)
	ex	(sp), hl
	push	hl
	ld	l, -26 (ix)
	ld	h, -25 (ix)
	ex	(sp), hl
	ld	h, a
	call	_dda_get_side_distance
	pop	af
	pop	af
	ld	-4 (ix), e
	ld	-3 (ix), d
	ld	-2 (ix), l
	ld	-1 (ix), h
	pop	de
	pop	bc
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:241: do
00116$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:252: *result_side = WALL_SIDE_X;
	ld	a, 4 (ix)
	ld	-22 (ix), a
	ld	a, 5 (ix)
	ld	-21 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:247: if (side_distance_x < side_distance_y)
	ld	a, -8 (ix)
	sub	a, -4 (ix)
	ld	a, -7 (ix)
	sbc	a, -3 (ix)
	ld	a, -6 (ix)
	sbc	a, -2 (ix)
	ld	a, -5 (ix)
	sbc	a, -1 (ix)
	jr	nc, 00114$
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:249: ray_distance = side_distance_x;
	ld	a, -8 (ix)
	ld	-20 (ix), a
	ld	a, -7 (ix)
	ld	-19 (ix), a
	ld	a, -6 (ix)
	ld	-18 (ix), a
	ld	a, -5 (ix)
	ld	-17 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:250: side_distance_x += delta_distance_x;
	ld	a, -8 (ix)
	add	a, -30 (ix)
	ld	-8 (ix), a
	ld	a, -7 (ix)
	adc	a, -29 (ix)
	ld	-7 (ix), a
	ld	a, -6 (ix)
	adc	a, -28 (ix)
	ld	-6 (ix), a
	ld	a, -5 (ix)
	adc	a, -27 (ix)
	ld	-5 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:251: map_x += step_x;
	ld	l, -12 (ix)
	ld	h, -11 (ix)
	add	hl, bc
	ld	-12 (ix), l
	ld	-11 (ix), h
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:252: *result_side = WALL_SIDE_X;
	ld	l, -22 (ix)
	ld	h, -21 (ix)
	ld	(hl), #0x00
	jr	00117$
00114$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:256: ray_distance = side_distance_y;
	ld	a, -4 (ix)
	ld	-20 (ix), a
	ld	a, -3 (ix)
	ld	-19 (ix), a
	ld	a, -2 (ix)
	ld	-18 (ix), a
	ld	a, -1 (ix)
	ld	-17 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:257: side_distance_y += delta_distance_y;
	ld	a, -4 (ix)
	add	a, -26 (ix)
	ld	-4 (ix), a
	ld	a, -3 (ix)
	adc	a, -25 (ix)
	ld	-3 (ix), a
	ld	a, -2 (ix)
	adc	a, -24 (ix)
	ld	-2 (ix), a
	ld	a, -1 (ix)
	adc	a, -23 (ix)
	ld	-1 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:258: map_y += step_y;
	ld	l, -10 (ix)
	ld	h, -9 (ix)
	add	hl, de
	ld	-10 (ix), l
	ld	-9 (ix), h
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:259: *result_side = WALL_SIDE_Y;
	ld	l, -22 (ix)
	ld	h, -21 (ix)
	ld	(hl), #0x01
00117$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:262: while (!world_is_wall((unsigned char)map_x, (unsigned char)map_y));
	ld	l, -10 (ix)
	ld	h, -12 (ix)
	push	hl
	push	bc
	push	de
	ld	a, h
	call	_world_is_wall
	pop	de
	pop	bc
	pop	hl
	or	a, a
	jp	z, 00116$
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:280: world_tile_id = world_get_tile((unsigned char)map_x,
	ld	a, h
	call	_world_get_tile
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:282: cast_hits_switch = world_tile_id == WORLD_TILE_RED_DOOR_SWITCH;
	ld	l, a
	sub	a, #0x07
	ld	a, #0x01
	jr	z, 00270$
	xor	a, a
00270$:
	ld	(_cast_hits_switch+0), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:283: *result_texture_id = world_get_texture(world_tile_id);
	ld	c, 8 (ix)
	ld	b, 9 (ix)
	push	bc
	ld	a, l
	call	_world_get_texture
	pop	bc
	ld	(bc), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:284: if (*result_side == WALL_SIDE_X)
	ld	l, -22 (ix)
	ld	h, -21 (ix)
	ld	a, (hl)
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:286: *result_offset = raycaster_calculate_hit_offset(position_y,
	ld	c, 6 (ix)
	ld	b, 7 (ix)
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:284: if (*result_side == WALL_SIDE_X)
	or	a, a
	jr	nz, 00120$
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:286: *result_offset = raycaster_calculate_hit_offset(position_y,
	push	bc
	ld	l, -18 (ix)
	ld	h, -17 (ix)
	push	hl
	ld	l, -20 (ix)
	ld	h, -19 (ix)
	push	hl
	ld	e, -16 (ix)
	ld	d, -15 (ix)
	ld	l, -33 (ix)
	ld	h, -32 (ix)
	call	_raycaster_calculate_hit_offset
	pop	bc
	ld	(bc), a
	jr	00121$
00120$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:292: *result_offset = raycaster_calculate_hit_offset(position_x,
	push	bc
	ld	l, -18 (ix)
	ld	h, -17 (ix)
	push	hl
	ld	l, -20 (ix)
	ld	h, -19 (ix)
	push	hl
	ld	e, -14 (ix)
	ld	d, -13 (ix)
	ld	l, -35 (ix)
	ld	h, -34 (ix)
	call	_raycaster_calculate_hit_offset
	pop	bc
	ld	(bc), a
00121$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:304: if (*result_side == WALL_SIDE_X)
	ld	l, -22 (ix)
	ld	h, -21 (ix)
	ld	a, (hl)
	or	a, a
	jr	nz, 00127$
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:307: if (direction_x < 0)
	ld	a, -31 (ix)
	or	a, a
	jr	z, 00128$
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:308: *result_offset = 255 - *result_offset;
	ld	a, (bc)
	ld	e, a
	ld	a, #0xff
	sub	a, e
	ld	(bc), a
	jr	00128$
00127$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:311: else if (direction_y > 0)
	xor	a, a
	cp	a, -16 (ix)
	sbc	a, -15 (ix)
	jp	po, 00271$
	xor	a, #0x80
00271$:
	jp	p, 00128$
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:312: *result_offset = 255 - *result_offset;
	ld	a, (bc)
	ld	e, a
	ld	a, #0xff
	sub	a, e
	ld	(bc), a
00128$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:314: if (ray_distance == 0)
	ld	a, -17 (ix)
	or	a, -18 (ix)
	or	a, -19 (ix)
	or	a, -20 (ix)
	jr	nz, 00130$
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:315: projection_distance = 1;
	ld	de, #0x0001
	jr	00131$
00130$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:317: projection_distance = (unsigned int)ray_distance;
	ld	e, -20 (ix)
	ld	d, -19 (ix)
00131$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:318: *result_distance = projection_distance;
	ld	l, 10 (ix)
	ld	h, 11 (ix)
	ld	(hl), e
	inc	hl
	ld	(hl), d
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:320: projected_height = WALL_HEIGHT_SCALE / projection_distance;
	ld	hl, #0x4000
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:322: if (projected_height > GAME_GEAR_SCREEN_HEIGHT)
	call	__divuint
	ld	a, #0x90
	cp	a, e
	ld	a, #0x00
	sbc	a, d
	jr	nc, 00135$
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:323: projected_height = GAME_GEAR_SCREEN_HEIGHT;
	ld	de, #0x0090
	jr	00136$
00135$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:324: else if (projected_height == 0)
	ld	a, d
	or	a, e
	jr	nz, 00136$
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:325: projected_height = 1;
	ld	de, #0x0001
00136$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:327: return (unsigned char)projected_height;
	ld	a, e
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:328: }
	ld	sp, ix
	pop	ix
	pop	hl
	pop	bc
	pop	bc
	pop	bc
	pop	bc
	jp	(hl)
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:330: void raycaster_initialize(void)
;	---------------------------------
; Function raycaster_initialize
; ---------------------------------
_raycaster_initialize::
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:334: ray_directions_valid = 0;
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:335: ray_output_valid = 0;
	xor	a, a
	ld	(#_ray_directions_valid), a
	ld	(#_ray_output_valid), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:337: for (ray_index = 0; ray_index < RAY_COUNT; ++ray_index)
	ld	c, #0x00
00102$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:339: rendered_rays[ray_index].wall_height = 1;
	ld	b, #0x00
	ld	l, c
	ld	h, b
	add	hl, hl
	add	hl, bc
	add	hl, hl
	ex	de, hl
	ld	hl, #_rendered_rays
	add	hl, de
	ex	de, hl
	ld	a, #0x01
	ld	(de), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:340: rendered_rays[ray_index].hit_side = WALL_SIDE_X;
	ld	l, e
	ld	h, d
	inc	hl
	ld	(hl), #0x00
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:341: rendered_rays[ray_index].hit_offset = 0;
	ld	l, e
	ld	h, d
	inc	hl
	inc	hl
	ld	(hl), #0x00
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:342: rendered_rays[ray_index].texture_id = WORLD_TILE_STONE;
	ld	l, e
	ld	h, d
	inc	hl
	inc	hl
	inc	hl
	ld	(hl), #0x01
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:343: rendered_rays[ray_index].wall_distance = 1;
	ld	hl, #0x0004
	add	hl, de
	ld	(hl), #0x01
	inc	hl
	ld	(hl), #0x00
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:337: for (ray_index = 0; ray_index < RAY_COUNT; ++ray_index)
	inc	c
	ld	a, c
	sub	a, #0x1c
	jr	c, 00102$
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:345: }
	ret
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:347: void raycaster_update(void)
;	---------------------------------
; Function raycaster_update
; ---------------------------------
_raycaster_update::
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	hl, #-19
	add	hl, sp
	ld	sp, hl
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:357: camera_direction_x = camera_get_direction_x();
	call	_camera_get_direction_x
	ld	-14 (ix), e
	ld	-13 (ix), d
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:358: camera_direction_y = camera_get_direction_y();
	call	_camera_get_direction_y
	ld	-12 (ix), e
	ld	-11 (ix), d
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:359: camera_plane_x = camera_get_plane_x();
	call	_camera_get_plane_x
	ld	-10 (ix), e
	ld	-9 (ix), d
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:360: camera_plane_y = camera_get_plane_y();
	call	_camera_get_plane_y
	ld	-8 (ix), e
	ld	-7 (ix), d
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:361: frame_position_x = camera_get_position_x();
	call	_camera_get_position_x
	ld	-2 (ix), e
	ld	-1 (ix), d
	ex	de, hl
	ld	(_frame_position_x), hl
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:362: frame_position_y = camera_get_position_y();
	call	_camera_get_position_y
	ld	-2 (ix), e
	ld	-1 (ix), d
	ex	de, hl
	ld	(_frame_position_y), hl
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:363: doors[0] = door_state_get(DOOR_INSTANCE_ROOM_ENTRANCE);
	xor	a, a
	call	_door_state_get
	ld	-17 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:364: doors[1] = door_state_get(DOOR_INSTANCE_ROOM_INTERNAL);
	ld	a, #0x01
	call	_door_state_get
	ld	-16 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:365: doors[2] = door_state_get(DOOR_INSTANCE_SOUTH_ENTRANCE);
	ld	a, #0x02
	call	_door_state_get
	ld	-15 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:366: switch_texture = red_door_switch_get_texture();
	call	_red_door_switch_get_texture
	ld	-6 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:372: && camera_direction_y == cached_camera_direction_y
	ld	a, (_cached_camera_direction_x)
	sub	a, -14 (ix)
	jr	nz, 00330$
	ld	a, (_cached_camera_direction_x + 1)
	sub	a, -13 (ix)
	ld	a, #0x01
	jr	z, 00331$
00330$:
	xor	a, a
00331$:
	ld	-5 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:373: && camera_plane_x == cached_camera_plane_x
	ld	a, (_cached_camera_direction_y)
	sub	a, -12 (ix)
	jr	nz, 00332$
	ld	a, (_cached_camera_direction_y + 1)
	sub	a, -11 (ix)
	ld	a, #0x01
	jr	z, 00333$
00332$:
	xor	a, a
00333$:
	ld	-4 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:374: && camera_plane_y == cached_camera_plane_y
	ld	a, -10 (ix)
	ld	iy, #_cached_camera_plane_x
	sub	a, 0 (iy)
	jr	nz, 00334$
	ld	a, -9 (ix)
	sub	a, 1 (iy)
	ld	a, #0x01
	jr	z, 00335$
00334$:
	xor	a, a
00335$:
	ld	-3 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:375: && doors[0] == cached_doors[0]
	ld	a, -8 (ix)
	ld	iy, #_cached_camera_plane_y
	sub	a, 0 (iy)
	jr	nz, 00336$
	ld	a, -7 (ix)
	sub	a, 1 (iy)
	ld	a, #0x01
	jr	z, 00337$
00336$:
	xor	a, a
00337$:
	ld	-2 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:368: if (ray_output_valid
	ld	a, (_ray_output_valid+0)
	or	a, a
	jp	z, 00107$
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:370: && frame_position_y == cached_position_y
	ld	a, (_frame_position_x)
	ld	iy, #_cached_position_x
	sub	a, 0 (iy)
	jp	nz, 00107$
	ld	a, (_frame_position_x + 1)
	sub	a, 1 (iy)
	jp	nz, 00107$
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:371: && camera_direction_x == cached_camera_direction_x
	ld	a, (_frame_position_y)
	ld	iy, #_cached_position_y
	sub	a, 0 (iy)
	jp	nz, 00107$
	ld	a, (_frame_position_y + 1)
	sub	a, 1 (iy)
	jp	nz, 00107$
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:372: && camera_direction_y == cached_camera_direction_y
	ld	a, -5 (ix)
	or	a, a
	jp	z, 00107$
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:373: && camera_plane_x == cached_camera_plane_x
	ld	a, -4 (ix)
	or	a, a
	jp	z, 00107$
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:374: && camera_plane_y == cached_camera_plane_y
	ld	a, -3 (ix)
	or	a, a
	jp	z, 00107$
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:375: && doors[0] == cached_doors[0]
	ld	a, -2 (ix)
	or	a, a
	jp	z, 00107$
	ld	a, -17 (ix)
	ld	-1 (ix), a
	ld	a, (#_cached_doors + 0)
	sub	a, -1 (ix)
	jr	nz, 00107$
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:376: && doors[1] == cached_doors[1]
	ld	a, -16 (ix)
	ld	-1 (ix), a
	ld	a, (#_cached_doors + 1)
	sub	a, -1 (ix)
	jr	nz, 00107$
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:377: && doors[2] == cached_doors[2])
	ld	a, -15 (ix)
	ld	-1 (ix), a
	ld	a, (#_cached_doors + 2)
	sub	a, -1 (ix)
	jr	nz, 00107$
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:382: if (switch_texture != cached_switch_texture)
	ld	a, (_cached_switch_texture)
	sub	a, -6 (ix)
	jp	z, 00131$
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:384: for (ray_index = 0; ray_index < RAY_COUNT; ++ray_index)
	ld	-1 (ix), #0x00
00125$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:385: if (ray_hits_switch[ray_index])
	ld	de, #_ray_hits_switch
	ld	l, -1 (ix)
	ld	h, #0x00
	add	hl, de
	ld	-3 (ix), l
	ld	-2 (ix), h
	ld	a, (hl)
	or	a, a
	jr	z, 00126$
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:386: rendered_rays[ray_index].texture_id = switch_texture;
	ld	c, -1 (ix)
	ld	b, #0x00
	ld	l, c
	ld	h, b
	add	hl, hl
	add	hl, bc
	add	hl, hl
	ld	-5 (ix), l
	ld	-4 (ix), h
	ld	a, #<(_rendered_rays)
	add	a, -5 (ix)
	ld	-3 (ix), a
	ld	a, #>(_rendered_rays)
	adc	a, -4 (ix)
	ld	-2 (ix), a
	ld	c, -3 (ix)
	ld	b, -2 (ix)
	inc	bc
	inc	bc
	inc	bc
	ld	a, -6 (ix)
	ld	(bc), a
00126$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:384: for (ray_index = 0; ray_index < RAY_COUNT; ++ray_index)
	inc	-1 (ix)
	ld	a, -1 (ix)
	sub	a, #0x1c
	jr	c, 00125$
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:387: cached_switch_texture = switch_texture;
	ld	a, -6 (ix)
	ld	(#_cached_switch_texture), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:389: return;
	jp	00131$
00107$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:392: if (!ray_directions_valid
	ld	a, (_ray_directions_valid+0)
	or	a, a
	jr	z, 00179$
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:394: || camera_direction_y != cached_camera_direction_y
	ld	c, -5 (ix)
	bit	0, c
	jr	z, 00179$
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:395: || camera_plane_x != cached_camera_plane_x
	ld	c, -4 (ix)
	bit	0, c
	jr	z, 00179$
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:396: || camera_plane_y != cached_camera_plane_y)
	ld	c, -3 (ix)
	bit	0, c
	jr	z, 00179$
	ld	c, -2 (ix)
	bit	0, c
	jp	nz, 00181$
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:399: for (ray_index = 0; ray_index < RAY_COUNT; ++ray_index)
00179$:
	ld	c, #0x00
00127$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:401: signed int camera_x = camera_x_by_ray[ray_index];
	ld	l, c
	ld	h, #0x00
	add	hl, hl
	ex	(sp), hl
	ld	iy, #_camera_x_by_ray
	pop	de
	push	de
	add	iy, de
	ld	a, 0 (iy)
	ld	-4 (ix), a
	ld	a, 1 (iy)
	ld	-3 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:403: ray_direction_x_by_ray[ray_index] = camera_direction_x
	ld	a, #<(_ray_direction_x_by_ray)
	add	a, -19 (ix)
	ld	l, a
	ld	a, #>(_ray_direction_x_by_ray)
	adc	a, -18 (ix)
	ld	h, a
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:404: + (signed int)((camera_plane_x * camera_x)
	push	hl
	push	bc
	ld	e, -4 (ix)
	ld	d, -3 (ix)
	ld	l, -10 (ix)
	ld	h, -9 (ix)
	call	__mulint
	pop	bc
	pop	hl
	ld	-2 (ix), e
	ld	-1 (ix), d
	bit	7, d
	jr	z, 00133$
	ld	a, e
	add	a, #0xff
	ld	-2 (ix), a
	ld	a, d
	adc	a, #0x00
	ld	-1 (ix), a
00133$:
	ld	e, -1 (ix)
	ld	a, e
	rlca
	sbc	a, a
	ld	d, a
	ld	a, e
	add	a, -14 (ix)
	ld	e, a
	ld	a, d
	adc	a, -13 (ix)
	ld	(hl), e
	inc	hl
	ld	(hl), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:406: ray_direction_y_by_ray[ray_index] = camera_direction_y
	pop	hl
	push	hl
	ld	de, #_ray_direction_y_by_ray
	add	hl, de
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:407: + (signed int)((camera_plane_y * camera_x)
	push	hl
	push	bc
	ld	e, -4 (ix)
	ld	d, -3 (ix)
	ld	l, -8 (ix)
	ld	h, -7 (ix)
	call	__mulint
	ld	-4 (ix), e
	ld	-3 (ix), d
	pop	bc
	pop	hl
	ld	a, -4 (ix)
	ld	-2 (ix), a
	ld	a, -3 (ix)
	ld	-1 (ix), a
	bit	7, -3 (ix)
	jr	z, 00134$
	ld	a, -4 (ix)
	add	a, #0xff
	ld	-2 (ix), a
	ld	a, -3 (ix)
	adc	a, #0x00
	ld	-1 (ix), a
00134$:
	ld	e, -1 (ix)
	ld	a, e
	rlca
	sbc	a, a
	ld	d, a
	ld	a, e
	add	a, -12 (ix)
	ld	e, a
	ld	a, d
	adc	a, -11 (ix)
	ld	d, a
	ld	(hl), e
	inc	hl
	ld	(hl), d
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:399: for (ray_index = 0; ray_index < RAY_COUNT; ++ray_index)
	inc	c
	ld	a, c
	sub	a, #0x1c
	jp	c, 00127$
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:411: cached_camera_direction_x = camera_direction_x;
	ld	l, -14 (ix)
	ld	h, -13 (ix)
	ld	(_cached_camera_direction_x), hl
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:412: cached_camera_direction_y = camera_direction_y;
	ld	l, -12 (ix)
	ld	h, -11 (ix)
	ld	(_cached_camera_direction_y), hl
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:413: cached_camera_plane_x = camera_plane_x;
	ld	l, -10 (ix)
	ld	h, -9 (ix)
	ld	(_cached_camera_plane_x), hl
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:414: cached_camera_plane_y = camera_plane_y;
	ld	l, -8 (ix)
	ld	h, -7 (ix)
	ld	(_cached_camera_plane_y), hl
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:415: ray_directions_valid = 1;
	ld	hl, #_ray_directions_valid
	ld	(hl), #0x01
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:418: for (ray_index = 0; ray_index < RAY_COUNT; ++ray_index)
00181$:
	ld	-1 (ix), #0x00
00129$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:420: rendered_rays[ray_index].wall_height = cast_ray(
	ld	c, -1 (ix)
	ld	b, #0x00
	ld	l, c
	ld	h, b
	add	hl, hl
	add	hl, bc
	add	hl, hl
	ld	-5 (ix), l
	ld	-4 (ix), h
	ld	a, #<(_rendered_rays)
	add	a, -5 (ix)
	ld	-3 (ix), a
	ld	a, #>(_rendered_rays)
	adc	a, -4 (ix)
	ld	-2 (ix), a
	ld	a, -3 (ix)
	ld	-10 (ix), a
	ld	a, -2 (ix)
	ld	-9 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:426: &rendered_rays[ray_index].wall_distance);
	ld	l, -3 (ix)
	ld	h, -2 (ix)
	ld	de, #0x0004
	add	hl, de
	push	hl
	pop	iy
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:425: &rendered_rays[ray_index].texture_id,
	ld	e, -3 (ix)
	ld	d, -2 (ix)
	inc	de
	inc	de
	inc	de
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:424: &rendered_rays[ray_index].hit_offset,
	ld	c, -3 (ix)
	ld	b, -2 (ix)
	inc	bc
	inc	bc
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:423: &rendered_rays[ray_index].hit_side,
	ld	l, -3 (ix)
	ld	h, -2 (ix)
	inc	hl
	ld	-8 (ix), l
	ld	-7 (ix), h
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:422: ray_direction_y_by_ray[ray_index],
	ld	l, -1 (ix)
	ld	h, #0x00
	add	hl, hl
	ld	-5 (ix), l
	ld	-4 (ix), h
	ld	a, #<(_ray_direction_y_by_ray)
	add	a, -5 (ix)
	ld	l, a
	ld	a, #>(_ray_direction_y_by_ray)
	adc	a, -4 (ix)
	ld	h, a
	ld	a, (hl)
	ld	-3 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-2 (ix), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:421: ray_direction_x_by_ray[ray_index],
	ld	a, #<(_ray_direction_x_by_ray)
	add	a, -5 (ix)
	ld	l, a
	ld	a, #>(_ray_direction_x_by_ray)
	adc	a, -4 (ix)
	ld	h, a
	ld	a, (hl)
	inc	hl
	ld	h, (hl)
	ld	l, a
	push	iy
	push	de
	push	bc
	ld	e, -8 (ix)
	ld	d, -7 (ix)
	push	de
	ld	e, -3 (ix)
	ld	d, -2 (ix)
	call	_cast_ray
	ld	l, -10 (ix)
	ld	h, -9 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:427: ray_hits_switch[ray_index] = cast_hits_switch;
	ld	a, #<(_ray_hits_switch)
	add	a, -1 (ix)
	ld	c, a
	ld	a, #>(_ray_hits_switch)
	adc	a, #0x00
	ld	b, a
	ld	a, (_cast_hits_switch)
	ld	(bc), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:418: for (ray_index = 0; ray_index < RAY_COUNT; ++ray_index)
	inc	-1 (ix)
	ld	a, -1 (ix)
	sub	a, #0x1c
	jp	c, 00129$
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:429: cached_position_x = frame_position_x;
	ld	hl, (_frame_position_x)
	ld	(_cached_position_x), hl
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:430: cached_position_y = frame_position_y;
	ld	hl, (_frame_position_y)
	ld	(_cached_position_y), hl
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:431: cached_doors[0] = doors[0];
	ld	bc, #_cached_doors+0
	ld	a, -17 (ix)
	ld	(bc), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:432: cached_doors[1] = doors[1];
	ld	a, -16 (ix)
	ld	(#(_cached_doors + 1)), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:433: cached_doors[2] = doors[2];
	inc	bc
	inc	bc
	ld	a, -15 (ix)
	ld	(bc), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:434: cached_switch_texture = switch_texture;
	ld	a, -6 (ix)
	ld	(#_cached_switch_texture), a
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:435: ray_output_valid = 1;
	ld	hl, #_ray_output_valid
	ld	(hl), #0x01
00131$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:436: }
	ld	sp, ix
	pop	ix
	ret
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:438: const RaycasterRay *raycaster_get_rendered_rays(void)
;	---------------------------------
; Function raycaster_get_rendered_rays
; ---------------------------------
_raycaster_get_rendered_rays::
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:440: return rendered_rays;
	ld	de, #_rendered_rays
;D:/mano_projektai/GearRay/build-astra-final-control-source/engine/render/raycaster.c:441: }
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
