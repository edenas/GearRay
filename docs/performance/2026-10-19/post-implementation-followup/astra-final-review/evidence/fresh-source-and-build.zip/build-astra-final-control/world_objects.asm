;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (MINGW64)
;--------------------------------------------------------
	.module world_objects
	
	.optsdcc -mz80 sdcccall(1)
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _world_object_get
	.globl _world_object_is_interactive
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute ram data
;--------------------------------------------------------
	.area _DABS (ABS)
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/world_objects.c:20: const WorldObject *world_object_get(WorldObjectId object_id)
;	---------------------------------
; Function world_object_get
; ---------------------------------
_world_object_get::
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/world_objects.c:22: if (object_id >= WORLD_OBJECT_COUNT)
	ld	c, a
	sub	a, #0x03
	jr	c, 00102$
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/world_objects.c:23: object_id = WORLD_OBJECT_NONE;
	ld	c, #0x00
00102$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/world_objects.c:25: return &world_objects[object_id];
	ld	hl, #_world_objects
	ld	b, #0x00
	add	hl, bc
	ex	de, hl
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/world_objects.c:26: }
	ret
_world_objects:
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x01	; 1
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/world_objects.c:28: unsigned char world_object_is_interactive(const WorldObject *object)
;	---------------------------------
; Function world_object_is_interactive
; ---------------------------------
_world_object_is_interactive::
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/world_objects.c:30: if (object == 0)
	ld	a, h
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/world_objects.c:31: return 0;
	or	a,l
	ret	z
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/world_objects.c:33: return object->interactive;
	ld	a, (hl)
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/world_objects.c:34: }
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
