;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (MINGW64)
;--------------------------------------------------------
	.module door_instances
	
	.optsdcc -mz80 sdcccall(1)
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _door_instance_find_at
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute ram data
;--------------------------------------------------------
	.area _DABS (ABS)
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/door_instances.c:15: DoorInstanceId door_instance_find_at(unsigned char x, unsigned char y)
;	---------------------------------
; Function door_instance_find_at
; ---------------------------------
_door_instance_find_at::
	push	ix
	ld	ix,	#0
	add	ix, sp
	push	af
	push	af
	ld	c, a
	ld	-1 (ix), l
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/door_instances.c:19: for (door_id = 0; door_id < DOOR_INSTANCE_COUNT; ++door_id)
	ld	-4 (ix), #0x00
	ld	e, #0x00
00105$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/door_instances.c:21: if (door_instances[door_id].map_x == x &&
	ld	l, e
	ld	h, #0x00
	add	hl, hl
	ld	-3 (ix), l
	ld	-2 (ix), h
	ld	a, #<(_door_instances)
	add	a, -3 (ix)
	ld	l, a
	ld	a, #>(_door_instances)
	adc	a, -2 (ix)
	ld	h, a
	ld	a, (hl)
	sub	a, c
	jr	nz, 00106$
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/door_instances.c:22: door_instances[door_id].map_y == y)
	inc	hl
	ld	a, (hl)
	sub	a, -1 (ix)
	jr	nz, 00106$
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/door_instances.c:23: return door_id;
	ld	a, -4 (ix)
	jr	00107$
00106$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/door_instances.c:19: for (door_id = 0; door_id < DOOR_INSTANCE_COUNT; ++door_id)
	inc	e
	ld	-4 (ix), e
	ld	a, e
	sub	a, #0x03
	jr	c, 00105$
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/door_instances.c:26: return DOOR_INSTANCE_COUNT;
	ld	a, #0x03
00107$:
;D:/mano_projektai/GearRay/build-astra-final-control-source/game/door_instances.c:27: }
	ld	sp, ix
	pop	ix
	ret
_door_instances:
	.db #0x06	; 6
	.db #0x04	; 4
	.db #0x06	; 6
	.db #0x02	; 2
	.db #0x06	; 6
	.db #0x08	; 8
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
