# Z80 performance measurement

Run from the repository root with the pinned Python3.12/JPype1.5.2 bridge and
installed Java8/Emulicious. Game ROMs are uninstrumented Release builds. These
tools never upgrade the emulator, rewrite historical CSVs, or modify game code.

```powershell
py -3.12 tools/performance/build_driver.py --java-tools build-pir-base-20261022/java-tools
py -3.12 tools/performance/test_profiler.py --java-tools build-pir-base-20261022/java-tools --output profiler-test.json
py -3.12 tools/performance/benchmark.py 256 --warmup 32 --logical-input --build build-pir-selected-20261022 --rom rom/GearRay-pir-selected-20261022.gg --java-tools build-pir-base-20261022/java-tools --only A_static,B_rotation,C_forward,F_geometry,G_zombies,I_pistol,I_shotgun,J_lod,L_mixed,M_authored --output replay-new
```

Use a new output directory. If `--rom` is omitted, the selected build's CMake
configuration determines the path. Record the emitted hash; do not assume the
local ignored `rom/GearRay.gg` contains current source. The old bridge is loaded
from `build-perf-20261019/python-tools`; build/tool hashes are retained.

`PerfRunner` closes spans at the exact return PC, return SP and physical return
page, using explicit per-symbol callee cleanup in `abi_cleanup.json`. The two
return-address bytes are separate from cleanup. Register arguments add zero.
Stack arguments include wall preparation1, wall rows4, sprite overlay6, HUD2,
preparation8 and scalar projection16 bytes. Recheck metadata against emitted
SDCC assembly when a prototype or compiler changes; unknown roots fail rather
than silently receiving a guessed cleanup range. No bounded-SP heuristic is
used. The selected game still uses its original calling convention.

Return recognition precedes interrupt acceptance at an already reached caller
site. Function/counter entry requires retiring the opcode, so IRQ/NMI acceptance
does not count as another call. Physical-page checks use pre-opcode mapper
state. World-initialization counter addresses keep their bank bits. Inclusive
child spans overlap their parents and must not be added. Native-wall and cold
region columns separately count retired instruction T states in linked physical
regions; these exclude interrupt acceptance and IRQ instructions outside them.

`test_profiler.py` runs a small synthetic Z80 program in the real core. Hand
counted cases cover three recursive returns, callee cleanup, a same-PC return
under the wrong bank, an IRQ at a tracked RET-only leaf, and deliberately wrong
metadata. Incorrect cleanup remains unclosed, rather than matching a nearby SP.
The synthetic fixture explicitly initializes mapper registers as CRT would.
This tests the observer; it is not a game/hardware compatibility test.

The normal benchmark requires one complete main-input interval. It reports
unclosed spans so interval-crossing calls are visible; spans are not silently
carried across a new `frame()` call. Blocking pause UI reuses the input function
and can cross that boundary; use a dedicated mode/return trace for such spans.
The ten frozen comparison routes complete all tracked spans. `--driver legacy`
uses the preserved original SP-only observer to establish unchanged whole-loop
times and output with the corrected observer. It intentionally misses some
argument-taking children and is not the profiling default.

Routes repeat over16 logical updates independently of sample count. Retain32
warm-up plus256 measured records per route, including cold rows. G/J/L are
seeded gameplay episodes that can die and restart into the authored world;
their averages are not sustained maximum-eight-actor stress. Classify active
and cold rows explicitly, using the now bank-qualified initialization counter
and executed cold code. Logical key seeding proves state/work equivalence;
absolute physical pulses and physical button-to-photon latency are separate
questions. Display refresh is not gameplay FPS.
