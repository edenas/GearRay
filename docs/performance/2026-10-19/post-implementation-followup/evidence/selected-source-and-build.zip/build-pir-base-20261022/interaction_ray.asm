;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (MINGW64)
;--------------------------------------------------------
	.module interaction_ray
	
	.optsdcc -mz80 sdcccall(1)
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _world_object_is_interactive
	.globl _world_object_get
	.globl _world_is_wall
	.globl _world_get_object
	.globl _world_get_tile
	.globl b_interaction_ray_cast
	.globl _interaction_ray_cast
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute ram data
;--------------------------------------------------------
	.area _DABS (ABS)
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _BANK1
;D:/mano_projektai/GearRay/game/interaction_ray.c:9: unsigned char interaction_ray_cast(
;	---------------------------------
; Function interaction_ray_cast
; ---------------------------------
	b_interaction_ray_cast	= 1
_interaction_ray_cast::
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	hl, #-22
	add	hl, sp
	ld	sp, hl
;D:/mano_projektai/GearRay/game/interaction_ray.c:19: signed int previous_map_x = (unsigned int)player_position_x >> 8;
	ld	c, 8 (ix)
	ld	-22 (ix), c
	ld	-21 (ix), #0x00
;D:/mano_projektai/GearRay/game/interaction_ray.c:20: signed int previous_map_y = (unsigned int)player_position_y >> 8;
	ld	c, 10 (ix)
	ld	-20 (ix), c
	ld	-19 (ix), #0x00
;D:/mano_projektai/GearRay/game/interaction_ray.c:27: if (target == 0)
	ld	a, 16 (ix)
	or	a, 15 (ix)
	jr	nz, 00147$
;D:/mano_projektai/GearRay/game/interaction_ray.c:28: return 0;
	xor	a, a
	jp	00119$
;D:/mano_projektai/GearRay/game/interaction_ray.c:30: for (distance = PLAYER_INTERACTION_STEP;
00147$:
	ld	-2 (ix), #0x20
	ld	-1 (ix), #0
00118$:
;D:/mano_projektai/GearRay/game/interaction_ray.c:35: + (signed long)direction_x * distance
	ld	a, 11 (ix)
	ld	-6 (ix), a
	ld	a, 12 (ix)
	ld	-5 (ix), a
	rlca
	sbc	a, a
	ld	-4 (ix), a
	ld	-3 (ix), a
	ld	a, -2 (ix)
	ld	-18 (ix), a
	ld	a, -1 (ix)
	ld	-17 (ix), a
	xor	a, a
	ld	-16 (ix), a
	ld	-15 (ix), a
	ld	hl, #0x0
	push	hl
	ld	l, -18 (ix)
	ld	h, -17 (ix)
	push	hl
	ld	e, -6 (ix)
	ld	d, -5 (ix)
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	call	__mullong
	pop	af
	pop	af
	ld	-10 (ix), e
	ld	-9 (ix), d
	ld	-8 (ix), l
	ld	-7 (ix), h
	ld	hl, #16
	add	hl, sp
	ex	de, hl
	ld	hl, #12
	add	hl, sp
	ld	bc, #4
	ldir
	bit	7, -7 (ix)
	jr	z, 00121$
	ld	de, #0x00ff
	ld	l, -10 (ix)
	ld	h, -9 (ix)
	add	hl, de
	ld	-6 (ix), l
	ld	-5 (ix), h
	ld	a, -8 (ix)
	adc	a, #0x00
	ld	-4 (ix), a
	ld	a, -7 (ix)
	adc	a, #0x00
	ld	-3 (ix), a
00121$:
	ld	a, -6 (ix)
	ld	-14 (ix), a
	ld	a, -5 (ix)
	ld	-13 (ix), a
	ld	a, -4 (ix)
	ld	-12 (ix), a
	ld	a, -3 (ix)
	ld	-11 (ix), a
	ld	b, #0x08
00211$:
	sra	-11 (ix)
	rr	-12 (ix)
	rr	-13 (ix)
	rr	-14 (ix)
	djnz	00211$
	ld	a, 7 (ix)
	ld	-10 (ix), a
	ld	a, 8 (ix)
	ld	-9 (ix), a
	rlca
	sbc	a, a
	ld	-8 (ix), a
	ld	-7 (ix), a
	ld	e, -14 (ix)
	ld	d, -13 (ix)
	ld	l, -10 (ix)
	ld	h, -9 (ix)
	add	hl, de
	ld	-6 (ix), l
	ld	-5 (ix), h
	ld	a, -8 (ix)
	adc	a, -12 (ix)
	ld	-4 (ix), a
	ld	a, -7 (ix)
	adc	a, -11 (ix)
	ld	-3 (ix), a
;D:/mano_projektai/GearRay/game/interaction_ray.c:38: + (signed long)direction_y * distance
	ld	a, 13 (ix)
	ld	-10 (ix), a
	ld	a, 14 (ix)
	ld	-9 (ix), a
	rlca
	sbc	a, a
	ld	-8 (ix), a
	ld	-7 (ix), a
	ld	hl, #0x0
	push	hl
	ld	l, -18 (ix)
	ld	h, -17 (ix)
	push	hl
	ld	e, -10 (ix)
	ld	d, -9 (ix)
	ld	l, -8 (ix)
	ld	h, -7 (ix)
	call	__mullong
	pop	af
	pop	af
	ld	-14 (ix), e
	ld	-13 (ix), d
	ld	-12 (ix), l
	ld	-11 (ix), h
	ld	hl, #12
	add	hl, sp
	ex	de, hl
	ld	hl, #8
	add	hl, sp
	ld	bc, #4
	ldir
	bit	7, -11 (ix)
	jr	z, 00122$
	ld	de, #0x00ff
	ld	l, -14 (ix)
	ld	h, -13 (ix)
	add	hl, de
	ld	-10 (ix), l
	ld	-9 (ix), h
	ld	a, -12 (ix)
	adc	a, #0x00
	ld	-8 (ix), a
	ld	a, -11 (ix)
	adc	a, #0x00
	ld	-7 (ix), a
00122$:
	ld	e, -10 (ix)
	ld	d, -9 (ix)
	ld	l, -8 (ix)
	ld	h, -7 (ix)
	ld	b, #0x08
00213$:
	sra	h
	rr	l
	rr	d
	rr	e
	djnz	00213$
	ld	a, 9 (ix)
	ld	-14 (ix), a
	ld	a, 10 (ix)
	ld	-13 (ix), a
	rlca
	sbc	a, a
	ld	-12 (ix), a
	ld	-11 (ix), a
	ld	a, -14 (ix)
	add	a, e
	ld	-10 (ix), a
	ld	a, -13 (ix)
	adc	a, d
	ld	-9 (ix), a
	ld	a, -12 (ix)
	adc	a, l
	ld	-8 (ix), a
	ld	a, -11 (ix)
	adc	a, h
	ld	-7 (ix), a
;D:/mano_projektai/GearRay/game/interaction_ray.c:41: if (sample_x < 0 || sample_y < 0)
	bit	7, -3 (ix)
	jr	nz, 00103$
	bit	7, -7 (ix)
	jr	z, 00104$
00103$:
;D:/mano_projektai/GearRay/game/interaction_ray.c:42: return 0;
	xor	a, a
	jp	00119$
00104$:
;D:/mano_projektai/GearRay/game/interaction_ray.c:44: map_x = (signed int)(sample_x / FIXED_POINT_SCALE);
	ld	e, -6 (ix)
	ld	d, -5 (ix)
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	ld	b, #0x08
00215$:
	sra	h
	rr	l
	rr	d
	rr	e
	djnz	00215$
;D:/mano_projektai/GearRay/game/interaction_ray.c:45: map_y = (signed int)(sample_y / FIXED_POINT_SCALE);
	ld	c, -10 (ix)
	ld	b, -9 (ix)
	ld	l, -8 (ix)
	ld	h, -7 (ix)
	ld	a, #0x08
00217$:
	sra	h
	rr	l
	rr	b
	rr	c
	dec	a
	jr	nz, 00217$
;D:/mano_projektai/GearRay/game/interaction_ray.c:47: if (map_x >= WORLD_WIDTH || map_y >= WORLD_HEIGHT)
	ld	a, e
	sub	a, #0x0d
	ld	a, d
	rla
	ccf
	rra
	sbc	a, #0x80
	jr	nc, 00106$
	ld	a, c
	sub	a, #0x0d
	ld	a, b
	rla
	ccf
	rra
	sbc	a, #0x80
	jr	c, 00107$
00106$:
;D:/mano_projektai/GearRay/game/interaction_ray.c:48: return 0;
	xor	a, a
	jp	00119$
00107$:
;D:/mano_projektai/GearRay/game/interaction_ray.c:50: if (map_x == previous_map_x && map_y == previous_map_y)
	pop	hl
	push	hl
	xor	a, a
	sbc	hl, de
	jr	nz, 00110$
	ld	l, -20 (ix)
	ld	h, -19 (ix)
	xor	a, a
	sbc	hl, bc
	jr	z, 00116$
;D:/mano_projektai/GearRay/game/interaction_ray.c:51: continue;
00110$:
;D:/mano_projektai/GearRay/game/interaction_ray.c:53: previous_map_x = map_x;
	pop	hl
	push	de
;D:/mano_projektai/GearRay/game/interaction_ray.c:54: previous_map_y = map_y;
	ld	-20 (ix), c
	ld	-19 (ix), b
;D:/mano_projektai/GearRay/game/interaction_ray.c:56: (unsigned char)map_y);
	ld	-4 (ix), c
;D:/mano_projektai/GearRay/game/interaction_ray.c:55: tile_id = world_get_tile((unsigned char)map_x,
	push	de
	ld	l, -4 (ix)
	ld	a, e
	call	_world_get_tile
;D:/mano_projektai/GearRay/game/interaction_ray.c:57: object_id = world_get_object(tile_id);
	ld	-3 (ix), a
	call	_world_get_object
	ld	c, a
	pop	de
;D:/mano_projektai/GearRay/game/interaction_ray.c:58: object = world_object_get(object_id);
	push	bc
	push	de
	ld	a, c
	call	_world_object_get
	ex	de, hl
;D:/mano_projektai/GearRay/game/interaction_ray.c:60: if (world_object_is_interactive(object))
	call	_world_object_is_interactive
	pop	de
	pop	bc
	or	a, a
	jr	z, 00113$
;D:/mano_projektai/GearRay/game/interaction_ray.c:62: target->map_x = (unsigned char)map_x;
	ld	l, 15 (ix)
	ld	h, 16 (ix)
	ld	(hl), e
;D:/mano_projektai/GearRay/game/interaction_ray.c:63: target->map_y = (unsigned char)map_y;
	ld	e, l
	ld	d, h
	inc	de
	ld	a, -4 (ix)
	ld	(de), a
;D:/mano_projektai/GearRay/game/interaction_ray.c:64: target->tile_id = tile_id;
	ld	e, l
	ld	d, h
	inc	de
	inc	de
	ld	a, -3 (ix)
;D:/mano_projektai/GearRay/game/interaction_ray.c:65: target->object_id = object_id;
	inc	hl
	inc	hl
	inc	hl
	ld	(de), a
	ld	(hl), c
;D:/mano_projektai/GearRay/game/interaction_ray.c:66: return 1;
	ld	a, #0x01
	jr	00119$
00113$:
;D:/mano_projektai/GearRay/game/interaction_ray.c:69: if (world_is_wall((unsigned char)map_x,
	ld	l, -4 (ix)
	ld	a, e
	call	_world_is_wall
	or	a, a
	jr	z, 00116$
;D:/mano_projektai/GearRay/game/interaction_ray.c:71: return 0;
	xor	a, a
	jr	00119$
00116$:
;D:/mano_projektai/GearRay/game/interaction_ray.c:32: distance += PLAYER_INTERACTION_STEP)
	ld	de, #0x0020
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	add	hl, de
	ld	-2 (ix), l
	ld	-1 (ix), h
;D:/mano_projektai/GearRay/game/interaction_ray.c:31: distance <= PLAYER_INTERACTION_RANGE;
	ld	a, #0x4a
	cp	a, -2 (ix)
	ld	a, #0x02
	sbc	a, -1 (ix)
	jp	nc, 00118$
;D:/mano_projektai/GearRay/game/interaction_ray.c:74: return 0;
	xor	a, a
00119$:
;D:/mano_projektai/GearRay/game/interaction_ray.c:75: }
	ld	sp, ix
	pop	ix
	ret
	.area _BANK1
	.area _INITIALIZER
	.area _CABS (ABS)
