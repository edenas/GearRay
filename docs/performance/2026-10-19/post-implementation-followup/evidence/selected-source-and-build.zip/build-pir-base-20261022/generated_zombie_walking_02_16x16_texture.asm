;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (MINGW64)
;--------------------------------------------------------
	.module zombie_walking_02_16x16_texture
	
	.optsdcc -mz80 sdcccall(1)
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _zombie_middle_walking_02_pixels
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute ram data
;--------------------------------------------------------
	.area _DABS (ABS)
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
	.area _CODE
	.area _BANK1
	.area _BANK1
_zombie_middle_walking_02_pixels:
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xf0	; 240
	.db #0x56	; 86	'V'
	.db #0x70	; 112	'p'
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xf6	; 246
	.db #0xc7	; 199
	.db #0xc7	; 199
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xf5	; 245
	.db #0x00	; 0
	.db #0x07	; 7
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0x50	; 80	'P'
	.db #0x6f	; 111	'o'
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xf7	; 247
	.db #0x8d	; 141
	.db #0xd0	; 208
	.db #0x05	; 5
	.db #0x0d	; 13
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xf7	; 247
	.db #0x57	; 87	'W'
	.db #0x80	; 128
	.db #0xdd	; 221
	.db #0x00	; 0
	.db #0xdd	; 221
	.db #0x5f	; 95
	.db #0xff	; 255
	.db #0x7d	; 125
	.db #0xff	; 255
	.db #0xf8	; 248
	.db #0xdd	; 221
	.db #0xdd	; 221
	.db #0x58	; 88	'X'
	.db #0x88	; 136
	.db #0xff	; 255
	.db #0x76	; 118	'v'
	.db #0xff	; 255
	.db #0xf8	; 248
	.db #0x0d	; 13
	.db #0xdd	; 221
	.db #0xdf	; 223
	.db #0xf7	; 247
	.db #0xff	; 255
	.db #0x75	; 117	'u'
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0x88	; 136
	.db #0x88	; 136
	.db #0x8f	; 143
	.db #0xfd	; 253
	.db #0x7f	; 127
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xf0	; 240
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0xf7	; 247
	.db #0x7f	; 127
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xdd	; 221
	.db #0xdd	; 221
	.db #0xdd	; 221
	.db #0xf5	; 245
	.db #0x6f	; 111	'o'
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xf5	; 245
	.db #0xdd	; 221
	.db #0xff	; 255
	.db #0xdd	; 221
	.db #0xdf	; 223
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xf5	; 245
	.db #0x7f	; 127
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xdd	; 221
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x5f	; 95
	.db #0xff	; 255
	.db #0xf0	; 240
	.db #0x00	; 0
	.db #0x0f	; 15
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
