;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (MINGW64)
;--------------------------------------------------------
	.module zombie_01_walking_02_texture
	
	.optsdcc -mz80 sdcccall(1)
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _zombie_01_walking_02_pixels_simple_lod
	.globl _zombie_01_walking_02_pixels_medium_lod
	.globl _zombie_01_walking_02_pixels
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute ram data
;--------------------------------------------------------
	.area _DABS (ABS)
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
	.area _CODE
	.area _BANK1
	.area _BANK1
_zombie_01_walking_02_pixels:
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0x77	; 119	'w'
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0x57	; 87	'W'
	.db #0xff	; 255
	.db #0xf8	; 248
	.db #0x70	; 112	'p'
	.db #0x08	; 8
	.db #0xff	; 255
	.db #0x8f	; 143
	.db #0x50	; 80	'P'
	.db #0x00	; 0
	.db #0x8f	; 143
	.db #0x7f	; 127
	.db #0x88	; 136
	.db #0x88	; 136
	.db #0xf8	; 248
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xf7	; 247
	.db #0xff	; 255
	.db #0x5f	; 95
	.db #0xff	; 255
	.db #0x0f	; 15
	.db #0xff	; 255
	.db #0x0f	; 15
	.db #0xff	; 255
	.db #0xf0	; 240
	.area _CODE
	.area _BANK1
_zombie_01_walking_02_pixels_medium_lod:
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xdd	; 221
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xad	; 173
	.db #0xff	; 255
	.db #0xfd	; 253
	.db #0xdd	; 221
	.db #0xdd	; 221
	.db #0xff	; 255
	.db #0xdf	; 223
	.db #0xad	; 173
	.db #0xdd	; 221
	.db #0xdf	; 223
	.db #0xdf	; 223
	.db #0xdd	; 221
	.db #0xdd	; 221
	.db #0xfd	; 253
	.db #0xff	; 255
	.db #0xdd	; 221
	.db #0xdd	; 221
	.db #0xfd	; 253
	.db #0xff	; 255
	.db #0xaf	; 175
	.db #0xff	; 255
	.db #0xdf	; 223
	.db #0xff	; 255
	.db #0xdf	; 223
	.db #0xff	; 255
	.db #0xfd	; 253
	.area _CODE
	.area _BANK1
_zombie_01_walking_02_pixels_simple_lod:
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xdd	; 221
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xdd	; 221
	.db #0xff	; 255
	.db #0xfd	; 253
	.db #0xdd	; 221
	.db #0xdd	; 221
	.db #0xff	; 255
	.db #0xdf	; 223
	.db #0xdd	; 221
	.db #0xdd	; 221
	.db #0xdf	; 223
	.db #0xdf	; 223
	.db #0xdd	; 221
	.db #0xdd	; 221
	.db #0xfd	; 253
	.db #0xff	; 255
	.db #0xdd	; 221
	.db #0xdd	; 221
	.db #0xfd	; 253
	.db #0xff	; 255
	.db #0xdf	; 223
	.db #0xff	; 255
	.db #0xdf	; 223
	.db #0xff	; 255
	.db #0xdf	; 223
	.db #0xff	; 255
	.db #0xfd	; 253
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
