;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (MINGW64)
;--------------------------------------------------------
	.module zombie_corpses
	
	.optsdcc -mz80 sdcccall(1)
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _world_sprite_get
	.globl _world_sprite_get_count
	.globl _world_sprite_remove
	.globl _world_sprite_make_corpse
	.globl _zombie_corpses_finalize
	.globl _zombie_corpses_crush_in_door
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute ram data
;--------------------------------------------------------
	.area _DABS (ABS)
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _BANK2
;D:/mano_projektai/GearRay/game/zombie_corpses.c:8: static unsigned char zombie_corpses_merge(unsigned char sprite_index)
;	---------------------------------
; Function zombie_corpses_merge
; ---------------------------------
_zombie_corpses_merge:
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	hl, #-5
	add	hl, sp
	ld	sp, hl
	ld	c, a
;D:/mano_projektai/GearRay/game/zombie_corpses.c:11: WorldSprite *sprite = world_sprite_get(sprite_index);
	push	bc
	ld	a, c
	call	_world_sprite_get
	ld	-5 (ix), e
	ld	-4 (ix), d
	pop	bc
;D:/mano_projektai/GearRay/game/zombie_corpses.c:13: for (other_index = 0;
	ld	e, #0x00
	ld	a, -5 (ix)
	ld	-3 (ix), a
	ld	a, -4 (ix)
	ld	-2 (ix), a
	ld	-1 (ix), #0x00
00109$:
;D:/mano_projektai/GearRay/game/zombie_corpses.c:14: other_index < world_sprite_get_count();
	push	bc
	push	de
	call	_world_sprite_get_count
	ld	l, a
	pop	de
	pop	bc
	ld	a, -1 (ix)
	sub	a, l
	jp	nc, 00107$
;D:/mano_projektai/GearRay/game/zombie_corpses.c:17: WorldSprite *other = world_sprite_get(other_index);
	push	bc
	push	de
	ld	a, -1 (ix)
	call	_world_sprite_get
	push	de
	pop	iy
	pop	de
	pop	bc
;D:/mano_projektai/GearRay/game/zombie_corpses.c:21: || WORLD_SPRITE_LIFE_STATE(other) != ZOMBIE_STATE_CORPSE
	ld	a, -1 (ix)
	sub	a, c
	jr	z, 00106$
	push	iy
	pop	hl
	push	bc
	ld	bc, #0x0006
	add	hl, bc
	pop	bc
	ld	a, (hl)
	and	a, #0x03
	cp	a, #0x02
	jr	nz, 00106$
;D:/mano_projektai/GearRay/game/zombie_corpses.c:22: || (unsigned int)(sprite->world_x - other->world_x
	pop	hl
	push	hl
	ld	a, (hl)
	inc	hl
	ld	b, (hl)
	push	af
	ld	l, 0 (iy)
	ld	d, 1 (iy)
	pop	af
	sub	a, l
	ld	l, a
	ld	a, b
	sbc	a, d
	ld	h, a
	push	de
	ld	de, #0x003f
	add	hl, de
	pop	de
	ld	a, l
	sub	a, #0x7f
	ld	a, h
	sbc	a, #0x00
	jr	nc, 00106$
;D:/mano_projektai/GearRay/game/zombie_corpses.c:25: || (unsigned int)(sprite->world_y - other->world_y
	ld	l, -3 (ix)
	ld	h, -2 (ix)
	inc	hl
	inc	hl
	ld	a, (hl)
	inc	hl
	ld	b, (hl)
	push	iy
	pop	hl
	inc	hl
	inc	hl
	push	af
	ld	a, (hl)
	inc	hl
	ld	h, (hl)
	ld	l, a
	pop	af
	sub	a, l
	ld	l, a
	ld	a, b
	sbc	a, h
	ld	h, a
	push	de
	ld	de, #0x003f
	add	hl, de
	pop	de
	ld	a, l
	sub	a, #0x7f
	ld	a, h
	sbc	a, #0x00
	jr	nc, 00106$
;D:/mano_projektai/GearRay/game/zombie_corpses.c:33: ? other_index : sprite_index;
	ld	a, c
	sub	a, e
	jr	c, 00113$
	ld	e, c
00113$:
	ld	b, e
;D:/mano_projektai/GearRay/game/zombie_corpses.c:34: world_sprite_remove(removed_index);
	push	bc
	ld	a, b
	call	_world_sprite_remove
	pop	bc
;D:/mano_projektai/GearRay/game/zombie_corpses.c:35: return removed_index == sprite_index;
	ld	a, c
	sub	a, b
	jr	nz, 00173$
	ld	a, #0x01
	jr	00110$
00173$:
	xor	a, a
	jr	00110$
00106$:
;D:/mano_projektai/GearRay/game/zombie_corpses.c:15: ++other_index)
	inc	-1 (ix)
	ld	e, -1 (ix)
	jp	00109$
00107$:
;D:/mano_projektai/GearRay/game/zombie_corpses.c:37: return 0;
	xor	a, a
00110$:
;D:/mano_projektai/GearRay/game/zombie_corpses.c:38: }
	ld	sp, ix
	pop	ix
	ret
;D:/mano_projektai/GearRay/game/zombie_corpses.c:40: unsigned char zombie_corpses_finalize(
;	---------------------------------
; Function zombie_corpses_finalize
; ---------------------------------
_zombie_corpses_finalize::
	ld	c, a
;D:/mano_projektai/GearRay/game/zombie_corpses.c:43: world_sprite_make_corpse(sprite_index);
	push	bc
	ld	a, c
	call	_world_sprite_make_corpse
	pop	bc
;D:/mano_projektai/GearRay/game/zombie_corpses.c:44: return zombie_corpses_merge(sprite_index);
	ld	a, c
;D:/mano_projektai/GearRay/game/zombie_corpses.c:45: }
	jp	_zombie_corpses_merge
;D:/mano_projektai/GearRay/game/zombie_corpses.c:47: void zombie_corpses_crush_in_door(unsigned char map_y)
;	---------------------------------
; Function zombie_corpses_crush_in_door
; ---------------------------------
_zombie_corpses_crush_in_door::
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	hl, #-12
	add	hl, sp
	ld	sp, hl
;D:/mano_projektai/GearRay/game/zombie_corpses.c:49: signed int door_center_y = ((signed int)map_y << 8) + 128;
	ld	c, a
	ld	-12 (ix), #0x80
	ld	-11 (ix), c
;D:/mano_projektai/GearRay/game/zombie_corpses.c:50: unsigned char sprite_index = 0;
	ld	-10 (ix), #0x00
;D:/mano_projektai/GearRay/game/zombie_corpses.c:52: while (sprite_index < world_sprite_get_count())
	ld	de, #0x00a0
	pop	hl
	push	hl
	add	hl, de
	ld	-9 (ix), l
	ld	-8 (ix), h
	ld	a, -12 (ix)
	add	a, #0x5f
	ld	-7 (ix), a
	ld	a, -11 (ix)
	adc	a, #0xff
	ld	-6 (ix), a
00107$:
	call	_world_sprite_get_count
	ld	c, a
	ld	a, -10 (ix)
	sub	a, c
	jp	nc, 00110$
;D:/mano_projektai/GearRay/game/zombie_corpses.c:54: WorldSprite *sprite = world_sprite_get(sprite_index);
	ld	a, -10 (ix)
	call	_world_sprite_get
;D:/mano_projektai/GearRay/game/zombie_corpses.c:56: if (WORLD_SPRITE_LIFE_STATE(sprite) != ZOMBIE_STATE_ALIVE
	push	de
	pop	iy
	ld	c, 6 (iy)
;D:/mano_projektai/GearRay/game/zombie_corpses.c:62: ++sprite_index;
	ld	a, -10 (ix)
	inc	a
	ld	-5 (ix), a
;D:/mano_projektai/GearRay/game/zombie_corpses.c:56: if (WORLD_SPRITE_LIFE_STATE(sprite) != ZOMBIE_STATE_ALIVE
	ld	a, c
	and	a, #0x03
	jr	nz, 00101$
;D:/mano_projektai/GearRay/game/zombie_corpses.c:57: || (unsigned int)(sprite->world_x
	ld	c, e
	ld	b, d
	ld	l, c
	ld	h, b
	ld	a, (hl)
	inc	hl
	ld	l, (hl)
	add	a, #0x20
	ld	h, a
	ld	a, l
	adc	a, #0xfa
	ld	l, a
	ld	a, h
	sub	a, #0x40
	ld	a, l
	sbc	a, #0x01
	jr	nc, 00101$
;D:/mano_projektai/GearRay/game/zombie_corpses.c:59: || (unsigned int)(sprite->world_y - door_center_y + 160)
	inc	de
	inc	de
	ld	l, e
	ld	h, d
	ld	a, (hl)
	inc	hl
	ld	h, (hl)
	sub	a, -12 (ix)
	ld	l, a
	ld	a, h
	sbc	a, -11 (ix)
	ld	h, a
	push	de
	ld	de, #0x00a0
	add	hl, de
	pop	de
	ld	a, l
	sub	a, #0x40
	ld	a, h
	sbc	a, #0x01
	jr	c, 00102$
00101$:
;D:/mano_projektai/GearRay/game/zombie_corpses.c:62: ++sprite_index;
	ld	a, -5 (ix)
	ld	-10 (ix), a
;D:/mano_projektai/GearRay/game/zombie_corpses.c:63: continue;
	jr	00107$
00102$:
;D:/mano_projektai/GearRay/game/zombie_corpses.c:66: sprite->world_x = 6 * FIXED_POINT_SCALE + 128;
	ld	a, #0x80
	ld	(bc), a
	inc	bc
	ld	a, #0x06
	ld	(bc), a
;D:/mano_projektai/GearRay/game/zombie_corpses.c:67: sprite->world_y = sprite->world_y < door_center_y
	ld	-4 (ix), e
	ld	-3 (ix), d
	ex	de, hl
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	ld	a, c
	sub	a, -12 (ix)
	ld	a, b
	sbc	a, -11 (ix)
	jp	po, 00164$
	xor	a, #0x80
00164$:
	jp	p, 00112$
;D:/mano_projektai/GearRay/game/zombie_corpses.c:69: : door_center_y + 128 + ZOMBIE_COLLISION_RADIUS;
	ld	a, -7 (ix)
	ld	-2 (ix), a
	ld	a, -6 (ix)
	ld	-1 (ix), a
	jr	00113$
00112$:
	ld	a, -9 (ix)
	ld	-2 (ix), a
	ld	a, -8 (ix)
	ld	-1 (ix), a
00113$:
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	ld	a, -2 (ix)
	ld	(hl), a
	inc	hl
	ld	a, -1 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/game/zombie_corpses.c:71: world_sprite_make_corpse(sprite_index);
	ld	a, -10 (ix)
	call	_world_sprite_make_corpse
;D:/mano_projektai/GearRay/game/zombie_corpses.c:72: if (!zombie_corpses_merge(sprite_index))
	ld	a, -10 (ix)
	call	_zombie_corpses_merge
	or	a, a
	jp	nz, 00107$
;D:/mano_projektai/GearRay/game/zombie_corpses.c:73: ++sprite_index;
	ld	a, -5 (ix)
	ld	-10 (ix), a
	jp	00107$
00110$:
;D:/mano_projektai/GearRay/game/zombie_corpses.c:75: }
	ld	sp, ix
	pop	ix
	ret
	.area _BANK2
	.area _INITIALIZER
	.area _CABS (ABS)
