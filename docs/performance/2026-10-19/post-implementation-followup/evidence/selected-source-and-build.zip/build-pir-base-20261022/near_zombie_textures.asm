;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (MINGW64)
;--------------------------------------------------------
	.module near_zombie_textures
	
	.optsdcc -mz80 sdcccall(1)
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _near_zombie_texture_pixels
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute ram data
;--------------------------------------------------------
	.area _DABS (ABS)
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
	.area _CODE
	.area _BANK2
	.area _BANK2
_near_zombie_texture_pixels:
	.dw _zombie_near_walking_01_pixels
	.dw _zombie_near_walking_02_pixels
	.dw _zombie_near_standing_attack_pixels
	.dw _zombie_near_attack_01_pixels
	.dw _zombie_near_attack_02_pixels
	.dw _zombie_near_shot_01_pixels
	.dw _zombie_near_corpse_pixels
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
