;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (MINGW64)
;--------------------------------------------------------
	.module world_interactions
	
	.optsdcc -mz80 sdcccall(1)
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _world_sprites_crush_in_door
	.globl _world_object_is_interactive
	.globl _world_object_get
	.globl _red_door_switch_activate
	.globl _player_get_position_y
	.globl _player_get_position_x
	.globl _door_state_toggle
	.globl _door_state_get
	.globl _door_instance_find_at
	.globl b_world_interact
	.globl _world_interact
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute ram data
;--------------------------------------------------------
	.area _DABS (ABS)
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _BANK1
;D:/mano_projektai/GearRay/game/world_interactions.c:10: void world_interact(const InteractionTarget *target) __banked
;	---------------------------------
; Function world_interact
; ---------------------------------
	b_world_interact	= 1
_world_interact::
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	hl, #-6
	add	hl, sp
	ld	sp, hl
;D:/mano_projektai/GearRay/game/world_interactions.c:17: if (target == 0)
	ld	a, 8 (ix)
	or	a, 7 (ix)
;D:/mano_projektai/GearRay/game/world_interactions.c:18: return;
	jp	z, 00121$
;D:/mano_projektai/GearRay/game/world_interactions.c:20: object = world_object_get(target->object_id);
	ld	e, 7 (ix)
	ld	d, 8 (ix)
	ld	c, e
	ld	b, d
	inc	bc
	inc	bc
	inc	bc
	ld	a, (bc)
	push	bc
	push	de
	call	_world_object_get
	ex	de, hl
;D:/mano_projektai/GearRay/game/world_interactions.c:22: if (!world_object_is_interactive(object))
	call	_world_object_is_interactive
	pop	de
	pop	bc
	or	a, a
;D:/mano_projektai/GearRay/game/world_interactions.c:23: return;
	jp	z, 00121$
;D:/mano_projektai/GearRay/game/world_interactions.c:25: switch (target->object_id)
	ld	a, (bc)
	or	a, a
	jp	z, 00121$
	cp	a, #0x01
	jr	z, 00105$
	cp	a, #0x02
	jp	z, 00117$
	jp	00121$
;D:/mano_projektai/GearRay/game/world_interactions.c:27: case WORLD_OBJECT_DOOR:
00105$:
;D:/mano_projektai/GearRay/game/world_interactions.c:29: target->map_y);
	ld	l, e
	ld	h, d
	inc	hl
	ex	(sp), hl
	pop	hl
	push	hl
	ld	l, (hl)
;D:/mano_projektai/GearRay/game/world_interactions.c:28: door_instance = door_instance_find_at(target->map_x,
	ld	c, e
	ld	b, d
	ld	a, (bc)
	push	bc
	push	de
	call	_door_instance_find_at
	ld	-4 (ix), a
	pop	de
	pop	bc
;D:/mano_projektai/GearRay/game/world_interactions.c:31: if (door_instance >= DOOR_INSTANCE_COUNT)
	ld	a, -4 (ix)
	sub	a, #0x03
	jr	nc, 00121$
;D:/mano_projektai/GearRay/game/world_interactions.c:34: if (target->tile_id == WORLD_TILE_RED_DOOR)
	inc	de
	inc	de
	ld	a, (de)
	cp	a, #0x06
	jr	z, 00121$
;D:/mano_projektai/GearRay/game/world_interactions.c:37: if (door_state_get(door_instance) == DOOR_STATE_OPEN)
	push	bc
	ld	a, -4 (ix)
	call	_door_state_get
	pop	bc
	cp	a, #0x01
	jr	nz, 00116$
;D:/mano_projektai/GearRay/game/world_interactions.c:39: player_x = player_get_position_x();
	push	bc
	call	_player_get_position_x
	ld	-3 (ix), e
	ld	-2 (ix), d
;D:/mano_projektai/GearRay/game/world_interactions.c:40: player_y = player_get_position_y();
	call	_player_get_position_y
	pop	bc
;D:/mano_projektai/GearRay/game/world_interactions.c:41: if (target->map_x
	ld	a, (bc)
	ld	b, a
;D:/mano_projektai/GearRay/game/world_interactions.c:43: - PLAYER_COLLISION_RADIUS) >> 8)
	ld	a, -3 (ix)
	add	a, #0xe0
	ld	a, -2 (ix)
	adc	a, #0xff
	ld	-1 (ix), a
;D:/mano_projektai/GearRay/game/world_interactions.c:29: target->map_y);
	pop	hl
	push	hl
	ld	c, (hl)
;D:/mano_projektai/GearRay/game/world_interactions.c:43: - PLAYER_COLLISION_RADIUS) >> 8)
	ld	a, b
	sub	a, -1 (ix)
	jr	c, 00111$
;D:/mano_projektai/GearRay/game/world_interactions.c:46: + PLAYER_COLLISION_RADIUS) >> 8)
	ld	a, -3 (ix)
	add	a, #0x20
	ld	a, -2 (ix)
	adc	a, #0x00
	sub	a, b
	jr	c, 00111$
;D:/mano_projektai/GearRay/game/world_interactions.c:49: - PLAYER_COLLISION_RADIUS) >> 8)
	ld	a, e
	add	a, #0xe0
	ld	a, d
	adc	a, #0xff
	ld	b, a
	ld	a, c
	sub	a, b
	jr	c, 00111$
;D:/mano_projektai/GearRay/game/world_interactions.c:52: + PLAYER_COLLISION_RADIUS) >> 8))
	ld	hl, #0x0020
	add	hl, de
	ld	a, h
	sub	a, c
	jr	nc, 00121$
;D:/mano_projektai/GearRay/game/world_interactions.c:54: break;
00111$:
;D:/mano_projektai/GearRay/game/world_interactions.c:56: world_sprites_crush_in_door(target->map_y);
	ld	a, c
	call	_world_sprites_crush_in_door
00116$:
;D:/mano_projektai/GearRay/game/world_interactions.c:58: door_state_toggle(door_instance);
	ld	a, -4 (ix)
	call	_door_state_toggle
;D:/mano_projektai/GearRay/game/world_interactions.c:59: break;
	jr	00121$
;D:/mano_projektai/GearRay/game/world_interactions.c:61: case WORLD_OBJECT_RED_DOOR_SWITCH:
00117$:
;D:/mano_projektai/GearRay/game/world_interactions.c:62: red_door_switch_activate();
	call	_red_door_switch_activate
;D:/mano_projektai/GearRay/game/world_interactions.c:68: }
00121$:
;D:/mano_projektai/GearRay/game/world_interactions.c:69: }
	ld	sp, ix
	pop	ix
	ret
	.area _BANK1
	.area _INITIALIZER
	.area _CABS (ABS)
