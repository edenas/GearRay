;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (MINGW64)
;--------------------------------------------------------
	.module world_sprite
	
	.optsdcc -mz80 sdcccall(1)
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _zombie_corpses_crush_in_door
	.globl _zombie_corpses_finalize
	.globl _world_sprite_remove
	.globl _world_sprites_initialize
	.globl _world_sprite_initialize
	.globl _world_sprites_update
	.globl _world_sprite_make_corpse
	.globl _world_sprites_crush_in_door
	.globl _world_sprite_apply_damage
	.globl _world_sprite_get_count
	.globl _world_sprite_get
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
_world_sprites:
	.ds 72
_world_sprite_count:
	.ds 1
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute ram data
;--------------------------------------------------------
	.area _DABS (ABS)
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;D:/mano_projektai/GearRay/game/world_sprite.c:16: void world_sprite_remove(unsigned char sprite_index)
;	---------------------------------
; Function world_sprite_remove
; ---------------------------------
_world_sprite_remove::
	ld	c, a
;D:/mano_projektai/GearRay/game/world_sprite.c:18: zombie_ai_wall_following_mask = 0;
	xor	a, a
	ld	(#_zombie_ai_wall_following_mask), a
;D:/mano_projektai/GearRay/game/world_sprite.c:19: --world_sprite_count;
	ld	hl, #_world_sprite_count
	dec	(hl)
;D:/mano_projektai/GearRay/game/world_sprite.c:20: if (sprite_index != world_sprite_count)
	ld	a, (_world_sprite_count)
	sub	a, c
	ret	z
;D:/mano_projektai/GearRay/game/world_sprite.c:21: world_sprites[sprite_index] = world_sprites[world_sprite_count];
	ld	a, (#_world_sprite_count + 0)
	ld	e, a
	ld	d, #0x00
	ld	l, e
	ld	h, d
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, de
	ld	de, #_world_sprites
	add	hl, de
	ex	de, hl
	ld	b, #0x00
	ld	l, c
	ld	h, b
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, bc
	ld	bc, #_world_sprites
	add	hl, bc
	ld	bc, #0x0009
	push	bc
	call	___memcpy
;D:/mano_projektai/GearRay/game/world_sprite.c:22: }
	ret
;D:/mano_projektai/GearRay/game/world_sprite.c:24: static void world_sprite_set_state(WorldSprite *sprite, ZombieState state)
;	---------------------------------
; Function world_sprite_set_state
; ---------------------------------
_world_sprite_set_state:
	push	ix
	ld	ix,	#0
	add	ix, sp
	ex	de, hl
;D:/mano_projektai/GearRay/game/world_sprite.c:26: sprite->state = state;
	ld	hl, #0x0006
	add	hl, de
	ld	a, 4 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/game/world_sprite.c:27: sprite->state_timer = 0;
	ld	hl, #0x0008
	add	hl, de
	ld	c, l
	ld	b, h
	xor	a, a
	ld	(bc), a
;D:/mano_projektai/GearRay/game/world_sprite.c:30: sprite->pixels = zombie_01_standing_pixels;
	inc	de
	inc	de
	inc	de
	inc	de
;D:/mano_projektai/GearRay/game/world_sprite.c:29: if (state == ZOMBIE_STATE_ALIVE)
	ld	a, 4 (ix)
	or	a, a
	jr	nz, 00105$
;D:/mano_projektai/GearRay/game/world_sprite.c:30: sprite->pixels = zombie_01_standing_pixels;
	ld	a, #<(_zombie_01_standing_pixels)
	ld	(de), a
	inc	de
	ld	a, #>(_zombie_01_standing_pixels)
	ld	(de), a
	jr	00107$
00105$:
;D:/mano_projektai/GearRay/game/world_sprite.c:31: else if (state == ZOMBIE_STATE_SHOT_DEAD)
	ld	a, 4 (ix)
	dec	a
	jr	nz, 00102$
;D:/mano_projektai/GearRay/game/world_sprite.c:33: sprite->pixels = zombie_01_shot_dead_pixels;
	ld	a, #<(_zombie_01_shot_dead_pixels)
	ld	(de), a
	inc	de
	ld	a, #>(_zombie_01_shot_dead_pixels)
	ld	(de), a
;D:/mano_projektai/GearRay/game/world_sprite.c:34: sprite->state_timer = ZOMBIE_SHOT_DEAD_FRAME_COUNT;
	ld	a, #0x04
	ld	(bc), a
	jr	00107$
00102$:
;D:/mano_projektai/GearRay/game/world_sprite.c:37: sprite->pixels = zombie_01_corps_pixels;
	ld	a, #<(_zombie_01_corps_pixels)
	ld	(de), a
	inc	de
	ld	a, #>(_zombie_01_corps_pixels)
	ld	(de), a
00107$:
;D:/mano_projektai/GearRay/game/world_sprite.c:38: }
	pop	ix
	pop	hl
	inc	sp
	jp	(hl)
;D:/mano_projektai/GearRay/game/world_sprite.c:40: void world_sprites_initialize(void)
;	---------------------------------
; Function world_sprites_initialize
; ---------------------------------
_world_sprites_initialize::
;D:/mano_projektai/GearRay/game/world_sprite.c:42: zombie_ai_wall_following_mask = 0;
;D:/mano_projektai/GearRay/game/world_sprite.c:43: world_sprite_count = 0;
	xor	a, a
	ld	(#_zombie_ai_wall_following_mask), a
	ld	(#_world_sprite_count), a
;D:/mano_projektai/GearRay/game/world_sprite.c:44: }
	ret
;D:/mano_projektai/GearRay/game/world_sprite.c:46: void world_sprite_initialize(unsigned char map_x, unsigned char map_y)
;	---------------------------------
; Function world_sprite_initialize
; ---------------------------------
_world_sprite_initialize::
	push	ix
	ld	ix,	#0
	add	ix, sp
	dec	sp
	ld	c, a
	ld	-1 (ix), l
;D:/mano_projektai/GearRay/game/world_sprite.c:50: if (world_sprite_count >= WORLD_SPRITE_MAX_COUNT)
	ld	a, (_world_sprite_count+0)
	sub	a, #0x08
;D:/mano_projektai/GearRay/game/world_sprite.c:51: return;
	jr	nc, 00103$
;D:/mano_projektai/GearRay/game/world_sprite.c:53: sprite = &world_sprites[world_sprite_count++];
	ld	a, (_world_sprite_count)
	ld	e, a
	ld	hl, #_world_sprite_count
	inc	(hl)
	ld	d, #0x00
	ld	l, e
	ld	h, d
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, de
	ld	de, #_world_sprites
	add	hl, de
;D:/mano_projektai/GearRay/game/world_sprite.c:54: sprite->world_x =
	ld	e, l
	ld	d, h
;D:/mano_projektai/GearRay/game/world_sprite.c:55: (signed int)map_x * FIXED_POINT_SCALE + FIXED_POINT_SCALE / 2;
	ld	b, c
	ld	(hl), #0x80
	inc	hl
	ld	(hl), b
;D:/mano_projektai/GearRay/game/world_sprite.c:56: sprite->world_y =
	ld	l, e
	ld	h, d
	inc	hl
	inc	hl
;D:/mano_projektai/GearRay/game/world_sprite.c:57: (signed int)map_y * FIXED_POINT_SCALE + FIXED_POINT_SCALE / 2;
	ld	b, -1 (ix)
	ld	c, #0x80
	ld	(hl), c
	inc	hl
	ld	(hl), b
;D:/mano_projektai/GearRay/game/world_sprite.c:58: sprite->health_and_hit_count = ZOMBIE_MAX_HEALTH;
	ld	hl, #0x0007
	add	hl, de
	ld	(hl), #0x0c
;D:/mano_projektai/GearRay/game/world_sprite.c:59: world_sprite_set_state(sprite, ZOMBIE_STATE_ALIVE);
	xor	a, a
	push	af
	inc	sp
	ex	de, hl
	call	_world_sprite_set_state
00103$:
;D:/mano_projektai/GearRay/game/world_sprite.c:60: }
	inc	sp
	pop	ix
	ret
;D:/mano_projektai/GearRay/game/world_sprite.c:62: void world_sprites_update(void)
;	---------------------------------
; Function world_sprites_update
; ---------------------------------
_world_sprites_update::
	push	ix
	ld	ix,	#0
	add	ix, sp
	push	af
	push	af
;D:/mano_projektai/GearRay/game/world_sprite.c:64: unsigned char sprite_index = 0;
	ld	c, #0x00
;D:/mano_projektai/GearRay/game/world_sprite.c:66: while (sprite_index < world_sprite_count)
00112$:
	ld	a, c
	ld	hl, #_world_sprite_count
	sub	a, (hl)
	jr	nc, 00115$
;D:/mano_projektai/GearRay/game/world_sprite.c:68: WorldSprite *sprite = &world_sprites[sprite_index];
	ld	b, #0x00
	ld	l, c
	ld	h, b
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, bc
	ld	de, #_world_sprites
	add	hl, de
	ex	(sp), hl
;D:/mano_projektai/GearRay/game/world_sprite.c:70: if (WORLD_SPRITE_LIFE_STATE(sprite) == ZOMBIE_STATE_CORPSE)
	ld	de, #0x0006
	pop	hl
	push	hl
	add	hl, de
	ld	-2 (ix), l
	ld	-1 (ix), h
	pop	de
	pop	hl
	push	hl
	push	de
	ld	a, (hl)
	and	a, #0x03
;D:/mano_projektai/GearRay/game/world_sprite.c:72: ++sprite_index;
	ld	e, c
	inc	e
;D:/mano_projektai/GearRay/game/world_sprite.c:70: if (WORLD_SPRITE_LIFE_STATE(sprite) == ZOMBIE_STATE_CORPSE)
	cp	a, #0x02
	jr	nz, 00102$
;D:/mano_projektai/GearRay/game/world_sprite.c:72: ++sprite_index;
	ld	c, e
;D:/mano_projektai/GearRay/game/world_sprite.c:73: continue;
	jr	00112$
00102$:
;D:/mano_projektai/GearRay/game/world_sprite.c:76: if (sprite->state_timer == 0)
	ld	a, -4 (ix)
	add	a, #0x08
	ld	l, a
	ld	a, -3 (ix)
	adc	a, #0x00
	ld	h, a
	ld	a, (hl)
	or	a, a
	jr	nz, 00104$
;D:/mano_projektai/GearRay/game/world_sprite.c:78: ++sprite_index;
	ld	c, e
;D:/mano_projektai/GearRay/game/world_sprite.c:79: continue;
	jr	00112$
00104$:
;D:/mano_projektai/GearRay/game/world_sprite.c:82: --sprite->state_timer;
	dec	a
	ld	(hl), a
;D:/mano_projektai/GearRay/game/world_sprite.c:83: if (sprite->state_timer != 0)
	or	a, a
	jr	z, 00106$
;D:/mano_projektai/GearRay/game/world_sprite.c:85: ++sprite_index;
	ld	c, e
;D:/mano_projektai/GearRay/game/world_sprite.c:86: continue;
	jr	00112$
00106$:
;D:/mano_projektai/GearRay/game/world_sprite.c:89: if (WORLD_SPRITE_LIFE_STATE(sprite) == ZOMBIE_STATE_SHOT_DEAD)
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	ld	a, (hl)
	and	a, #0x03
	cp	a, #0x01
	jr	nz, 00110$
;D:/mano_projektai/GearRay/game/world_sprite.c:91: if (zombie_corpses_finalize(sprite_index))
	push	bc
	push	de
	ld	a, c
	call	_zombie_corpses_finalize
	pop	de
	pop	bc
	or	a, a
	jr	z, 00111$
;D:/mano_projektai/GearRay/game/world_sprite.c:92: continue;
	jr	00112$
00110$:
;D:/mano_projektai/GearRay/game/world_sprite.c:95: sprite->pixels = zombie_01_standing_pixels;
	pop	hl
	push	hl
	ld	bc, #0x0004
	add	hl, bc
	ld	(hl), #<(_zombie_01_standing_pixels)
	inc	hl
	ld	(hl), #>(_zombie_01_standing_pixels)
00111$:
;D:/mano_projektai/GearRay/game/world_sprite.c:96: ++sprite_index;
	ld	c, e
	jr	00112$
00115$:
;D:/mano_projektai/GearRay/game/world_sprite.c:98: }
	ld	sp, ix
	pop	ix
	ret
;D:/mano_projektai/GearRay/game/world_sprite.c:100: void world_sprite_make_corpse(unsigned char sprite_index)
;	---------------------------------
; Function world_sprite_make_corpse
; ---------------------------------
_world_sprite_make_corpse::
;D:/mano_projektai/GearRay/game/world_sprite.c:102: if (sprite_index < world_sprite_count)
	ld	c, a
	ld	hl, #_world_sprite_count
	sub	a, (hl)
	ret	nc
;D:/mano_projektai/GearRay/game/world_sprite.c:104: world_sprite_set_state(&world_sprites[sprite_index],
	ld	de, #_world_sprites+0
	ld	b, #0x00
	ld	l, c
	ld	h, b
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, bc
	add	hl, de
	push	hl
	ld	a, #0x02
	push	af
	inc	sp
	call	_world_sprite_set_state
	pop	de
;D:/mano_projektai/GearRay/game/world_sprite.c:106: world_sprites[sprite_index].health_and_hit_count = 0;
	ld	hl, #0x0007
	add	hl, de
	ld	(hl), #0x00
;D:/mano_projektai/GearRay/game/world_sprite.c:108: }
	ret
;D:/mano_projektai/GearRay/game/world_sprite.c:110: void world_sprites_crush_in_door(unsigned char map_y)
;	---------------------------------
; Function world_sprites_crush_in_door
; ---------------------------------
_world_sprites_crush_in_door::
;D:/mano_projektai/GearRay/game/world_sprite.c:112: zombie_corpses_crush_in_door(map_y);
;D:/mano_projektai/GearRay/game/world_sprite.c:113: }
	jp	_zombie_corpses_crush_in_door
;D:/mano_projektai/GearRay/game/world_sprite.c:115: void world_sprite_apply_damage(unsigned char sprite_index,
;	---------------------------------
; Function world_sprite_apply_damage
; ---------------------------------
_world_sprite_apply_damage::
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	iy, #-12
	add	iy, sp
	ld	sp, iy
	ld	-1 (ix), a
	ld	-2 (ix), l
;D:/mano_projektai/GearRay/game/world_sprite.c:122: if (sprite_index >= world_sprite_count)
	ld	a, -1 (ix)
	ld	hl, #_world_sprite_count
	sub	a, (hl)
;D:/mano_projektai/GearRay/game/world_sprite.c:123: return;
	jp	nc, 00107$
;D:/mano_projektai/GearRay/game/world_sprite.c:125: sprite = &world_sprites[sprite_index];
	ld	c, -1 (ix)
	ld	b, #0x00
	ld	l, c
	ld	h, b
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, bc
	ld	-6 (ix), l
	ld	-5 (ix), h
	ld	a, #<(_world_sprites)
	add	a, -6 (ix)
	ld	-4 (ix), a
	ld	a, #>(_world_sprites)
	adc	a, -5 (ix)
	ld	-3 (ix), a
	ld	a, -4 (ix)
	ld	-10 (ix), a
	ld	a, -3 (ix)
	ld	-9 (ix), a
;D:/mano_projektai/GearRay/game/world_sprite.c:126: if (WORLD_SPRITE_LIFE_STATE(sprite) != ZOMBIE_STATE_ALIVE)
	ld	a, -10 (ix)
	ld	-4 (ix), a
	ld	a, -9 (ix)
	ld	-3 (ix), a
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	ld	de, #0x0006
	add	hl, de
	ld	a, (hl)
	and	a, #0x03
;D:/mano_projektai/GearRay/game/world_sprite.c:127: return;
	jp	nz, 00107$
;D:/mano_projektai/GearRay/game/world_sprite.c:129: health = sprite->health_and_hit_count & ZOMBIE_HEALTH_MASK;
	ld	de, #0x0007
	ld	l, -10 (ix)
	ld	h, -9 (ix)
	add	hl, de
	ld	-8 (ix), l
	ld	-7 (ix), h
	ld	a, (hl)
	ld	-3 (ix), a
	and	a, #0x0f
	ld	-4 (ix), a
;D:/mano_projektai/GearRay/game/world_sprite.c:130: hit_count = (sprite->health_and_hit_count & ZOMBIE_HIT_COUNT_MASK)
	ld	a, -3 (ix)
	ld	-12 (ix), a
	ld	-11 (ix), #0x00
	ld	a, -12 (ix)
	and	a, #0x70
	ld	-6 (ix), a
	ld	-5 (ix), #0x00
	sra	-5 (ix)
	rr	-6 (ix)
	sra	-5 (ix)
	rr	-6 (ix)
	sra	-5 (ix)
	rr	-6 (ix)
	sra	-5 (ix)
	rr	-6 (ix)
	ld	a, -6 (ix)
;D:/mano_projektai/GearRay/game/world_sprite.c:132: ++hit_count;
	ld	-5 (ix), a
	inc	a
;D:/mano_projektai/GearRay/game/world_sprite.c:138: | (hit_count << ZOMBIE_HIT_COUNT_SHIFT) | health;
	ld	-6 (ix), a
	add	a, a
	add	a, a
	add	a, a
	add	a, a
	ld	-5 (ix), a
;D:/mano_projektai/GearRay/game/world_sprite.c:133: if (damage < health)
	ld	a, -2 (ix)
	sub	a, -4 (ix)
	jr	nc, 00106$
;D:/mano_projektai/GearRay/game/world_sprite.c:135: health -= damage;
	ld	a, -4 (ix)
	sub	a, -2 (ix)
	ld	-4 (ix), a
;D:/mano_projektai/GearRay/game/world_sprite.c:137: (sprite->health_and_hit_count & ZOMBIE_AI_CHASING_MASK)
	ld	a, -3 (ix)
	and	a, #0x80
;D:/mano_projektai/GearRay/game/world_sprite.c:138: | (hit_count << ZOMBIE_HIT_COUNT_SHIFT) | health;
	ld	-3 (ix), a
	or	a, -5 (ix)
	ld	-3 (ix), a
	or	a, -4 (ix)
	ld	l, -8 (ix)
	ld	h, -7 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/game/world_sprite.c:139: sprite->pixels = hit_count & 1U
	ld	de, #0x0004
	ld	l, -10 (ix)
	ld	h, -9 (ix)
	add	hl, de
	ld	-4 (ix), l
	ld	-3 (ix), h
;D:/mano_projektai/GearRay/game/world_sprite.c:140: ? zombie_01_shot_01_pixels
	bit	0, -6 (ix)
	jr	z, 00109$
	ld	hl, #_zombie_01_shot_01_pixels+0
	ld	-6 (ix), l
	ld	-5 (ix), h
	jr	00110$
00109$:
;D:/mano_projektai/GearRay/game/world_sprite.c:141: : zombie_01_shot_02_pixels;
	ld	hl, #_zombie_01_shot_02_pixels+0
	ld	-6 (ix), l
	ld	-5 (ix), h
00110$:
	ld	c, -6 (ix)
	ld	b, -5 (ix)
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	ld	(hl), c
	inc	hl
	ld	(hl), b
;D:/mano_projektai/GearRay/game/world_sprite.c:142: sprite->state_timer = ZOMBIE_HIT_REACTION_FRAME_COUNT;
	pop	de
	pop	hl
	push	hl
	push	de
	ld	de, #0x0008
	add	hl, de
	ld	(hl), #0x03
;D:/mano_projektai/GearRay/game/world_sprite.c:143: return;
	jr	00107$
00106$:
;D:/mano_projektai/GearRay/game/world_sprite.c:146: sprite->health_and_hit_count = hit_count << ZOMBIE_HIT_COUNT_SHIFT;
	ld	l, -8 (ix)
	ld	h, -7 (ix)
	ld	a, -5 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/game/world_sprite.c:147: world_sprite_set_state(sprite, ZOMBIE_STATE_SHOT_DEAD);
	ld	a, #0x01
	push	af
	inc	sp
	ld	l, -10 (ix)
	ld	h, -9 (ix)
	call	_world_sprite_set_state
00107$:
;D:/mano_projektai/GearRay/game/world_sprite.c:148: }
	ld	sp, ix
	pop	ix
	ret
;D:/mano_projektai/GearRay/game/world_sprite.c:150: unsigned char world_sprite_get_count(void)
;	---------------------------------
; Function world_sprite_get_count
; ---------------------------------
_world_sprite_get_count::
;D:/mano_projektai/GearRay/game/world_sprite.c:152: return world_sprite_count;
	ld	a, (_world_sprite_count)
;D:/mano_projektai/GearRay/game/world_sprite.c:153: }
	ret
;D:/mano_projektai/GearRay/game/world_sprite.c:155: WorldSprite *world_sprite_get(unsigned char sprite_index)
;	---------------------------------
; Function world_sprite_get
; ---------------------------------
_world_sprite_get::
;D:/mano_projektai/GearRay/game/world_sprite.c:157: if (sprite_index >= world_sprite_count)
	ld	c, a
	ld	hl, #_world_sprite_count
	sub	a, (hl)
	jr	c, 00102$
;D:/mano_projektai/GearRay/game/world_sprite.c:158: return 0;
	ld	de, #0x0000
	ret
00102$:
;D:/mano_projektai/GearRay/game/world_sprite.c:160: return &world_sprites[sprite_index];
	ld	b, #0x00
	ld	l, c
	ld	h, b
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, bc
	ld	de, #_world_sprites
	add	hl, de
	ex	de, hl
;D:/mano_projektai/GearRay/game/world_sprite.c:161: }
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
