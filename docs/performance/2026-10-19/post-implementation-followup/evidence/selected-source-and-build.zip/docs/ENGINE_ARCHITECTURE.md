# GearRay Engine Architecture

## Project overview

GearRay is a custom Wolfenstein-style raycasting engine written specifically
for the Sega Game Gear. It targets the Z80-based hardware and the constraints
of SMSlib/devkitSMS rather than adapting a desktop or floating-point engine.
The current program is both an engine and a small workshop environment used to
develop and validate engine systems on real hardware.

The project favours readable code, explicit module boundaries, deterministic
behaviour, and maintainability before clever tricks. Abstractions are added
only when they give a concrete ownership boundary. Performance work is kept
local to measured hot paths and must preserve output unless a gameplay change
is intentional.

## Engine architecture

### Verified performance implementation (2026-10-19)

[Current behavior](CURRENT_BEHAVIOR.md) and the [follow-up report](performance/2026-10-19/post-implementation-followup/IMPLEMENTATION_REPORT.md) define the selected ROM and current bank/resource/timing contract. Exact HUD masks, the legacy camera graph, full ray/material invalidation, native wall schedules, sprite spans and complete preparation reuse are enabled. The sprite compositor also reuses foreground keep/plane masks for repeated clamped source Y within one call; every destination row still merges independently. Wall offset comparison uses upper three bits only in columns without a current projected sprite; exact offsets, dirty/removal gates and actual rays are retained. Fixed scheduling and double buffering remain measured experiments outside production linkage. The production renderer owns a completed preparation cache and still updates live VRAM.

### Game loop

`game/main.c` owns initialization and frame sequencing. It is the only module
that coordinates input, player movement, camera rotation, interaction,
raycasting, VBlank synchronization, and drawing. It does not contain rendering
or collision algorithms.

Startup first clears VRAM and uploads the centred SEGA logo once against black
using a dedicated palette. The display remains on for 180 VBlank frames, with
no gameplay raycasting, sprite projection, or HUD composition. Startup then
blanks the display and clears VRAM before gameplay video state and the gameplay
palette are initialized. World, player, camera, raycaster, and the complete
first gameplay frame are prepared while blanked; after VBlank the display is
deliberately enabled. The startup palette is never reused by gameplay.

### Input

`platform/game_gear/input.c` owns the current and previous controller bitmasks.
It reads `SMS_getKeysStatus()` once per processed frame and exposes semantic
movement, rotation, interaction, and fire requests. D-pad up/down move
forward/backward. D-pad left/right rotate unless Button 2 is held, in which
case they strafe. A Button 2 hold session that never uses horizontal strafe
requests one interaction on release. Button 1 produces one fire request on its
rising edge; holding it does not repeat. Start is reserved and has no current
semantic request API or consumer. Opposing inputs accumulate to zero.

### Player

`game/player.c` owns the authoritative player position in Q8.8 world
coordinates. It composes forward and strafe intent from the camera basis,
applies diagonal normalization, performs collision, and starts interaction checks.
The player does not own viewing direction.

### Camera

`game/camera.c` owns camera position, direction, and projection-plane vectors.
The player position is copied to the camera after movement. Rotation updates
the direction, normalizes it, and reconstructs the perpendicular camera plane.
At initialization the camera faces map north, toward the workshop's first row.
The camera plane points map east, so screen-left is map west and screen-right
is map east. The camera does not perform movement or collision.

### World and map

`game/world.c` is the query boundary for map tiles, spawn position, textures,
objects, and solidity. The current `workshop_map` is a 13×13 permanent engine
laboratory with a spawn at tile (6, 7). `WORLD_TILE_VOID` marks non-existent,
non-playable space outside the workshop's renderable enclosure. VOID and
out-of-range coordinates are blocked; out-of-range tile queries resolve safely
to VOID without indexing the map array. Tile IDs are empty 0, stone 1, blood
concrete 2, brick placeholder 3, metal placeholder 4, standard door 5, red
door 6, red-door switch 7, VOID 8, and zombie marker 9. Every authored `Z`
marker creates one sprite at tile centre during initialization, up to the
eight-sprite limit; runtime tile queries expose all markers as empty.

`world.c` maps ordinary semantic tile IDs directly to texture IDs; invalid IDs
fall back to stone, while the red-door switch selects its current animation
frame. Blood concrete is an ordinary solid, noninteractive wall. Door instances
at (6, 4), (6, 2), and (6, 8) and their three mutable open/closed states are
kept separately in `door_instances.c` and `door_states.c`. The switch at
(6, 12) controls the red door at (6, 2).

The generated switch-texture contract is explicit: texture IDs 7 and 8 are the
red OFF frames used while waiting, and texture IDs 9 and 10 are the green ON
frames used after activation. These are texture IDs, not world tile IDs.
Activation changes the state once and opens the internal red door; the existing
six-update animation cadence continues in either state.

### Raycaster

`engine/render/raycaster.c` is platform-independent gameplay/render geometry.
It generates 28 camera rays, traverses the grid with DDA, and stores each ray's
projected height, hit side, oriented texture offset, tile ID, and texture ID.
It queries the camera and world but performs no VRAM operations.

### Renderer and video

The active Game Gear renderer is implemented primarily in
`platform/game_gear/video.c`. It converts pairs of ray results into native 8×8
Game Gear wall tiles, tracks dirty tile-columns, uploads changed patterns, and
changes tilemap cells when their ceiling/wall/floor state changes.

`native_wall.c` prepares exact column plans from generated height/source-row schedules and directional palette columns. Its slot-2 Bank 3 worker emits native four-plane rows while preserving near, ordered-attenuation and fog decisions. `video.c` owns mapper restoration, sprite row merging and VRAM writes. `wall_textures.c` supplies the palette. Packed wall art is generator/reference input outside runtime linkage; the scalar sampler is retained in performance test evidence.

Projected height selects one of three conservative wall levels in `video.c`.
Heights above 16 use exact source-row schedules and directional shading. Heights 9
through 16 use the opaque ordered attenuation tables from Sprint 28. Heights 8
and below use Sprint 29 Candidate C hybrid fog: 87.5% opaque attenuated wall
pixels and 12.5% deterministic background contribution. Each ray in a native
tile-column classifies independently, and both table-driven levels avoid
sampler initialization and texture reads. Cached projected heights
already invalidate a column at the 8/9 and 16/17 boundaries, so the dirty
signature needs no LOD flags.

The raycaster records a texture ID for every ray. The native wall-column path
samples the selected entry in the generated ten-texture table and shades it by
hit side.
Obsolete pre-native shaded-tile and wall-material modules were removed in the
Sprint 23 audit; multi-material rendering must be designed against this active
path rather than restored as unused compatibility code.

### Interaction ray and world interactions

`game/interaction_ray.c` samples forward from the player in 32-unit increments
up to 512 Q8.8 units (two tiles). It visits each map cell at most once, returns
the first interactive object, and stops at a blocking wall or world boundary.
`world_interactions.c` dispatches the resulting target. Either ordinary yellow
door toggles. Direct interaction with the red door is rejected; activating
the red-door switch opens that door idempotently.

### Renderer profiling

Profiling is compile-time optional through `GEARRAY_PROFILE_RENDERER`. When
enabled, counters cover rays, DDA iterations, dirty columns, generated wall
halves, active tiles, texture and sampler calls, palette lookups,
and VRAM calls/bytes. Counters reset at the start of each processed frame,
before input and simulation, and are printed every 60 processed frames. When
profiling is disabled, its macros are no-ops.

Distant-wall counters distinguish near and far wall halves and count texture
samples avoided. Profiling report/clear routines are compiled into Bank 1 and
called only at frame boundaries; all counter operations and renderer paths
remain resident.

### Frame data flow

The ownership and transfer path is:

```text
controller bits -> semantic movement intent -> player position
                -> semantic rotation intent -> camera direction
player position -> camera position
camera + world  -> per-ray results
per-ray results -> native tile bytes + tile states
tile bytes/states -> VRAM
eligible Button 2 release -> interaction ray -> world/door/switch state
```

## Frame pipeline

After one-time video, input, world, player, camera, and raycaster
initialization, every processed frame runs in this exact order:

1. Optional profiling counters are reset.
2. Input copies the current key mask to `previous_keys` and reads a new mask.
3. `world_sprites_update()` advances active hit/death presentation timers.
4. The loop samples the Button 1 fire edge and updates the weapon HUD state.
5. Input resolves rotation from Left/Right when Button 2 is not held. With
   Button 2 held, Left/Right produce only strafe intent. Up/Down always produce
   forward/backward intent. Each opposing pair cancels to zero.
6. The camera applies the resolved rotation exactly once. Left and right use
   equal sine magnitudes with opposite signs.
7. If movement is active, the player composes translation from the newly
   rotated camera basis. The retained 177/256 diagonal normalization runs once.
8. The player performs X-then-Y collision and updates its authoritative position.
9. The final player position is copied into the camera.
10. Every fourth gameplay frame, zombie AI updates movement, attacks, player
    health, damage shake, and attack HUD state. Gameplay exits immediately if
    player health has reached zero.
11. A non-strafe Button 2 release request, if present, casts the interaction ray
    using the player position and current camera direction, then may update door
    or switch state.
12. The red-door switch advances its animation by one processed frame.
13. `raycaster_update()` generates and casts all 28 rays using the synchronized
    camera position and current direction/plane.
14. The previous frame's `pending_shot`, if set, is resolved against the current
    rays; the current fire edge is then retained as the next pending shot.
15. The loop waits for VBlank with `SMS_waitForVBlank()`.
16. Damage-shake presentation state advances.
17. The renderer rebuilds/uploads changed background data and composites ordered
    world sprites, weapon/health HUD elements, and attack feedback.
18. Optional profiling completes and periodically prints the counters.

There is one simulation update per rendered loop. There is no delta time,
fixed-timestep accumulator, collision substep, or queued renderer snapshot.

## Rendering pipeline

### Ray generation

The camera direction has nominal length 256. Its perpendicular plane has
length 169, producing the horizontal field of view. For every entry in the
28-element `camera_x_by_ray` table, the raycaster calculates:

```text
ray_direction = camera_direction + camera_plane * camera_x / 256
```

The table contains the centered 28 coordinates retained from the established
32-ray projection: -178 through 177. It is deliberately not regenerated from
the current ray count. Keeping the original spacing makes the current view a
centered crop with unchanged ray directions and perspective.

### DDA traversal

For each axis, the raycaster derives the map step, distance to the first cell
boundary, and distance between later boundaries. Division in the hot DDA setup
is replaced by a 513-entry reciprocal table for magnitudes 1..512. Entry `n`
is `floor(65536 / n)`; zero-direction axes use an unsigned-long infinity
sentinel.

The DDA advances whichever side distance is smaller, records whether an X or
Y wall face was crossed, and stops when `world_is_wall()` reports a solid cell.
Open doors are non-solid; closed doors are solid. Out-of-map queries are solid,
so a valid bounded map terminates every ray.

VOID has no authored texture and is not a visible wall material. Build-time map
validation proves that reachable floor and open doors have a renderable
stone/blood/door/switch boundary before VOID. A ray reaching VOID directly
therefore indicates invalid level construction rather than a rendering case.

The hot solidity query decides empty and ordinary solid workshop tiles directly
after one bounded map lookup. Only door tiles enter instance/state resolution.
Texture and object mappings are direct world queries; interaction retains the
object API.

The hit coordinate along a wall face is calculated in Q8.8. X-side hits use
the Y impact fraction; Y-side hits use X. The raycaster then maps the physical
face to the authored left-to-right PNG direction:

| Physical face | Texture X |
|---|---|
| West | Unflipped |
| East | Flipped |
| North | Flipped |
| South | Unflipped |

This mapping is independent of player orientation, camera initialization, map
rotation, and texture identity. It depends only on the DDA hit axis, ray travel
direction on that axis, and physical wall face entered. The platform renderer
receives the resulting oriented coordinate and performs no additional flip.

### Projection

Projected wall height is:

```text
projected_height = 16384 / ray_distance
```

The result is clamped to 1..144 pixels. Walls are vertically centred in the
64-pixel viewport; the renderer clips generation to visible rows. The
raycaster's distance is already the perpendicular DDA distance for the camera
ray construction, so no separate fish-eye correction pass is used.

### Texture lookup and sampling

The oriented 0..255 hit offset is shifted right by five to select texture X in
the 8×8 source. Packed access derives its byte column directly by shifting
right six, while hit-offset bit 5 selects the nibble. A sampler calculates a
Q8.8 texture-Y step once per projected
wall column. A carried remainder reproduces the exact integer mapping when the
step does not divide evenly. Clipped portions above the viewport are skipped
when the sampler is initialized.

The generated texture stores two 4-bit pixels per byte. X parity selects the
high or low nibble. Sampler initialization selects the generated X-side or
Y-side palette-index map. The hot sampler returns the final palette index in
one call, combining coordinate advancement, packed fetch, nibble selection,
and directional shading without an additional texture or palette function.

### Native wall-column generation

One tile-column consumes two ray results. Each ray supplies one four-pixel half
of an 8-pixel Game Gear tile, so 28 rays fill 14 tile-columns and 112 pixels.
For each active 8-pixel row, the renderer samples both projected walls eight
times only when they are textured. Table-driven halves reuse byte-sized top
and bottom bounds computed once on builder entry; this removes repeated signed
bottom construction while preserving the exact centred 1..16-pixel silhouette.
The resulting left and right palette indices are packed into native 4bpp tile
bytes.

Packing uses two constant 16×4 bitplane lookup tables. Four table reads per
half, four OR operations, and four writes replace a per-bitplane packing loop.
The common near/near path takes an early fast path and writes rows through a
sequential destination pointer. Mixed and flat columns receive their constant
palette indices during column setup, so the row loop adds no distance test or
side-palette selection.

### Dirty-column upload

Every viewport tile-column caches a signature containing both ray heights,
both hit offsets, both hit sides, and a valid flag. If the new signature is
identical, the entire column is skipped. A changed column rebuilds only the
8×8 rows intersecting either projected wall.

The active wall patterns for one tile-column are uploaded with one contiguous
`SMS_loadTiles()` call. A separate cached state per tilemap cell records
ceiling, floor, or wall. `SMS_setTileatXY()` is called only when that state
changes. The scan advances through this cache sequentially and uses the fixed
horizon tile row directly. The cache avoids redundant pattern construction
and tilemap writes; it does not skip raycasting.

## Current optimized renderer configuration

| Property | Current value |
| --- | ---: |
| Game Gear display | 160×144 pixels |
| Viewport origin | tile (9, 8) in the SMS tilemap coordinate space |
| Viewport width | 112 pixels |
| Viewport height | 64 pixels |
| Viewport grid | 14×8 tiles |
| Ray count | 28 |
| Horizontal coverage per ray | 4 pixels |
| Rays per native tile-column | 2 |
| Camera direction length | 256 |
| Camera plane length | 169 |
| Projection height scale | 16384 |

This configuration is the hardware-tested optimized baseline. Earlier
measurement identified texture sampling/native packing, dirty-column traversal,
VRAM transfer, and DDA as the important renderer costs. The viewport was
reduced to a centred 28-ray crop, and the extra diagnostic centre cast was
removed; the current frame casts exactly the 28 visible rays. Native bitplane
packing was then replaced by output-equivalent lookup tables. Dirty columns and
active vertical ranges bound the remaining CPU and VRAM work.

The selected baseline retains the established camera coordinates rather than
rescaling them. This preserves projection behaviour while reducing visible
width, ray count, generated tiles, and possible upload volume. Renderer
optimizations change workload, not gameplay geometry.

## Movement system

All movement values are integer Q8.8 units.

- `PLAYER_MOVE_SPEED` is 74, or 74/256 = 0.2890625 tile for a cardinal step.
  This is the second general-control-speed adjustment, approximately 30 percent
  above the first adjustment's value of 57. Engine Foundation v1.0.0 used 44.
- Forward movement uses the normalized direction vector with scale 256.
- Strafe movement uses the camera plane with its own length of 169, making its
  cardinal magnitude match forward movement.
- When forward/backward and strafe are both active, their composed components
  are multiplied by 177/256. The scale is bounded and applied once to the
  complete vector before collision. At an axis-aligned orientation, `(74,74)`
  becomes `(51,51)`, magnitude approximately 72.12 rather than 104.65.
- Movement retains full speed while rotation is active. Rotation is applied
  first, so translation follows the direction displayed in the same frame.
- `PLAYER_COLLISION_RADIUS` is 32, one eighth of a tile. It keeps the player
  away from walls while remaining small enough for the current corridors and
  workshop geometry.

All signed scales round symmetrically by adding or subtracting half the
denominator before integer division. Forward/backward movement therefore
retains equal magnitude, and left/right rotation uses the same angular
magnitude with opposite signs. Component quantization at rotated headings is
the only expected integer difference. Collision and wall-sliding behaviour are
unchanged by diagonal normalization.

## Collision system

The player is represented by an axis-aligned square footprint extending 32
Q8.8 units from its centre. A candidate position is clear only when all four
corner cells are non-solid.

Movement is resolved once per processed frame:

1. Test the candidate X coordinate while retaining the current Y coordinate.
2. Accept X if all four footprint corners are clear.
3. Test the candidate Y coordinate using the possibly updated X coordinate.
4. Accept Y if all four corners are clear.

Independent axes provide natural wall sliding: a blocked component is rejected
while a clear component is retained. X has deterministic precedence at a
corner because it is tested first. Near an inside corner, accepting X can cause
the later Y test to fail; if X fails, Y may still succeed. Changing this order
or combining the two checks changes wall-sliding and corner behaviour.

There are no collision substeps. Current movement constants must therefore
remain small enough that the four-corner test cannot cross relevant solid
geometry in one update.

## Fixed-point math

GearRay uses integer and fixed-point arithmetic because the target Z80 has no
hardware floating-point unit. Integer operations give predictable ROM/runtime
cost, deterministic rounding, and identical gameplay results across builds and
hardware.

The principal world scale is Q8.8:

```text
256 units = 1 map tile
128 units = half a tile
```

Player and camera positions use this scale. Direction vectors have nominal
length 256. The camera plane has length 169 and is reconstructed after every
rotation as `(-direction_y, direction_x) * 169 / 256`.

Camera rotation uses a separate 12-bit trigonometric scale:

```text
cosine = 4058 / 4096
sine   =  556 / 4096
```

These rounded constants encode `atan2(556, 4058)`, approximately
7.802 degrees per processed frame. The second speed experiment used a
10.138-degree 4032/721 step. After the exact-equivalence ray-direction rebuild
optimization and emulator/original-hardware control evaluation, the final
selection returned to 4058/556 while retaining movement speed 74. The rotation
scale, normalization path, direction length, camera plane, and symmetrical
left/right step are unchanged. After rotating the direction, the camera
computes an integer square root, normalizes direction back to length 256, and
rebuilds the perpendicular plane. This prevents accumulated vector-length
drift.

Movement multiplies direction or plane components by speed and divides by the
corresponding basis length. The stable diagonal scale is 177/256. Intermediate
products use `signed long` to avoid 16-bit overflow.

DDA reciprocals are Q8.8-compatible values `floor(65536 / magnitude)`. Side
distances multiply a 0..256 boundary distance by that reciprocal and shift
right eight. Texture-Y positions also use Q8.8, with a remainder accumulator
to retain exact source-row progression. Projection uses the integer ratio
`16384 / ray_distance`.

## Performance optimizations

### Centred viewport and ray reduction

The active viewport is 112×64 (14×8 tiles) rather than the full Game Gear
display, and only 28 visible rays are cast. Each ray represents four horizontal
pixels, and two rays form one native tile-column. This reduces DDA work, tile
construction, and maximum VRAM traffic. The view remains centred and
perspective is preserved through the retained camera table. Gameplay movement
and collision are unchanged.

### Removed diagnostic centre ray

The renderer no longer performs a separate, non-visible centre cast before the
visible ray loop. Exactly 28 casts feed the 28 visible ray results. This removes
redundant DDA work without changing the displayed frame or gameplay.

### Reciprocal lookup for DDA

The 1..512 direction-magnitude reciprocal table moves division out of the
per-ray axis setup. Zero directions use an infinity sentinel and unexpected
larger magnitudes clamp safely. Ray geometry is deterministic and retains the
defined integer approximation.

### Cached camera basis during ray generation

Direction and plane components are read once at the start of
`raycaster_update()`. The 28 derived ray-direction pairs are rebuilt only when
that basis changes and are reused during static or position-only frames. The
renderer traverses the resulting `RaycasterRay` array sequentially instead of
calling bounds-checked field getters for each tile-column. Each record also
retains the exact unsigned Q8.8 perpendicular projection distance already used
to calculate wall height.

### Dirty tile-column signatures

The video layer skips tile-columns whose heights, offsets, and sides match the
previous frame. This targets texture sampling, native tile construction, and
VRAM transfer while leaving raycasting unchanged.

### Multi-zombie billboard composition

World initialization extracts every authored `Z` marker, up to
`WORLD_SPRITE_MAX_COUNT` (8), places its sprite at the tile centre, and exposes
the underlying runtime tile as `EMPTY`. Each nine-byte `WorldSprite` stores
position, presentation state, a texture pointer, a timer, and one packed byte:
health in bits 0-3, successful-hit count in bits 4-6, and the AI chasing flag
in bit 7.

The Bank 1 projection pass applies the renderer's fixed-point inverse camera
transform to every sprite. Horizontal placement uses scale 80 around viewport
centre 56. Living presentation is hidden beyond distance 1260, uses distant
8x8 at 617..1260, authored 16x16 at 393..616, authored 32x32 locomotion at
281..392, and authored 32x32 melee presentation at 280 or less. One packed
walking phase is shared across resolutions. Corpses are stateless: depth 159
or less is hidden-close; distance tiers are authored 32x32 through 392,
authored 16x16 through 540, authored 8x8 through 688, dark pile through 836,
then hidden-far. See
[`ZOMBIE_PRESENTATION_PIPELINE.md`](ZOMBIE_PRESENTATION_PIPELINE.md) for the
complete presentation, audit, memory, and deliberate non-change record.
See [`ZOMBIE_SYSTEM_ARCHITECTURE_AUDIT.md`](ZOMBIE_SYSTEM_ARCHITECTURE_AUDIT.md)
for the maintained AI/combat/spatial-model audit, camera-independence proof,
melee-spacing measurements, and rejected heavyweight alternatives.

Visible candidates are selected deterministically within a total render-cost
budget of 12: native Bank 2 presentation costs 8, full detail costs 5, medium
costs 2, and simple or corpse-pile presentation costs 1. Gameplay state
continues to update when presentation is culled or rejected by the budget.

The resident video layer composes opaque sprite pixels into tile-local native
background data after wall, ceiling, and floor pixels exist. Palette index 15
is transparent. Sprite depth must be strictly less than the matching
four-pixel ray's exact wall depth, so walls win equal-depth ties without a
second raycast. The union of old and current coverage is regenerated, and a
texture-pointer change invalidates otherwise identical coverage, preventing
stale pose or movement pixels.

### Zombie combat and state

Button 1 is press-edge shooting input; holding it does not autofire. The main
loop retains one `pending_shot` byte so the firing HUD appears for one rendered
frame before the corresponding damage is applied, and remains visible on the
damage frame. An accepted shot performs one Bank 1 target scan, selecting the
nearest aligned living zombie and rejecting targets at or behind the nearest
centre wall depth. The scan reuses the exact renderer-contract depth transform;
there is no post-selection projected-height division.

The target footprint test is division-free:
`abs(lateral_product) * 5 <= abs(determinant) * 2`. It is symmetric, with
offsets ±67 accepted and ±68 rejected. Pistol damage is cumulative. Projected
heights 36+, 28..35, 17..27, and 13..16 deal 12, 6, 4, and 3 damage
respectively. The equivalent direct-depth ranges are 33..455, 456..585,
586..963, and 964..1260. Distance chooses only the current shot's damage and
never rescales existing health.

Surviving odd and even hits display `shot_01` and `shot_02` for three rendered
frames, then return to standing without changing health. A rapid hit replaces
and restarts that reaction. Lethal damage clamps health to zero, holds
`SHOT_DEAD` for four rendered frames, then enters persistent `CORPSE` state.
Misses, hidden targets, walls, and corpses do not change health.

### Zombie awareness and pursuit

Living zombies begin idle. An idle zombie enters chasing only when its cheap
integer distance is at most 963 world units and one tile-Bresenham LOS reaches
the player. Once chasing, it tracks the player's current position until the
distance exceeds 1260 or LOS becomes blocked; it then stops at its current
position without following a remembered target. This hysteresis permits later
reactivation while preventing distant silhouettes from becoming aware.

LOS delegates every traversed cell to `world_is_wall()`. Static walls, VOID,
closed standard doors, and the closed red door therefore block awareness,
while open doors permit it. Presentation culling and render-budget rejection
do not affect AI state.

The resident main loop owns one cadence byte and makes one direct same-page
`zombie_ai_update_all()` call every four completed gameplay updates. This is
workload dependent; 15 calls per second would require 60 gameplay updates,
which the display counter does not establish. The BANK1 coordinator iterates all zombies; there
is no per-zombie bank transition and no nested banked call. On each admitted
tick, an alive chasing zombie takes one 56-unit dominant-axis Q8.8 step toward
the current player position. A hypothetical 15 AI updates per second would move 840 world units or
3.28125 tiles per second; production has no fixed wall-clock AI rate. The
movement requires no floating
point, trigonometry, square root, or vector normalization.

`enemy_position_is_walkable()` is the narrow BANK1 enemy/world collision API.
It uses `world_is_wall()` for bounds, static walls, and live door state with a
32-unit zombie radius. Candidate movement also preserves 64 units of body
separation from the player and directly checks at most seven other living
zombies. `SHOT_DEAD` sprites and corpses do not block, so a larger occupancy
system is not justified for the eight-sprite maximum.

The three-frame living hit reaction pauses movement without clearing the
packed chasing flag. Pursuit resumes when the reaction expires if awareness
conditions still hold. Lethal damage immediately prevents further AI work;
`SHOT_DEAD` and `CORPSE` never move.

At an inclusive octagonal distance of 280, a clear-LOS living zombie stops
moving and attacks. Each zombie stores its cooldown and alternating attack
phase in the existing packed state byte. An admitted strike removes 20 points
from the player's 100-point health, triggers four-frame hardware-scroll damage
shake, and presents standing/attack poses without changing movement cadence.
At zero health, gameplay enters a cleared three-second Game Over presentation
and then uses the shared session restart path.

Moving sprites use the renderer's existing union of old/current coverage and
texture-change invalidation. The AI introduces no VRAM path or full-viewport
redraw, although movement can increase data-dependent dirty-column work.

### First-person HUD weapon composition

The accepted first-person weapon is a screen-space overlay independent of
camera projection, wall depth, and world-sprite occlusion. Its authored idle
and firing sources are `gun_12x12.png` and `gun_shoot_12x12.png`; each is
expanded to exactly 24×24 by
mapping destination coordinates with `>> 1`, an exact integer 2×
nearest-neighbor scale. The current input state selects the source without
changing composition geometry. It occupies viewport bounds `[80, 104) × [40, 64)`.

The resident renderer first builds ceiling, floor, and walls, then composes the
world sprites, and finally calls the Bank 1 HUD compositor for the weapon's
three-by-three tile footprint. Palette index 6 is the weapon's semantic
transparency sentinel and preserves the completed world pixel even though BG
entry 6 contains a visible colour. The fixed overlay participates in an
already-dirty column only; it introduces no independent frame update or
recurring VRAM upload. Because each regenerated tile is rebuilt from the world
before the HUD is applied, transparent areas and previously covered pixels
cannot become stale.

The packed 12×12 source retains an eight-byte row stride, using 96 ROM bytes,
so its hot address calculation is `texture_y << 3`. Removing the former
24-byte coordinate table saves 38 Bank 1 ROM bytes and approximately 19,152
cycles for a complete nine-tile recomposition, with no RAM or VRAM change.
Uploading the border only at startup removes 13 Bank 0 ROM bytes, one
persistent RAM byte, and approximately 45 cycles from each debug frame.

### Active vertical row generation

For a dirty column, only tile rows intersecting a visible projected wall are
built and uploaded. Walls are clipped to the 64-pixel viewport before row
bounds are calculated. This avoids producing ceiling/floor-only pattern rows.

### Contiguous pattern uploads

All active patterns in one dirty tile-column are sent in a single
`SMS_loadTiles()` call. This reduces call overhead while preserving the same
native tile data.

### Cached tilemap states

Each viewport tile cell remembers whether it currently represents ceiling,
floor, or wall. Tilemap writes occur only on state transitions, reducing VRAM
calls and bytes without changing the intended image.

### Ceiling and floor backgrounds

Ceiling and floor use solid 1bpp tiles with existing BG palette entries. The
ceiling uses global BG index 3, RGB `(7, 7, 7)` / `0x777`, and the floor uses
global BG index 10, RGB `(3, 3, 3)` / `0x333`. Since
`GAME_GEAR_WALL_PALETTE_BASE` is global index 1, the source constants use
relative offsets `+2` and `+9`; these are not absolute palette indices.

Native wall tiles select the same ceiling or floor index for pixels outside the
projected wall silhouette according to the viewport horizon. This keeps
partially occupied wall tiles continuous with the flat backgrounds without
changing wall samples, shading, geometry, dirty signatures, or upload counts.

### Generated native wall plans

The earlier incremental step/remainder scalar sampler is preserved only as a test reference. Production generates packed exact source-row schedules for near heights17..144. Two51-byte plans cache the column's source rows and palette columns. Clipping is encoded with a background sentinel. All emitted rows match the old direct integer mapping, including heights extending above the viewport.

### Artwork storage and runtime colors

Packed two-pixel-per-byte wall artwork remains the generator input. The final runtime palette object contains only15 RGB444 colors. Generated directional source-color columns eliminate per-output-pixel nibble decoding and repeated palette lookup; no raw artwork or old step/remainder arrays are linked merely for this path.

### Native bitplane packing

A256x4 native pair table combines the two half-tile palette indices into four complete plane bytes. Existing ordered attenuation/fog fragments retain their exact pixel/background patterns. The Bank3 tail worker owns these constants under slot2 mapping; the resident renderer owns restoration, sprite overlays and transfer. Compiled168,960-tile comparisons and host all-offset proofs establish byte equality.

### Stable BG palette and directional mapping

All walls, ceiling, floor, switches, the zombie, and the HUD weapon are
software-composited through one 16-entry BG master palette. Hardware sprites
and their palette remain unused. The master entries are:

`0:000` black, `1:03a` gameplay brown, `2:555` concrete, `3:777`
ceiling/light gray, `4:b80` bright blue, `5:02b` primary red, `6:057`
door yellow-brown, `7:265` moss, `8:860` dark blue, `9:566` ordered LOD
shade, `10:333` floor/dark wall, `11:acf` light skin, `12:fff` white,
`13:222` darkest gray, `14:143` moss side shade, and `15:7af` dark skin.

One moss green and one primary red are shared; dedicated brown and both skin
tones are preserved. All entries are assigned. Zombie index 15 and weapon
index 6 remain semantic transparency sentinels and are skipped by their
compositors. LOD1 X uses indices 2/9, LOD1 Y uses 2/10, and LOD2 uses 0/2/10
through precomputed ordered tables.

`SMS_autoSetUpTextRenderer()` overwrites a BG palette entry, so startup restores
the complete master palette exactly once after text initialization.

### Compile-time profiling removal

When profiling is off, counter operations preprocess to no-ops. Normal builds
do not pay runtime counter costs.

### Bounded diagonal movement

The 177/256 scale prevents simultaneous forward/strafe input from increasing
translation magnitude. It changes gameplay intentionally by making diagonal
speed match cardinal speed within integer rounding. The scale remained
unchanged through final hardware control tuning. It is a stable control rule,
not a renderer optimization.

### Fixed-point camera rotation step

The camera's final 4058 cosine and 556 sine constants encode approximately
7.802 degrees. Engine Foundation v1.0.0 used the approximately 5.997-degree
4074/428 step; the first gameplay-speed adjustment introduced 4058/556; and
the second speed experiment used the approximately 10.138-degree 4032/721
step. The final selection returned to 4058/556 after the exact-equivalence
ray-direction rebuild optimization and emulator/original-hardware control
evaluation. None of these adjustments changes camera normalization, the
projection plane length, ray generation, or renderer output rules.

Production now follows the generated242-state/484-edge closure of that legacy arithmetic. It copies exact normalized vectors/planes rather than computing a turn at runtime. All484 compiled transitions match; the retained constants define generation provenance. These new performance changes await physical hardware validation.

## Design decisions

- Player position is authoritative; camera position is a synchronized copy.
  Do not create a second independently moving camera state.
- Camera direction and plane remain the exact legacy normalized pair. The
  generated graph copies both vectors from proven states; do not rotate the
  plane independently or substitute uniform angles.
- Movement composition happens before collision, and collision runs once.
  Applying collision separately to input vectors would change diagonal and
  sliding behaviour.
- Preserve input cancellation: equal opposing intents resolve to zero.
- Preserve update order: rotation, movement composition, diagonal normalization,
  X-then-Y collision, then camera position synchronization.
- Treat speed 74, diagonal scale 177/256, and the 4058/556 rotation pair as the
  control baseline.
  Retune them only through explicit emulator and original-hardware validation.
- Preserve every directed legacy transition. The graph generator applies
  positive sine for left and negative sine for right through the old signed
  arithmetic/normalization path; runtime turns follow those exact edges.
- Preserve X-then-Y collision unless corner behaviour is intentionally being
  redesigned.
- Keep world semantics out of the raycaster. The raycaster asks whether a cell
  is solid and which texture it represents; door state is owned by the world.
- Keep ray geometry out of the platform renderer. Hit-side orientation and
  projection belong to the raycaster; native tiles and VRAM belong to video.
- The camera coordinate table is an established projection definition, not a
  disposable derivative of `RAY_COUNT`.
- Dirty rendering is a presentation cache. It must never suppress raycasting
  or mutate simulation state.
- VBlank currently precedes VRAM drawing. Moving synchronization or uploads
  can change hardware presentation and must be validated on real Game Gear
  hardware.
- Generated texture data and native packing formats are performance-critical
  contracts. Changes require byte-level output verification.
- The current renderer consumes semantic texture IDs from a generated
  ten-texture table. Normal concrete remains primary; blood concrete is an
  ordinary palette-sharing variation placed explicitly in `workshop_map.c`.
  Placement and visual composition remain level-design responsibilities.

Intentional tradeoffs include a small viewport and coarse four-pixel ray
columns for practical hardware performance, variable work from dirty columns,
fixed per-loop simulation steps, axis-biased corner resolution, and lookup
tables that spend ROM to save Z80 instructions.

## Engine history

GearRay reached the current architecture through a small number of structural
milestones. This history explains the purpose of the resulting design; it is
not a record of every intermediate change.

### Hardware foundation and first working raycaster

The project first established a bootable Game Gear ROM, video initialization,
controller input, and a fixed-point camera. Raycasting then grew from a single
centre-ray calculation into one projected wall column and finally a stable
twenty-column 3D preview. This sequence established the core separation still
used today: camera state describes the view, the raycaster queries world
geometry, and the platform video layer presents the result. Obsolete 2D debug
rendering was removed once the first-person projection became authoritative.

The renderer was subsequently expanded to forty DDA rays. That stage proved
the full grid traversal and exposed the cost of treating desktop-style display
density as the primary goal. It also led to the stabilized DDA implementation,
including deterministic hit sides, distances, and bounded world queries.

### First-person movement and collision

Early held-input movement became camera-relative movement once camera and
player positions were synchronized. A collision radius replaced point-like
movement, and axis-separated collision provided predictable wall sliding.
Movement speed was then tuned for the target hardware rather than derived from
desktop timing assumptions. These steps established the player as owner of
physical position and the camera as owner of orientation—a boundary that
should not be collapsed.

### From wall geometry to a native textured renderer

Per-ray hit offsets, centralized viewport layout, ceiling/floor backgrounds,
side shading, and texture-column selection transformed the geometric preview
into a native Game Gear wall renderer. Ray results were organized into a
stable per-ray structure, while world meaning and texture data were separated
from ray traversal. Rendering is divided into focused modules for video,
texture sampling, wall texture access, palette treatment, and VRAM constants.

This cleanup mattered as much as the visual features: it made world semantics,
ray geometry, texture sampling, and hardware output independently inspectable.
The later world-object and door architecture followed the same principle by
separating static tile meaning, object behaviour, instance identity, and
mutable state.

### Stable native renderer and measured optimization

The first renderer milestone established stable native Game Gear wall output.
Profiling instrumentation and generated-assembly inspection then identified
texture sampling/native tile packing, dirty-column work, VRAM traffic, and DDA
as the meaningful cost centres. Optimization was driven by those findings
rather than by broad rewrites.

Native wall-row packing was replaced with exact bitplane lookup tables. The
new path removed a hot inner loop and was exhaustively verified against the old
packer, so its importance was architectural as well as computational: GearRay
adopted the rule that renderer optimizations must preserve output and be proven
at the native-byte level when practical.

### Viewport optimization and ray-count reduction

Real hardware performance made clear that the renderer needed a smaller,
explicit workload. The hardware-tested final viewport became a 112×64,
14×8-tile region using 28 rays. Each ray represents four horizontal pixels,
and two rays form one native tile-column. The 28 camera coordinates were
retained from the centred portion of the established 32-ray projection,
preserving ray spacing and
perspective rather than redefining the field of view around a cheaper count.

This change reduced DDA traversal, wall generation, and worst-case VRAM upload
while keeping gameplay geometry unchanged. Dirty-column signatures, active
vertical row bounds, contiguous pattern uploads, and cached tilemap states then
made the cost respond to what actually changed on screen.

### Renderer cleanup and removal of redundant work

Once the 28 visible rays were the stable presentation, the separate diagnostic
centre ray no longer justified its cost. It was removed so every cast in a
normal frame contributes directly to the viewport. Camera basis values are
also captured once for the ray set, and the renderer consumes the resulting
snapshot without mixing camera states inside a cast pass.

This stage produced the current optimized renderer baseline: fewer rays and
tiles by design, no invisible diagnostic cast, bounded dirty work, and native
output generation retained as a platform responsibility.

### Composed movement normalization

Movement originally handled directional inputs as mutually exclusive actions.
Support for simultaneous forward/backward and strafe input required composing
both intents before collision. Applying the bounded 177/256 scale to the final
combined vector prevented diagonal input from increasing translation speed.
Collision remained a single X-then-Y operation, preserving established wall
sliding and corner behaviour.

This milestone is why movement normalization belongs after composition rather
than inside individual input branches. It also explains why future movement
features must operate on the final vector before the one collision pass.

### Earlier hardware control tuning and Sprint 24

Emulator and real Game Gear testing exposed two separate control issues after
diagonal movement was already correct. First, simultaneous movement and
rotation presented too much translation in one rendered transition. The player
was not receiving two movement vectors; the problem was the amount of the
complete translation displayed together with the perspective change. Second,
the approximately eight-degree rotation step itself produced a larger visible
frame-to-frame perspective jump than cardinal movement, including during
rotation-only input.

That pass introduced 176/256 movement-with-turn translation, reduced the camera
step to approximately six degrees with cosine 4074 and sine 428, and tuned
cardinal speed to 44. Sprint 24 retained the angle and cardinal speed but removed
the turn-specific translation penalty after renderer work eliminated its former
presentation rationale. Rotation now precedes movement-vector calculation, and
opposing inputs cancel. Collision and diagonal normalization remain unchanged.

Together, these milestones explain the present engine: its small centred
viewport is a measured hardware budget, its ray and renderer boundaries grew
from the first working projection, its native caches avoid verified redundant
work, and its movement system keeps one diagonal rule without coupling speed to
rotation or renderer cost.

## Current project status

The project builds a valid banked Game Gear ROM and has a stable optimized
baseline previously verified in Emulicious and on original Sega Game Gear
hardware. Bank 0 retains the hot engine core, while the low-frequency world
interaction dispatcher is the first module migrated to Bank 1. The
centred 28-ray viewport, optimized wall renderer, fixed-point camera,
approximately 7.802-degree rotation, `PLAYER_MOVE_SPEED = 74`, normalized
full-speed diagonal movement, axis-separated
collision, wall sliding, texture rendering, dirty-column caching, and VRAM
upload behaviour are treated as stable.

Original Game Gear testing approves the current native 8×8 texture,
side-aware shading, three-level distance treatment, Candidate C Hybrid Distance
Fog, 112×64 viewport, and renderer pacing as production behavior. Future
renderer work must preserve its byte-level output contract and pass the host
oracle.

The ROM banking model, module-placement rules, and future expansion strategy
are defined in `docs/ROM_BANKING.md`.

The workshop map, multi-zombie extraction, moving billboard LOD renderer,
distance-scaled pistol combat, world/material/object boundaries, interaction
ray, toggleable yellow doors, and switch-activated red door are implemented.
Zombies implement LOS-driven activation, direct pursuit, shared walking phase,
melee attacks, player damage, hit/death presentation, persistent corpse states,
Game Over presentation, and full-session restart.

Normal movement and combined movement/rotation use the same translation speed.
Forward/backward translation and left/right rotation remain symmetrical by
construction. Renderer profiling remains an
optional diagnostic configuration rather than a shipping feature.

## Future work

Moving-zombie measurements should trigger another renderer review if practical
frames repeatedly approach 10–12 dirty columns, 80–96 regenerated tiles, or
about 2.5–3 KiB of pattern traffic. The selected follow-up Release has 3,519
Bank 0 bytes free; future resident work must continue to audit that margin.

- **Doors:** add animation, timing, obstruction rules, and audiovisual feedback
  beyond the accepted instantaneous open/closed state.
- **Weapons:** add ammunition, recoil, switching, and additional weapons around
  the accepted press-edge pistol and firing frame.
- **Sprites:** extend deterministic multi-sprite presentation to additional
  moving actor types.
- **HUD and helmet overlay:** extend the accepted weapon, health, damage, and
  attack overlays while preserving viewport tile and pattern ownership.
- **Lighting:** extend the current side-based palette treatment only after its
  RAM, ROM, palette, and sampling costs are defined.
- **Map system:** support additional maps, metadata, spawn points, objects, and
  transitions while keeping world queries independent of storage format.
- **Sound:** integrate Game Gear audio with explicit ownership and predictable
  per-frame cost.
- **Game logic:** add progression, health, inventory, objectives, and scene
  state above the existing engine modules.

These are prospective systems; none should be inferred to exist today beyond
the foundations described elsewhere in this document.

## Developer notes

Use the existing C style: four-space indentation, braces on their own lines,
lowercase snake_case functions and variables, uppercase macro constants, and
module-prefixed public functions. Keep headers small and expose behaviour
rather than internal storage.

Respect module ownership. Input owns controller history, player owns physical
position and collision, camera owns view vectors, world owns map semantics,
raycaster owns geometric results, and Game Gear video owns native rendering and
VRAM. New systems should communicate through narrow headers instead of reading
another module's static data.

Add systems safely by first identifying their authoritative state, update
point, and platform boundary. Keep gameplay code under `game/`, reusable render
geometry under `engine/`, and SMSlib/native-format work under
`platform/game_gear/`. Update `main.c` only to establish explicit frame order;
do not turn it into an implementation module.

Files that should change rarely include:

- `game/main.c`, because it defines the engine's temporal behaviour;
- `game/camera.c`, because vector normalization defines projection stability;
- `game/player.c`, because scaling and collision order define controls;
- `engine/render/raycaster.c`, especially the reciprocal and camera tables;
- `platform/game_gear/video.c`, because its caches, native formats, and VRAM
  calls are tightly coupled to hardware behaviour;
- `platform/game_gear/vram_layout.h`, because tile indices are shared resource
  allocations.

The most performance-critical paths are the DDA loop, texture sampling,
palette mapping, native tile construction, dirty-column traversal, and VRAM
transfer. Inspect generated SDCC assembly and measure event counts before
optimizing them. Output-preserving changes should be validated exhaustively
when the input space is small, and all renderer/control changes should be
tested on real hardware.

Before accepting engine changes, run `git diff --check`, build with
`build.bat`, verify the `TMR SEGA` header and ROM checksum, inspect the changed
file set, and confirm that compiler warnings have not increased. Profiling
builds should be returned to the normal ROM configuration after measurement.

## Final summary

The current code is the stable optimized GearRay
engine baseline: a modular, deterministic Game Gear raycaster with a centred
28-ray viewport, a fixed-point camera with approximately 7.802-degree symmetric
rotation, 74-unit cardinal movement, bounded full-speed diagonal translation,
axis-separated collision, table-driven DDA, native textured wall
generation, and dirty VRAM updates. Normal movement and simultaneous turning
use the same translation speed. The
design deliberately trades display resolution and ROM tables for predictable
Z80 work, clear ownership, and maintainable hardware behaviour. Future work
should extend this baseline without silently changing its established frame
order, control constants, collision semantics, projection, or rendering
contracts.
