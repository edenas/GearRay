;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (MINGW64)
;--------------------------------------------------------
	.module video
	
	.optsdcc -mz80 sdcccall(1)
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _game_gear_prepare_cached_world_sprites
	.globl _game_gear_overlay_hud_weapon_tile
	.globl _game_gear_hud_weapon_render_complete
	.globl _game_gear_hud_weapon_changed
	.globl _world_sprite_get_count
	.globl _SMS_VRAMmemcpy
	.globl _SMS_load1bppTiles
	.globl _SMS_crt0_RST18
	.globl _SMS_crt0_RST08
	.globl _SMS_setBGScrollX
	.globl _wall_plan_rows
	.globl _wall_plan_prepare
	.globl _raycaster_get_rendered_rays
	.globl _game_gear_damage_shake_phase
	.globl _previous_projected_sprite_count
	.globl _previous_wall_columns
	.globl _viewport_tile_states
	.globl _SMS_SRAM
	.globl _SRAM_bank_to_be_mapped_on_slot2
	.globl _ROM_bank_to_be_mapped_on_slot0
	.globl _ROM_bank_to_be_mapped_on_slot1
	.globl _ROM_bank_to_be_mapped_on_slot2
	.globl _game_gear_damage_shake_update
	.globl _game_gear_video_draw_wall_columns
	.globl _game_gear_video_draw_viewport_border
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
_SMS_VDPControlPort	=	0x00bf
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
_ROM_bank_to_be_mapped_on_slot2	=	0xffff
_ROM_bank_to_be_mapped_on_slot1	=	0xfffe
_ROM_bank_to_be_mapped_on_slot0	=	0xfffd
_SRAM_bank_to_be_mapped_on_slot2	=	0xfffc
_SMS_SRAM	=	0x8000
_projected_wall_column:
	.ds 256
_viewport_tile_states::
	.ds 112
_previous_wall_columns::
	.ds 98
_previous_projected_sprites:
	.ds 153
_previous_projected_sprite_count::
	.ds 1
_game_gear_damage_shake_phase::
	.ds 1
_left_wall_plan:
	.ds 51
_right_wall_plan:
	.ds 51
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute ram data
;--------------------------------------------------------
	.area _DABS (ABS)
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;D:/mano_projektai/GearRay/platform/game_gear/video.c:54: void game_gear_damage_shake_update(void)
;	---------------------------------
; Function game_gear_damage_shake_update
; ---------------------------------
_game_gear_damage_shake_update::
;D:/mano_projektai/GearRay/platform/game_gear/video.c:56: if (game_gear_damage_shake_phase == 0)
	ld	a, (_game_gear_damage_shake_phase+0)
	or	a, a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:57: return;
	ret	z
;D:/mano_projektai/GearRay/platform/game_gear/video.c:59: --game_gear_damage_shake_phase;
	ld	hl, #_game_gear_damage_shake_phase
	dec	(hl)
;D:/mano_projektai/GearRay/platform/game_gear/video.c:61: game_gear_damage_shake_offsets[game_gear_damage_shake_phase]);
	ld	hl, #_game_gear_damage_shake_offsets
	ld	a, (_game_gear_damage_shake_phase)
	ld	e, a
	ld	d, #0x00
	add	hl, de
	ld	l, (hl)
;D:/mano_projektai/GearRay/platform/game_gear/video.c:62: }
	jp	_SMS_setBGScrollX
	.area _BANK1
	.area _BANK1
_debug_border_tiles:
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x01	; 1
	.area _CODE
	.area _CODE
;D:/mano_projektai/GearRay/platform/game_gear/video.c:64: static unsigned char game_gear_sprite_covers_tile_column(
;	---------------------------------
; Function game_gear_sprite_covers_tile_column
; ---------------------------------
_game_gear_sprite_covers_tile_column:
	push	ix
	ld	ix,	#0
	add	ix, sp
	push	af
	ex	de, hl
;D:/mano_projektai/GearRay/platform/game_gear/video.c:68: signed int tile_left = tile_column * 8;
	ld	l, 4 (ix)
	ld	h, #0x00
	add	hl, hl
	add	hl, hl
	add	hl, hl
	ld	c, l
	ld	b, h
;D:/mano_projektai/GearRay/platform/game_gear/video.c:69: signed int tile_right = tile_left + 8;
	ld	hl, #0x0008
	add	hl, bc
	ex	(sp), hl
;D:/mano_projektai/GearRay/platform/game_gear/video.c:71: return sprite->visible
	ld	a, (de)
	or	a, a
	jr	z, 00103$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:72: && sprite->right > tile_left
	ld	l, e
	ld	h, d
	inc	hl
	inc	hl
	inc	hl
	ld	a, (hl)
	inc	hl
	ld	h, (hl)
	ld	l, a
	ld	a, c
	sub	a, l
	ld	a, b
	sbc	a, h
	jp	po, 00124$
	xor	a, #0x80
00124$:
	jp	p, 00103$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:73: && sprite->left < tile_right;
	ex	de, hl
	inc	hl
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	ld	a, c
	sub	a, -2 (ix)
	ld	a, b
	sbc	a, -1 (ix)
	jp	po, 00125$
	xor	a, #0x80
00125$:
	jp	m, 00104$
00103$:
	xor	a, a
	jr	00105$
00104$:
	ld	a, #0x01
00105$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:74: }
	ld	sp, ix
	pop	ix
	pop	hl
	inc	sp
	jp	(hl)
;D:/mano_projektai/GearRay/platform/game_gear/video.c:76: static unsigned char game_gear_sprite_covers_tile(
;	---------------------------------
; Function game_gear_sprite_covers_tile
; ---------------------------------
_game_gear_sprite_covers_tile:
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	c, l
	ld	b, h
;D:/mano_projektai/GearRay/platform/game_gear/video.c:81: signed int tile_top = tile_row * 8;
	ld	e, 5 (ix)
	ld	d, #0x00
	ex	de, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
;D:/mano_projektai/GearRay/platform/game_gear/video.c:83: return game_gear_sprite_covers_tile_column(sprite, tile_column)
	push	bc
	push	hl
	ld	a, 4 (ix)
	push	af
	inc	sp
	ld	l, c
	ld	h, b
	call	_game_gear_sprite_covers_tile_column
	pop	de
	pop	bc
	or	a, a
	jr	z, 00103$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:84: && sprite->bottom > tile_top
	ld	l, c
	ld	h, b
	push	bc
	ld	bc, #0x0007
	add	hl, bc
	pop	bc
	ld	a, (hl)
	inc	hl
	ld	h, (hl)
	ld	l, a
	ld	a, e
	sub	a, l
	ld	a, d
	sbc	a, h
	jp	po, 00124$
	xor	a, #0x80
00124$:
	jp	p, 00103$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:85: && sprite->top < tile_top + 8;
	ld	hl, #5
	add	hl, bc
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	ld	hl, #0x0008
	add	hl, de
	ld	a, c
	sub	a, l
	ld	a, b
	sbc	a, h
	jp	po, 00125$
	xor	a, #0x80
00125$:
	jp	m, 00104$
00103$:
	xor	a, a
	jr	00105$
00104$:
	ld	a, #0x01
00105$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:86: }
	pop	ix
	pop	hl
	pop	bc
	jp	(hl)
;D:/mano_projektai/GearRay/platform/game_gear/video.c:89: static void game_gear_overlay_sprite_tile(
;	---------------------------------
; Function game_gear_overlay_sprite_tile
; ---------------------------------
_game_gear_overlay_sprite_tile:
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	iy, #-38
	add	iy, sp
	ld	sp, iy
	ld	-8 (ix), l
	ld	-7 (ix), h
;D:/mano_projektai/GearRay/platform/game_gear/video.c:93: const unsigned char *pixels=projected->near_texture_id==NEAR_ZOMBIE_TEXTURE_NONE
	ld	c, 6 (ix)
	ld	b, 7 (ix)
	ld	hl, #15
	add	hl, bc
	ld	l, (hl)
	ld	a, l
	inc	a
	ld	a, #0x01
	jr	z, 00317$
	xor	a, a
00317$:
	ld	c, a
	or	a, a
	jr	z, 00141$
	ld	e, 6 (ix)
	ld	d, 7 (ix)
	ld	hl, #13
	add	hl, de
	ld	e, (hl)
	inc	hl
	ld	a, (hl)
	jr	00142$
00141$:
	ld	de, #_near_zombie_texture_pixels+0
	ld	h, #0x00
	add	hl, hl
	add	hl, de
	ld	e, (hl)
	inc	hl
	ld	a, (hl)
00142$:
	ld	-28 (ix), e
	ld	-27 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:95: unsigned char source_size=projected->near_texture_id==NEAR_ZOMBIE_TEXTURE_NONE
	ld	a, c
	or	a, a
	jr	z, 00143$
	ld	c, 6 (ix)
	ld	b, 7 (ix)
	ld	hl, #16
	add	hl, bc
	ld	a, (hl)
	jr	00144$
00143$:
	ld	a, #0x20
00144$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:97: unsigned char packed_row_stride=source_size>>1;
	ld	-6 (ix), a
	srl	a
	ld	-26 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:98: signed int tile_left=tile_column*8,tile_top=tile_row*8,screen_x,screen_y;
	ld	l, 4 (ix)
	ld	h, #0x00
	add	hl, hl
	add	hl, hl
	add	hl, hl
	ex	(sp), hl
	ld	l, 5 (ix)
	ld	h, #0x00
	add	hl, hl
	add	hl, hl
	add	hl, hl
	ld	-25 (ix), l
	ld	-24 (ix), h
;D:/mano_projektai/GearRay/platform/game_gear/video.c:101: unsigned char last_source_y=255;
	ld	-23 (ix), #0xff
;D:/mano_projektai/GearRay/platform/game_gear/video.c:103: for(pixel_x=0;pixel_x<8;++pixel_x) {
	ld	de, #0x000b
	ld	l, 6 (ix)
	ld	h, 7 (ix)
	add	hl, de
	ld	-3 (ix), l
	ld	-2 (ix), h
	ld	a, 6 (ix)
	ld	-18 (ix), a
	ld	a, 7 (ix)
	ld	-17 (ix), a
	ld	a, 6 (ix)
	ld	-16 (ix), a
	ld	a, 7 (ix)
	ld	-15 (ix), a
	ld	a, 6 (ix)
	ld	-14 (ix), a
	ld	a, 7 (ix)
	ld	-13 (ix), a
	ld	-1 (ix), #0x00
00136$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:104: screen_x=tile_left+pixel_x;source_x[pixel_x]=255;
	ld	a, -1 (ix)
	ld	c, #0x00
	add	a, -38 (ix)
	ld	-12 (ix), a
	ld	a, c
	adc	a, -37 (ix)
	ld	-11 (ix), a
	ld	e, -1 (ix)
	ld	d, #0x00
	ld	hl, #2
	add	hl, sp
	add	hl, de
	ld	-10 (ix), l
	ld	-9 (ix), h
	ld	(hl), #0xff
;D:/mano_projektai/GearRay/platform/game_gear/video.c:105: if(screen_x<projected->left || screen_x>=projected->right) continue;
	ld	l, -14 (ix)
	ld	h, -13 (ix)
	inc	hl
	ld	a, (hl)
	ld	-5 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-4 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:108: if(texture_x>=source_size) texture_x=source_size-1;
	ld	a, -6 (ix)
	ld	-22 (ix), a
	ld	-21 (ix), #0x00
	ld	a, -6 (ix)
	ld	c, #0x00
	add	a, #0xff
	ld	-20 (ix), a
	ld	a, c
	adc	a, #0xff
	ld	-19 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:105: if(screen_x<projected->left || screen_x>=projected->right) continue;
	ld	a, -12 (ix)
	sub	a, -5 (ix)
	ld	a, -11 (ix)
	sbc	a, -4 (ix)
	jp	po, 00318$
	xor	a, #0x80
00318$:
	jp	m, 00108$
	ld	l, -16 (ix)
	ld	h, -15 (ix)
	inc	hl
	inc	hl
	inc	hl
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	ld	a, -12 (ix)
	sub	a, c
	ld	a, -11 (ix)
	sbc	a, b
	jp	po, 00319$
	xor	a, #0x80
00319$:
	jp	p, 00108$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:106: if(projected->depth>=rays[(unsigned char)screen_x>>2].wall_distance) continue;
	ld	l, -18 (ix)
	ld	h, -17 (ix)
	ld	de, #0x0009
	add	hl, de
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	ld	e, -12 (ix)
	srl	e
	srl	e
	ld	d, #0x00
	ld	l, e
	ld	h, d
	add	hl, hl
	add	hl, de
	add	hl, hl
	ex	de, hl
	ld	l, 8 (ix)
	ld	h, 9 (ix)
	add	hl, de
	ld	de, #0x0004
	add	hl, de
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	ld	a, c
	sub	a, e
	ld	a, b
	sbc	a, d
	jr	nc, 00108$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:107: texture_x=((unsigned int)(screen_x-projected->left)*projected->texture_step)>>8;
	ld	a, -12 (ix)
	sub	a, -5 (ix)
	ld	c, a
	ld	a, -11 (ix)
	sbc	a, -4 (ix)
	ld	b, a
	ld	l, -3 (ix)
	ld	h, -2 (ix)
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	ld	l, c
	ld	h, b
	call	__mulint
	ld	-5 (ix), d
	ld	-4 (ix), #0x00
;D:/mano_projektai/GearRay/platform/game_gear/video.c:108: if(texture_x>=source_size) texture_x=source_size-1;
	ld	a, -5 (ix)
	sub	a, -22 (ix)
	jr	c, 00107$
	ld	a, -20 (ix)
	ld	-5 (ix), a
	ld	a, -19 (ix)
	ld	-4 (ix), a
00107$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:109: source_x[pixel_x]=(unsigned char)texture_x;
	ld	a, -5 (ix)
	ld	l, -10 (ix)
	ld	h, -9 (ix)
	ld	(hl), a
00108$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:103: for(pixel_x=0;pixel_x<8;++pixel_x) {
	inc	-1 (ix)
	ld	a, -1 (ix)
	sub	a, #0x08
	jp	c, 00136$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:111: for(pixel_y=0;pixel_y<8;++pixel_y) {
	ld	a, -3 (ix)
	ld	-18 (ix), a
	ld	a, -2 (ix)
	ld	-17 (ix), a
	ld	a, 6 (ix)
	ld	-16 (ix), a
	ld	a, 7 (ix)
	ld	-15 (ix), a
	ld	a, 6 (ix)
	ld	-14 (ix), a
	ld	a, 7 (ix)
	ld	-13 (ix), a
	ld	-6 (ix), #0x00
	ld	-5 (ix), #0x00
	ld	-4 (ix), #0x00
	ld	-3 (ix), #0x00
	ld	-2 (ix), #0x00
	ld	-1 (ix), #0x00
00138$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:112: screen_y=tile_top+pixel_y;
	ld	a, -6 (ix)
	ld	-12 (ix), a
	ld	-11 (ix), #0x00
	ld	e, -12 (ix)
	ld	d, #0x00
	ld	l, -25 (ix)
	ld	h, -24 (ix)
	add	hl, de
	ld	-10 (ix), l
	ld	-9 (ix), h
;D:/mano_projektai/GearRay/platform/game_gear/video.c:113: if(screen_y<projected->top || screen_y>=projected->bottom) continue;
	ld	l, -14 (ix)
	ld	h, -13 (ix)
	ld	de, #0x0005
	add	hl, de
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	ld	a, -10 (ix)
	sub	a, c
	ld	a, -9 (ix)
	sbc	a, b
	jp	po, 00320$
	xor	a, #0x80
00320$:
	jp	m, 00134$
	ld	l, -16 (ix)
	ld	h, -15 (ix)
	ld	de, #0x0007
	add	hl, de
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	ld	a, -10 (ix)
	sub	a, e
	ld	a, -9 (ix)
	sbc	a, d
	jp	po, 00321$
	xor	a, #0x80
00321$:
	jp	p, 00134$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:114: texture_y=((unsigned int)(screen_y-projected->top)*projected->texture_step)>>8;
	ld	a, -10 (ix)
	sub	a, c
	ld	c, a
	ld	a, -9 (ix)
	sbc	a, b
	ld	b, a
	ld	l, -18 (ix)
	ld	h, -17 (ix)
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	ld	l, c
	ld	h, b
	call	__mulint
	ld	c, d
	ld	b, #0x00
;D:/mano_projektai/GearRay/platform/game_gear/video.c:115: if(texture_y>=source_size) texture_y=source_size-1;
	ld	a, c
	sub	a, -22 (ix)
	jr	c, 00114$
	ld	c, -20 (ix)
	ld	b, -19 (ix)
00114$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:119: if(texture_y!=last_source_y) {
	ld	l, -23 (ix)
	xor	a, a
	ld	h, a
	sbc	hl, bc
	jp	z, 00133$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:120: last_source_y=(unsigned char)texture_y;
	ld	-23 (ix), c
;D:/mano_projektai/GearRay/platform/game_gear/video.c:121: source_row=pixels+texture_y*packed_row_stride;
	ld	e, -26 (ix)
	ld	d, #0x00
	ld	l, c
	ld	h, b
	call	__mulint
	ld	a, e
	add	a, -28 (ix)
	ld	c, a
	ld	a, d
	adc	a, -27 (ix)
	ld	b, a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:122: keep=255;b0=b1=b2=b3=0;
	ld	-5 (ix), #0xff
	ld	-1 (ix), #0x00
	ld	-2 (ix), #0x00
	ld	-3 (ix), #0x00
	ld	-4 (ix), #0x00
;D:/mano_projektai/GearRay/platform/game_gear/video.c:123: for(pixel_x=0;pixel_x<8;++pixel_x) {
	ld	e, #0x00
00137$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:124: texture_x=source_x[pixel_x];if(texture_x==255) continue;
	push	de
	ld	d, #0x00
	ld	hl, #4
	add	hl, sp
	add	hl, de
	pop	de
	ld	a, (hl)
	ld	-10 (ix), a
	ld	-9 (ix), #0x00
	ld	a, -10 (ix)
	inc	a
	or	a, -9 (ix)
	jr	z, 00130$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:125: palette_index=source_row[texture_x>>1];
	ld	a, -10 (ix)
	ld	h, #0x00
	srl	h
	rr	a
	ld	l, a
	add	hl, bc
	ld	a, (hl)
;D:/mano_projektai/GearRay/platform/game_gear/video.c:126: if(texture_x&1) palette_index&=15;else palette_index>>=4;
	bit	0, -10 (ix)
	jr	z, 00118$
	and	a, #0x0f
	ld	d, a
	jr	00119$
00118$:
	rlca
	rlca
	rlca
	rlca
	and	a, #0x0f
	ld	d, a
00119$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:127: if(palette_index==SPRITE_TRANSPARENT_INDEX) continue;
	ld	a, d
	sub	a, #0x0f
	jr	z, 00130$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:128: mask=128U>>pixel_x;keep&=(unsigned char)~mask;
	ld	a, e
	ld	hl, #0x0080
	inc	a
	jr	00327$
00326$:
	srl	h
	rr	l
00327$:
	dec	a
	jr	nz, 00326$
	ld	a, l
	cpl
	and	a, -5 (ix)
	ld	-5 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:129: if(palette_index&1) b0|=mask;if(palette_index&2) b1|=mask;
	bit	0, d
	jr	z, 00123$
	ld	a, -4 (ix)
	or	a, l
	ld	-4 (ix), a
00123$:
	bit	1, d
	jr	z, 00125$
	ld	a, -3 (ix)
	or	a, l
	ld	-3 (ix), a
00125$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:130: if(palette_index&4) b2|=mask;if(palette_index&8) b3|=mask;
	bit	2, d
	jr	z, 00127$
	ld	a, -2 (ix)
	or	a, l
	ld	-2 (ix), a
00127$:
	bit	3, d
	jr	z, 00130$
	ld	a, -1 (ix)
	or	a, l
	ld	-1 (ix), a
00130$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:123: for(pixel_x=0;pixel_x<8;++pixel_x) {
	inc	e
	ld	a, e
	sub	a, #0x08
	jp	c, 00137$
00133$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:133: destination[pixel_y*4]=(destination[pixel_y*4]&keep)|b0;
	ld	l, -12 (ix)
	ld	h, #0x00
	add	hl, hl
	add	hl, hl
	ex	de, hl
	ld	l, -8 (ix)
	ld	h, -7 (ix)
	add	hl, de
	ld	a, (hl)
	and	a, -5 (ix)
	or	a, -4 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:134: destination[pixel_y*4+1]=(destination[pixel_y*4+1]&keep)|b1;
	ld	c, e
	ld	b, d
	inc	bc
	ld	l, -8 (ix)
	ld	h, -7 (ix)
	add	hl, bc
	ld	a, (hl)
	and	a, -5 (ix)
	or	a, -3 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:135: destination[pixel_y*4+2]=(destination[pixel_y*4+2]&keep)|b2;
	ld	c, e
	ld	b, d
	inc	bc
	inc	bc
	ld	l, -8 (ix)
	ld	h, -7 (ix)
	add	hl, bc
	ld	a, (hl)
	and	a, -5 (ix)
	or	a, -2 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:136: destination[pixel_y*4+3]=(destination[pixel_y*4+3]&keep)|b3;
	inc	de
	inc	de
	inc	de
	ld	l, -8 (ix)
	ld	h, -7 (ix)
	add	hl, de
	ld	a, (hl)
	and	a, -5 (ix)
	or	a, -1 (ix)
	ld	(hl), a
00134$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:111: for(pixel_y=0;pixel_y<8;++pixel_y) {
	inc	-6 (ix)
	ld	a, -6 (ix)
	sub	a, #0x08
	jp	c, 00138$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:138: }
	ld	sp, ix
	pop	ix
	pop	hl
	pop	af
	pop	af
	pop	af
	jp	(hl)
;D:/mano_projektai/GearRay/platform/game_gear/video.c:140: static unsigned char game_gear_wall_column_is_unchanged(
;	---------------------------------
; Function game_gear_wall_column_is_unchanged
; ---------------------------------
_game_gear_wall_column_is_unchanged:
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	c, l
	ld	b, h
;D:/mano_projektai/GearRay/platform/game_gear/video.c:151: unsigned char side_flags = 0;
	ld	e, #0x00
;D:/mano_projektai/GearRay/platform/game_gear/video.c:153: if ((previous->side_and_valid_flags & WALL_COLUMN_VALID_FLAG) == 0)
	push	bc
	pop	iy
	ld	d, 6 (iy)
	bit	7, d
	jr	nz, 00102$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:154: return 0;
	xor	a, a
	jr	00107$
00102$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:156: if (left_wall_side == WALL_SIDE_Y)
	ld	a, 10 (ix)
	dec	a
	jr	nz, 00104$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:157: side_flags |= WALL_COLUMN_LEFT_SIDE_Y_FLAG;
	ld	e, #0x01
00104$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:159: if (right_wall_side == WALL_SIDE_Y)
	ld	a, 11 (ix)
	dec	a
	jr	nz, 00106$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:160: side_flags |= WALL_COLUMN_RIGHT_SIDE_Y_FLAG;
	set	1, e
00106$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:162: return previous->left_wall_height == left_wall_height
	ld	a, (bc)
	sub	a, 4 (ix)
	jr	nz, 00109$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:163: && previous->right_wall_height == right_wall_height
	ld	l, c
	ld	h, b
	inc	hl
	ld	a, (hl)
	sub	a, 5 (ix)
	jr	nz, 00109$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:164: && previous->left_hit_offset == left_hit_offset
	ld	l, c
	ld	h, b
	inc	hl
	inc	hl
	ld	a, (hl)
	sub	a, 6 (ix)
	jr	nz, 00109$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:165: && previous->right_hit_offset == right_hit_offset
	ld	l, c
	ld	h, b
	inc	hl
	inc	hl
	inc	hl
	ld	a, (hl)
	sub	a, 7 (ix)
	jr	nz, 00109$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:166: && previous->left_texture_id == left_texture_id
	ld	l, c
	ld	h, b
	inc	hl
	inc	hl
	inc	hl
	inc	hl
	ld	a, (hl)
	sub	a, 8 (ix)
	jr	nz, 00109$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:167: && previous->right_texture_id == right_texture_id
	ld	hl, #5
	add	hl, bc
	ld	a, (hl)
	sub	a, 9 (ix)
	jr	nz, 00109$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:168: && (previous->side_and_valid_flags
	ld	a, d
	and	a, #0x03
	sub	a, e
	jr	z, 00110$
00109$:
	xor	a, a
	jr	00111$
00110$:
	ld	a, #0x01
00111$:
00107$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:171: }
	pop	ix
	pop	hl
	pop	bc
	pop	bc
	pop	bc
	pop	bc
	jp	(hl)
;D:/mano_projektai/GearRay/platform/game_gear/video.c:173: static void game_gear_store_wall_column_signature(
;	---------------------------------
; Function game_gear_store_wall_column_signature
; ---------------------------------
_game_gear_store_wall_column_signature:
	push	ix
	ld	ix,	#0
	add	ix, sp
	ex	de, hl
;D:/mano_projektai/GearRay/platform/game_gear/video.c:184: unsigned char side_and_valid_flags = WALL_COLUMN_VALID_FLAG;
	ld	c, #0x80
;D:/mano_projektai/GearRay/platform/game_gear/video.c:186: previous->left_wall_height = left_wall_height;
	ld	a, 4 (ix)
	ld	(de), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:187: previous->right_wall_height = right_wall_height;
	ld	l, e
	ld	h, d
	inc	hl
	ld	a, 5 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:188: previous->left_hit_offset = left_hit_offset;
	ld	l, e
	ld	h, d
	inc	hl
	inc	hl
	ld	a, 6 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:189: previous->right_hit_offset = right_hit_offset;
	ld	l, e
	ld	h, d
	inc	hl
	inc	hl
	inc	hl
	ld	a, 7 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:190: previous->left_texture_id = left_texture_id;
	ld	hl, #0x0004
	add	hl, de
	ld	a, 8 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:191: previous->right_texture_id = right_texture_id;
	ld	hl, #0x0005
	add	hl, de
	ld	a, 9 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:192: if (left_wall_side == WALL_SIDE_Y)
	ld	a, 10 (ix)
	dec	a
	jr	nz, 00102$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:193: side_and_valid_flags |= WALL_COLUMN_LEFT_SIDE_Y_FLAG;
	ld	c, #0x81
00102$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:195: if (right_wall_side == WALL_SIDE_Y)
	ld	a, 11 (ix)
	dec	a
	jr	nz, 00104$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:196: side_and_valid_flags |= WALL_COLUMN_RIGHT_SIDE_Y_FLAG;
	set	1, c
00104$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:198: previous->side_and_valid_flags = side_and_valid_flags;
	ld	hl, #0x0006
	add	hl, de
	ld	(hl), c
;D:/mano_projektai/GearRay/platform/game_gear/video.c:199: }
	pop	ix
	pop	hl
	pop	af
	pop	af
	pop	af
	pop	af
	jp	(hl)
;D:/mano_projektai/GearRay/platform/game_gear/video.c:202: static void game_gear_build_native_wall_tile(unsigned char *destination,unsigned char screen_y)
;	---------------------------------
; Function game_gear_build_native_wall_tile
; ---------------------------------
_game_gear_build_native_wall_tile:
	push	ix
	ld	ix,	#0
	add	ix, sp
;D:/mano_projektai/GearRay/platform/game_gear/video.c:204: SMS_MAPPER_SLOT2_REGISTER=3;
	push	hl
	ld	hl, #0xffff
	ld	(hl), #0x03
	pop	hl
;D:/mano_projektai/GearRay/platform/game_gear/video.c:205: wall_plan_rows(destination,&left_wall_plan,&right_wall_plan,screen_y,8);
	ld	d, #0x08
	ld	e, 4 (ix)
	push	de
	ld	de, #_right_wall_plan
	push	de
	ld	de, #_left_wall_plan
	call	_wall_plan_rows
;D:/mano_projektai/GearRay/platform/game_gear/video.c:206: SMS_MAPPER_SLOT2_REGISTER=2;
	ld	hl, #0xffff
	ld	(hl), #0x02
;D:/mano_projektai/GearRay/platform/game_gear/video.c:207: }
	pop	ix
	pop	hl
	inc	sp
	jp	(hl)
;D:/mano_projektai/GearRay/platform/game_gear/video.c:209: static unsigned char game_gear_get_visible_wall_pixels(
;	---------------------------------
; Function game_gear_get_visible_wall_pixels
; ---------------------------------
_game_gear_get_visible_wall_pixels:
	push	ix
	ld	ix,	#0
	add	ix, sp
	push	af
	push	af
	ld	-2 (ix), l
	ld	-1 (ix), h
;D:/mano_projektai/GearRay/platform/game_gear/video.c:215: signed int wall_bottom = wall_top + wall_height;
	ld	a, 4 (ix)
	ld	c, #0x00
	add	a, -2 (ix)
	ld	-4 (ix), a
	ld	a, c
	adc	a, -1 (ix)
	ld	-3 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:217: if (wall_bottom <= 0 || wall_top >= GAME_GEAR_VIEWPORT_PIXEL_HEIGHT)
	xor	a, a
	cp	a, -4 (ix)
	sbc	a, -3 (ix)
	jp	po, 00134$
	xor	a, #0x80
00134$:
	jp	p, 00101$
	ld	a, -2 (ix)
	sub	a, #0x40
	ld	a, -1 (ix)
	rla
	ccf
	rra
	sbc	a, #0x80
	jr	c, 00102$
00101$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:218: return 0;
	xor	a, a
	jr	00108$
00102$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:220: *visible_top = wall_top;
	ld	c, 5 (ix)
	ld	b, 6 (ix)
	ld	l, c
	ld	h, b
	ld	a, -2 (ix)
	ld	(hl), a
	inc	hl
	ld	a, -1 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:221: *visible_bottom = wall_bottom;
	ld	e, 7 (ix)
	ld	d, 8 (ix)
	ld	l, e
	ld	h, d
	ld	a, -4 (ix)
	ld	(hl), a
	inc	hl
	ld	a, -3 (ix)
	ld	(hl), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:223: if (*visible_top < 0)
	ld	l, c
	ld	h, b
	inc	hl
	bit	7, (hl)
	jr	z, 00105$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:224: *visible_top = 0;
	xor	a, a
	ld	(bc), a
	inc	bc
	ld	(bc), a
00105$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:226: if (*visible_bottom > GAME_GEAR_VIEWPORT_PIXEL_HEIGHT)
	ld	l, e
	ld	h, d
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	ld	a, #0x40
	cp	a, c
	ld	a, #0x00
	sbc	a, b
	jp	po, 00135$
	xor	a, #0x80
00135$:
	jp	p, 00107$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:227: *visible_bottom = GAME_GEAR_VIEWPORT_PIXEL_HEIGHT;
	ld	a, #0x40
	ld	(de), a
	inc	de
	xor	a, a
	ld	(de), a
00107$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:229: return 1;
	ld	a, #0x01
00108$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:230: }
	ld	sp, ix
	pop	ix
	pop	hl
	pop	bc
	pop	bc
	inc	sp
	jp	(hl)
;D:/mano_projektai/GearRay/platform/game_gear/video.c:232: static unsigned char game_gear_get_active_wall_rows(
;	---------------------------------
; Function game_gear_get_active_wall_rows
; ---------------------------------
_game_gear_get_active_wall_rows:
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	iy, #-10
	add	iy, sp
	ld	sp, iy
;D:/mano_projektai/GearRay/platform/game_gear/video.c:244: signed int combined_top = GAME_GEAR_VIEWPORT_PIXEL_HEIGHT;
	ld	bc, #0x0040
;D:/mano_projektai/GearRay/platform/game_gear/video.c:245: signed int combined_bottom = 0;
	xor	a, a
	ld	-2 (ix), a
	ld	-1 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:250: left_wall_top, left_wall_height, &left_top, &left_bottom);
	ex	de, hl
	ld	hl, #0
	add	hl, sp
	push	bc
	ex	de, hl
	push	hl
	ld	hl, #6
	add	hl, sp
	ex	(sp), hl
	push	de
	ld	a, 4 (ix)
	push	af
	inc	sp
	call	_game_gear_get_visible_wall_pixels
	ld	e, a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:252: right_wall_top, right_wall_height, &right_top, &right_bottom);
	push	de
	ld	hl, #10
	add	hl, sp
	push	hl
	dec	hl
	dec	hl
	push	hl
	ld	a, 7 (ix)
	push	af
	inc	sp
	ld	l, 5 (ix)
	ld	h, 6 (ix)
	call	_game_gear_get_visible_wall_pixels
	ld	l, a
	pop	de
	pop	bc
;D:/mano_projektai/GearRay/platform/game_gear/video.c:254: if (has_left_wall)
	ld	a, e
	or	a, a
	jr	z, 00102$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:256: combined_top = left_top;
	pop	bc
	push	bc
;D:/mano_projektai/GearRay/platform/game_gear/video.c:257: combined_bottom = left_bottom;
	ld	a, -8 (ix)
	ld	-2 (ix), a
	ld	a, -7 (ix)
	ld	-1 (ix), a
00102$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:260: if (has_right_wall)
	ld	a, l
	or	a, a
	jr	z, 00108$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:262: if (right_top < combined_top)
	ld	a, -6 (ix)
	sub	a, c
	ld	a, -5 (ix)
	sbc	a, b
	jp	po, 00180$
	xor	a, #0x80
00180$:
	jp	p, 00104$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:263: combined_top = right_top;
	ld	c, -6 (ix)
	ld	b, -5 (ix)
00104$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:265: if (right_bottom > combined_bottom)
	ld	a, -2 (ix)
	sub	a, -4 (ix)
	ld	a, -1 (ix)
	sbc	a, -3 (ix)
	jp	po, 00181$
	xor	a, #0x80
00181$:
	jp	p, 00108$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:266: combined_bottom = right_bottom;
	ld	a, -4 (ix)
	ld	-2 (ix), a
	ld	a, -3 (ix)
	ld	-1 (ix), a
00108$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:269: if (!has_left_wall && !has_right_wall)
	ld	a, e
	or	a, a
	jr	nz, 00110$
	or	a, l
	jr	nz, 00110$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:270: return 0;
	xor	a, a
	jr	00112$
00110$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:272: *first_row = (unsigned char)(combined_top / 8);
	ld	e, 8 (ix)
	ld	d, 9 (ix)
	ld	l, c
	ld	h, b
	bit	7, b
	jr	z, 00114$
	ld	hl, #0x0007
	add	hl, bc
00114$:
	ld	a, l
	sra	h
	rr	a
	sra	h
	rr	a
	sra	h
	rr	a
	ld	(de), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:273: *last_row = (unsigned char)((combined_bottom - 1) / 8);
	ld	c, 10 (ix)
	ld	b, 11 (ix)
	ld	e, -2 (ix)
	ld	d, -1 (ix)
	dec	de
	ld	l, e
	ld	h, d
	bit	7, d
	jr	z, 00115$
	ld	hl, #0x0007
	add	hl, de
00115$:
	ld	a, l
	sra	h
	rr	a
	sra	h
	rr	a
	sra	h
	rr	a
	ld	(bc), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:274: return 1;
	ld	a, #0x01
00112$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:275: }
	ld	sp, ix
	pop	ix
	pop	hl
	pop	bc
	pop	bc
	pop	bc
	pop	bc
	jp	(hl)
;D:/mano_projektai/GearRay/platform/game_gear/video.c:277: void game_gear_video_draw_wall_columns(void)
;	---------------------------------
; Function game_gear_video_draw_wall_columns
; ---------------------------------
_game_gear_video_draw_wall_columns::
	push	ix
	ld	ix,	#0
	add	ix, sp
	ld	hl, #-201
	add	hl, sp
	ld	sp, hl
;D:/mano_projektai/GearRay/platform/game_gear/video.c:297: unsigned char *tile_states = viewport_tile_states;
;D:/mano_projektai/GearRay/platform/game_gear/video.c:298: GameGearWallColumnSignature *previous_wall_column = previous_wall_columns;
;D:/mano_projektai/GearRay/platform/game_gear/video.c:309: unsigned char near_bank_mapped = 0;
	ld	-36 (ix), #0x00
;D:/mano_projektai/GearRay/platform/game_gear/video.c:310: unsigned char previous_slot2_page = 0;
	ld	-35 (ix), #0x00
;D:/mano_projektai/GearRay/platform/game_gear/video.c:311: unsigned char ordered_sprite_count = 0;
	ld	iy, #2
	add	iy, sp
	ld	0 (iy), #0x00
;D:/mano_projektai/GearRay/platform/game_gear/video.c:313: const RaycasterRay *rendered_rays = raycaster_get_rendered_rays();
	call	_raycaster_get_rendered_rays
	ld	-34 (ix), e
	ld	-33 (ix), d
;D:/mano_projektai/GearRay/platform/game_gear/video.c:314: const RaycasterRay *left_ray = rendered_rays;
	ld	a, -34 (ix)
	ld	-2 (ix), a
	ld	a, -33 (ix)
	ld	-1 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:318: projected_sprite_count = world_sprite_get_count();
	call	_world_sprite_get_count
	ld	-9 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:319: if (SHOTGUN_PICKUP_PRESENT) ++projected_sprite_count;
	ld	a, (_owned_weapons)
	bit	1, a
	jr	nz, 00102$
	inc	-9 (ix)
00102$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:326: &ordered_sprite_count);
;D:/mano_projektai/GearRay/platform/game_gear/video.c:325: ordered_sprite_indices,
;D:/mano_projektai/GearRay/platform/game_gear/video.c:323: previous_projected_sprites,
;D:/mano_projektai/GearRay/platform/game_gear/video.c:321: projected_sprites,
	ld	hl, #2
	add	hl, sp
	push	hl
	inc	hl
	push	hl
	ld	a, (_previous_projected_sprite_count)
	push	af
	inc	sp
	ld	hl, #_previous_projected_sprites
	push	hl
	ld	a, -9 (ix)
	push	af
	inc	sp
	ld	hl, #20
	add	hl, sp
	call	_game_gear_prepare_cached_world_sprites
	ld	-32 (ix), e
	ld	-31 (ix), d
;D:/mano_projektai/GearRay/platform/game_gear/video.c:327: hud_weapon_changed = game_gear_hud_weapon_changed();
	call	_game_gear_hud_weapon_changed
	ld	-30 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:330: for (sprite_index = 0;
	ld	-3 (ix), #0x00
00193$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:331: sprite_index < projected_sprite_count;
	ld	a, -3 (ix)
	sub	a, -9 (ix)
	jr	nc, 00336$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:334: if (projected_sprites[sprite_index].visible
	ld	c, -3 (ix)
	ld	b, #0x00
	ld	l, c
	ld	h, b
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, bc
	ld	-7 (ix), l
	ld	-6 (ix), h
	ex	de, hl
	ld	hl, #12
	add	hl, sp
	add	hl, de
	ld	-5 (ix), l
	ld	-4 (ix), h
	ld	a, (hl)
	or	a, a
	jr	z, 00194$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:335: && projected_sprites[sprite_index].near_texture_id
	ld	c, -5 (ix)
	ld	b, -4 (ix)
	ld	hl, #15
	add	hl, bc
	ld	c, (hl)
	inc	c
	jr	z, 00194$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:338: previous_slot2_page = SMS_MAPPER_SLOT2_REGISTER;
	ld	a, (#0xffff)
	ld	-35 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:339: SMS_MAPPER_SLOT2_REGISTER = NEAR_ZOMBIE_ROM_PAGE;
	ld	hl, #0xffff
	ld	(hl), #0x02
;D:/mano_projektai/GearRay/platform/game_gear/video.c:340: near_bank_mapped = 1;
	ld	-36 (ix), #0x01
;D:/mano_projektai/GearRay/platform/game_gear/video.c:341: break;
	jr	00336$
00194$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:332: ++sprite_index)
	inc	-3 (ix)
	jr	00193$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:345: for (tile_column = 0;
00336$:
	ld	-8 (ix), #0x00
	ld	a, -2 (ix)
	ld	-7 (ix), a
	ld	a, -1 (ix)
	ld	-6 (ix), a
	ld	-5 (ix), #<(_previous_wall_columns)
	ld	-4 (ix), #>(_previous_wall_columns)
	ld	-3 (ix), #<(_viewport_tile_states)
	ld	-2 (ix), #>(_viewport_tile_states)
00209$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:352: right_ray = left_ray + 1;
	ld	de, #0x0006
	ld	l, -7 (ix)
	ld	h, -6 (ix)
	add	hl, de
	ld	-29 (ix), l
	ld	-28 (ix), h
;D:/mano_projektai/GearRay/platform/game_gear/video.c:354: left_wall_height = left_ray->wall_height;
	ld	l, -7 (ix)
	ld	h, -6 (ix)
	ld	a, (hl)
	ld	-27 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:355: right_wall_height = right_ray->wall_height;
	ld	l, -29 (ix)
	ld	h, -28 (ix)
	ld	a, (hl)
	ld	-26 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:356: left_hit_offset = left_ray->hit_offset;
	ld	c, -7 (ix)
	ld	b, -6 (ix)
	inc	bc
	inc	bc
	ld	a, (bc)
	ld	-25 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:357: right_hit_offset = right_ray->hit_offset;
	ld	c, -29 (ix)
	ld	b, -28 (ix)
	inc	bc
	inc	bc
	ld	a, (bc)
	ld	-24 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:358: left_wall_side = left_ray->hit_side;
	ld	c, -7 (ix)
	ld	b, -6 (ix)
	inc	bc
	ld	a, (bc)
	ld	-23 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:359: right_wall_side = right_ray->hit_side;
	ld	c, -29 (ix)
	ld	b, -28 (ix)
	inc	bc
	ld	a, (bc)
	ld	-22 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:360: current_sprite_column = 0;
	ld	-1 (ix), #0x00
;D:/mano_projektai/GearRay/platform/game_gear/video.c:361: sprite_dirty_column = 0;
	ld	-11 (ix), #0x00
;D:/mano_projektai/GearRay/platform/game_gear/video.c:362: for (sprite_index = 0;
	ld	c, #0x00
00196$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:363: sprite_index < projected_sprite_count;
	ld	a, c
	sub	a, -9 (ix)
	jr	nc, 00111$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:367: &projected_sprites[sprite_index], tile_column))
	ld	b, #0x00
	ld	l, c
	ld	h, b
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, bc
	ex	de, hl
	ld	hl, #12
	add	hl, sp
	add	hl, de
	push	bc
	ld	a, -8 (ix)
	push	af
	inc	sp
	call	_game_gear_sprite_covers_tile_column
	pop	bc
	or	a, a
	jr	z, 00197$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:369: current_sprite_column = 1;
	ld	-1 (ix), #0x01
;D:/mano_projektai/GearRay/platform/game_gear/video.c:370: if (sprite_changed_mask & (1U << sprite_index))
	ld	b, c
	ld	hl, #0x0001
	inc	b
	jr	00696$
00695$:
	add	hl, hl
00696$:
	djnz	00695$
	ld	a, l
	and	a, -32 (ix)
	ld	e, a
	ld	a, h
	and	a, -31 (ix)
	or	a, e
	jr	z, 00197$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:371: sprite_dirty_column = 1;
	ld	-11 (ix), #0x01
00197$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:364: ++sprite_index)
	inc	c
	jr	00196$
00111$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:374: for (sprite_index = 0;
	ld	c, #0x00
00199$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:375: sprite_index < previous_projected_sprite_count;
	ld	a, c
	ld	hl, #_previous_projected_sprite_count
	sub	a, (hl)
	jr	nc, 00118$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:379: &previous_projected_sprites[sprite_index], tile_column))
	ld	b, #0x00
	ld	l, c
	ld	h, b
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, bc
	ld	de, #_previous_projected_sprites
	add	hl, de
	push	bc
	ld	a, -8 (ix)
	push	af
	inc	sp
	call	_game_gear_sprite_covers_tile_column
	pop	bc
	or	a, a
	jr	z, 00200$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:381: if (sprite_changed_mask & (1U << sprite_index))
	ld	b, c
	ld	hl, #0x0001
	inc	b
	jr	00698$
00697$:
	add	hl, hl
00698$:
	djnz	00697$
	ld	a, l
	and	a, -32 (ix)
	ld	b, a
	ld	a, h
	and	a, -31 (ix)
	or	a, b
	jr	z, 00200$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:382: sprite_dirty_column = 1;
	ld	-11 (ix), #0x01
00200$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:376: ++sprite_index)
	inc	c
	jr	00199$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:387: GEAR_RAY_PROFILE_INCREMENT(sprite_driven_dirty_columns);
00118$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:395: right_ray->texture_id,
	ld	de, #0x0003
	ld	l, -29 (ix)
	ld	h, -28 (ix)
	add	hl, de
	ld	-21 (ix), l
	ld	-20 (ix), h
	ld	b, (hl)
;D:/mano_projektai/GearRay/platform/game_gear/video.c:394: left_ray->texture_id,
	ld	de, #0x0003
	ld	l, -7 (ix)
	ld	h, -6 (ix)
	add	hl, de
	ld	-19 (ix), l
	ld	-18 (ix), h
	ld	a, (hl)
;D:/mano_projektai/GearRay/platform/game_gear/video.c:389: if (game_gear_wall_column_is_unchanged(previous_wall_column,
	ld	h, -22 (ix)
	push	hl
	inc	sp
	ld	h, -23 (ix)
	ld	l, b
	push	hl
	push	af
	inc	sp
	ld	h, -24 (ix)
	ld	l, -25 (ix)
	push	hl
	ld	h, -26 (ix)
	ld	l, -27 (ix)
	push	hl
	ld	l, -5 (ix)
	ld	h, -4 (ix)
	call	_game_gear_wall_column_is_unchanged
	ld	-10 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:401: && tile_column <= HUD_WEAPON_LAST_TILE_COLUMN))
	ld	a, -8 (ix)
	sub	a, #0x08
	ld	a, #0x00
	rla
	ld	-17 (ix), a
	ld	a, #0x0c
	sub	a, -8 (ix)
	ld	a, #0x00
	rla
	ld	-16 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:389: if (game_gear_wall_column_is_unchanged(previous_wall_column,
	ld	a, -10 (ix)
	or	a, a
	jr	z, 00120$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:398: && !sprite_dirty_column
	ld	a, -11 (ix)
	or	a, a
	jr	nz, 00120$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:399: && !(hud_weapon_changed
	ld	a, -30 (ix)
	or	a, a
	jp	z, 00187$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:401: && tile_column <= HUD_WEAPON_LAST_TILE_COLUMN))
	bit	0, -17 (ix)
	jp	nz, 00187$
	bit	0, -16 (ix)
	jp	nz, 00187$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:403: continue;
00120$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:409: - left_wall_height) / 2;
	ld	a, -27 (ix)
	ld	-11 (ix), a
	ld	-10 (ix), #0x00
	ld	a, #0x40
	sub	a, -11 (ix)
	ld	-13 (ix), a
	sbc	a, a
	ld	-12 (ix), a
	ld	a, -13 (ix)
	ld	-11 (ix), a
	ld	a, -12 (ix)
	ld	-10 (ix), a
	bit	7, -12 (ix)
	jr	z, 00215$
	ld	l, -13 (ix)
	ld	h, -12 (ix)
	inc	hl
	ld	-11 (ix), l
	ld	-10 (ix), h
00215$:
	ld	a, -11 (ix)
	ld	-13 (ix), a
	ld	a, -10 (ix)
	ld	-12 (ix), a
	sra	-12 (ix)
	rr	-13 (ix)
;D:/mano_projektai/GearRay/platform/game_gear/video.c:411: - right_wall_height) / 2;
	ld	a, -26 (ix)
	ld	-11 (ix), a
	ld	-10 (ix), #0x00
	ld	a, #0x40
	sub	a, -11 (ix)
	ld	-15 (ix), a
	sbc	a, a
	ld	-14 (ix), a
	ld	a, -15 (ix)
	ld	-11 (ix), a
	ld	a, -14 (ix)
	ld	-10 (ix), a
	bit	7, -14 (ix)
	jr	z, 00216$
	ld	l, -15 (ix)
	ld	h, -14 (ix)
	inc	hl
	ld	-11 (ix), l
	ld	-10 (ix), h
00216$:
	sra	-10 (ix)
	rr	-11 (ix)
;D:/mano_projektai/GearRay/platform/game_gear/video.c:418: &last_active_row);
;D:/mano_projektai/GearRay/platform/game_gear/video.c:417: &first_active_row,
;D:/mano_projektai/GearRay/platform/game_gear/video.c:413: left_wall_top,
	ld	hl, #1
	add	hl, sp
	push	hl
	dec	hl
	push	hl
	ld	a, -26 (ix)
	push	af
	inc	sp
	ld	l, -11 (ix)
	ld	h, -10 (ix)
	push	hl
	ld	a, -27 (ix)
	push	af
	inc	sp
	ld	l, -13 (ix)
	ld	h, -12 (ix)
	call	_game_gear_get_active_wall_rows
	ld	-15 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:420: if (current_sprite_column)
	ld	a, -1 (ix)
	or	a, a
	jp	z, 00143$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:422: for (sprite_index = 0;
	ld	-1 (ix), #0x00
00202$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:423: sprite_index < projected_sprite_count;
	ld	a, -1 (ix)
	sub	a, -9 (ix)
	jp	nc, 00143$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:427: &projected_sprites[sprite_index], tile_column))
	ld	c, -1 (ix)
	ld	b, #0x00
	ld	l, c
	ld	h, b
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, bc
	ld	-13 (ix), l
	ld	-12 (ix), h
	ex	de, hl
	ld	hl, #12
	add	hl, sp
	add	hl, de
	ld	-11 (ix), l
	ld	-10 (ix), h
	ld	a, -11 (ix)
	ld	-13 (ix), a
	ld	a, -10 (ix)
	ld	-12 (ix), a
	ld	a, -8 (ix)
	push	af
	inc	sp
	ld	l, -13 (ix)
	ld	h, -12 (ix)
	call	_game_gear_sprite_covers_tile_column
	ld	-12 (ix), a
	or	a, a
	jp	z, 00140$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:431: sprite_visible_top = projected_sprites[sprite_index].top;
	ld	a, -11 (ix)
	ld	-13 (ix), a
	ld	a, -10 (ix)
	ld	-12 (ix), a
	ld	l, -13 (ix)
	ld	h, -12 (ix)
	ld	de, #0x0005
	add	hl, de
	ld	a, (hl)
	ld	-13 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-12 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:432: sprite_visible_bottom = projected_sprites[sprite_index].bottom;
	ld	l, -11 (ix)
	ld	h, -10 (ix)
	ld	de, #0x0007
	add	hl, de
	ld	a, (hl)
	ld	-11 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-10 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:433: if (sprite_visible_top < 0)
	bit	7, -12 (ix)
	jr	z, 00128$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:434: sprite_visible_top = 0;
	xor	a, a
	ld	-13 (ix), a
	ld	-12 (ix), a
00128$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:435: if (sprite_visible_bottom > GAME_GEAR_VIEWPORT_PIXEL_HEIGHT)
	ld	a, #0x40
	cp	a, -11 (ix)
	ld	a, #0x00
	sbc	a, -10 (ix)
	jp	po, 00699$
	xor	a, #0x80
00699$:
	jp	p, 00130$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:436: sprite_visible_bottom = GAME_GEAR_VIEWPORT_PIXEL_HEIGHT;
	ld	-11 (ix), #0x40
	ld	-10 (ix), #0
00130$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:437: if (sprite_visible_bottom > sprite_visible_top)
	ld	a, -13 (ix)
	sub	a, -11 (ix)
	ld	a, -12 (ix)
	sbc	a, -10 (ix)
	jp	po, 00700$
	xor	a, #0x80
00700$:
	jp	p, 00140$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:440: (unsigned char)(sprite_visible_top / 8);
	sra	-12 (ix)
	rr	-13 (ix)
	sra	-12 (ix)
	rr	-13 (ix)
	sra	-12 (ix)
	rr	-13 (ix)
	ld	a, -13 (ix)
	ld	-14 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:442: (unsigned char)((sprite_visible_bottom - 1) / 8);
	ld	c, -11 (ix)
	ld	b, -10 (ix)
	dec	bc
	ld	-13 (ix), c
	ld	-12 (ix), b
	ld	a, -13 (ix)
	ld	-11 (ix), a
	ld	a, -12 (ix)
	ld	-10 (ix), a
	bit	7, -12 (ix)
	jr	z, 00218$
	ld	de, #0x0007
	ld	l, -13 (ix)
	ld	h, -12 (ix)
	add	hl, de
	ld	-11 (ix), l
	ld	-10 (ix), h
00218$:
	ld	e, -11 (ix)
	ld	a, -10 (ix)
	sra	a
	rr	e
	sra	a
	rr	e
	sra	a
	rr	e
;D:/mano_projektai/GearRay/platform/game_gear/video.c:443: if (!has_active_wall)
	ld	a, -15 (ix)
	or	a, a
	jr	nz, 00136$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:445: first_active_row = sprite_first_row;
	ld	a, -14 (ix)
	ld	iy, #0
	add	iy, sp
	ld	0 (iy), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:446: last_active_row = sprite_last_row;
	ld	1 (iy), e
;D:/mano_projektai/GearRay/platform/game_gear/video.c:447: has_active_wall = 1;
	ld	-15 (ix), #0x01
	jr	00140$
00136$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:451: if (sprite_first_row < first_active_row)
	ld	a, -14 (ix)
	ld	iy, #0
	add	iy, sp
	sub	a, 0 (iy)
	jr	nc, 00132$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:452: first_active_row = sprite_first_row;
	ld	a, -14 (ix)
	ld	0 (iy), a
00132$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:453: if (sprite_last_row > last_active_row)
	ld	iy, #1
	add	iy, sp
	ld	a, 0 (iy)
	sub	a, e
	jr	nc, 00140$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:454: last_active_row = sprite_last_row;
	ld	0 (iy), e
00140$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:424: ++sprite_index)
	inc	-1 (ix)
	jp	00202$
00143$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:461: && tile_column <= HUD_WEAPON_LAST_TILE_COLUMN)
	ld	a, -17 (ix)
	ld	-1 (ix), a
	bit	0, -17 (ix)
	jr	nz, 00150$
	bit	0, -16 (ix)
	jr	nz, 00150$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:463: if (!has_active_wall)
	ld	a, -15 (ix)
	or	a, a
	jr	nz, 00147$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:464: first_active_row = HUD_WEAPON_FIRST_TILE_ROW;
	ld	iy, #0
	add	iy, sp
	ld	0 (iy), #0x04
	jr	00148$
00147$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:465: else if (first_active_row > HUD_WEAPON_FIRST_TILE_ROW)
	ld	a, #0x04
	ld	iy, #0
	add	iy, sp
	sub	a, 0 (iy)
	jr	nc, 00148$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:466: first_active_row = HUD_WEAPON_FIRST_TILE_ROW;
	ld	0 (iy), #0x04
00148$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:467: last_active_row = HUD_WEAPON_LAST_TILE_ROW;
	ld	iy, #1
	add	iy, sp
	ld	0 (iy), #0x07
;D:/mano_projektai/GearRay/platform/game_gear/video.c:468: has_active_wall = 1;
	ld	-15 (ix), #0x01
00150$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:549: SMS_loadTiles(
	ld	l, -8 (ix)
	ld	h, #0x00
	add	hl, hl
	add	hl, hl
	add	hl, hl
	ld	a, l
	add	a, #0x66
	ld	-11 (ix), a
	ld	a, h
	adc	a, #0x00
	ld	-10 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:471: if (has_active_wall)
	ld	a, -15 (ix)
	or	a, a
	jp	z, 00334$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:488: SMS_MAPPER_SLOT2_REGISTER=3;
	ld	hl, #0xffff
	ld	(hl), #0x03
;D:/mano_projektai/GearRay/platform/game_gear/video.c:489: wall_plan_prepare(left_ray,&left_wall_plan,tile_column);
	ld	a, -8 (ix)
	push	af
	inc	sp
	ld	de, #_left_wall_plan
	ld	l, -7 (ix)
	ld	h, -6 (ix)
	call	_wall_plan_prepare
;D:/mano_projektai/GearRay/platform/game_gear/video.c:490: wall_plan_prepare(right_ray,&right_wall_plan,tile_column);
	ld	a, -8 (ix)
	push	af
	inc	sp
	ld	de, #_right_wall_plan
	ld	l, -29 (ix)
	ld	h, -28 (ix)
	call	_wall_plan_prepare
;D:/mano_projektai/GearRay/platform/game_gear/video.c:491: SMS_MAPPER_SLOT2_REGISTER=2;
	ld	hl, #0xffff
	ld	(hl), #0x02
;D:/mano_projektai/GearRay/platform/game_gear/video.c:493: for (row = first_active_row;
	ld	hl, #0
	add	hl, sp
	ld	e, (hl)
	ld	d, -16 (ix)
00206$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:497: unsigned char *native_tile =
	ld	iy, #0
	add	iy, sp
	ld	c, 0 (iy)
	ld	b, #0x00
;D:/mano_projektai/GearRay/platform/game_gear/video.c:494: row <= last_active_row;
	ld	a, 1 (iy)
	sub	a, e
	jp	c, 00170$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:497: unsigned char *native_tile =
	ld	l, e
	ld	h, #0x00
	cp	a, a
	sbc	hl, bc
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	ld	bc, #_projected_wall_column
	add	hl, bc
	ld	c, l
	ld	b, h
;D:/mano_projektai/GearRay/platform/game_gear/video.c:500: game_gear_build_native_wall_tile(native_tile,row*8);
	ld	a, e
	add	a, a
	add	a, a
	add	a, a
	push	bc
	push	de
	push	af
	inc	sp
	ld	l, c
	ld	h, b
	call	_game_gear_build_native_wall_tile
	pop	de
	pop	bc
;D:/mano_projektai/GearRay/platform/game_gear/video.c:508: for (ordered_sprite_index = 0;
	ld	-12 (ix), #0x00
00204$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:509: ordered_sprite_index < ordered_sprite_count;
	ld	a, -12 (ix)
	ld	hl, #2
	add	hl, sp
	sub	a, (hl)
	jr	nc, 00165$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:512: unsigned char selected =
	push	de
	ld	e, -12 (ix)
	ld	d, #0x00
	ld	hl, #5
	add	hl, sp
	add	hl, de
;D:/mano_projektai/GearRay/platform/game_gear/video.c:517: &projected_sprites[selected],
	ld	e, (hl)
	ld	d, #0x00
	ld	l, e
	ld	h, d
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, de
	pop	de
	ld	-14 (ix), l
	ld	-13 (ix), h
	push	de
	ld	e, -14 (ix)
	ld	d, -13 (ix)
	ld	hl, #14
	add	hl, sp
	add	hl, de
	pop	de
	push	hl
	push	bc
	push	de
	ld	d, e
	ld	e, -8 (ix)
	push	de
	call	_game_gear_sprite_covers_tile
	pop	de
	pop	bc
	pop	hl
	or	a, a
	jr	z, 00164$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:524: native_tile,
	push	bc
	push	de
	push	hl
	ld	l, -34 (ix)
	ld	h, -33 (ix)
	ex	(sp), hl
	push	hl
	ld	h, e
	ld	l, -8 (ix)
	push	hl
	ld	l, c
	ld	h, b
	call	_game_gear_overlay_sprite_tile
	pop	de
	pop	bc
00164$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:510: ++ordered_sprite_index)
	inc	-12 (ix)
	jr	00204$
00165$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:532: && tile_column <= HUD_WEAPON_LAST_TILE_COLUMN
	bit	0, -1 (ix)
	jr	nz, 00207$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:533: && row >= HUD_WEAPON_FIRST_TILE_ROW)
	bit	0, d
	jr	nz, 00207$
	ld	a, e
	sub	a, #0x04
	jr	c, 00207$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:535: game_gear_overlay_hud_weapon_tile(native_tile,
	push	de
	ld	h, e
	ld	l, -8 (ix)
	push	hl
	ld	l, c
	ld	h, b
	call	_game_gear_overlay_hud_weapon_tile
	pop	de
00207$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:495: ++row)
	inc	e
	jp	00206$
00170$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:541: active_tile_count = last_active_row - first_active_row + 1;
	ld	hl, #0
	add	hl, sp
	ld	iy, #1
	add	iy, sp
	ld	a, 0 (iy)
	sub	a, (hl)
	ld	e, a
	inc	e
;D:/mano_projektai/GearRay/platform/game_gear/video.c:549: SMS_loadTiles(
	ld	d, #0x00
	ex	de, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	ex	de, hl
	ld	l, -11 (ix)
	ld	h, -10 (ix)
	add	hl, bc
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	push	de
	ld	de, #_projected_wall_column
	call	_SMS_VRAMmemcpy
;D:/mano_projektai/GearRay/platform/game_gear/video.c:557: for (row = 0; row < GAME_GEAR_VIEWPORT_TILE_ROWS; ++row)
00334$:
	ld	-1 (ix), #0x00
00208$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:560: ? VIEWPORT_TILE_STATE_CEILING
	ld	a, -1 (ix)
	sub	a, #0x04
	ld	a, #0x00
	rla
	ld	-12 (ix), a
	or	a, a
	jr	z, 00219$
	xor	a, a
	jr	00220$
00219$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:561: : VIEWPORT_TILE_STATE_FLOOR;
	ld	a, #0x01
00220$:
	ld	-14 (ix), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:563: if (has_active_wall &&
	ld	a, -15 (ix)
	or	a, a
	jr	z, 00174$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:564: row >= first_active_row &&
	ld	a, -1 (ix)
	ld	iy, #0
	add	iy, sp
	sub	a, 0 (iy)
	jr	c, 00174$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:565: row <= last_active_row)
	ld	a, 1 (iy)
	sub	a, -1 (ix)
	jr	c, 00174$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:567: desired_state = VIEWPORT_TILE_STATE_WALL;
	ld	-14 (ix), #0x02
00174$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:570: if (tile_states[row] == desired_state)
	ld	e, -1 (ix)
	ld	d, #0x00
	ld	l, -3 (ix)
	ld	h, -2 (ix)
	add	hl, de
	ld	-17 (ix), l
	ld	-16 (ix), h
	ld	a, (hl)
	sub	a, -14 (ix)
	jr	z, 00185$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:573: if (desired_state == VIEWPORT_TILE_STATE_WALL)
	ld	a, -14 (ix)
	sub	a, #0x02
	jr	nz, 00180$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:577: + row;
	ld	a, -1 (ix)
	ld	c, #0x00
	add	a, -11 (ix)
	ld	e, a
	ld	a, c
	adc	a, -10 (ix)
	ld	d, a
	jr	00182$
00180$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:581: ? CEILING_TILE_INDEX
	ld	a, -12 (ix)
	or	a, a
	jr	z, 00221$
	ld	-13 (ix), #0x64
	ld	-12 (ix), #0
	jr	00222$
00221$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:582: : FLOOR_TILE_INDEX;
	ld	-13 (ix), #0x65
	ld	-12 (ix), #0
00222$:
	ld	e, -13 (ix)
	ld	d, #0x00
;D:/mano_projektai/GearRay/platform/game_gear/video.c:584: SMS_setTileatXY(
00182$:
	ld	a, -1 (ix)
	add	a, #0x08
	ld	h, #0x00
	ld	l, a
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	ld	a, -8 (ix)
	add	a, #0x09
	ld	b, #0x00
	ld	c, a
	add	hl, bc
	add	hl, hl
	ld	a, h
	or	a, #0x78
	ld	h, a
	rst	#0x08
	ex	de, hl
	rst	#0x18
;D:/mano_projektai/GearRay/platform/game_gear/video.c:591: tile_states[row] = desired_state;
	ld	l, -17 (ix)
	ld	h, -16 (ix)
	ld	a, -14 (ix)
	ld	(hl), a
00185$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:557: for (row = 0; row < GAME_GEAR_VIEWPORT_TILE_ROWS; ++row)
	inc	-1 (ix)
	ld	a, -1 (ix)
	sub	a, #0x08
	jp	c, 00208$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:600: right_ray->texture_id,
	ld	l, -21 (ix)
	ld	h, -20 (ix)
	ld	a, (hl)
;D:/mano_projektai/GearRay/platform/game_gear/video.c:599: left_ray->texture_id,
	ld	l, -19 (ix)
	ld	h, -18 (ix)
	ld	b, (hl)
;D:/mano_projektai/GearRay/platform/game_gear/video.c:594: game_gear_store_wall_column_signature(previous_wall_column,
	ld	h, -22 (ix)
	push	hl
	inc	sp
	ld	h, -23 (ix)
	push	hl
	inc	sp
	push	af
	inc	sp
	push	bc
	inc	sp
	ld	h, -24 (ix)
	ld	l, -25 (ix)
	push	hl
	ld	h, -26 (ix)
	ld	l, -27 (ix)
	push	hl
	ld	l, -5 (ix)
	ld	h, -4 (ix)
	call	_game_gear_store_wall_column_signature
00187$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:347: ++tile_column,
	inc	-8 (ix)
;D:/mano_projektai/GearRay/platform/game_gear/video.c:348: left_ray += 2,
	ld	de, #0x000c
	ld	l, -7 (ix)
	ld	h, -6 (ix)
	add	hl, de
	ld	-7 (ix), l
	ld	-6 (ix), h
;D:/mano_projektai/GearRay/platform/game_gear/video.c:349: ++previous_wall_column,
	ld	de, #0x0007
	ld	l, -5 (ix)
	ld	h, -4 (ix)
	add	hl, de
	ld	-5 (ix), l
	ld	-4 (ix), h
;D:/mano_projektai/GearRay/platform/game_gear/video.c:350: tile_states += GAME_GEAR_VIEWPORT_TILE_ROWS)
	ld	de, #0x0008
	ld	l, -3 (ix)
	ld	h, -2 (ix)
	add	hl, de
	ld	-3 (ix), l
	ld	-2 (ix), h
;D:/mano_projektai/GearRay/platform/game_gear/video.c:346: tile_column < GAME_GEAR_VIEWPORT_TILE_COLUMNS;
	ld	a, -8 (ix)
	sub	a, #0x0e
	jp	c, 00209$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:605: previous_projected_sprite_count = projected_sprite_count;
	ld	a, -9 (ix)
	ld	(#_previous_projected_sprite_count), a
;D:/mano_projektai/GearRay/platform/game_gear/video.c:606: for (sprite_index = 0;
	ld	b, #0x00
00211$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:607: sprite_index < projected_sprite_count;
	ld	a, b
	sub	a, -9 (ix)
	jr	nc, 00189$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:611: projected_sprites[sprite_index];
	ld	e, b
	ld	d, #0x00
	ld	l, e
	ld	h, d
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, de
	ex	de, hl
	ld	hl, #12
	add	hl, sp
	add	hl, de
;D:/mano_projektai/GearRay/platform/game_gear/video.c:610: previous_projected_sprites[sprite_index] =
	ld	a, #<(_previous_projected_sprites)
	add	a, e
	ld	c, a
	ld	a, #>(_previous_projected_sprites)
	adc	a, d
	push	bc
	ld	de, #0x0011
	ex	de, hl
	push	hl
	ld	l, c
	ld	h, a
	call	___memcpy
	pop	bc
;D:/mano_projektai/GearRay/platform/game_gear/video.c:608: ++sprite_index)
	inc	b
	jr	00211$
00189$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:613: game_gear_hud_weapon_render_complete();
	call	_game_gear_hud_weapon_render_complete
;D:/mano_projektai/GearRay/platform/game_gear/video.c:615: if (near_bank_mapped)
	ld	a, -36 (ix)
	or	a, a
	jr	z, 00213$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:616: SMS_MAPPER_SLOT2_REGISTER = previous_slot2_page;
	ld	hl, #0xffff
	ld	a, -35 (ix)
	ld	(hl), a
00213$:
;D:/mano_projektai/GearRay/platform/game_gear/video.c:618: }
	ld	sp, ix
	pop	ix
	ret
;D:/mano_projektai/GearRay/platform/game_gear/video.c:621: void game_gear_video_draw_viewport_border(void)
;	---------------------------------
; Function game_gear_video_draw_viewport_border
; ---------------------------------
_game_gear_video_draw_viewport_border::
;D:/mano_projektai/GearRay/platform/game_gear/video.c:625: SMS_load1bppTiles(debug_border_tiles,
	ld	hl, #0xc00
	push	hl
	ld	hl, #0x0018
	push	hl
	ld	de, #0x0061
	ld	hl, #_debug_border_tiles
	call	_SMS_load1bppTiles
;D:/mano_projektai/GearRay/platform/game_gear/video.c:631: SMS_setTileatXY(GAME_GEAR_VIEWPORT_BORDER_TILE_LEFT,
	ld	hl, #0x79d0
	rst	#0x08
	ld	hl, #0x0063
	rst	#0x18
;D:/mano_projektai/GearRay/platform/game_gear/video.c:634: SMS_setTileatXY(GAME_GEAR_VIEWPORT_BORDER_TILE_RIGHT,
	ld	hl, #0x79ee
	rst	#0x08
	ld	hl, #0x0263
	rst	#0x18
;D:/mano_projektai/GearRay/platform/game_gear/video.c:637: SMS_setTileatXY(GAME_GEAR_VIEWPORT_BORDER_TILE_LEFT,
	ld	hl, #0x7c10
	rst	#0x08
	ld	hl, #0x0463
	rst	#0x18
;D:/mano_projektai/GearRay/platform/game_gear/video.c:640: SMS_setTileatXY(GAME_GEAR_VIEWPORT_BORDER_TILE_RIGHT,
	ld	hl, #0x7c2e
	rst	#0x08
	ld	hl, #0x0663
	rst	#0x18
;D:/mano_projektai/GearRay/platform/game_gear/video.c:649: SMS_setTileatXY(GAME_GEAR_VIEWPORT_TILE_ORIGIN_X + tile_offset,
	ld	b, #0x00
00113$:
	ld	a, b
	add	a, #0x09
	ld	e, a
	ld	d, #0x00
	ld	hl, #0x00e0
	add	hl, de
	add	hl, hl
	ld	a, h
	or	a, #0x78
	ld	h, a
	rst	#0x08
	ld	hl, #0x0061
	rst	#0x18
;D:/mano_projektai/GearRay/platform/game_gear/video.c:652: SMS_setTileatXY(GAME_GEAR_VIEWPORT_TILE_ORIGIN_X + tile_offset,
	ld	hl, #0x0200
	add	hl, de
	add	hl, hl
	ld	a, h
	or	a, #0x78
	ld	h, a
	rst	#0x08
	ld	hl, #0x0461
	rst	#0x18
;D:/mano_projektai/GearRay/platform/game_gear/video.c:647: ++tile_offset)
	inc	b
;D:/mano_projektai/GearRay/platform/game_gear/video.c:646: tile_offset < GAME_GEAR_VIEWPORT_TILE_COLUMNS;
	ld	a, b
	sub	a, #0x0e
	jr	c, 00113$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:661: SMS_setTileatXY(GAME_GEAR_VIEWPORT_BORDER_TILE_LEFT,
	ld	b, #0x00
00120$:
	ld	a, b
	add	a, #0x08
	ld	h, #0x00
	ld	l, a
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	ex	de, hl
	ld	hl, #0x0008
	add	hl, de
	add	hl, hl
	ld	a, h
	or	a, #0x78
	ld	h, a
	rst	#0x08
	ld	hl, #0x0062
	rst	#0x18
;D:/mano_projektai/GearRay/platform/game_gear/video.c:664: SMS_setTileatXY(GAME_GEAR_VIEWPORT_BORDER_TILE_RIGHT,
	ld	hl, #0x0017
	add	hl, de
	add	hl, hl
	ld	a, h
	or	a, #0x78
	ld	h, a
	rst	#0x08
	ld	hl, #0x0262
	rst	#0x18
;D:/mano_projektai/GearRay/platform/game_gear/video.c:659: ++tile_offset)
	inc	b
;D:/mano_projektai/GearRay/platform/game_gear/video.c:658: tile_offset < GAME_GEAR_VIEWPORT_TILE_ROWS;
	ld	a, b
	sub	a, #0x08
	jr	c, 00120$
;D:/mano_projektai/GearRay/platform/game_gear/video.c:669: }
	ret
	.area _CODE
	.area _BANK1
	.area _INITIALIZER
	.area _CABS (ABS)
